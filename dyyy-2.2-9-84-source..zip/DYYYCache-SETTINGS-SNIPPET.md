//  DYYYCache-SETTINGS-SNIPPET.md
//
//  给父 agent 的接入说明（本文件只是说明，不参与编译）。

## 接入（宿主侧，2 行）

```objc
#import "DYYYCacheCleaner.h"
#import "DYYYCacheSettingsViewController.h"

// 启动时调一次（主线程；幂等；未开任何开关时不产生清理动作）：
DYYYInstallCacheCleanerHooks();

// 设置页“缓存管理”入口推本页（无需参数）：
DYYYCacheSettingsViewController *cacheVC = [[DYYYCacheSettingsViewController alloc] init];
[navigationController pushViewController:cacheVC animated:YES];
```

## 不需要做的事

- 不需要在 AwemeHeaders.h 里加任何声明：本功能没有 hook 任何抖音类，
  只订阅 UIApplication 前后台通知 + 自家两个自定义通知。
- 不需要改 Makefile 以外的位置：新文件只有 DYYYCacheCleaner.h/.m、
  DYYYCachePolicy.h、DYYYCacheSettingsViewController.h/.m，
  需把这 3 个 .m 加进编译源文件列表。
- 不需要 __attribute__((constructor))：安装函数由宿主显式调用。
  DYYYCacheStatistics / DYYYCleanHostCache 被调用时也会按需自安装一次。

## 设置键（NSUserDefaults standardUserDefaults；全部默认关闭）

| 键 | 类型 | 缺省 | 说明 |
| --- | --- | --- | --- |
| DYYYCacheEnabled | BOOL | NO | 按规则自动清理（只管容量/时间规则） |
| DYYYCacheCleanOnLaunch | BOOL | NO | 启动抖音时清理（独立，与 Enabled 无关） |
| DYYYCacheCleanOnReturn | BOOL | NO | 从后台返回时清理（独立，与 Enabled 无关） |
| DYYYCacheMaxMB | double | 1024（1.00 GB） | 可管理缓存上限，MB；0 = 不限制 |
| DYYYCacheMaxAgeHours | double | 0（从不） | 超过多久清理，小时；0 = 不按时间清理 |
| DYYYCacheLastCleanup | NSDictionary | 无 | 最近清理记录：date / deletedBytes / deletedCount / partial / cancelled / skipped |

## 通知（自家自定义，未订阅 NSUserDefaultsDidChangeNotification）

- DYYYCacheStatisticsChangedNotification（@"DYYYCacheStatisticsChanged"）：用量/清理进度变化，userInfo 即统计字典。
- DYYYCachePreferencesChangedNotification（@"DYYYCachePreferencesChanged"）：DYYYCacheSetValue 改写某个 DYYYCache* 键时发出，userInfo = @{@"key": key}。清理器只订阅这个。
