// DYYYLiveInfoCapsuleEditorViewController.m — “卡片胶囊样式”编辑子页（2.2-9-68）。
// 对齐 / 上下顺序 / 大小三项 + 实时预览，点右上角“保存”后才写入三键，
// 直接返回则不保存。预览胶囊的尺寸与真实胶囊一致（字号 11/12/14、高 24/28/32）。
#import "DYYYLiveInfoCapsuleEditorViewController.h"
#import "DYYYLiveInfoSettingsViewController.h"
#import "AwemeHeaders.h"
#import "DYYYSettingsHelper.h"
#import "DYYYUtils.h"

@interface DYYYLiveInfoCapsuleEditorViewController ()
@property(nonatomic, strong) UIStackView *previewStack;
@property(nonatomic, copy) NSString *stagedAlign;
@property(nonatomic, copy) NSString *stagedOrder;
@property(nonatomic, copy) NSString *stagedSize;
@end

@implementation DYYYLiveInfoCapsuleEditorViewController

- (instancetype)init {
    if ((self = [super initWithStyle:UITableViewStyleInsetGrouped])) {
        self.title = @"卡片胶囊样式";
    }
    return self;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    NSString *align = DYYYGetString(@"DYYYLivePreviewCapsuleAlign");
    NSString *order = DYYYGetString(@"DYYYLivePreviewCapsuleOrder");
    NSString *size = DYYYGetString(@"DYYYLivePreviewCapsuleSize");
    _stagedAlign = align.length ? align : @"居中";
    _stagedOrder = order.length ? order : @"人数在上";
    _stagedSize = size.length ? size : @"中";
    self.tableView.backgroundColor = UIColor.systemGroupedBackgroundColor;
    self.tableView.rowHeight = UITableViewAutomaticDimension;
    self.tableView.estimatedRowHeight = 72;
    self.tableView.sectionHeaderHeight = UITableViewAutomaticDimension;
    self.tableView.sectionFooterHeight = UITableViewAutomaticDimension;
    self.tableView.separatorInset = UIEdgeInsetsMake(0, 20, 0, 20);
    if (@available(iOS 15.0, *)) self.tableView.sectionHeaderTopPadding = 6;
    self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc] initWithTitle:@"保存"
                                                                              style:UIBarButtonItemStyleDone
                                                                             target:self
                                                                             action:@selector(saveAndPop)];
    self.navigationItem.rightBarButtonItem.tintColor = [DYYYLiveInfoSettingsViewController accentColor];
    [self buildPreviewHeader];
}

- (void)saveAndPop {
    [DYYYSettingsHelper setUserDefaults:self.stagedAlign forKey:@"DYYYLivePreviewCapsuleAlign"];
    [DYYYSettingsHelper setUserDefaults:self.stagedOrder forKey:@"DYYYLivePreviewCapsuleOrder"];
    [DYYYSettingsHelper setUserDefaults:self.stagedSize forKey:@"DYYYLivePreviewCapsuleSize"];
    [DYYYUtils showToast:@"已保存卡片胶囊样式"];
    [self.navigationController popViewControllerAnimated:YES];
}

#pragma mark - 预览（纯 Auto Layout，不改 frame）

- (void)buildPreviewHeader {
    UIView *container = [[UIView alloc] initWithFrame:CGRectMake(0, 0, self.tableView.bounds.size.width, 150)];
    container.autoresizingMask = UIViewAutoresizingFlexibleWidth;
    UIView *card = [UIView new];
    card.backgroundColor = [UIColor colorWithDynamicProvider:^UIColor *(UITraitCollection *trait) {
        return trait.userInterfaceStyle == UIUserInterfaceStyleDark ?
            [UIColor colorWithRed:.17 green:.17 blue:.18 alpha:1] :
            [UIColor colorWithRed:.91 green:.93 blue:.93 alpha:1];
    }];
    card.layer.cornerRadius = 16;
    card.translatesAutoresizingMaskIntoConstraints = NO;
    [container addSubview:card];
    self.previewStack = [UIStackView new];
    self.previewStack.axis = UILayoutConstraintAxisVertical;
    self.previewStack.spacing = 6;
    self.previewStack.translatesAutoresizingMaskIntoConstraints = NO;
    [card addSubview:self.previewStack];
    [NSLayoutConstraint activateConstraints:@[
        [card.leadingAnchor constraintEqualToAnchor:container.leadingAnchor constant:16],
        [card.trailingAnchor constraintEqualToAnchor:container.trailingAnchor constant:-16],
        [card.topAnchor constraintEqualToAnchor:container.topAnchor constant:12],
        [card.bottomAnchor constraintEqualToAnchor:container.bottomAnchor constant:-12],
        [self.previewStack.centerXAnchor constraintEqualToAnchor:card.centerXAnchor],
        [self.previewStack.centerYAnchor constraintEqualToAnchor:card.centerYAnchor],
    ]];
    self.tableView.tableHeaderView = container;
    [self rebuildPreview];
}

- (void)rebuildPreview {
    for (UIView *view in self.previewStack.arrangedSubviews) [view removeFromSuperview];
    if ([self.stagedAlign isEqualToString:@"左对齐"]) {
        self.previewStack.alignment = UIStackViewAlignmentLeading;
    } else if ([self.stagedAlign isEqualToString:@"右对齐"]) {
        self.previewStack.alignment = UIStackViewAlignmentTrailing;
    } else {
        self.previewStack.alignment = UIStackViewAlignmentCenter;
    }
    BOOL durationFirst = [self.stagedOrder isEqualToString:@"时长在上"];
    UIView *viewersPill = [self pillWithSymbol:@"person.2.fill" text:@"1.2万"];
    UIView *durationPill = [self pillWithSymbol:@"clock" text:@"00:12:34"];
    if (durationFirst) {
        [self.previewStack addArrangedSubview:durationPill];
        [self.previewStack addArrangedSubview:viewersPill];
    } else {
        [self.previewStack addArrangedSubview:viewersPill];
        [self.previewStack addArrangedSubview:durationPill];
    }
}

// 胶囊尺寸与 DYYYLivePreviewCapsule 一致：字号 11/12/14、高 24/28/32、内边距 30/34/38。
- (UIView *)pillWithSymbol:(NSString *)symbol text:(NSString *)text {
    BOOL small = [self.stagedSize isEqualToString:@"小"];
    BOOL large = [self.stagedSize isEqualToString:@"大"];
    CGFloat fontSize = small ? 11 : (large ? 14 : 12);
    CGFloat iconSize = small ? 10 : (large ? 13 : 11);
    CGFloat height = small ? 24 : (large ? 32 : 28);
    CGFloat padding = small ? 30 : (large ? 38 : 34);
    UIView *pill = [UIView new];
    pill.backgroundColor = [UIColor.blackColor colorWithAlphaComponent:.64];
    pill.layer.cornerRadius = height / 2;
    pill.layer.cornerCurve = kCACornerCurveContinuous;
    pill.translatesAutoresizingMaskIntoConstraints = NO;
    UILabel *label = [UILabel new];
    label.text = text;
    label.textColor = UIColor.whiteColor;
    label.font = [UIFont monospacedDigitSystemFontOfSize:fontSize weight:UIFontWeightSemibold];
    label.textAlignment = NSTextAlignmentCenter;
    UIImageView *icon = [[UIImageView alloc] initWithImage:[UIImage systemImageNamed:symbol
        withConfiguration:[UIImageSymbolConfiguration configurationWithPointSize:iconSize weight:UIImageSymbolWeightSemibold]]];
    icon.tintColor = UIColor.whiteColor;
    icon.contentMode = UIViewContentModeScaleAspectFit;
    UIStackView *stack = [[UIStackView alloc] initWithArrangedSubviews:@[icon, label]];
    stack.axis = UILayoutConstraintAxisHorizontal;
    stack.spacing = 4;
    stack.alignment = UIStackViewAlignmentCenter;
    stack.translatesAutoresizingMaskIntoConstraints = NO;
    [pill addSubview:stack];
    CGSize labelSize = [label sizeThatFits:CGSizeMake(260, 20)];
    CGFloat width = MIN(294, MAX(18, ceil(labelSize.width)) + padding);
    [NSLayoutConstraint activateConstraints:@[
        [stack.leadingAnchor constraintEqualToAnchor:pill.leadingAnchor constant:8],
        [stack.trailingAnchor constraintEqualToAnchor:pill.trailingAnchor constant:-10],
        [stack.centerYAnchor constraintEqualToAnchor:pill.centerYAnchor],
        [pill.heightAnchor constraintEqualToConstant:height],
        [pill.widthAnchor constraintEqualToConstant:width],
        [icon.widthAnchor constraintEqualToConstant:iconSize],
        [icon.heightAnchor constraintEqualToConstant:iconSize],
    ]];
    return pill;
}

#pragma mark - 表格

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return 3;
}

- (NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section {
    return @"样式";
}

- (NSString *)tableView:(UITableView *)tableView titleForFooterInSection:(NSInteger)section {
    return @"对齐、上下顺序、大小实时预览，点右上角“保存”后生效；直接返回则不保存。";
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)path {
    NSArray *titles = @[@"对齐", @"上下顺序", @"大小"];
    NSArray *values = @[self.stagedAlign, self.stagedOrder, self.stagedSize];
    NSArray *icons = @[@"slider.horizontal.3", @"arrow.up.arrow.down", @"textformat"];
    UITableViewCell *cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleValue1 reuseIdentifier:nil];
    cell.backgroundColor = [UIColor colorWithDynamicProvider:^UIColor *(UITraitCollection *trait) {
        return trait.userInterfaceStyle == UIUserInterfaceStyleDark ?
            [UIColor colorWithRed:.105 green:.119 blue:.13 alpha:1] : UIColor.whiteColor;
    }];
    UIListContentConfiguration *config = [UIListContentConfiguration valueCellConfiguration];
    config.text = titles[path.row];
    config.secondaryText = values[path.row];
    config.textProperties.font = [UIFont preferredFontForTextStyle:UIFontTextStyleBody];
    config.textProperties.color = UIColor.labelColor;
    config.secondaryTextProperties.color = UIColor.secondaryLabelColor;
    config.image = [UIImage systemImageNamed:icons[path.row]];
    config.imageProperties.tintColor = [DYYYLiveInfoSettingsViewController accentColor];
    config.imageProperties.maximumSize = CGSizeMake(28, 28);
    config.imageProperties.reservedLayoutSize = CGSizeMake(28, 28);
    config.imageToTextPadding = 14;
    config.directionalLayoutMargins = NSDirectionalEdgeInsetsMake(14, 20, 14, 20);
    cell.contentConfiguration = config;
    cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)path {
    [tableView deselectRowAtIndexPath:path animated:YES];
    NSArray *titles = @[@"对齐", @"上下顺序", @"大小"];
    NSArray *options = @[
        @[@"左对齐", @"居中", @"右对齐"],
        @[@"人数在上", @"时长在上"],
        @[@"小", @"中", @"大"],
    ];
    NSArray *current = @[self.stagedAlign, self.stagedOrder, self.stagedSize];
    UIAlertController *sheet = [UIAlertController alertControllerWithTitle:titles[path.row] message:nil preferredStyle:UIAlertControllerStyleActionSheet];
    sheet.view.tintColor = [DYYYLiveInfoSettingsViewController accentColor];
    for (NSString *option in options[path.row]) {
        NSString *title = [option isEqualToString:current[path.row]] ? [option stringByAppendingString:@"  ✓"] : option;
        __weak typeof(self) weakSelf = self;
        [sheet addAction:[UIAlertAction actionWithTitle:title style:UIAlertActionStyleDefault handler:^(__unused UIAlertAction *action) {
            DYYYLiveInfoCapsuleEditorViewController *self = weakSelf;
            if (!self) return;
            if (path.row == 0) self.stagedAlign = option;
            else if (path.row == 1) self.stagedOrder = option;
            else self.stagedSize = option;
            [self rebuildPreview];
            [self.tableView reloadData];
        }]];
    }
    [sheet addAction:[UIAlertAction actionWithTitle:@"取消" style:UIAlertActionStyleCancel handler:nil]];
    UITableViewCell *cell = [tableView cellForRowAtIndexPath:path];
    sheet.popoverPresentationController.sourceView = cell;
    sheet.popoverPresentationController.sourceRect = cell.bounds;
    [self presentViewController:sheet animated:YES completion:nil];
}

@end
