#ifndef DYYYConstants_h
#define DYYYConstants_h

#define DYYY_NAME @"DYYY"
#define DYYY_SETTINGS_NAME @"DYYY设置"

#define DYYY_VERSION @"2.2-9"

#define DYYYGeonamesErrorDomain @"com.dyyy.geonames.api.error"
#define DYYYGeonamesStatusUserInfoKey @"com.dyyy.geonames.api.status"

#endif
