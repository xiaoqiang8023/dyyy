//  DYYYCacheCleaner.h
//
//  缓存管理（Cache Cleaner，DY778 1.0-3 移植）。
//  只删除白名单内的缓存目录，插件配置一律保留；全部文件操作都在后台队列。
//  本文件不 hook 任何抖音类，不需要往 AwemeHeaders.h 里加声明。
//  安装入口由宿主在主线程调用一次：DYYYInstallCacheCleanerHooks()。

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

// ---- 设置键（全部默认关闭；缺省键按 NO / 默认值处理）----
// DYYYCacheEnabled      按规则自动清理：总开关，只管容量/时间规则，不管启动/返回清理
// DYYYCacheCleanOnLaunch 启动抖音时清理（与 DYYYCacheEnabled 无关，独立生效）
// DYYYCacheCleanOnReturn 从后台返回时清理（与 DYYYCacheEnabled 无关，独立生效）
// DYYYCacheMaxMB        可管理缓存上限，单位 MB；0 = 不限制；缺省 1024（1.00 GB）
// DYYYCacheMaxAgeHours  超过多久清理，单位小时；0 = 从不按时间清理；缺省 0
// DYYYCacheLastCleanup  最近一次清理记录（字典：date / deletedBytes / deletedCount / partial / cancelled / skipped）
#define DYYYCacheEnabledKey      @"DYYYCacheEnabled"
#define DYYYCacheOnLaunchKey     @"DYYYCacheCleanOnLaunch"
#define DYYYCacheOnReturnKey     @"DYYYCacheCleanOnReturn"
#define DYYYCacheMaxMBKey        @"DYYYCacheMaxMB"
#define DYYYCacheMaxAgeHoursKey  @"DYYYCacheMaxAgeHours"
#define DYYYCacheLastCleanupKey  @"DYYYCacheLastCleanup"

// 缓存上限缺省值：1.00 GB（1024 MB）。显式写 0 表示不限制。
#define DYYYCacheDefaultMaxMB 1024.0

// ---- 通知（只用自家自定义通知，绝不订阅 NSUserDefaultsDidChangeNotification）----
// 缓存用量/清理进度变化时发出，userInfo 即统计字典。
FOUNDATION_EXPORT NSNotificationName const DYYYCacheStatisticsChangedNotification;
// 某个 DYYYCache* 设置被 DYYYCacheSetValue 改写时发出，userInfo = @{@"key": key}。
// 清理器只订阅这一个通知来重读开关；设置页翻开关时调 DYYYCacheSetValue 即可同步。
FOUNDATION_EXPORT NSNotificationName const DYYYCachePreferencesChangedNotification;

// ---- 设置读写（NSUserDefaults standardUserDefaults；缺省键 = 默认值）----
FOUNDATION_EXPORT NSUserDefaults *DYYYCachePreferences(void);
FOUNDATION_EXPORT BOOL DYYYCacheBoolForKey(NSString *key);
FOUNDATION_EXPORT double DYYYCacheNumberForKey(NSString *key);
// 写设置并发出 DYYYCachePreferencesChangedNotification（数值键自动钳制到合法范围）。
FOUNDATION_EXPORT void DYYYCacheSetValue(NSString *key, id _Nullable value);
// 注册缺省值（不覆盖已有值）。DYYYInstallCacheCleanerHooks 内部会调一次。
FOUNDATION_EXPORT void DYYYCacheRegisterDefaults(void);

// ---- 安装与清理 ----
// 安装缓存清理器：幂等（dispatch_once），便宜；未开任何开关时不产生清理动作。
// 只订阅自家通知 + UIApplication 前后台通知，不 hook 抖音类。
// 注意：不含 __attribute__((constructor))，由宿主在主线程调用。
FOUNDATION_EXPORT void DYYYInstallCacheCleanerHooks(void);
// 按容量/时间规则跑一次维护（仅 DYYYCacheEnabled=YES 且设了上限或时间时生效）。
FOUNDATION_EXPORT void DYYYRunCacheMaintenance(void);
// 当前已缓存的统计（仅主线程可取），nil 表示尚未统计过。
FOUNDATION_EXPORT NSDictionary * _Nullable DYYYCachedCacheStatistics(void);
// 异步统计用量（30 秒内直接返回缓存结果，不重复扫描）。
FOUNDATION_EXPORT void DYYYCacheStatistics(void (^completion)(NSDictionary *statistics));
// 强制重新统计用量。
FOUNDATION_EXPORT void DYYYRefreshCacheStatistics(void (^completion)(NSDictionary *statistics));
// 手动清理全部缓存（清空白名单目录，保留插件配置）。可重复调，正在跑时合并。
FOUNDATION_EXPORT void DYYYCleanHostCache(void (^completion)(NSDictionary *statistics));
// 停止正在进行的手动清理（已删的不回退）。
FOUNDATION_EXPORT void DYYYCancelHostCacheCleanup(void);

FOUNDATION_EXPORT NSString *DYYYCacheFormatBytes(uint64_t bytes);

NS_ASSUME_NONNULL_END
