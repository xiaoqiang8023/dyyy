// DYYYRecallMediaView.h
// 由 DY778RecallMediaView.h 移植（DY778 → DYYY 前缀重命名）。
// 撤回记录详情里的媒体预览：图片 / 视频 / 语音 / 作品卡片。
// 媒体只在线播放（远程 URL），不预下载、不写磁盘。
#import <UIKit/UIKit.h>

@interface DYYYRecallMediaView : UIView
@property(nonatomic, copy) void (^openMedia)(NSDictionary *media);
@property(nonatomic, copy) dispatch_block_t openOriginal;
@property(nonatomic, copy) dispatch_block_t openMessage;
- (void)cancel;
- (void)configureRecord:(NSDictionary *)record;
@end

@interface DYYYRecallCoverView : UIImageView
- (void)configureRecord:(NSDictionary *)record;
- (void)cancel;
@end
