// DYYYMessageUI.h
// 由 DY778MessageUI.h 移植（DY778 → DYYY 前缀重命名；只要撤回标记，不要时间/编辑标记）。
// 在消息列表 cell 上显示“已撤回”标记：点按打开对应会话的撤回记录。
// 标记用 frame 在 cell 展示路径里一次性摆好，绝不在 layoutSubviews 里改 frame，也绝不 Hook layoutSubviews。
#import <UIKit/UIKit.h>

FOUNDATION_EXPORT void DYYYInstallMessageUIHooks(void);
FOUNDATION_EXPORT NSString *DYYYFormatMessageTime(NSTimeInterval timestamp);
FOUNDATION_EXPORT void DYYYRefreshMessageDecorations(void);
