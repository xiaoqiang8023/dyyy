// DYYYRecallSettingsViewController.h
// 消息留存设置页：独立 UITableViewController（insetGrouped，标题“消息留存”），
// 无参 [[DYYYRecallSettingsViewController alloc] init] 即可使用。
// 开关直接读写 DYYYRecall* 键，变更后投递 DYYYRecallPreferencesChangedNotification。
#import <UIKit/UIKit.h>

@interface DYYYRecallSettingsViewController : UITableViewController
@end
