#import "DYYYFansRuntime.h"
#import "DYYYFansPolicy.h"
#import "DYYYToast.h"
#import "DYYYUtils.h"
#import <string.h>
#import <objc/runtime.h>
#import <objc/message.h>
#import <CoreFoundation/CoreFoundation.h>

NSString * const DYYYFansName = @"星牌查询";
NSString * const DYYYFansVersion = @"1.0-3";

id DYYYFansRead(id object, NSString *key) {
    if (!object || object == NSNull.null) return nil;
    @try {
        id value;
        if ([object isKindOfClass:NSDictionary.class]) value = object[key];
        else if ([object respondsToSelector:NSSelectorFromString(key)]) value = [object valueForKey:key];
        return value == NSNull.null ? nil : value;
    } @catch (__unused NSException *exception) { return nil; }
}
id DYYYFansFirst(id object, NSArray<NSString *> *keys) {
    for (NSString *key in keys) { id value = DYYYFansRead(object, key); if (value) return value; }
    return nil;
}
BOOL DYYYFansSet(id object, NSString *key, id value) {
    if (!object) return NO;
    @try { [object setValue:value forKey:key]; return YES; }
    @catch (__unused NSException *exception) { return NO; }
}
BOOL DYYYFansHas(id object, NSString *selector, const char *returns, const char *arguments) {
    NSMethodSignature *signature = [object methodSignatureForSelector:NSSelectorFromString(selector)];
    if (!signature || signature.numberOfArguments != strlen(arguments) + 2 || !strchr(returns, signature.methodReturnType[0])) return NO;
    for (NSUInteger i = 0; arguments[i]; i++) if ([signature getArgumentTypeAtIndex:i + 2][0] != arguments[i]) return NO;
    return YES;
}
// 按宿主的方法签名传递对象与标量。
id DYYYFansCall(id object, NSString *selector, NSArray *arguments) {
    SEL sel = NSSelectorFromString(selector);
    if (![object respondsToSelector:sel]) return nil;
    NSMethodSignature *signature = [object methodSignatureForSelector:sel];
    if (!signature || signature.numberOfArguments != arguments.count + 2) return nil;
    @try {
        NSInvocation *call = [NSInvocation invocationWithMethodSignature:signature]; call.target = object; call.selector = sel;
        for (NSUInteger i = 0; i < arguments.count; i++) {
            id value = arguments[i] == NSNull.null ? nil : arguments[i];
            switch ([signature getArgumentTypeAtIndex:i + 2][0]) {
                case '@': case '#': { id v = value; [call setArgument:&v atIndex:i + 2]; break; }
                case 'B': case 'c': { BOOL v = [value boolValue]; [call setArgument:&v atIndex:i + 2]; break; }
                case 'q': { long long v = [value longLongValue]; [call setArgument:&v atIndex:i + 2]; break; }
                case 'Q': { unsigned long long v = [value unsignedLongLongValue]; [call setArgument:&v atIndex:i + 2]; break; }
                case 'i': { int v = [value intValue]; [call setArgument:&v atIndex:i + 2]; break; }
                case 'I': { unsigned int v = [value unsignedIntValue]; [call setArgument:&v atIndex:i + 2]; break; }
                case 'd': { double v = [value doubleValue]; [call setArgument:&v atIndex:i + 2]; break; }
                default: return nil;
            }
        }
        [call retainArguments]; [call invoke];
        switch (signature.methodReturnType[0]) {
            case '@': case '#': { __unsafe_unretained id v = nil; [call getReturnValue:&v]; return v; }
            case 'B': case 'c': { BOOL v = NO; [call getReturnValue:&v]; return @(v); }
            case 'q': { long long v = 0; [call getReturnValue:&v]; return @(v); }
            case 'Q': { unsigned long long v = 0; [call getReturnValue:&v]; return @(v); }
            case 'i': { int v = 0; [call getReturnValue:&v]; return @(v); }
            case 'I': { unsigned int v = 0; [call getReturnValue:&v]; return @(v); }
            default: return nil;
        }
    } @catch (__unused NSException *exception) { return nil; }
}
NSString *DYYYFansString(id value) {
    if ([value isKindOfClass:NSString.class]) return value;
    if ([value isKindOfClass:NSNumber.class] && CFGetTypeID((__bridge CFTypeRef)value) != CFBooleanGetTypeID()) return [value stringValue];
    return @"";
}
NSNumber *DYYYFansInteger(id value) {
    NSString *text = DYYYFansString(value); uint64_t number = 0;
    if (!DYYYFansParseUnsigned(text.UTF8String, [text lengthOfBytesUsingEncoding:NSUTF8StringEncoding], INT64_MAX, &number)) return nil;
    return @((long long)number);
}
BOOL DYYYFansUID(NSString *text) {
    return [text isKindOfClass:NSString.class] && DYYYFansASCIIUID(text.UTF8String, [text lengthOfBytesUsingEncoding:NSUTF8StringEncoding]);
}
BOOL DYYYFansSecUID(NSString *text) {
    return [text isKindOfClass:NSString.class] && DYYYFansASCIISECUid(text.UTF8String, [text lengthOfBytesUsingEncoding:NSUTF8StringEncoding]);
}
BOOL DYYYFansEnabled(NSString *key) { (void)key; return [[NSUserDefaults standardUserDefaults] boolForKey:@"DYYYFansEnabled"]; }
NSError *DYYYFansError(NSInteger code, NSString *message) {
    return [NSError errorWithDomain:@"DYYYFans" code:code userInfo:@{NSLocalizedDescriptionKey: message ?: @"暂时无法查询"}];
}
NSUserDefaults *DYYYFansPreferences(void) { return NSUserDefaults.standardUserDefaults; }

NSString *DYYYFansAccount(void) {
    // 原 DY778CurrentAccountID 的等价实现：AWEUserService sharedService 的 userID。
    Class cls = NSClassFromString(@"AWEUserService");
    SEL selector = NSSelectorFromString(@"sharedService");
    Method method = class_getClassMethod(cls, selector);
    if (!method) return @"";
    NSMethodSignature *signature = [NSMethodSignature signatureWithObjCTypes:method_getTypeEncoding(method)];
    if (signature.numberOfArguments != 2 || signature.methodReturnType[0] != '@') return @"";
    @try {
        id service = ((id (*)(id, SEL))objc_msgSend)(cls, selector);
        id userID = DYYYFansRead(service, @"userID");
        NSString *text = [userID isKindOfClass:NSString.class] ? userID : ([userID isKindOfClass:NSNumber.class] ? [userID stringValue] : nil);
        return (text.length && ![text isEqualToString:@"0"]) ? text : @"";
    } @catch (__unused NSException *exception) { return @""; }
}

static DYYYToast *DYYYFansLoadingToast;
void DYYYFansShowToast(NSString *channel, NSString *message, BOOL loading, BOOL success) {
    if (!NSThread.isMainThread) { dispatch_async(dispatch_get_main_queue(), ^{ DYYYFansShowToast(channel, message, loading, success); }); return; }
    (void)channel;
    if (loading) {
        if (!DYYYFansLoadingToast) {
            UIWindow *window = [DYYYUtils getActiveWindow];
            CGRect frame = window ? window.bounds : UIScreen.mainScreen.bounds;
            DYYYFansLoadingToast = [[DYYYToast alloc] initWithFrame:frame];
            [DYYYFansLoadingToast show];
        }
        return;
    }
    if (DYYYFansLoadingToast) { [DYYYFansLoadingToast dismiss]; DYYYFansLoadingToast = nil; }
    if (success) [DYYYToast showSuccessToastWithMessage:message];
    else [DYYYUtils showToast:message];
}
void DYYYFansDismissToast(NSString *channel) {
    (void)channel;
    if (!NSThread.isMainThread) { dispatch_async(dispatch_get_main_queue(), ^{ DYYYFansDismissToast(channel); }); return; }
    if (DYYYFansLoadingToast) { [DYYYFansLoadingToast dismiss]; DYYYFansLoadingToast = nil; }
}
void DYYYFansToast(NSString *message) { DYYYFansShowToast(@"general", message, NO, NO); }

UIViewController *DYYYFansTopController(void) { return [DYYYUtils topView]; }
UIUserInterfaceStyle DYYYFansInterfaceStyle(void) {
    UIWindow *window = [DYYYUtils getActiveWindow];
    return window.traitCollection.userInterfaceStyle == UIUserInterfaceStyleDark ? UIUserInterfaceStyleDark : UIUserInterfaceStyleLight;
}
UIColor *DYYYFansAccent(void) { return UIColor.systemTealColor; }
UIColor *DYYYFansBackground(void) {
    return [UIColor colorWithDynamicProvider:^UIColor *(UITraitCollection *trait) {
        return trait.userInterfaceStyle == UIUserInterfaceStyleDark ?
            [UIColor colorWithRed:.055 green:.064 blue:.075 alpha:1] :
            [UIColor colorWithRed:.951 green:.965 blue:.966 alpha:1];
    }];
}
void DYYYFansStyleController(UIViewController *controller) {
    controller.overrideUserInterfaceStyle = DYYYFansInterfaceStyle();
    controller.edgesForExtendedLayout = UIRectEdgeNone;
    controller.extendedLayoutIncludesOpaqueBars = NO;
    controller.navigationItem.backButtonTitle = @"返回";
    controller.view.backgroundColor = DYYYFansBackground();
    controller.view.opaque = YES; controller.view.clipsToBounds = YES;
    controller.view.tintColor = DYYYFansAccent();
    UINavigationBarAppearance *appearance = [UINavigationBarAppearance new];
    [appearance configureWithOpaqueBackground];
    appearance.backgroundColor = DYYYFansBackground();
    appearance.shadowColor = UIColor.clearColor;
    appearance.titleTextAttributes = @{NSForegroundColorAttributeName: UIColor.labelColor};
    appearance.largeTitleTextAttributes = @{NSForegroundColorAttributeName: UIColor.labelColor};
    controller.navigationItem.standardAppearance = appearance;
    controller.navigationItem.scrollEdgeAppearance = appearance;
    controller.navigationItem.compactAppearance = appearance;
    controller.navigationItem.largeTitleDisplayMode = UINavigationItemLargeTitleDisplayModeNever;
    [controller setNeedsStatusBarAppearanceUpdate];
}

// 原版 DY778NavigationController 的等价移植：-57 只用了普通 UINavigationController，
// 抖音自己的导航栏会被宿主藏掉、且根控制器本来就没有返回按钮，查询页成了死胡同。
// 本类保证导航栏常显、每页左上角都有“‹ 返回”按钮（多页则 pop，根页则 dismiss），
// 并用自己的右滑手势恢复返回（系统 interactivePopGestureRecognizer 在这里是关掉的）。
@interface DYYYFansReturnTransition : NSObject <UIViewControllerAnimatedTransitioning>
@end
@implementation DYYYFansReturnTransition
- (NSTimeInterval)transitionDuration:(id<UIViewControllerContextTransitioning>)context {
    return UIAccessibilityIsReduceMotionEnabled() ? .18 : .35;
}
- (void)animateTransition:(id<UIViewControllerContextTransitioning>)context {
    UIViewController *from = [context viewControllerForKey:UITransitionContextFromViewControllerKey];
    UIViewController *to = [context viewControllerForKey:UITransitionContextToViewControllerKey];
    UIView *container = context.containerView;
    UIView *outgoing = [context viewForKey:UITransitionContextFromViewKey] ?: from.view;
    UIView *incoming = [context viewForKey:UITransitionContextToViewKey] ?: to.view;
    CGRect destination = [context finalFrameForViewController:to];
    if (CGRectIsEmpty(destination)) destination = container.bounds;
    CGAffineTransform savedIncoming = incoming.transform, savedOutgoing = outgoing.transform;
    incoming.frame = destination;
    [container insertSubview:incoming belowSubview:outgoing];
    CGFloat width = CGRectGetWidth(container.bounds);
    incoming.transform = CGAffineTransformTranslate(savedIncoming, -width * .25, 0);
    UIView *shade = [[UIView alloc] initWithFrame:container.bounds];
    shade.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
    shade.backgroundColor = UIColor.blackColor; shade.alpha = .12;
    shade.userInteractionEnabled = NO; [container insertSubview:shade belowSubview:outgoing];
    [UIView animateWithDuration:[self transitionDuration:context] delay:0 options:UIViewAnimationOptionCurveLinear animations:^{
        incoming.transform = savedIncoming;
        outgoing.transform = CGAffineTransformTranslate(savedOutgoing, width, 0);
        shade.alpha = 0;
    } completion:^(__unused BOOL finished) {
        BOOL cancelled = context.transitionWasCancelled;
        [shade removeFromSuperview];
        incoming.transform = savedIncoming; outgoing.transform = savedOutgoing;
        [context completeTransition:!cancelled];
    }];
}
@end

@interface DYYYFansNavigationController : UINavigationController <UINavigationControllerDelegate, UIGestureRecognizerDelegate, UIViewControllerTransitioningDelegate>
@property(nonatomic) BOOL changingPage;
@property(nonatomic, strong) UIPanGestureRecognizer *rootBackGesture;
@property(nonatomic, strong) UIPercentDrivenInteractiveTransition *returnInteraction;
- (void)DYYYFansPrepareController:(UIViewController *)controller;
- (void)DYYYFansBack;
@end
@implementation DYYYFansNavigationController
- (void)viewDidLoad {
    [super viewDidLoad]; self.delegate = self;
    self.navigationBarHidden = NO; self.navigationBar.translucent = NO; self.navigationBar.tintColor = DYYYFansAccent();
    self.view.backgroundColor = DYYYFansBackground(); self.view.opaque = YES; self.view.clipsToBounds = YES;
    self.navigationBar.backgroundColor = DYYYFansBackground(); self.navigationBar.prefersLargeTitles = NO;
    self.interactivePopGestureRecognizer.enabled = NO;
    self.transitioningDelegate = self;
    self.rootBackGesture = [[UIPanGestureRecognizer alloc] initWithTarget:self action:@selector(DYYYFansRootBack:)];
    self.rootBackGesture.maximumNumberOfTouches = 1; self.rootBackGesture.delegate = self;
    [self.view addGestureRecognizer:self.rootBackGesture];
}
- (UIViewController *)childViewControllerForStatusBarStyle { return self.topViewController; }
- (void)DYYYFansPrepareController:(UIViewController *)controller {
    controller.overrideUserInterfaceStyle = DYYYFansInterfaceStyle();
    [controller loadViewIfNeeded]; DYYYFansStyleController(controller);
    UIButton *back = [UIButton buttonWithType:UIButtonTypeSystem];
    [back setTitle:@"返回" forState:UIControlStateNormal];
    [back setImage:[UIImage systemImageNamed:@"chevron.backward" withConfiguration:[UIImageSymbolConfiguration configurationWithPointSize:17 weight:UIFontWeightSemibold]] forState:UIControlStateNormal];
    back.titleLabel.font = [UIFont preferredFontForTextStyle:UIFontTextStyleBody];
    back.titleLabel.adjustsFontForContentSizeCategory = YES; back.tintColor = DYYYFansAccent();
    back.contentHorizontalAlignment = UIControlContentHorizontalAlignmentLeading;
    back.contentEdgeInsets = UIEdgeInsetsMake(0, 0, 0, 12); back.titleEdgeInsets = UIEdgeInsetsMake(0, 6, 0, -6);
    back.accessibilityLabel = @"返回上一层";
    [back addTarget:self action:@selector(DYYYFansBack) forControlEvents:UIControlEventTouchUpInside];
    CGFloat width = MAX(74, ceil([@"返回" sizeWithAttributes:@{NSFontAttributeName:back.titleLabel.font}].width) + 36);
    back.frame = CGRectMake(0, 0, width, 44);
    controller.navigationItem.hidesBackButton = YES;
    controller.navigationItem.leftBarButtonItem = [[UIBarButtonItem alloc] initWithCustomView:back];
}
- (void)DYYYFansBack {
    if (self.changingPage || self.transitionCoordinator) return;
    [self.view endEditing:YES];
    if (self.viewControllers.count > 1) [self popViewControllerAnimated:YES];
    else [self dismissViewControllerAnimated:YES completion:nil];
}
- (BOOL)gestureRecognizerShouldBegin:(UIGestureRecognizer *)gestureRecognizer {
    if (self.changingPage || self.transitionCoordinator || self.presentedViewController) return NO;
    if (gestureRecognizer == self.rootBackGesture) {
        CGPoint velocity = [self.rootBackGesture velocityInView:self.view];
        return (self.viewControllers.count > 1 || self.presentingViewController != nil) && velocity.x > 0 && fabs(velocity.x) > fabs(velocity.y);
    }
    return self.viewControllers.count > 1;
}
- (BOOL)gestureRecognizer:(UIGestureRecognizer *)gesture shouldReceiveTouch:(UITouch *)touch {
    if (gesture != self.rootBackGesture) return YES;
    for (UIView *view = touch.view; view && view != self.view; view = view.superview) {
        if ([view isKindOfClass:UIControl.class] || [view isKindOfClass:UITextView.class]) return NO;
        if ([view isKindOfClass:UIScrollView.class]) {
            UIScrollView *scroll = (UIScrollView *)view;
            if (scroll.contentSize.width > scroll.bounds.size.width - scroll.adjustedContentInset.left - scroll.adjustedContentInset.right + 1 || scroll.isZooming) return NO;
        }
    }
    return YES;
}
- (BOOL)gestureRecognizer:(UIGestureRecognizer *)gesture shouldRecognizeSimultaneouslyWithGestureRecognizer:(UIGestureRecognizer *)other {
    if (gesture != self.rootBackGesture || ![other.view isKindOfClass:UIScrollView.class]) return NO;
    UIScrollView *scroll = (UIScrollView *)other.view;
    return other == scroll.panGestureRecognizer && [scroll isDescendantOfView:self.view] &&
        scroll.contentSize.width <= scroll.bounds.size.width - scroll.adjustedContentInset.left - scroll.adjustedContentInset.right + 1;
}
- (void)DYYYFansRootBack:(UIPanGestureRecognizer *)gesture {
    CGFloat width = MAX(1, CGRectGetWidth(self.view.bounds));
    CGFloat progress = MIN(1, MAX(0, [gesture translationInView:self.view].x / width));
    if (gesture.state == UIGestureRecognizerStateBegan) {
        [self.view endEditing:YES];
        self.returnInteraction = [UIPercentDrivenInteractiveTransition new];
        self.returnInteraction.completionCurve = UIViewAnimationCurveEaseOut;
        if (self.viewControllers.count > 1) [self popViewControllerAnimated:YES];
        else [self dismissViewControllerAnimated:YES completion:nil];
    } else if (gesture.state == UIGestureRecognizerStateChanged) {
        [self.returnInteraction updateInteractiveTransition:progress];
    } else if (gesture.state == UIGestureRecognizerStateEnded || gesture.state == UIGestureRecognizerStateCancelled || gesture.state == UIGestureRecognizerStateFailed) {
        CGFloat velocity = [gesture velocityInView:self.view].x;
        CGFloat projected = progress + velocity / width * .20;
        self.returnInteraction.completionSpeed = MIN(1.4, MAX(.7, fabs(velocity) / width));
        if (gesture.state == UIGestureRecognizerStateEnded && velocity > -120 && projected > .45)
            [self.returnInteraction finishInteractiveTransition];
        else [self.returnInteraction cancelInteractiveTransition];
        self.returnInteraction = nil;
    }
}
- (id<UIViewControllerAnimatedTransitioning>)navigationController:(UINavigationController *)navigationController animationControllerForOperation:(UINavigationControllerOperation)operation fromViewController:(UIViewController *)from toViewController:(UIViewController *)to {
    return operation == UINavigationControllerOperationPop ? [DYYYFansReturnTransition new] : nil;
}
- (id<UIViewControllerInteractiveTransitioning>)navigationController:(UINavigationController *)navigationController interactionControllerForAnimationController:(id<UIViewControllerAnimatedTransitioning>)animator {
    return self.returnInteraction;
}
- (id<UIViewControllerAnimatedTransitioning>)animationControllerForDismissedController:(UIViewController *)dismissed {
    return [DYYYFansReturnTransition new];
}
- (id<UIViewControllerInteractiveTransitioning>)interactionControllerForDismissal:(id<UIViewControllerAnimatedTransitioning>)animator {
    return self.returnInteraction;
}
- (void)navigationController:(UINavigationController *)navigationController willShowViewController:(UIViewController *)controller animated:(BOOL)animated {
    self.changingPage = YES;
    [self setNavigationBarHidden:NO animated:NO]; [self DYYYFansPrepareController:controller];
}
- (void)navigationController:(UINavigationController *)navigationController didShowViewController:(UIViewController *)controller animated:(BOOL)animated {
    self.changingPage = NO;
}
@end
void DYYYFansPresentController(UIViewController *source, UIViewController *controller) {
    if (!NSThread.isMainThread) { dispatch_async(dispatch_get_main_queue(), ^{ DYYYFansPresentController(source, controller); }); return; }
    UIViewController *top = source ?: DYYYFansTopController();
    while (top.presentedViewController) top = top.presentedViewController;
    if (!top || !controller || top.isBeingDismissed || top.isBeingPresented) return;
    controller.overrideUserInterfaceStyle = DYYYFansInterfaceStyle();
    // 只有宿主已经是星牌自己的导航栈时才直接 push；个人主页走的是抖音自己的导航栈，
    // 它的导航栏会被宿主藏掉、根页也没有返回按钮，所以一律走自己的全屏导航控制器 modal，
    // 与原版 DY778PresentController 的做法一致。
    if ([top.navigationController isKindOfClass:DYYYFansNavigationController.class] && ![top isKindOfClass:UIAlertController.class]) {
        DYYYFansNavigationController *navigation = (DYYYFansNavigationController *)top.navigationController;
        if (navigation.changingPage || navigation.transitionCoordinator || navigation.topViewController != top) return;
        [top.view endEditing:YES];
        [navigation DYYYFansPrepareController:controller];
        [navigation pushViewController:controller animated:!UIAccessibilityIsReduceMotionEnabled()];
    } else {
        DYYYFansNavigationController *navigation = [[DYYYFansNavigationController alloc] initWithRootViewController:controller];
        navigation.overrideUserInterfaceStyle = DYYYFansInterfaceStyle();
        navigation.modalPresentationStyle = UIModalPresentationFullScreen;
        [navigation loadViewIfNeeded]; [navigation DYYYFansPrepareController:controller];
        [top presentViewController:navigation animated:NO completion:nil];
    }
}
