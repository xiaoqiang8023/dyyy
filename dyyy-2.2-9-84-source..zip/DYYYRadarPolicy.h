// DYYYRadarPolicy.h — 特别关注：纯 C 策略函数（间隔/退避/到期/新作品判定）。
// 由 DY778RadarPolicy.h 移植，仅重命名，无行为变化。
#ifndef DYYYRadarPolicy_h
#define DYYYRadarPolicy_h
#include <stdbool.h>
#include <stddef.h>
#ifdef __cplusplus
extern "C" {
#endif
bool DYYYRadarNoticeReady(double now, double shownAt);
double DYYYRadarInterval(double value);
double DYYYRadarRetryInterval(double interval, unsigned failures);
bool DYYYRadarDue(double now, double lastAttempt, double interval, unsigned failures);
size_t DYYYRadarNewItems(const char *const *current, size_t count,
                  const char *const *previous, size_t previousCount,
                  const char *const *seen, size_t seenCount,
                  bool baselineValid, bool previousComplete,
                  bool *selected, bool *gap);
#ifdef __cplusplus
}
#endif
#endif
