#import "DYYYFansModel.h"

typedef void (^DYYYFansWebReply)(id response, NSError *error);
BOOL DYYYFansWebConnected(void);
@interface DYYYFansWebClient : NSObject
- (void)get:(NSString *)route params:(NSDictionary *)params completion:(DYYYFansWebReply)completion;
- (void)cancel;
@end
