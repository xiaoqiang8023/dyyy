// DYYYRadarModel.h — 特别关注：通用模型/解析帮助（由 DY778Radar 1.0-3 移植，DY778→DYYY 重命名）。
#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

extern NSString *const DYYYRadarVersion;
extern NSString *const DYYYRadarName;
extern NSNotificationName const DYYYRadarStoreChanged;
extern NSNotificationName const DYYYRadarThemeChanged;

id _Nullable DYYYRadarRead(id _Nullable object, NSString *key);
id _Nullable DYYYRadarFirst(id _Nullable object, NSArray<NSString *> *keys);
NSString *DYYYRadarString(id _Nullable value);
NSNumber * _Nullable DYYYRadarCount(id _Nullable value);
BOOL DYYYRadarIdentifier(id _Nullable value);
BOOL DYYYRadarSet(id _Nullable object, NSString *key, id _Nullable value);
BOOL DYYYRadarHasMethod(id _Nullable receiver, NSString *selector, const char *returns, const char *arguments);
id _Nullable DYYYRadarCall(id _Nullable receiver, NSString *selector, NSArray *arguments);
NSDictionary * _Nullable DYYYRadarProfile(id _Nullable value);

extern NSUInteger const DYYYRadarSignatureLimit;
NSString *DYYYRadarSignatureText(id _Nullable value);
NSDictionary * _Nullable DYYYRadarVideo(id _Nullable value);
NSArray<NSDictionary *> *DYYYRadarChanges(NSDictionary *previous, NSDictionary *current);
NSDictionary *DYYYRadarCompareLikes(NSDictionary * _Nullable previous, NSArray<NSDictionary *> *videos, BOOL complete);
NSString *DYYYRadarMetricName(NSString *key);
NSString *DYYYRadarDisplayName(NSDictionary *person);
NSString *DYYYRadarPersonSearchText(NSDictionary *person);
NSString *DYYYRadarDateText(NSTimeInterval timestamp);
NSError *DYYYRadarError(NSInteger code, NSString *message);

NS_ASSUME_NONNULL_END
