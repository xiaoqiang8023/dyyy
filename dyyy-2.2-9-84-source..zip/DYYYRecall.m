// DYYYRecall.m
// 由 DY778Recall.m 移植（DY778 → DYYY 前缀重命名）。
// 消息留存（防撤回）核心：
//  - 观察 TIMXOMessage 的 content / recalled 等属性，收到对方消息时先留存一份；
//  - 对方撤回后，content / recalled 读 Hook 仍返回留存的原文（气泡照常显示原文），
//    同时把 recalled=YES 记进本地存档并弹出“已撤回”标记；
//  - 聊天信息页（···）注入“此聊天防撤回”开关与“已撤回的消息”入口；
//  - 撤回记录页按联系人 / 群聊分组展示，作品卡片可直接打开原作品。
//
// 与上游的差别（有意为之，见报告）：
//  1. 存档用 Application Support/DYYY/Recall/records.json（JSON 文件 + 内存缓存 + 串行队列），
//     不用 sqlite3——避免给 Makefile 增加链接依赖；记录量不大时完全够用。
//  2. 不装 setEditInfo Hook、不做编辑历史（那是另一个功能）；不做 VM 层二次恢复
//     （DY778RestoreRecallPresentation 未移植——模型层 content/recalled Hook 已能让气泡显示原文）。
//  3. 媒体不预下载落盘，只在线打开远程 URL。
//  4. 不订阅 NSUserDefaultsDidChangeNotification；设置变更只走自有的
//     DYYYRecallPreferencesChangedNotification / 生命周期 Hook。
#import "DYYYRecall.h"
#import "DYYYRecallPolicy.h"
#import "DYYYRecallReentry.h"
#import "DYYYRecallContent.h"
#import "DYYYRecallMediaView.h"
#import <objc/runtime.h>
#import <objc/message.h>
#import <stdatomic.h>

NSNotificationName const DYYYRecallPreferencesChangedNotification = @"DYYYRecallPreferencesChanged";
NSNotificationName const DYYYRecallChangedNotification = @"DYYYRecallChanged";
NSNotificationName const DYYYRecallDetectedNotification = @"DYYYRecallDetected";

NSString *const DYYYRecallEnabledKey = @"DYYYRecallEnabled";
NSString *const DYYYRecallShowBadgeKey = @"DYYYRecallShowBadge";
NSString *const DYYYRecallBadgeTextKey = @"DYYYRecallBadgeText";
NSString *const DYYYRecallPositionKey = @"DYYYRecallPosition";
NSString *const DYYYRecallArchiveEntryKey = @"DYYYRecallArchiveEntry";
NSString *const DYYYRecallNotificationsKey = @"DYYYRecallNotifications";
NSString *const DYYYRecallNotificationPreviewKey = @"DYYYRecallNotificationPreview";
NSString *const DYYYRecallPlainBubbleOnSkinKey = @"DYYYRecallPlainBubbleOnSkin";
NSString *const DYYYRecallTintBubbleKey = @"DYYYRecallTintBubble";
NSString *const DYYYRecallBubbleColorKey = @"DYYYRecallBubbleColor";
NSString *const DYYYRecallRetentionDaysKey = @"DYYYRecallRetentionDays";
NSString *const DYYYRecallMaxRecordsKey = @"DYYYRecallMaxRecords";
NSString *const DYYYRecallDisabledConversationsKey = @"DYYYRecallDisabledConversations";
NSString *const DYYYRecallEnableNoticeShownKey = @"DYYYRecallEnableNoticeShown";

static NSString *const DYYYRecallChatItemIdentifier = @"com.dyyy.recalled-messages";
static NSString *const DYYYRecallChatSwitchIdentifier = @"com.dyyy.recall-switch";

// 仅为编译期声明聊天设置项的构造方法（与雷达同款做法）；运行时仍先做签名校验。
@protocol DYYYRecallChatItem <NSObject>
- (instancetype)initWithIdentifier:(NSString *)identifier;
@end

#pragma mark - 设置读写

NSUserDefaults *DYYYRecallPreferences(void) {
    return NSUserDefaults.standardUserDefaults;
}

BOOL DYYYRecallBool(NSString *key) {
    return [DYYYRecallPreferences() boolForKey:key];
}

NSString *DYYYRecallString(NSString *key) {
    id value = [DYYYRecallPreferences() objectForKey:key];
    return [value isKindOfClass:NSString.class] ? value : nil;
}

NSInteger DYYYRecallInteger(NSString *key) {
    return [DYYYRecallPreferences() integerForKey:key];
}

void DYYYRecallSet(NSString *key, id value) {
    if (!key.length) return;
    if (value) [DYYYRecallPreferences() setObject:value forKey:key];
    else [DYYYRecallPreferences() removeObjectForKey:key];
    [NSNotificationCenter.defaultCenter postNotificationName:DYYYRecallPreferencesChangedNotification object:nil userInfo:@{@"key": key}];
}

NSString *DYYYRecallMarkerText(void) {
    NSString *text = DYYYRecallString(DYYYRecallBadgeTextKey);
    if (!text.length) return @"已撤回";
    return text;
}

#pragma mark - 安全 KVC / 身份

static id DYYYRead(id object, NSString *key) {
    if (!object || object == NSNull.null || !key.length) return nil;
    if ([object isKindOfClass:NSDictionary.class]) {
        id value = object[key];
        return value == NSNull.null ? nil : value;
    }
    SEL selector = NSSelectorFromString(key);
    NSString *getter = [@"is" stringByAppendingString:[key stringByReplacingCharactersInRange:NSMakeRange(0, 1)
                                                                                   withString:[[key substringToIndex:1] uppercaseString]]];
    if (![object respondsToSelector:selector] && ![object respondsToSelector:NSSelectorFromString(getter)]) return nil;
    @try {
        id result = [object valueForKey:key];
        return result == NSNull.null ? nil : result;
    } @catch (__unused NSException *exception) {
        return nil;
    }
}

static BOOL DYYYWrite(id object, NSString *key, id value) {
    if (!object || !key.length) return NO;
    @try {
        [object setValue:value forKey:key];
        return YES;
    } @catch (__unused NSException *exception) {
        return NO;
    }
}

static NSString *DYYYIdentifier(id value) {
    if ([value isKindOfClass:NSString.class]) return [value length] ? value : nil;
    if ([value isKindOfClass:NSNumber.class]) return [value stringValue];
    return nil;
}

NSString *DYYYRecallCurrentAccountID(void) {
    Class cls = NSClassFromString(@"AWEUserService");
    SEL selector = NSSelectorFromString(@"sharedService");
    Method method = class_getClassMethod(cls, selector);
    if (!method) return @"";
    NSMethodSignature *signature = [NSMethodSignature signatureWithObjCTypes:method_getTypeEncoding(method)];
    if (signature.numberOfArguments != 2 || signature.methodReturnType[0] != '@') return @"";
    @try {
        id service = ((id (*)(id, SEL))objc_msgSend)(cls, selector);
        NSString *userID = DYYYIdentifier(DYYYRead(service, @"userID"));
        return userID.length && ![userID isEqualToString:@"0"] ? userID : @"";
    } @catch (__unused NSException *exception) {
        return @"";
    }
}

static UIWindow *DYYYRecallActiveWindow(void) {
    UIWindow *candidate = nil;
    for (UIScene *scene in UIApplication.sharedApplication.connectedScenes) {
        if (![scene isKindOfClass:UIWindowScene.class]) continue;
        for (UIWindow *window in ((UIWindowScene *)scene).windows) {
            if (window.isKeyWindow) return window;
            if (!candidate) candidate = window;
        }
    }
    return candidate ?: UIApplication.sharedApplication.keyWindow;
}

static UIViewController *DYYYRecallTopController(void) {
    UIViewController *controller = DYYYRecallActiveWindow().rootViewController;
    while (controller.presentedViewController) controller = controller.presentedViewController;
    return controller;
}

// 只保留 JSON 能装的值（NSString/NSNumber/NSArray/NSDictionary/NSNull），其余丢弃。
static id DYYYRecallJSONValue(id value, NSUInteger depth) {
    if (depth > 24) return nil;
    if ([value isKindOfClass:NSString.class] || [value isKindOfClass:NSNumber.class] || value == NSNull.null) return value;
    if ([value isKindOfClass:NSArray.class]) {
        NSMutableArray *array = [NSMutableArray array];
        for (id item in (NSArray *)value) {
            id clean = DYYYRecallJSONValue(item, depth + 1);
            if (clean) [array addObject:clean];
        }
        return array;
    }
    if ([value isKindOfClass:NSDictionary.class]) {
        NSMutableDictionary *dict = [NSMutableDictionary dictionary];
        for (id key in (NSDictionary *)value) {
            if (![key isKindOfClass:NSString.class]) continue;
            id clean = DYYYRecallJSONValue(value[key], depth + 1);
            if (clean) dict[key] = clean;
        }
        return dict;
    }
    if ([value respondsToSelector:@selector(stringValue)]) return [value stringValue];
    return nil;
}

NSTimeInterval DYYYMessageTimestamp(id value) {
    if ([value respondsToSelector:@selector(doubleValue)]) {
        double seconds = [value doubleValue];
        if (seconds > 1e12) seconds /= 1000.0; // 毫秒时间戳
        if (seconds > 1e9 && seconds < 1e11) return seconds;
    }
    if ([value isKindOfClass:NSDictionary.class]) {
        for (NSString *key in @[@"timestamp", @"createTime", @"createdAt", @"created", @"messageTime", @"sendTime", @"time"]) {
            NSTimeInterval found = DYYYMessageTimestamp(value[key]);
            if (found > 0) return found;
        }
    }
    return 0;
}

#pragma mark - Hook 工具

static BOOL DYYYRecallHook(Class cls, SEL selector, IMP replacement, IMP *original) {
    if (!cls || !selector || !replacement || !original) return NO;
    Method method = class_getInstanceMethod(cls, selector);
    if (!method) return NO;
    IMP previous = method_getImplementation(method);
    if (previous == replacement) return YES;
    *original = previous;
    // 先在子类上添加方法：直接替换继承来的 Method 会改到父类。
    if (!class_addMethod(cls, selector, replacement, method_getTypeEncoding(method)))
        method_setImplementation(class_getInstanceMethod(cls, selector), replacement);
    return YES;
}

// 带签名校验的 Hook：方法不存在、参数个数不对、返回值/首参类型不对时不装，返回 NO。
static BOOL DYYYRecallHookChecked(Class cls, NSString *selectorName, IMP replacement, IMP *original, unsigned int arguments, char resultType, char parameterType) {
    if (!cls || !selectorName.length) return NO;
    SEL selector = NSSelectorFromString(selectorName);
    Method method = class_getInstanceMethod(cls, selector);
    if (!method || method_getNumberOfArguments(method) != arguments) return NO;
    char *result = method_copyReturnType(method);
    BOOL compatible = result && (result[0] == resultType || (resultType == 'B' && result[0] == 'c'));
    free(result);
    if (compatible && arguments > 2 && parameterType) {
        char *parameter = method_copyArgumentType(method, 2);
        compatible = parameter && (parameter[0] == parameterType || (parameterType == 'B' && parameter[0] == 'c'));
        free(parameter);
    }
    return compatible && DYYYRecallHook(cls, selector, replacement, original);
}

#pragma mark - 快速状态（常驻内存，供 Hook 内快速判断）

static char kDYYYMessageSnapshot, kDYYYMessageRecalled, kDYYYMessageAccount, kDYYYMessageGuard, kDYYYHydrationRequested, kDYYYExtraMessage, kDYYYLiveRecall, kDYYYObservedContent, kDYYYSuppressLive, kDYYYSystemNotice;
static char kDYYYFastState;
static char kDYYYVMRestoredState, kDYYYCanonicalMessageKey;

@interface DYYYRecallFastState : NSObject {
@public atomic_bool queued;
@public atomic_uint nativeMutations;
}
@property(atomic) BOOL allowed;
@property(atomic) BOOL invalidated;
@property(atomic) BOOL recalled;
@property(atomic) BOOL rawRecalled;
@property(atomic, copy) NSDictionary *snapshot;
@property(atomic, copy) NSDictionary *capturedContent;
@property(atomic, copy) NSDictionary *rawContent;
@property(atomic, copy) NSString *account;
@property(atomic, copy) NSString *conversation;
@property(atomic, copy) NSString *key;
@property(atomic, weak) id message;
@property(atomic, copy) NSString *serverID;
@property(atomic) NSUInteger displayRevision;
@property(atomic) BOOL profileRequested;
@end

@implementation DYYYRecallFastState
@end

static atomic_bool DYYYRecallSwitch;
static _Thread_local unsigned int DYYYObservationDepth;
static _Thread_local DYYYRecallFrame *DYYYRecallFrames;

static dispatch_queue_t DYYYObservationQueue(void) {
    static dispatch_queue_t queue;
    static dispatch_once_t once;
    dispatch_once(&once, ^{
        queue = dispatch_queue_create("com.dyyy.recall-observation", DISPATCH_QUEUE_SERIAL);
    });
    return queue;
}

static NSHashTable *DYYYKnownMessageStates(void) {
    static NSHashTable *states;
    static dispatch_once_t once;
    dispatch_once(&once, ^{
        states = [NSHashTable weakObjectsHashTable];
    });
    return states;
}

static DYYYRecallFastState *DYYYFastState(id message, BOOL create) {
    if (!message) return nil;
    DYYYRecallFastState *state = objc_getAssociatedObject(message, &kDYYYFastState);
    if (!state && create) {
        state = [DYYYRecallFastState new];
        state.message = message;
        objc_setAssociatedObject(message, &kDYYYFastState, state, OBJC_ASSOCIATION_RETAIN);
    }
    return state;
}

static BOOL DYYYFastAllowed(DYYYRecallFastState *state) {
    return state && atomic_load_explicit(&DYYYRecallSwitch, memory_order_relaxed) && state.allowed;
}

static void DYYYPublishRecallSnapshot(DYYYRecallFastState *state, NSDictionary *record) {
    NSDictionary *old = state.snapshot;
    BOOL changed = [old[@"available"] boolValue] != [record[@"available"] boolValue] ||
                   [old[@"recalled"] boolValue] != [record[@"recalled"] boolValue] ||
                   ![old[@"content"] isEqual:record[@"content"]];
    state.snapshot = record;
    if (changed || !state.displayRevision) state.displayRevision++;
}

static BOOL DYYYRecallNotificationScheduled;
static void DYYYScheduleRecallNotification(void) {
    if (DYYYRecallNotificationScheduled) return;
    DYYYRecallNotificationScheduled = YES;
    dispatch_async(dispatch_get_main_queue(), ^{
        DYYYRecallNotificationScheduled = NO;
        [NSNotificationCenter.defaultCenter postNotificationName:DYYYRecallChangedNotification object:nil];
    });
}

#pragma mark - 本地存档（JSON 文件 + 内存缓存 + 串行队列）
//
// 目录：Application Support/DYYY/Recall/records.json（已排除 iCloud 备份）。
// 只存本插件自己的记录；绝不读写抖音自己的消息数据库或用户数据。
// 写操作全部在串行队列上做，且合并 0.4 秒内的多次保存；Hook 内只做内存快照，不碰磁盘。

@interface DYYYRecallStore : NSObject
@property(nonatomic, strong) dispatch_queue_t queue;
@property(nonatomic, strong) NSURL *root;
@property(nonatomic, strong) NSURL *fileURL;
@property(nonatomic, strong) NSMutableDictionary<NSString *, NSDictionary *> *messages;
@property(nonatomic, strong) NSMutableSet<NSString *> *recalledKeys;
@property(nonatomic, strong) NSMutableSet<NSString *> *archivedKeys;
@property(nonatomic, strong) NSMutableSet<NSString *> *forgottenKeys;
@property(nonatomic, strong) NSMutableSet<NSString *> *notifiedKeys;
@property(nonatomic, strong) NSMutableDictionary<NSString *, NSDictionary *> *profiles;
@property(nonatomic, strong) NSMutableDictionary<NSString *, NSDictionary *> *pendingRecords;
@property(nonatomic, copy) NSString *status;
+ (instancetype)shared;
- (void)save:(NSDictionary *)record key:(NSString *)key recalled:(BOOL)recalled;
- (NSDictionary *)cachedRecord:(NSString *)key;
- (BOOL)isRecalled:(NSString *)key;
- (BOOL)isForgotten:(NSString *)key;
- (void)loadRecordForKey:(NSString *)key account:(NSString *)account conversation:(NSString *)conversation server:(NSString *)server legacyKey:(NSString *)legacyKey completion:(void (^)(NSDictionary *stored))completion;
- (void)removeForAccount:(NSString *)account key:(NSString *)key completion:(dispatch_block_t)completion;
- (void)removeConversation:(NSString *)conversation account:(NSString *)account completion:(dispatch_block_t)completion;
- (NSDictionary *)profileForAccount:(NSString *)account conversation:(NSString *)conversation;
- (void)updateProfile:(NSDictionary *)profile account:(NSString *)account conversation:(NSString *)conversation;
- (NSString *)preferenceKeyForAccount:(NSString *)account conversation:(NSString *)conversation;
- (void)conversationSummaries:(NSString *)account completion:(void (^)(NSArray *summaries))completion;
- (void)recordsForAccount:(NSString *)account conversation:(NSString *)conversation offset:(NSUInteger)offset completion:(void (^)(NSArray *records))completion;
- (void)maintenance;
- (void)storageStatistics:(void (^)(NSDictionary *statistics))completion;
@end

@implementation DYYYRecallStore

+ (instancetype)shared {
    static DYYYRecallStore *store;
    static dispatch_once_t once;
    dispatch_once(&once, ^{
        store = [self new];
    });
    return store;
}

- (instancetype)init {
    if ((self = [super init])) {
        _queue = dispatch_queue_create("com.dyyy.recall-store", DISPATCH_QUEUE_SERIAL);
        _messages = [NSMutableDictionary dictionary];
        _recalledKeys = [NSMutableSet set];
        _archivedKeys = [NSMutableSet set];
        _forgottenKeys = [NSMutableSet set];
        _notifiedKeys = [NSMutableSet set];
        _profiles = [NSMutableDictionary dictionary];
        _pendingRecords = [NSMutableDictionary dictionary];
        _status = @"正在准备本地记录";
        dispatch_async(_queue, ^{
            [self loadFromDisk];
        });
    }
    return self;
}

- (NSURL *)storeRoot {
    NSURL *support = [NSFileManager.defaultManager URLsForDirectory:NSApplicationSupportDirectory inDomains:NSUserDomainMask].firstObject;
    if (!support) return nil;
    NSURL *root = [[support URLByAppendingPathComponent:@"DYYY" isDirectory:YES] URLByAppendingPathComponent:@"Recall" isDirectory:YES];
    NSDictionary *protection = @{NSFileProtectionKey: NSFileProtectionCompleteUntilFirstUserAuthentication};
    NSError *error = nil;
    if (![NSFileManager.defaultManager createDirectoryAtURL:root withIntermediateDirectories:YES attributes:protection error:&error]) return nil;
    [root setResourceValue:@YES forKey:NSURLIsExcludedFromBackupKey error:nil];
    return root;
}

- (void)loadFromDisk {
    self.root = [self storeRoot];
    if (!self.root) {
        @synchronized (self) {
            self.status = @"本地记录目录不可写";
        }
        return;
    }
    self.fileURL = [self.root URLByAppendingPathComponent:@"records.json"];
    NSData *data = [NSData dataWithContentsOfURL:self.fileURL];
    NSDictionary *disk = nil;
    if (data.length) disk = [NSJSONSerialization JSONObjectWithData:data options:0 error:nil];
    if ([disk isKindOfClass:NSDictionary.class]) {
        NSDictionary *messages = disk[@"messages"];
        if ([messages isKindOfClass:NSDictionary.class]) {
            @synchronized (self) {
                for (NSString *key in messages) {
                    if ([messages[key] isKindOfClass:NSDictionary.class]) self.messages[key] = messages[key];
                }
            }
        }
        NSArray *forgotten = disk[@"forgotten"];
        if ([forgotten isKindOfClass:NSArray.class]) {
            @synchronized (self) {
                [self.forgottenKeys addObjectsFromArray:forgotten];
            }
        }
        NSDictionary *profiles = disk[@"profiles"];
        if ([profiles isKindOfClass:NSDictionary.class]) {
            @synchronized (self) {
                for (NSString *key in profiles) {
                    if ([profiles[key] isKindOfClass:NSDictionary.class]) self.profiles[key] = profiles[key];
                }
            }
        }
        [self rebuildIndexes];
    }
    @synchronized (self) {
        self.status = @"本地记录就绪";
    }
}

- (void)rebuildIndexes {
    @synchronized (self) {
        [self.recalledKeys removeAllObjects];
        [self.archivedKeys removeAllObjects];
        for (NSString *key in self.messages) {
            NSDictionary *record = self.messages[key];
            if ([self.forgottenKeys containsObject:key]) continue;
            if ([record[@"recalled"] boolValue]) {
                [self.recalledKeys addObject:key];
                if (!DYYYRecallRecordShouldHide(record)) [self.archivedKeys addObject:key];
            }
        }
    }
}

// 必须在 _queue 上调用。
- (void)flushToDisk {
    NSDictionary *snapshot = nil;
    @synchronized (self) {
        snapshot = @{@"messages": [self.messages copy], @"forgotten": [self.forgottenKeys allObjects], @"profiles": [self.profiles copy]};
    }
    NSData *data = [NSJSONSerialization dataWithJSONObject:snapshot options:0 error:nil];
    if (data) [data writeToURL:self.fileURL atomically:YES];
}

- (void)scheduleFlush {
    static BOOL scheduled;
    if (scheduled) return;
    scheduled = YES;
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.4 * NSEC_PER_SEC)), self.queue, ^{
        scheduled = NO;
        [self flushToDisk];
    });
}

- (void)save:(NSDictionary *)record key:(NSString *)key recalled:(BOOL)recalled {
    if (!record || !key.length) return;
    NSDictionary *clean = DYYYRecallJSONValue(record, 0);
    if (![clean isKindOfClass:NSDictionary.class]) return;
    @synchronized (self) {
        if ([self.forgottenKeys containsObject:key]) return;
        self.pendingRecords[key] = clean;
    }
    dispatch_async(self.queue, ^{
        NSDictionary *pending = nil;
        @synchronized (self) {
            pending = self.pendingRecords[key];
            [self.pendingRecords removeObjectForKey:key];
        }
        if (!pending) return;
        @synchronized (self) {
            if ([self.forgottenKeys containsObject:key]) return;
            self.messages[key] = pending;
            if (recalled) {
                [self.recalledKeys addObject:key];
                if (!DYYYRecallRecordShouldHide(pending)) [self.archivedKeys addObject:key];
                else [self.archivedKeys removeObject:key];
            }
        }
        [self scheduleFlush];
    });
}

- (NSDictionary *)cachedRecord:(NSString *)key {
    if (!key.length) return nil;
    @synchronized (self) {
        return self.messages[key];
    }
}

- (BOOL)isRecalled:(NSString *)key {
    if (!key.length) return NO;
    @synchronized (self) {
        return [self.recalledKeys containsObject:key];
    }
}

- (BOOL)isForgotten:(NSString *)key {
    if (!key.length) return NO;
    @synchronized (self) {
        return [self.forgottenKeys containsObject:key];
    }
}

- (void)loadRecordForKey:(NSString *)key account:(NSString *)account conversation:(NSString *)conversation server:(NSString *)server legacyKey:(NSString *)legacyKey completion:(void (^)(NSDictionary *))completion {
    dispatch_async(self.queue, ^{
        NSDictionary *stored = nil;
        @synchronized (self) {
            stored = self.messages[key] ?: self.messages[legacyKey];
            if (!stored && server.length) {
                for (NSDictionary *record in self.messages.allValues) {
                    if ([record[@"account"] isEqual:account] && [record[@"conversation"] isEqual:conversation] && [record[@"serverID"] isEqual:server]) {
                        stored = record;
                        break;
                    }
                }
            }
        }
        NSDictionary *result = stored ? DYYYRecallEnrichRecord(stored) : nil;
        dispatch_async(dispatch_get_main_queue(), ^{
            if (completion) completion(result);
        });
    });
}

- (void)removeForAccount:(NSString *)account key:(NSString *)key completion:(dispatch_block_t)completion {
    dispatch_async(self.queue, ^{
        @synchronized (self) {
            if (key.length) {
                [self.forgottenKeys addObject:key];
                [self.messages removeObjectForKey:key];
                [self.pendingRecords removeObjectForKey:key];
            } else if (account.length) {
                for (NSString *storedKey in [self.messages allKeys]) {
                    if ([self.messages[storedKey][@"account"] isEqual:account]) {
                        [self.forgottenKeys addObject:storedKey];
                        [self.messages removeObjectForKey:storedKey];
                    }
                }
                [self.pendingRecords removeAllObjects];
            }
        }
        [self rebuildIndexes];
        [self flushToDisk];
        dispatch_async(dispatch_get_main_queue(), ^{
            DYYYScheduleRecallNotification();
            if (completion) completion();
        });
    });
}

- (void)removeConversation:(NSString *)conversation account:(NSString *)account completion:(dispatch_block_t)completion {
    if (!conversation.length || !account.length) return;
    dispatch_async(self.queue, ^{
        NSMutableSet *keys = [NSMutableSet set];
        @synchronized (self) {
            for (NSString *key in self.messages) {
                NSDictionary *record = self.messages[key];
                if ([record[@"account"] isEqual:account] && [record[@"conversation"] isEqual:conversation]) [keys addObject:key];
            }
            for (NSString *key in self.pendingRecords) {
                if ([self.pendingRecords[key][@"account"] isEqual:account] && [self.pendingRecords[key][@"conversation"] isEqual:conversation]) [keys addObject:key];
            }
            [self.forgottenKeys unionSet:keys];
            for (NSString *key in keys) {
                [self.messages removeObjectForKey:key];
                [self.pendingRecords removeObjectForKey:key];
            }
        }
        [self rebuildIndexes];
        [self flushToDisk];
        dispatch_async(dispatch_get_main_queue(), ^{
            DYYYScheduleRecallNotification();
            if (completion) completion();
        });
    });
}

- (NSDictionary *)profileForAccount:(NSString *)account conversation:(NSString *)conversation {
    NSString *key = [self preferenceKeyForAccount:account conversation:conversation];
    @synchronized (self) {
        return key ? self.profiles[key] : nil;
    }
}

- (NSString *)preferenceKeyForAccount:(NSString *)account conversation:(NSString *)conversation {
    if (!account.length || !conversation.length) return nil;
    NSData *data = [NSJSONSerialization dataWithJSONObject:@[account, conversation] options:0 error:nil];
    return [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];
}

- (void)updateProfile:(NSDictionary *)profile account:(NSString *)account conversation:(NSString *)conversation {
    NSString *key = [self preferenceKeyForAccount:account conversation:conversation];
    if (!key || !profile.count) return;
    @synchronized (self) {
        NSMutableDictionary *merged = [self.profiles[key] mutableCopy] ?: [NSMutableDictionary dictionary];
        for (NSString *field in profile) {
            if ([profile[field] respondsToSelector:@selector(length)] ? [profile[field] length] > 0 : YES) merged[field] = profile[field];
        }
        if ([merged isEqual:self.profiles[key]]) return;
        self.profiles[key] = [merged copy];
    }
    dispatch_async(self.queue, ^{
        [self scheduleFlush];
    });
}

- (void)conversationSummaries:(NSString *)account completion:(void (^)(NSArray *))completion {
    dispatch_async(self.queue, ^{
        NSMutableArray *grouped = [NSMutableArray array];
        NSMutableDictionary *byConversation = [NSMutableDictionary dictionary];
        @synchronized (self) {
            for (NSString *key in self.messages) {
                NSDictionary *record = self.messages[key];
                if (![record[@"account"] isEqual:account] || ![record[@"recalled"] boolValue]) continue;
                if (DYYYRecallRecordShouldHide(record)) continue;
                NSString *conversation = record[@"conversation"] ?: @"";
                NSMutableDictionary *group = byConversation[conversation];
                if (!group) {
                    group = [@{@"conversation": conversation, @"account": account, @"count": @0, @"time": @0, @"record": record} mutableCopy];
                    byConversation[conversation] = group;
                    [grouped addObject:group];
                }
                group[@"count"] = @([group[@"count"] integerValue] + 1);
                NSTimeInterval recalledAt = [record[@"recalledAt"] doubleValue];
                if (recalledAt > [group[@"time"] doubleValue]) {
                    group[@"time"] = @(recalledAt);
                    group[@"record"] = record;
                }
            }
        }
        NSMutableArray *result = [NSMutableArray array];
        for (NSDictionary *group in grouped) {
            NSDictionary *record = DYYYRecallEnrichRecord(group[@"record"]);
            NSDictionary *profile = [self profileForAccount:account conversation:group[@"conversation"]] ?: @{};
            NSString *name = [record[@"conversationName"] length] ? record[@"conversationName"] : ([record[@"senderName"] length] ? record[@"senderName"] : profile[@"name"]);
            BOOL hasName = name.length > 0;
            if (!name.length) name = [NSString stringWithFormat:@"%@ · %@", [profile[@"group"] boolValue] ? @"群聊" : @"联系人", [record[@"sender"] length] ? record[@"sender"] : group[@"conversation"]];
            NSString *avatar = [record[@"conversationAvatar"] length] ? record[@"conversationAvatar"] : ([record[@"senderAvatar"] length] ? record[@"senderAvatar"] : profile[@"avatar"]);
            [result addObject:@{@"conversation": group[@"conversation"], @"account": account, @"sender": record[@"sender"] ?: @"", @"hasName": @(hasName), @"name": name, @"avatar": avatar ?: @"", @"group": profile[@"group"] ?: @NO, @"count": group[@"count"], @"time": group[@"time"], @"summary": DYYYRecallSummary(record ?: @{})}];
        }
        [result sortUsingComparator:^NSComparisonResult(NSDictionary *a, NSDictionary *b) {
            return [b[@"time"] compare:a[@"time"]];
        }];
        dispatch_async(dispatch_get_main_queue(), ^{
            if (completion) completion(result);
        });
    });
}

- (void)recordsForAccount:(NSString *)account conversation:(NSString *)conversation offset:(NSUInteger)offset completion:(void (^)(NSArray *))completion {
    dispatch_async(self.queue, ^{
        NSMutableArray *records = [NSMutableArray array];
        @synchronized (self) {
            for (NSDictionary *record in self.messages.allValues) {
                if (![record[@"account"] isEqual:account] || ![record[@"conversation"] isEqual:conversation] || ![record[@"recalled"] boolValue]) continue;
                if (DYYYRecallRecordShouldHide(record)) continue;
                [records addObject:DYYYRecallEnrichRecord(record)];
            }
        }
        [records sortUsingComparator:^NSComparisonResult(NSDictionary *a, NSDictionary *b) {
            NSComparisonResult time = [b[@"recalledAt"] compare:a[@"recalledAt"]];
            if (time != NSOrderedSame) return time;
            return [b[@"key"] compare:a[@"key"]];
        }];
        NSArray *page = @[];
        if (offset < records.count) {
            NSUInteger end = MIN(records.count, offset + 100);
            page = [records subarrayWithRange:NSMakeRange(offset, end - offset)];
        }
        dispatch_async(dispatch_get_main_queue(), ^{
            if (completion) completion(page);
        });
    });
}

- (void)maintenance {
    NSInteger retentionDays = DYYYRecallInteger(DYYYRecallRetentionDaysKey);
    NSInteger maxRecords = DYYYRecallInteger(DYYYRecallMaxRecordsKey);
    if (retentionDays <= 0 && maxRecords <= 0) return;
    dispatch_async(self.queue, ^{
        NSTimeInterval now = NSDate.date.timeIntervalSince1970;
        NSMutableArray *all = [NSMutableArray array];
        @synchronized (self) {
            [all addObjectsFromArray:self.messages.allValues];
        }
        [all sortUsingComparator:^NSComparisonResult(NSDictionary *a, NSDictionary *b) {
            return [b[@"recalledAt"] compare:a[@"recalledAt"]];
        }];
        NSMutableSet *drop = [NSMutableSet set];
        for (NSUInteger i = 0; i < all.count; i++) {
            NSDictionary *record = all[i];
            BOOL tooOld = retentionDays > 0 && [record[@"recalledAt"] doubleValue] > 0 && now - [record[@"recalledAt"] doubleValue] > retentionDays * 86400.0;
            BOOL overCap = maxRecords > 0 && (NSInteger)i >= maxRecords;
            if (tooOld || overCap) [drop addObject:record[@"key"]];
        }
        if (!drop.count) return;
        @synchronized (self) {
            for (NSString *key in drop) [self.messages removeObjectForKey:key];
        }
        [self rebuildIndexes];
        [self flushToDisk];
        dispatch_async(dispatch_get_main_queue(), ^{
            DYYYScheduleRecallNotification();
        });
    });
}

- (void)storageStatistics:(void (^)(NSDictionary *))completion {
    NSString *account = DYYYRecallCurrentAccountID();
    dispatch_async(self.queue, ^{
        unsigned long long bytes = 0;
        NSUInteger count = 0;
        NSMutableSet *conversations = [NSMutableSet set];
        @synchronized (self) {
            for (NSDictionary *record in self.messages.allValues) {
                if (![record[@"account"] isEqual:account] || DYYYRecallRecordShouldHide(record)) continue;
                if ([record[@"recalled"] boolValue]) {
                    count++;
                    [conversations addObject:record[@"conversation"] ?: @""];
                }
            }
        }
        NSDictionary *attributes = [NSFileManager.defaultManager attributesOfItemAtPath:self.fileURL.path error:nil];
        bytes = [attributes[NSFileSize] unsignedLongLongValue];
        NSDictionary *stats = @{@"bytes": @(bytes), @"records": @(count), @"conversations": @(conversations.count), @"account": account ?: @""};
        dispatch_async(dispatch_get_main_queue(), ^{
            if (completion) completion(stats);
        });
    });
}

@end

#pragma mark - 会话开关与消息身份

static NSString *DYYYConversationPreferenceKey(NSString *account, NSString *conversation) {
    if (!account.length || !conversation.length) return nil;
    return [NSString stringWithFormat:@"%@|%@", account, conversation];
}

static BOOL DYYYRecallEnabledForAccountConversation(NSString *account, NSString *conversation) {
    if (!DYYYRecallBool(DYYYRecallEnabledKey)) return NO;
    NSString *key = DYYYConversationPreferenceKey(account, conversation);
    if (!key) return NO;
    NSArray *disabled = [DYYYRecallPreferences() objectForKey:DYYYRecallDisabledConversationsKey];
    return !([disabled isKindOfClass:NSArray.class] && [disabled containsObject:key]);
}

BOOL DYYYRecallEnabledForConversation(NSString *conversationID) {
    return DYYYRecallEnabledForAccountConversation(DYYYRecallCurrentAccountID(), conversationID);
}

BOOL DYYYRecallEnabledForMessage(id message) {
    return DYYYFastAllowed(DYYYFastState(message, NO));
}

void DYYYSetConversationRecallEnabled(NSString *conversationID, BOOL enabled) {
    NSString *key = DYYYConversationPreferenceKey(DYYYRecallCurrentAccountID(), conversationID);
    if (!key.length) return;
    @synchronized (DYYYRecallPreferences()) {
        NSArray *value = [DYYYRecallPreferences() objectForKey:DYYYRecallDisabledConversationsKey];
        NSMutableArray *disabled = [value isKindOfClass:NSArray.class] ? [value mutableCopy] : [NSMutableArray array];
        if (enabled) [disabled removeObject:key];
        else if (![disabled containsObject:key]) [disabled addObject:key];
        [DYYYRecallPreferences() setObject:[disabled copy] forKey:DYYYRecallDisabledConversationsKey];
    }
    [NSNotificationCenter.defaultCenter postNotificationName:DYYYRecallPreferencesChangedNotification object:nil userInfo:@{@"key": DYYYRecallDisabledConversationsKey}];
    DYYYScheduleRecallNotification();
}

static void DYYYRefreshRecallPolicy(void) {
    atomic_store_explicit(&DYYYRecallSwitch, DYYYRecallBool(DYYYRecallEnabledKey), memory_order_relaxed);
    NSString *activeAccount = DYYYRecallCurrentAccountID();
    for (DYYYRecallFastState *state in DYYYKnownMessageStates().allObjects) {
        BOOL allowed = !state.invalidated && [state.account isEqual:activeAccount] &&
                       DYYYRecallEnabledForAccountConversation(state.account, state.conversation) &&
                       ![[DYYYRecallStore shared] isForgotten:state.key];
        state.allowed = allowed;
    }
}

static NSString *DYYYMessageAccountID(id message) {
    NSString *bound = objc_getAssociatedObject(message, &kDYYYMessageAccount);
    if (bound.length) return bound;
    Ivar rootIvar = class_getInstanceVariable(NSClassFromString(@"TIMXOModel"), "_r");
    const char *encoding = rootIvar ? ivar_getTypeEncoding(rootIvar) : NULL;
    id root = encoding && encoding[0] == '@' && [message isKindOfClass:NSClassFromString(@"TIMXOModel")] ? object_getIvar(message, rootIvar) : nil;
    NSString *account = DYYYIdentifier(DYYYRead(DYYYRead(root, @"config"), @"uid"));
    if (!account.length || [account isEqualToString:@"0"]) {
        if (root) return nil; // 没有 UID 的 SDK 实例不得继承另一个前台账号。
        account = DYYYRecallCurrentAccountID();
    }
    if (!account.length || [account isEqualToString:@"0"]) return nil;
    return account;
}

static NSString *DYYYRecordKey(NSString *account, NSString *conversation, NSString *message) {
    if (!account.length || !conversation.length || !message.length) return nil;
    NSData *data = [NSJSONSerialization dataWithJSONObject:@[account, conversation, message] options:0 error:nil];
    return [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];
}

static NSString *DYYYKeyForMessage(id message) {
    NSString *account = DYYYMessageAccountID(message);
    NSString *conversation = DYYYIdentifier(DYYYRead(message, @"belongingConversationIdentifier")) ?: DYYYIdentifier(DYYYRead(message, @"conversationID"));
    NSDictionary *resolved = objc_getAssociatedObject(message, &kDYYYCanonicalMessageKey);
    if ([resolved[@"account"] isEqual:account] && [resolved[@"conversation"] isEqual:conversation]) return resolved[@"key"];
    NSString *identifier = DYYYIdentifier(DYYYRead(message, @"serverMessageID"));
    if (!identifier.length || [identifier isEqual:@"0"]) identifier = DYYYIdentifier(DYYYRead(message, @"identifier"));
    return DYYYRecordKey(account, conversation, identifier);
}

static BOOL DYYYIncomingMessage(id message) {
    NSString *account = DYYYMessageAccountID(message);
    NSString *sender = DYYYIdentifier(DYYYRead(message, @"sender"));
    return account.length && sender.length && ![sender isEqualToString:@"0"] && ![sender isEqualToString:account];
}

static BOOL DYYYRawRecalled(id message) {
    return [DYYYRead(message, @"recalled") boolValue];
}

static BOOL DYYYContentAvailable(id content) {
    if (![content isKindOfClass:NSDictionary.class] || ![content count]) return NO;
    NSString *text = [content[@"text"] isKindOfClass:NSString.class] ? content[@"text"] : nil;
    return ![text isEqualToString:@"Recall Content Hided"];
}

NSDictionary *DYYYMessageIdentity(id message) {
    if (!message) return @{};
    return @{@"account": DYYYMessageAccountID(message) ?: @"",
             @"conversation": DYYYIdentifier(DYYYRead(message, @"belongingConversationIdentifier")) ?: DYYYIdentifier(DYYYRead(message, @"conversationID")) ?: @"",
             @"message": DYYYIdentifier(DYYYRead(message, @"serverMessageID")) ?: DYYYIdentifier(DYYYRead(message, @"identifier")) ?: @"",
             @"sender": DYYYIdentifier(DYYYRead(message, @"sender")) ?: @"",
             @"timestamp": @(DYYYMessageTimestamp(DYYYRead(message, @"createTime")) ?: DYYYMessageTimestamp(DYYYRead(message, @"timestamp"))),
             @"recalled": @(DYYYRawRecalled(message))};
}

// 本函数仅限观察队列调用；绝不从 SDK Hook 里调用。
static BOOL DYYYEvaluateMessagePolicy(id message) {
    NSString *conversation = DYYYIdentifier(DYYYRead(message, @"belongingConversationIdentifier"));
    if (!conversation.length) conversation = DYYYIdentifier(DYYYRead(message, @"conversationID"));
    return message && DYYYRecallEnabledForAccountConversation(DYYYMessageAccountID(message), conversation);
}

static NSString *DYYYFirstString(id object, NSArray<NSString *> *keys) {
    for (NSString *key in keys) {
        NSString *value = DYYYIdentifier(DYYYRead(object, key));
        if (value.length) return value;
    }
    return nil;
}

static NSDictionary *DYYYPerson(id person) {
    if (!person) return @{};
    NSString *uid = DYYYIdentifier(DYYYRead(person, @"uid")) ?: DYYYIdentifier(DYYYRead(person, @"userID")) ?: @"";
    NSString *name = DYYYIdentifier(DYYYRead(person, @"nickname")) ?: DYYYIdentifier(DYYYRead(person, @"name")) ?: @"";
    NSString *remark = DYYYIdentifier(DYYYRead(person, @"remarkName")) ?: DYYYIdentifier(DYYYRead(person, @"remark")) ?: @"";
    id avatar = DYYYRead(person, @"avatarURL") ?: DYYYRead(person, @"avatar") ?: DYYYRead(person, @"avatarThumb");
    NSString *avatarURL = @"";
    if ([avatar isKindOfClass:NSString.class]) avatarURL = avatar;
    else if ([avatar isKindOfClass:NSURL.class]) avatarURL = [(NSURL *)avatar absoluteString];
    else if ([avatar isKindOfClass:NSArray.class]) avatarURL = DYYYIdentifier([(NSArray *)avatar firstObject]);
    else if ([avatar isKindOfClass:NSDictionary.class]) avatarURL = DYYYIdentifier(avatar[@"url_list"] ? [(NSArray *)avatar[@"url_list"] firstObject] : avatar[@"url"]);
    return @{@"uid": uid, @"name": name, @"remark": remark, @"avatar": avatarURL ?: @""};
}

static void DYYYRememberConversation(id conversation, id peer, NSString *account) {
    if (!conversation && !peer) return;
    NSString *identifier = DYYYIdentifier(DYYYRead(conversation, @"conversationID")) ?: DYYYIdentifier(DYYYRead(conversation, @"identifier"));
    if (!identifier.length) return;
    NSDictionary *person = DYYYPerson(peer ?: DYYYRead(conversation, @"peerUser"));
    NSString *name = DYYYIdentifier(DYYYRead(conversation, @"title")) ?: DYYYIdentifier(DYYYRead(conversation, @"name")) ?: person[@"name"] ?: @"";
    NSString *avatar = DYYYIdentifier(DYYYRead(conversation, @"avatarURL")) ?: person[@"avatar"] ?: @"";
    BOOL group = [DYYYRead(conversation, @"isGroup") boolValue] || [DYYYRead(conversation, @"group") boolValue];
    [[DYYYRecallStore shared] updateProfile:@{@"name": name ?: @"", @"avatar": avatar ?: @"", @"group": @(group)} account:account conversation:identifier];
}

static NSString *DYYYMediaKindFromHint(NSString *mime, NSString *extension, NSString *hint) {
    NSString *value = [[NSString stringWithFormat:@"%@ %@ %@", mime ?: @"", extension ?: @"", hint ?: @""] lowercaseString];
    for (NSString *word in @[@"image", @"photo", @"jpg", @"jpeg", @"png", @"webp", @"gif", @"heic"])
        if ([value containsString:word]) return @"image";
    for (NSString *word in @[@"audio", @"voice", @"mp3", @"m4a", @"aac", @"wav", @"amr", @"opus"])
        if ([value containsString:word]) return @"audio";
    for (NSString *word in @[@"video", @"mp4", @"mov", @"m3u8"])
        if ([value containsString:word]) return @"video";
    return @"file";
}

static NSString *DYYYSafeLocalPath(id value) {
    NSString *path = [value isKindOfClass:NSURL.class] ? ([value isFileURL] ? [value path] : nil) : ([value isKindOfClass:NSString.class] ? value : nil);
    if ([path hasPrefix:@"file://"]) path = [NSURL URLWithString:path].path;
    if (!path.length || ![path isAbsolutePath]) return nil;
    NSString *standard = path.stringByStandardizingPath;
    return [standard hasPrefix:[NSHomeDirectory().stringByStandardizingPath stringByAppendingString:@"/"]] ? standard : nil;
}

// 附件（本地已下载文件优先）+ content 解析出的媒体，去重后合并。只读路径字符串，不读文件内容。
static NSArray *DYYYMessageMedia(id message, NSDictionary *content) {
    NSMutableArray *media = [NSMutableArray array];
    NSMutableSet *seen = [NSMutableSet set];
    for (NSString *property in @[@"fileAttachments", @"messageBodyFiles"]) {
        id attachments = DYYYRead(message, property);
        if (![attachments isKindOfClass:NSArray.class]) continue;
        for (id attachment in attachments) {
            if (media.count >= 24) break;
            NSString *path = DYYYSafeLocalPath(DYYYRead(attachment, @"localFileURL"));
            NSString *remote = DYYYIdentifier(DYYYRead(attachment, @"remotePath"));
            NSURL *url = [NSURL URLWithString:remote ?: @""];
            if (![@[@"http", @"https"] containsObject:url.scheme.lowercaseString]) remote = nil;
            NSString *identity = path ?: remote;
            if (!identity.length || [seen containsObject:identity]) continue;
            [seen addObject:identity];
            NSString *extension = DYYYIdentifier(DYYYRead(attachment, @"fileExtension")) ?: path.pathExtension;
            NSString *mime = DYYYIdentifier(DYYYRead(attachment, @"mimeType")) ?: @"";
            NSString *kind = DYYYMediaKindFromHint(mime, extension, DYYYIdentifier(DYYYRead(attachment, @"displayType")));
            NSMutableDictionary *item = [@{@"kind": kind, @"mime": mime, @"extension": extension ?: @"", @"name": path.lastPathComponent ?: url.lastPathComponent ?: @"消息附件"} mutableCopy];
            if (path) item[@"sourcePath"] = path;
            if (remote) item[@"remoteURL"] = remote;
            if ([DYYYIdentifier(DYYYRead(attachment, @"algorithm")) length]) item[@"encrypted"] = @YES;
            [media addObject:item];
        }
    }
    for (NSDictionary *item in DYYYRecallMediaFromContent(content)) {
        NSString *identity = item[@"remoteURL"];
        if (![seen containsObject:identity]) {
            [seen addObject:identity];
            [media addObject:item];
        }
    }
    return media;
}

#pragma mark - 快照构建与留存

static void DYYYObserveMessageNow(id message);
static void DYYYRememberMessage(id message, NSDictionary *content, BOOL recalled);

static NSDictionary *DYYYBuildSnapshot(id message, NSDictionary *content, BOOL recalled) {
    NSString *key = DYYYKeyForMessage(message);
    if (!key || [[DYYYRecallStore shared] isForgotten:key]) return nil;
    DYYYRecallFastState *state = DYYYFastState(message, YES);
    NSDictionary *old = objc_getAssociatedObject(message, &kDYYYMessageSnapshot) ?: [[DYYYRecallStore shared] cachedRecord:key];
    NSString *account = DYYYMessageAccountID(message);
    NSString *conversation = DYYYIdentifier(DYYYRead(message, @"belongingConversationIdentifier")) ?: DYYYIdentifier(DYYYRead(message, @"conversationID"));
    NSString *sender = DYYYIdentifier(DYYYRead(message, @"sender"));
    NSTimeInterval timestamp = DYYYMessageTimestamp(DYYYRead(message, @"createTime"));
    if (timestamp <= 0) timestamp = DYYYMessageTimestamp(DYYYRead(message, @"timestamp"));
    if (timestamp <= 0) timestamp = NSDate.date.timeIntervalSince1970;
    BOOL liveRecall = [objc_getAssociatedObject(message, &kDYYYLiveRecall) boolValue];
    NSMutableDictionary *record = [NSMutableDictionary dictionary];
    record[@"key"] = key;
    record[@"account"] = account ?: @"";
    record[@"conversation"] = conversation ?: @"";
    record[@"message"] = DYYYIdentifier(DYYYRead(message, @"serverMessageID")) ?: DYYYIdentifier(DYYYRead(message, @"identifier")) ?: @"";
    record[@"serverID"] = state.serverID ?: @"";
    record[@"sender"] = sender ?: @"";
    record[@"timestamp"] = @(timestamp);
    record[@"created"] = @(timestamp);
    record[@"type"] = DYYYRead(message, @"messageType") ?: @0;
    record[@"recalled"] = @(recalled);
    record[@"recalledAt"] = recalled ? @(NSDate.date.timeIntervalSince1970) : ([old[@"recalledAt"] doubleValue] > 0 ? old[@"recalledAt"] : @0);
    record[@"available"] = @(DYYYContentAvailable(content));
    record[@"content"] = content ?: @{};
    record[@"presentationClass"] = state.snapshot[@"presentationClass"] ?: @"";
    record[@"_liveRecall"] = @(liveRecall);
    if ([objc_getAssociatedObject(message, &kDYYYSystemNotice) boolValue]) record[@"systemRecallNotice"] = @YES;
    NSDictionary *capturedComment = DYYYMergeCapturedComment(DYYYRecallCommentFromContent(content), nil);
    if (capturedComment) record[@"comment"] = capturedComment;
    NSArray *media = DYYYMessageMedia(message, content);
    if (media.count) record[@"media"] = media;
    NSDictionary *profile = [[DYYYRecallStore shared] profileForAccount:account conversation:conversation];
    if ([profile[@"name"] length]) record[@"conversationName"] = profile[@"name"];
    if ([profile[@"avatar"] length]) record[@"conversationAvatar"] = profile[@"avatar"];
    record = [DYYYRecallEnrichRecord(record) mutableCopy];
    return record;
}

static BOOL DYYYRecordEquivalent(NSDictionary *old, NSDictionary *record) {
    if (!old) return NO;
    return [old[@"content"] isEqual:record[@"content"]] && [old[@"recalled"] boolValue] == [record[@"recalled"] boolValue] &&
           [old[@"available"] boolValue] == [record[@"available"] boolValue];
}

static void DYYYRememberMessage(id message, NSDictionary *content, BOOL recalled) {
    if (!message || !DYYYRecallEnabledForMessage(message) || !DYYYIncomingMessage(message)) return;
    NSDictionary *record = DYYYBuildSnapshot(message, content, recalled);
    if (!record) return;
    NSDictionary *old = objc_getAssociatedObject(message, &kDYYYMessageSnapshot) ?: [[DYYYRecallStore shared] cachedRecord:record[@"key"]];
    DYYYRecallDecision decision = DYYYRecallDecide(YES, old != nil, DYYYRecordEquivalent(old, record),
                                                    [old[@"recalled"] boolValue], recalled,
                                                    [old[@"available"] boolValue], [record[@"available"] boolValue]);
    DYYYRecallFastState *state = DYYYFastState(message, YES);
    DYYYPublishRecallSnapshot(state, record);
    if (!decision.persist) return;
    NSString *key = record[@"key"];
    BOOL liveRecall = [record[@"_liveRecall"] boolValue];
    // 磁盘写在后台串行队列上；Hook 与观察路径只做内存快照，绝不阻塞主线程。
    dispatch_async(DYYYObservationQueue(), ^{
        id live = message;
        DYYYRecallFastState *current = DYYYFastState(live, NO);
        if (!live || !DYYYFastAllowed(current) || ![key isEqual:current.key] || [[DYYYRecallStore shared] isForgotten:key]) return;
        NSDictionary *prior = [[DYYYRecallStore shared] cachedRecord:key];
        NSMutableDictionary *toSave = [record mutableCopy];
        if (prior && [prior[@"recalled"] boolValue] && ![record[@"recalled"] boolValue]) toSave[@"recalled"] = @YES;
        if ([toSave[@"recalledAt"] doubleValue] <= 0 && [prior[@"recalledAt"] doubleValue] > 0) toSave[@"recalledAt"] = prior[@"recalledAt"];
        [[DYYYRecallStore shared] save:toSave key:key recalled:[toSave[@"recalled"] boolValue]];
        DYYYScheduleRecallNotification();
        if (decision.notify && liveRecall && ![toSave[@"systemRecallNotice"] boolValue] && !DYYYRecallRecordShouldHide(toSave)) {
            @synchronized ([DYYYRecallStore shared]) {
                if (![[DYYYRecallStore shared].notifiedKeys containsObject:key]) {
                    [[DYYYRecallStore shared].notifiedKeys addObject:key];
                    dispatch_async(dispatch_get_main_queue(), ^{
                        [NSNotificationCenter.defaultCenter postNotificationName:DYYYRecallDetectedNotification object:nil userInfo:@{@"record": toSave}];
                    });
                }
            }
        }
    });
}

static void DYYYObserveMessageNow(id message) {
    if (!message || [objc_getAssociatedObject(message, &kDYYYMessageGuard) boolValue]) return;
    DYYYRecallFastState *current = DYYYFastState(message, NO);
    if (current && atomic_load_explicit(&current->nativeMutations, memory_order_acquire)) return;
    objc_setAssociatedObject(message, &kDYYYMessageGuard, @YES, OBJC_ASSOCIATION_RETAIN);
    @try {
        DYYYRecallFastState *state = DYYYFastState(message, YES);
        BOOL previouslyAllowed = state.allowed;
        state.allowed = !state.invalidated && DYYYEvaluateMessagePolicy(message) && DYYYIncomingMessage(message);
        if (!state.allowed) {
            if (previouslyAllowed) DYYYScheduleRecallNotification();
            return;
        }
        NSString *key = DYYYKeyForMessage(message);
        state.key = key;
        state.message = message;
        state.serverID = DYYYIdentifier(DYYYRead(message, @"serverMessageID"));
        state.account = DYYYMessageAccountID(message);
        state.conversation = DYYYIdentifier(DYYYRead(message, @"belongingConversationIdentifier")) ?: DYYYIdentifier(DYYYRead(message, @"conversationID"));
        [DYYYKnownMessageStates() addObject:state];
        if ([[DYYYRecallStore shared] isForgotten:key]) {
            state.allowed = NO;
            return;
        }
        NSDictionary *rawContent = DYYYRead(message, @"content");
        NSDictionary *content = state.capturedContent ?: rawContent;
        BOOL rawRecalled = DYYYRawRecalled(message);
        state.rawRecalled = rawRecalled;
        if (rawContent) state.rawContent = rawContent;
        BOOL recalled = [objc_getAssociatedObject(message, &kDYYYMessageRecalled) boolValue] || rawRecalled || [[DYYYRecallStore shared] isRecalled:key];
        if (recalled) state.recalled = YES;
        if (recalled && !DYYYContentAvailable(content)) content = DYYYRead(message, @"recalledContent");
        NSNumber *hydration = objc_getAssociatedObject(message, &kDYYYHydrationRequested);
        if (!key.length || (hydration && !hydration.boolValue)) return;
        if (!hydration) {
            // 写入前先等存档身份解析完成：同一条服务端消息的多个 SDK 对象在重启后不得各自创建独立的存档行。
            objc_setAssociatedObject(message, &kDYYYHydrationRequested, @NO, OBJC_ASSOCIATION_RETAIN);
            NSDictionary *provisional = DYYYBuildSnapshot(message, content, recalled);
            if (provisional) {
                DYYYPublishRecallSnapshot(state, provisional);
                if (recalled) DYYYScheduleRecallNotification();
            }
            NSString *legacyKey = DYYYRecordKey(state.account, state.conversation, DYYYIdentifier(DYYYRead(message, @"identifier")));
            __weak id weakMessage = message;
            [[DYYYRecallStore shared] loadRecordForKey:key account:state.account conversation:state.conversation server:state.serverID legacyKey:legacyKey completion:^(NSDictionary *stored) {
                dispatch_async(DYYYObservationQueue(), ^{
                    id live = weakMessage;
                    DYYYRecallFastState *currentState = DYYYFastState(live, NO);
                    if (!live || ![key isEqual:currentState.key]) return;
                    objc_setAssociatedObject(live, &kDYYYHydrationRequested, @YES, OBJC_ASSOCIATION_RETAIN);
                    if ([[DYYYRecallStore shared] isForgotten:key] || [[DYYYRecallStore shared] isForgotten:legacyKey]) {
                        currentState.allowed = NO;
                        return;
                    }
                    NSString *resolvedKey = stored[@"key"] ?: key;
                    objc_setAssociatedObject(live, &kDYYYCanonicalMessageKey, @{@"account": currentState.account, @"conversation": currentState.conversation, @"key": resolvedKey}, OBJC_ASSOCIATION_RETAIN);
                    currentState.key = resolvedKey;
                    NSDictionary *currentSnapshot = currentState.snapshot;
                    if (stored && DYYYRecallShouldHydrate([stored[@"available"] boolValue], [currentSnapshot[@"available"] boolValue], [stored[@"recalled"] boolValue], currentState.recalled)) {
                        NSMutableDictionary *restored = [stored mutableCopy];
                        BOOL wasRecalled = currentState.recalled || [stored[@"recalled"] boolValue];
                        restored[@"recalled"] = @(wasRecalled);
                        if ([restored[@"recalledAt"] doubleValue] <= 0 && [currentSnapshot[@"recalledAt"] doubleValue] > 0) restored[@"recalledAt"] = currentSnapshot[@"recalledAt"];
                        for (NSString *field in @[@"senderName", @"senderAvatar", @"conversationName", @"conversationAvatar"])
                            if (![restored[field] length] && [currentSnapshot[field] length]) restored[field] = currentSnapshot[field];
                        objc_setAssociatedObject(live, &kDYYYMessageSnapshot, restored, OBJC_ASSOCIATION_RETAIN);
                        if (wasRecalled) currentState.capturedContent = restored[@"content"];
                        DYYYPublishRecallSnapshot(currentState, restored);
                        if (wasRecalled) {
                            currentState.recalled = YES;
                            objc_setAssociatedObject(live, &kDYYYMessageRecalled, @YES, OBJC_ASSOCIATION_RETAIN);
                        }
                        DYYYScheduleRecallNotification();
                    }
                    objc_setAssociatedObject(live, &kDYYYObservedContent, nil, OBJC_ASSOCIATION_RETAIN);
                    DYYYObserveMessage(live);
                });
            }];
            return;
        }
        NSDictionary *previous = objc_getAssociatedObject(message, &kDYYYMessageSnapshot);
        id seenContent = objc_getAssociatedObject(message, &kDYYYObservedContent);
        if (content && seenContent == content && [previous[@"recalled"] boolValue] == recalled && [previous[@"key"] isEqual:key]) return;
        if (content) objc_setAssociatedObject(message, &kDYYYObservedContent, content, OBJC_ASSOCIATION_RETAIN);
        DYYYRememberMessage(message, content, recalled);
    } @finally {
        objc_setAssociatedObject(message, &kDYYYMessageGuard, nil, OBJC_ASSOCIATION_RETAIN);
    }
}

void DYYYObserveMessage(id message) {
    DYYYRecallFastState *state = DYYYFastState(message, NO);
    if (state && atomic_load_explicit(&state->nativeMutations, memory_order_acquire)) return;
    if (!message || !atomic_load_explicit(&DYYYRecallSwitch, memory_order_relaxed)) return;
    state = DYYYFastState(message, YES);
    if (atomic_exchange_explicit(&state->queued, true, memory_order_acq_rel)) return;
    dispatch_async(DYYYObservationQueue(), ^{
        atomic_store_explicit(&state->queued, false, memory_order_release);
        if (atomic_load_explicit(&state->nativeMutations, memory_order_acquire)) return;
        DYYYObservationDepth++;
        @try {
            DYYYObserveMessageNow(message);
        } @finally {
            DYYYObservationDepth--;
        }
    });
}

BOOL DYYYMessageWasRecalled(id message) {
    DYYYRecallFastState *state = DYYYFastState(message, NO);
    return DYYYFastAllowed(state) && ![state.snapshot[@"systemRecallNotice"] boolValue] && (state.recalled || [state.snapshot[@"recalled"] boolValue]);
}

NSDictionary *DYYYRecallRecordForMessage(id message) {
    DYYYRecallFastState *state = DYYYFastState(message, NO);
    return DYYYFastAllowed(state) ? state.snapshot : nil;
}

static void DYYYObserveMessageContextNow(id viewModel) {
    id message = DYYYRead(viewModel, @"iesMessage");
    id presentation = DYYYRead(viewModel, @"message");
    if (!message || !DYYYEvaluateMessagePolicy(message)) return;
    NSString *account = DYYYMessageAccountID(message);
    id conversation = DYYYRead(viewModel, @"conversation");
    DYYYRememberConversation(conversation, nil, account);
    NSDictionary *sender = DYYYPerson(DYYYRead(presentation, @"fromUser"));
    if ([sender[@"uid"] length] && ![sender[@"uid"] isEqual:DYYYIdentifier(DYYYRead(message, @"sender"))]) sender = @{};
    NSMutableDictionary *extra = [NSMutableDictionary dictionary];
    if ([sender[@"name"] length]) extra[@"senderName"] = sender[@"name"];
    if ([sender[@"avatar"] length]) {
        extra[@"senderAvatar"] = sender[@"avatar"];
    }
    if ([sender[@"remark"] length]) extra[@"senderRemark"] = sender[@"remark"];
    BOOL recallPresentation = [presentation isKindOfClass:NSClassFromString(@"AWEIMRecallMessage")];
    if (presentation) extra[@"presentationClass"] = NSStringFromClass([presentation class]);
    NSDictionary *existing = DYYYFastState(message, NO).snapshot;
    if (recallPresentation && [DYYYRead(message, @"messageType") longLongValue] == 40001 && ![existing[@"presentationClass"] length]) {
        objc_setAssociatedObject(message, &kDYYYSystemNotice, @YES, OBJC_ASSOCIATION_RETAIN);
        id origin = DYYYRead(presentation, @"recalledMsg");
        NSString *target = DYYYFirstString(origin, @[@"messageID", @"serverMessageID"]);
        if (target.length) extra[@"recallTargetID"] = target;
    }
    if (recallPresentation && ![existing[@"available"] boolValue]) {
        id recalledOriginal = DYYYRead(presentation, @"recalledMsg");
        id originalContent = DYYYRead(recalledOriginal, @"getContentDict");
        if (DYYYContentAvailable(originalContent) && !DYYYRecallContentIsNotice(originalContent)) {
            DYYYFastState(message, YES).capturedContent = originalContent;
        } else if (DYYYRecallContentIsNotice(DYYYRead(message, @"content"))) {
            objc_setAssociatedObject(message, &kDYYYSystemNotice, @YES, OBJC_ASSOCIATION_RETAIN);
        }
    }
    if (recallPresentation) {
        id original = DYYYRead(presentation, @"recalledMsg");
        if (original && ![original isKindOfClass:NSClassFromString(@"AWEIMRecallMessage")]) presentation = original;
        if ([existing[@"presentationClass"] length]) extra[@"presentationClass"] = existing[@"presentationClass"];
        else if (presentation && presentation != DYYYRead(viewModel, @"message")) extra[@"presentationClass"] = NSStringFromClass([presentation class]);
    }
    id nativeBody = DYYYRead(presentation, @"getContentDict");
    if ([nativeBody isKindOfClass:NSDictionary.class]) {
        DYYYRecallFastState *state = DYYYFastState(message, YES);
        NSMutableDictionary *snapshot = [state.snapshot mutableCopy] ?: [NSMutableDictionary dictionary];
        for (NSString *key in extra) snapshot[key] = extra[key];
        if (![snapshot[@"presentationClass"] length] && extra[@"presentationClass"]) snapshot[@"presentationClass"] = extra[@"presentationClass"];
        DYYYPublishRecallSnapshot(state, [snapshot copy]);
    }
    DYYYObserveMessage(message);
}

void DYYYObserveMessageContext(id viewModel) {
    if (!viewModel || !atomic_load_explicit(&DYYYRecallSwitch, memory_order_relaxed)) return;
    DYYYRecallFastState *state = DYYYFastState(viewModel, YES);
    if (atomic_exchange_explicit(&state->queued, true, memory_order_acq_rel)) return;
    dispatch_async(DYYYObservationQueue(), ^{
        atomic_store_explicit(&state->queued, false, memory_order_release);
        DYYYObserveMessageContextNow(viewModel);
    });
}

#pragma mark - TIMXOMessage Hook

static id (*DYYYOriginalContent)(id, SEL);
static void (*DYYYOriginalSetContent)(id, SEL, id);
static void (*DYYYOriginalSetRecalled)(id, SEL, BOOL);
static BOOL (*DYYYOriginalRecalled)(id, SEL);
static void (*DYYYOriginalApply)(id, SEL, id);
static void (*DYYYOriginalApplyV2)(id, SEL, id);
static void (*DYYYOriginalSetRecalledContent)(id, SEL, id);
static void (*DYYYOriginalVMSetup)(id, SEL, id);
static void (*DYYYOriginalVMConversation)(id, SEL, id);
static id (*DYYYOriginalChatSections)(id, SEL);

static void DYYYSetContentHook(id message, SEL selector, id content) {
    if (DYYYRecallFrameContains(DYYYRecallFrames, (__bridge const void *)message, DYYYRecallWriteContent)) return;
    DYYYRecallFrame frame = {(__bridge const void *)message, DYYYRecallWriteContent, DYYYRecallFrames};
    DYYYRecallFrames = &frame;
    DYYYRecallFastState *mutation = DYYYFastState(message, atomic_load_explicit(&DYYYRecallSwitch, memory_order_relaxed));
    if (mutation) atomic_fetch_add_explicit(&mutation->nativeMutations, 1, memory_order_acq_rel);
    @try {
        DYYYRecallFastState *state = DYYYFastState(message, atomic_load_explicit(&DYYYRecallSwitch, memory_order_relaxed));
        if (state) {
            state.rawContent = [content isKindOfClass:NSDictionary.class] ? content : nil;
            if (DYYYContentAvailable(content)) state.capturedContent = content;
            else if ([content isKindOfClass:NSDictionary.class] && [content[@"text"] isEqual:@"Recall Content Hided"]) {
                NSDictionary *prior = state.snapshot;
                if (state.allowed && ![objc_getAssociatedObject(message, &kDYYYSuppressLive) boolValue] && prior && !state.recalled && [prior[@"available"] boolValue])
                    objc_setAssociatedObject(message, &kDYYYLiveRecall, @YES, OBJC_ASSOCIATION_RETAIN);
                state.recalled = YES;
                objc_setAssociatedObject(message, &kDYYYMessageRecalled, @YES, OBJC_ASSOCIATION_RETAIN);
            }
        }
        DYYYOriginalSetContent(message, selector, content);
    } @finally {
        if (mutation) atomic_fetch_sub_explicit(&mutation->nativeMutations, 1, memory_order_release);
        DYYYRecallFrames = frame.previous;
    }
    DYYYObserveMessage(message);
}

static id DYYYContentHook(id message, SEL selector) {
    DYYYRecallFastState *state = DYYYFastState(message, NO);
    if (state && DYYYRecallFrameIsMutating(DYYYRecallFrames, (__bridge const void *)message)) return state.rawContent;
    if (DYYYRecallFrameContains(DYYYRecallFrames, (__bridge const void *)message, DYYYRecallReadContent)) return state.rawContent;
    DYYYRecallFrame frame = {(__bridge const void *)message, DYYYRecallReadContent, DYYYRecallFrames};
    DYYYRecallFrames = &frame;
    @try {
        NSDictionary *record = state.snapshot;
        // 对方已撤回且原文已留存时，仍返回原文——气泡继续显示原文，而不是撤回提示。
        if (!DYYYObservationDepth && DYYYFastAllowed(state) && state.recalled && [record[@"available"] boolValue]) return record[@"content"];
        return DYYYOriginalContent(message, selector);
    } @finally {
        DYYYRecallFrames = frame.previous;
    }
}

static void DYYYSetRecalledHook(id message, SEL selector, BOOL recalled) {
    if (DYYYRecallFrameContains(DYYYRecallFrames, (__bridge const void *)message, DYYYRecallWriteFlag)) return;
    DYYYRecallFrame frame = {(__bridge const void *)message, DYYYRecallWriteFlag, DYYYRecallFrames};
    DYYYRecallFrames = &frame;
    DYYYRecallFastState *mutation = DYYYFastState(message, atomic_load_explicit(&DYYYRecallSwitch, memory_order_relaxed));
    if (mutation) atomic_fetch_add_explicit(&mutation->nativeMutations, 1, memory_order_acq_rel);
    @try {
        DYYYRecallFastState *state = DYYYFastState(message, atomic_load_explicit(&DYYYRecallSwitch, memory_order_relaxed));
        state.rawRecalled = recalled;
        if (recalled && state) {
            NSDictionary *prior = state.snapshot;
            if (state.allowed && ![objc_getAssociatedObject(message, &kDYYYSuppressLive) boolValue] && prior && !state.recalled && ![prior[@"recalled"] boolValue])
                objc_setAssociatedObject(message, &kDYYYLiveRecall, @YES, OBJC_ASSOCIATION_RETAIN);
            state.recalled = YES;
            objc_setAssociatedObject(message, &kDYYYMessageRecalled, @YES, OBJC_ASSOCIATION_RETAIN);
        }
        DYYYOriginalSetRecalled(message, selector, recalled);
    } @finally {
        if (mutation) atomic_fetch_sub_explicit(&mutation->nativeMutations, 1, memory_order_release);
        DYYYRecallFrames = frame.previous;
    }
    DYYYObserveMessage(message);
}

static BOOL DYYYRecalledHook(id message, SEL selector) {
    DYYYRecallFastState *state = DYYYFastState(message, NO);
    if (state && DYYYRecallFrameIsMutating(DYYYRecallFrames, (__bridge const void *)message)) return state.rawRecalled;
    if (DYYYRecallFrameContains(DYYYRecallFrames, (__bridge const void *)message, DYYYRecallReadFlag)) return state.rawRecalled;
    DYYYRecallFrame frame = {(__bridge const void *)message, DYYYRecallReadFlag, DYYYRecallFrames};
    DYYYRecallFrames = &frame;
    @try {
        // 原文已留存时，对外谎称“未撤回”，抖音才会继续按原文渲染气泡；真实撤回状态只记在本地快照里。
        if (!DYYYObservationDepth && DYYYFastAllowed(state) && state.recalled && [state.snapshot[@"available"] boolValue]) return NO;
        return DYYYOriginalRecalled(message, selector);
    } @finally {
        DYYYRecallFrames = frame.previous;
    }
}

static void DYYYRecalledContentHook(id message, SEL selector, id content) {
    if (DYYYRecallFrameContains(DYYYRecallFrames, (__bridge const void *)message, DYYYRecallWriteOriginal)) return;
    DYYYRecallFrame frame = {(__bridge const void *)message, DYYYRecallWriteOriginal, DYYYRecallFrames};
    DYYYRecallFrames = &frame;
    DYYYRecallFastState *mutation = DYYYFastState(message, atomic_load_explicit(&DYYYRecallSwitch, memory_order_relaxed));
    if (mutation) atomic_fetch_add_explicit(&mutation->nativeMutations, 1, memory_order_acq_rel);
    @try {
        DYYYRecallFastState *state = DYYYFastState(message, atomic_load_explicit(&DYYYRecallSwitch, memory_order_relaxed));
        if (state && DYYYContentAvailable(content)) {
            state.capturedContent = content;
            state.recalled = YES;
            objc_setAssociatedObject(message, &kDYYYMessageRecalled, @YES, OBJC_ASSOCIATION_RETAIN);
        }
        DYYYOriginalSetRecalledContent(message, selector, content);
    } @finally {
        if (mutation) atomic_fetch_sub_explicit(&mutation->nativeMutations, 1, memory_order_release);
        DYYYRecallFrames = frame.previous;
    }
    DYYYObserveMessage(message);
}

static void DYYYApplyMessage(id message, SEL selector, id model, void (*original)(id, SEL, id)) {
    unsigned int operation = original == DYYYOriginalApplyV2 ? DYYYRecallApplyV2 : DYYYRecallApply;
    if (DYYYRecallFrameContains(DYYYRecallFrames, (__bridge const void *)message, operation)) return;
    DYYYRecallFrame frame = {(__bridge const void *)message, operation, DYYYRecallFrames};
    DYYYRecallFrames = &frame;
    DYYYRecallFastState *mutation = DYYYFastState(message, atomic_load_explicit(&DYYYRecallSwitch, memory_order_relaxed));
    if (mutation) atomic_fetch_add_explicit(&mutation->nativeMutations, 1, memory_order_acq_rel);
    id suppression = objc_getAssociatedObject(message, &kDYYYSuppressLive);
    if (!objc_getAssociatedObject(message, &kDYYYMessageSnapshot)) objc_setAssociatedObject(message, &kDYYYSuppressLive, @YES, OBJC_ASSOCIATION_RETAIN);
    @try {
        original(message, selector, model);
    } @finally {
        if (mutation) atomic_fetch_sub_explicit(&mutation->nativeMutations, 1, memory_order_release);
        objc_setAssociatedObject(message, &kDYYYSuppressLive, suppression, OBJC_ASSOCIATION_RETAIN);
        DYYYRecallFrames = frame.previous;
    }
    DYYYObserveMessage(message);
}

static void DYYYApplyHook(id message, SEL selector, id model) {
    DYYYApplyMessage(message, selector, model, DYYYOriginalApply);
}

static void DYYYApplyV2Hook(id message, SEL selector, id model) {
    DYYYApplyMessage(message, selector, model, DYYYOriginalApplyV2);
}

#pragma mark - ViewModel Hook

static void DYYYVMSetupHook(id vm, SEL selector, id message) {
    DYYYOriginalVMSetup(vm, selector, message);
    DYYYObserveMessageContext(vm);
}

static void DYYYVMConversationHook(id vm, SEL selector, id conversation) {
    DYYYOriginalVMConversation(vm, selector, conversation);
    DYYYObserveMessageContext(vm);
}

#pragma mark - 聊天信息页（···）入口

static NSString *DYYYChatConversationID(id provider) {
    id context = DYYYRead(provider, @"context");
    NSString *identifier = DYYYIdentifier(DYYYRead(DYYYRead(context, @"conversation"), @"conversationID"));
    if (!identifier.length) identifier = DYYYIdentifier(DYYYRead(DYYYRead(context, @"con"), @"identifier"));
    return identifier;
}

static id DYYYNewChatItem(Class itemClass, NSString *identifier) {
    SEL initializer = NSSelectorFromString(@"initWithIdentifier:");
    Method method = class_getInstanceMethod(itemClass, initializer);
    if (!method || method_getNumberOfArguments(method) != 3) return nil;
    char returned[16] = {0}, argument[16] = {0};
    method_getReturnType(method, returned, sizeof(returned));
    method_getArgumentType(method, 2, argument, sizeof(argument));
    if (returned[0] != '@' || argument[0] != '@') return nil;
    return [(id<DYYYRecallChatItem>)[itemClass alloc] initWithIdentifier:identifier];
}

static id DYYYChatGroupedSection(Class sectionClass, NSArray *items, id templateSection) {
    if (!items.count) return nil;
    id section = [sectionClass new];
    if (!DYYYWrite(section, @"itemViewModels", items)) return nil;
    // 原生位置：单条=0，首条=1，中间=2，末条=3；原生 cell 自行套用圆角遮罩、分隔线与主题。
    for (NSUInteger index = 0; index < items.count; index++) {
        NSInteger position = items.count == 1 ? 0 : index == 0 ? 1 : index == items.count - 1 ? 3 : 2;
        DYYYWrite(items[index], @"internalPosition", @(position));
    }
    id inset = DYYYRead(templateSection, @"sectionInset");
    if ([inset isKindOfClass:NSValue.class]) DYYYWrite(section, @"sectionInset", inset);
    NSNumber *spacing = DYYYRead(templateSection, @"sectionSpace");
    double gap = [spacing respondsToSelector:@selector(doubleValue)] ? spacing.doubleValue : 0;
    DYYYWrite(section, @"sectionSpace", @(isfinite(gap) && gap >= 8 && gap <= 32 ? gap : 12));
    return section;
}

static id DYYYChatSectionsHook(id provider, SEL selector) {
    id original = DYYYOriginalChatSections(provider, selector);
    if (![original isKindOfClass:NSArray.class]) return original;
    NSString *conversation = DYYYChatConversationID(provider);
    if (!conversation.length) return original;
    id context = DYYYRead(provider, @"context");
    NSString *account = DYYYRecallCurrentAccountID();
    if (DYYYRecallEnabledForConversation(conversation))
        DYYYRememberConversation(DYYYRead(context, @"conversation") ?: DYYYRead(context, @"con"), DYYYRead(context, @"peerUser"), account);
    for (id section in original) {
        id items = DYYYRead(section, @"itemViewModels");
        if (![items isKindOfClass:NSArray.class]) continue;
        for (id item in items)
            if ([DYYYRead(item, @"identifier") isEqual:DYYYRecallChatSwitchIdentifier]) return original;
    }
    Class sectionClass = NSClassFromString(@"IESIMChatSettingsSectionViewModel");
    if (!sectionClass) return original;
    NSMutableArray *items = [NSMutableArray array];
    __weak id weakProvider = provider;
    id toggle = DYYYNewChatItem(NSClassFromString(@"IESIMChatSettingsItemSwitchViewModel"), DYYYRecallChatSwitchIdentifier);
    if (toggle) {
        DYYYWrite(toggle, @"title", @"此聊天防撤回");
        DYYYWrite(toggle, @"describe", DYYYRecallBool(DYYYRecallEnabledKey) ? @"DYYY · 单独管理此聊天" : @"先在 DYYY 设置开启防撤回总开关");
        DYYYWrite(toggle, @"isOn", @(DYYYRecallEnabledForConversation(conversation)));
        __weak id weakToggle = toggle;
        void (^changed)(BOOL) = ^(BOOL on) {
            id activeProvider = weakProvider;
            if (![account isEqual:DYYYRecallCurrentAccountID()] || ![conversation isEqual:DYYYChatConversationID(activeProvider)]) return;
            UIViewController *source = DYYYRead(DYYYRead(activeProvider, @"context"), @"hostViewController");
            if (!DYYYRecallBool(DYYYRecallEnabledKey)) {
                DYYYWrite(weakToggle, @"isOn", @NO);
                UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"先开启防撤回" message:@"请到抖音设置 → DYYY → 消息留存，开启防撤回总开关。首次开启后，所有聊天默认生效，也可以在这里单独关闭。" preferredStyle:UIAlertControllerStyleAlert];
                [alert addAction:[UIAlertAction actionWithTitle:@"知道了" style:UIAlertActionStyleDefault handler:nil]];
                UIViewController *presenter = [source isKindOfClass:UIViewController.class] ? source : DYYYRecallTopController();
                [presenter presentViewController:alert animated:YES completion:nil];
                return;
            }
            DYYYSetConversationRecallEnabled(conversation, on);
            DYYYWrite(weakToggle, @"isOn", @(on));
        };
        if (DYYYWrite(toggle, @"manualSwitchChanged", changed)) [items addObject:toggle];
    }
    if (DYYYRecallBool(DYYYRecallArchiveEntryKey)) {
        id item = DYYYNewChatItem(NSClassFromString(@"IESIMChatSettingsItemInfoViewModel"), DYYYRecallChatItemIdentifier);
        void (^open)(void) = ^{
            id active = weakProvider;
            NSString *current = DYYYChatConversationID(active);
            if (![account isEqual:DYYYRecallCurrentAccountID()] || ![current isEqual:conversation]) return;
            id source = DYYYRead(DYYYRead(active, @"context"), @"hostViewController");
            DYYYPresentRecallArchive([source isKindOfClass:UIViewController.class] ? source : DYYYRecallTopController(), current);
        };
        if (item && DYYYWrite(item, @"title", @"已撤回的消息") && DYYYWrite(item, @"subtitle", @"查看撤回记录") && DYYYWrite(item, @"onClicked", open)) {
            DYYYWrite(item, @"disableArrow", @NO);
            [items addObject:item];
        }
    }
    if (!items.count) return original;
    NSMutableArray *sections = [original mutableCopy];
    id templateSection = [original count] > 1 ? original[1] : [original firstObject];
    NSUInteger insertion = MIN((NSUInteger)1, sections.count);
    id section = DYYYChatGroupedSection(sectionClass, items, templateSection);
    if (section) [sections insertObject:section atIndex:insertion];
    return sections;
}

#pragma mark - 撤回记录页

static NSString *DYYYRecallFormatTime(NSTimeInterval timestamp) {
    if (timestamp <= 0) return @"";
    NSDate *date = [NSDate dateWithTimeIntervalSince1970:timestamp];
    NSCalendar *calendar = NSCalendar.currentCalendar;
    NSDateFormatter *formatter = [NSDateFormatter new];
    if ([calendar isDateInToday:date]) formatter.dateFormat = @"HH:mm";
    else if ([calendar isDateInYesterday:date]) formatter.dateFormat = @"昨天 HH:mm";
    else if ([calendar component:NSCalendarUnitYear fromDate:date] == [calendar component:NSCalendarUnitYear fromDate:NSDate.date]) formatter.dateFormat = @"MM-dd HH:mm";
    else formatter.dateFormat = @"yyyy-MM-dd HH:mm";
    return [formatter stringFromDate:date];
}

static void DYYYRecallOpenWork(UIViewController *source, NSString *identifier) {
    if (!identifier.length) return;
    Class router = NSClassFromString(@"AWERouter");
    SEL selector = NSSelectorFromString(@"transferToURLString:");
    Method method = class_getClassMethod(router, selector);
    char result[16] = {0}, argument[16] = {0};
    if (method) {
        method_getReturnType(method, result, sizeof(result));
        method_getArgumentType(method, 2, argument, sizeof(argument));
    }
    if (!method || method_getNumberOfArguments(method) != 3 || !strchr("Bc", result[0]) || argument[0] != '@') return;
    @try {
        ((BOOL (*)(id, SEL, id))objc_msgSend)(router, selector, [@"aweme://aweme/detail/" stringByAppendingString:identifier]);
    } @catch (__unused NSException *exception) {
    }
}

static void DYYYRecallPresentController(UIViewController *source, UIViewController *controller) {
    if (!controller) return;
    UIViewController *presenter = source ?: DYYYRecallTopController();
    if (!presenter) return;
    if (presenter.navigationController) {
        [presenter.navigationController pushViewController:controller animated:YES];
        return;
    }
    UINavigationController *nav = [[UINavigationController alloc] initWithRootViewController:controller];
    nav.modalPresentationStyle = UIModalPresentationFullScreen;
    [presenter presentViewController:nav animated:YES completion:nil];
}

@interface DYYYRecallDetailViewController : UIViewController
@property(nonatomic, copy) NSDictionary *record;
@end

@interface DYYYRecallRecordsViewController : UITableViewController
@property(nonatomic, copy) NSString *account;
@property(nonatomic, copy) NSString *conversationID;
@property(nonatomic, strong) NSArray *records;
@property(nonatomic) BOOL loadingMore;
- (void)reloadRecords;
@end

@interface DYYYRecallArchiveViewController : UITableViewController
@property(nonatomic, copy) NSString *account;
@property(nonatomic, copy) NSString *conversationID;
@property(nonatomic, strong) NSArray *summaries;
- (void)reloadSummaries;
@end

@implementation DYYYRecallDetailViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"撤回记录";
    self.view.backgroundColor = UIColor.systemBackgroundColor;
    DYYYRecallMediaView *mediaView = [DYYYRecallMediaView new];
    mediaView.translatesAutoresizingMaskIntoConstraints = NO;
    __weak typeof(self) weakSelf = self;
    mediaView.openOriginal = ^{
        NSString *identifier = DYYYRecallWorkIdentifier(weakSelf.record);
        if (identifier.length) DYYYRecallOpenWork(weakSelf, identifier);
    };
    mediaView.openMessage = ^{
        // 详情内点按媒体默认打开原作品（有作品时）；否则什么都不做。
        NSString *identifier = DYYYRecallWorkIdentifier(weakSelf.record);
        if (identifier.length) DYYYRecallOpenWork(weakSelf, identifier);
    };
    [mediaView configureRecord:self.record];
    [self.view addSubview:mediaView];
    UILabel *summaryLabel = [UILabel new];
    summaryLabel.translatesAutoresizingMaskIntoConstraints = NO;
    summaryLabel.numberOfLines = 0;
    summaryLabel.font = [UIFont systemFontOfSize:15];
    summaryLabel.textColor = UIColor.labelColor;
    summaryLabel.text = DYYYRecallSummary(self.record);
    [self.view addSubview:summaryLabel];
    UILabel *metaLabel = [UILabel new];
    metaLabel.translatesAutoresizingMaskIntoConstraints = NO;
    metaLabel.numberOfLines = 0;
    metaLabel.font = [UIFont systemFontOfSize:13];
    metaLabel.textColor = UIColor.secondaryLabelColor;
    NSString *sender = [self.record[@"senderName"] length] ? self.record[@"senderName"] : ([self.record[@"sender"] length] ? self.record[@"sender"] : @"对方");
    metaLabel.text = [NSString stringWithFormat:@"%@ · %@ · %@", sender, DYYYRecallFormatTime([self.record[@"recalledAt"] doubleValue] ?: [self.record[@"timestamp"] doubleValue]), [self.record[@"available"] boolValue] ? @"原文已留存" : @"未取得原文"];
    [self.view addSubview:metaLabel];
    [NSLayoutConstraint activateConstraints:@[
        [mediaView.topAnchor constraintEqualToAnchor:self.view.safeAreaLayoutGuide.topAnchor constant:12],
        [mediaView.leadingAnchor constraintEqualToAnchor:self.view.leadingAnchor constant:16],
        [mediaView.trailingAnchor constraintEqualToAnchor:self.view.trailingAnchor constant:-16],
        [summaryLabel.topAnchor constraintEqualToAnchor:mediaView.bottomAnchor constant:16],
        [summaryLabel.leadingAnchor constraintEqualToAnchor:self.view.leadingAnchor constant:16],
        [summaryLabel.trailingAnchor constraintEqualToAnchor:self.view.trailingAnchor constant:-16],
        [metaLabel.topAnchor constraintEqualToAnchor:summaryLabel.bottomAnchor constant:8],
        [metaLabel.leadingAnchor constraintEqualToAnchor:self.view.leadingAnchor constant:16],
        [metaLabel.trailingAnchor constraintEqualToAnchor:self.view.trailingAnchor constant:-16],
    ]];
    NSString *workID = DYYYRecallWorkIdentifier(self.record);
    if (workID.length) {
        self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc] initWithTitle:@"打开原作品" style:UIBarButtonItemStylePlain target:self action:@selector(openWork)];
    }
}

- (void)openWork {
    DYYYRecallOpenWork(self, DYYYRecallWorkIdentifier(self.record));
}

@end

@implementation DYYYRecallRecordsViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"已撤回的消息";
    [self.tableView registerClass:UITableViewCell.class forCellReuseIdentifier:@"DYYYRecallRecordCell"];
    self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc] initWithImage:[UIImage systemImageNamed:@"ellipsis.circle"] style:UIBarButtonItemStylePlain target:self action:@selector(manageConversation)];
    self.refreshControl = [UIRefreshControl new];
    [self.refreshControl addTarget:self action:@selector(reloadRecords) forControlEvents:UIControlEventValueChanged];
    [NSNotificationCenter.defaultCenter addObserver:self selector:@selector(reloadRecords) name:DYYYRecallChangedNotification object:nil];
    [self reloadRecords];
}

- (void)dealloc {
    [NSNotificationCenter.defaultCenter removeObserver:self];
}

- (void)reloadRecords {
    __weak typeof(self) weakSelf = self;
    [[DYYYRecallStore shared] recordsForAccount:self.account conversation:self.conversationID offset:0 completion:^(NSArray *records) {
        weakSelf.records = records;
        [weakSelf.refreshControl endRefreshing];
        [weakSelf.tableView reloadData];
    }];
}

- (void)manageConversation {
    UIAlertController *sheet = [UIAlertController alertControllerWithTitle:@"此会话的记录" message:nil preferredStyle:UIAlertControllerStyleActionSheet];
    __weak typeof(self) weakSelf = self;
    NSString *account = self.account, *conversation = self.conversationID;
    [sheet addAction:[UIAlertAction actionWithTitle:@"删除此会话全部记录" style:UIAlertActionStyleDestructive handler:^(__unused UIAlertAction *action) {
        UIAlertController *confirm = [UIAlertController alertControllerWithTitle:@"删除此会话全部记录？" message:@"将删除本地消息记录，其他联系人不受影响。" preferredStyle:UIAlertControllerStyleAlert];
        [confirm addAction:[UIAlertAction actionWithTitle:@"删除全部" style:UIAlertActionStyleDestructive handler:^(__unused UIAlertAction *a) {
            if ([account isEqual:DYYYRecallCurrentAccountID()]) DYYYClearConversationRecallArchive(conversation);
            [weakSelf reloadRecords];
        }]];
        [confirm addAction:[UIAlertAction actionWithTitle:@"取消" style:UIAlertActionStyleCancel handler:nil]];
        [weakSelf presentViewController:confirm animated:YES completion:nil];
    }]];
    [sheet addAction:[UIAlertAction actionWithTitle:@"取消" style:UIAlertActionStyleCancel handler:nil]];
    sheet.popoverPresentationController.barButtonItem = self.navigationItem.rightBarButtonItem;
    [self presentViewController:sheet animated:YES completion:nil];
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return self.records.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"DYYYRecallRecordCell" forIndexPath:indexPath];
    NSDictionary *record = self.records[indexPath.row];
    cell.textLabel.text = DYYYRecallSummary(record);
    cell.textLabel.numberOfLines = 2;
    NSString *sender = [record[@"senderName"] length] ? record[@"senderName"] : ([record[@"sender"] length] ? record[@"sender"] : @"对方");
    cell.detailTextLabel.text = [NSString stringWithFormat:@"%@ · %@", sender, DYYYRecallFormatTime([record[@"recalledAt"] doubleValue] ?: [record[@"timestamp"] doubleValue])];
    cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    DYYYRecallDetailViewController *detail = [DYYYRecallDetailViewController new];
    detail.record = self.records[indexPath.row];
    [self.navigationController pushViewController:detail animated:YES];
}

- (UISwipeActionsConfiguration *)tableView:(UITableView *)tableView trailingSwipeActionsConfigurationForRowAtIndexPath:(NSIndexPath *)indexPath {
    if ((NSUInteger)indexPath.row >= self.records.count) return nil;
    NSDictionary *record = self.records[indexPath.row];
    __weak typeof(self) weakSelf = self;
    NSString *account = self.account;
    UIContextualAction *remove = [UIContextualAction contextualActionWithStyle:UIContextualActionStyleDestructive title:@"删除" handler:^(UIContextualAction *action, UIView *view, void (^completion)(BOOL)) {
        completion(NO);
        if (![account isEqual:DYYYRecallCurrentAccountID()] || ![weakSelf.account isEqual:account]) return;
        [[DYYYRecallStore shared] removeForAccount:account key:record[@"key"] completion:^{
            [weakSelf reloadRecords];
        }];
    }];
    UISwipeActionsConfiguration *configuration = [UISwipeActionsConfiguration configurationWithActions:@[remove]];
    configuration.performsFirstActionWithFullSwipe = NO;
    return configuration;
}

@end

@implementation DYYYRecallArchiveViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"已撤回的消息";
    [self.tableView registerClass:UITableViewCell.class forCellReuseIdentifier:@"DYYYRecallConversationCell"];
    self.refreshControl = [UIRefreshControl new];
    [self.refreshControl addTarget:self action:@selector(reloadSummaries) forControlEvents:UIControlEventValueChanged];
    [NSNotificationCenter.defaultCenter addObserver:self selector:@selector(reloadSummaries) name:DYYYRecallChangedNotification object:nil];
    [NSNotificationCenter.defaultCenter addObserver:self selector:@selector(reloadSummaries) name:UIApplicationDidBecomeActiveNotification object:nil];
    [self reloadSummaries];
}

- (void)dealloc {
    [NSNotificationCenter.defaultCenter removeObserver:self];
}

- (void)reloadSummaries {
    __weak typeof(self) weakSelf = self;
    [[DYYYRecallStore shared] conversationSummaries:self.account completion:^(NSArray *summaries) {
        weakSelf.summaries = summaries;
        [weakSelf.refreshControl endRefreshing];
        [weakSelf.tableView reloadData];
    }];
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return self.summaries.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"DYYYRecallConversationCell" forIndexPath:indexPath];
    NSDictionary *summary = self.summaries[indexPath.row];
    NSString *groupPrefix = [summary[@"group"] boolValue] ? @"群聊 · " : @"";
    cell.textLabel.text = [NSString stringWithFormat:@"%@%@（%@ 条）", groupPrefix, summary[@"name"], summary[@"count"]];
    cell.detailTextLabel.text = [NSString stringWithFormat:@"%@ · %@", summary[@"summary"], DYYYRecallFormatTime([summary[@"time"] doubleValue])];
    cell.detailTextLabel.numberOfLines = 2;
    cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    NSDictionary *summary = self.summaries[indexPath.row];
    DYYYRecallRecordsViewController *records = [DYYYRecallRecordsViewController new];
    records.account = self.account;
    records.conversationID = summary[@"conversation"];
    [self.navigationController pushViewController:records animated:YES];
}

- (UISwipeActionsConfiguration *)tableView:(UITableView *)tableView trailingSwipeActionsConfigurationForRowAtIndexPath:(NSIndexPath *)indexPath {
    if ((NSUInteger)indexPath.row >= self.summaries.count) return nil;
    NSDictionary *summary = self.summaries[indexPath.row];
    __weak typeof(self) weakSelf = self;
    NSString *account = self.account;
    UIContextualAction *remove = [UIContextualAction contextualActionWithStyle:UIContextualActionStyleDestructive title:@"删除" handler:^(UIContextualAction *action, UIView *view, void (^completion)(BOOL)) {
        completion(NO);
        if (![account isEqual:DYYYRecallCurrentAccountID()] || ![weakSelf.account isEqual:account]) return;
        [[DYYYRecallStore shared] removeConversation:summary[@"conversation"] account:account completion:^{
            [weakSelf reloadSummaries];
        }];
    }];
    UISwipeActionsConfiguration *configuration = [UISwipeActionsConfiguration configurationWithActions:@[remove]];
    configuration.performsFirstActionWithFullSwipe = NO;
    return configuration;
}

@end

void DYYYPresentRecallArchive(UIViewController *source, NSString *conversationID) {
    if (!NSThread.isMainThread) {
        dispatch_async(dispatch_get_main_queue(), ^{
            DYYYPresentRecallArchive(source, conversationID);
        });
        return;
    }
    NSString *account = DYYYRecallCurrentAccountID();
    if (conversationID.length) {
        DYYYRecallRecordsViewController *records = [DYYYRecallRecordsViewController new];
        records.account = account;
        records.conversationID = conversationID;
        DYYYRecallPresentController(source, records);
    } else {
        DYYYRecallArchiveViewController *archive = [DYYYRecallArchiveViewController new];
        archive.account = account;
        DYYYRecallPresentController(source, archive);
    }
}

#pragma mark - 公共 API

void DYYYClearRecallArchive(void) {
    NSString *account = DYYYRecallCurrentAccountID();
    [[DYYYRecallStore shared] removeForAccount:account key:nil completion:nil];
}

void DYYYClearConversationRecallArchive(NSString *conversationID) {
    [[DYYYRecallStore shared] removeConversation:conversationID account:DYYYRecallCurrentAccountID() completion:nil];
}

void DYYYRecallStorageStatistics(void (^completion)(NSDictionary *)) {
    [[DYYYRecallStore shared] storageStatistics:completion];
}

void DYYYRecallMaintenance(void) {
    [[DYYYRecallStore shared] maintenance];
}

NSString *DYYYRecallStorageStatus(void) {
    DYYYRecallStore *store = [DYYYRecallStore shared];
    @synchronized (store) {
        return store.status;
    }
}

NSUInteger DYYYRecallCount(void) {
    NSString *account = DYYYRecallCurrentAccountID();
    if (!account.length) return 0;
    DYYYRecallStore *store = [DYYYRecallStore shared];
    NSUInteger count = 0;
    @synchronized (store) {
        for (NSString *key in store.archivedKeys) {
            if ([store.forgottenKeys containsObject:key]) continue;
            NSDictionary *record = store.messages[key];
            if ([record[@"account"] isEqual:account]) count++;
        }
    }
    return count;
}

#pragma mark - 安装

void DYYYInstallRecallHooks(void) {
    static dispatch_once_t once;
    dispatch_once(&once, ^{
        [DYYYRecallStore shared];
        DYYYRefreshRecallPolicy();
        // 只订阅本模块自有的通知与系统生命周期通知；绝不订阅 NSUserDefaultsDidChangeNotification。
        for (NSNotificationName name in @[DYYYRecallPreferencesChangedNotification, DYYYRecallChangedNotification, UIApplicationDidBecomeActiveNotification])
            [NSNotificationCenter.defaultCenter addObserverForName:name object:nil queue:nil usingBlock:^(__unused NSNotification *note) {
                DYYYRefreshRecallPolicy();
            }];
    });
    DYYYRecallHookChecked(NSClassFromString(@"AWEIMMessageViewModel"), @"setupWithMessage:", (IMP)DYYYVMSetupHook, (IMP *)&DYYYOriginalVMSetup, 3, 'v', '@');
    DYYYRecallHookChecked(NSClassFromString(@"AWEIMMessageViewModel"), @"setConversation:", (IMP)DYYYVMConversationHook, (IMP *)&DYYYOriginalVMConversation, 3, 'v', '@');
    Class message = NSClassFromString(@"TIMXOMessage");
    DYYYRecallHookChecked(message, @"content", (IMP)DYYYContentHook, (IMP *)&DYYYOriginalContent, 2, '@', 0);
    DYYYRecallHookChecked(message, @"setContent:", (IMP)DYYYSetContentHook, (IMP *)&DYYYOriginalSetContent, 3, 'v', '@');
    DYYYRecallHookChecked(message, @"recalled", (IMP)DYYYRecalledHook, (IMP *)&DYYYOriginalRecalled, 2, 'B', 0);
    DYYYRecallHookChecked(message, @"setRecalled:", (IMP)DYYYSetRecalledHook, (IMP *)&DYYYOriginalSetRecalled, 3, 'v', 'B');
    DYYYRecallHookChecked(message, @"setRecalledContent:", (IMP)DYYYRecalledContentHook, (IMP *)&DYYYOriginalSetRecalledContent, 3, 'v', '@');
    DYYYRecallHookChecked(message, @"applyAttributesFromModel:", (IMP)DYYYApplyHook, (IMP *)&DYYYOriginalApply, 3, 'v', '@');
    DYYYRecallHookChecked(message, @"applyAttributesFromModelV2:", (IMP)DYYYApplyV2Hook, (IMP *)&DYYYOriginalApplyV2, 3, 'v', '@');
    DYYYRecallHookChecked(NSClassFromString(@"IESIMChatSettingsListViewModelProviderComponent"), @"createSectionViewModels", (IMP)DYYYChatSectionsHook, (IMP *)&DYYYOriginalChatSections, 2, '@', 0);
}
