// DYYYRadarApi.h — 特别关注：抖音数据入口（资料/抖音号解析/互关好友/喜欢列表）。
// 由 DY778RadarApi.h 移植，仅重命名。
#import "DYYYRadarNetwork.h"

NS_ASSUME_NONNULL_BEGIN

@interface DYYYRadarApi : NSObject
+ (void)profile:(NSDictionary *)target owner:(NSString *)owner completion:(DYYYRadarReply)completion;
+ (void)resolveHandle:(NSString *)handle owner:(NSString *)owner completion:(DYYYRadarReply)completion;
+ (void)friendsForOwner:(NSString *)owner completion:(DYYYRadarReply)completion;
+ (void)likes:(NSDictionary *)target cursor:(NSNumber *)cursor owner:(NSString *)owner completion:(DYYYRadarReply)completion;
@end

NS_ASSUME_NONNULL_END
