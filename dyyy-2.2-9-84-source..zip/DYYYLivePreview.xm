// DYYYLivePreview.xm
// 推荐页直播卡片人数 + 开播时长（DY778 直播信息移植，2.2-9-56，用户 2026-11-11 点名全套按截图做）
//
// 范围说明：
//   照搬 DY778 1.0-3（GitHub，2026-11-05）的核心做法：
//     - 钩 AWELiveNewPreStreamViewController（推荐页直播预览卡片），卡片中下方挂两个独立小胶囊；
//     - 人数先读卡片模型，读不到再调抖音自己的 HTSLiveRoomAPI fetchRoomInfoWithRoomID 拿；
//     - 开播时间从房间模型 startTime/start_time/liveStartTime/createTime/create_time 提取，算 HH:MM:SS；
//     - 卡片停稳（0.20 秒不动）且数据齐了才显示，滚动中、卡片不可见、切后台就暂停刷新；
//     - 请求有 in-flight/超时（间隔 x 1.5，至少 5 秒）/代际守卫，只在卡片基本可见且不在滚动时刷。
//   按 DYYY 规矩改动的地方：
//     - 人数简洁格式不用 DY778 的 1 位小数，改用 DYYY 直播间已有的万规则：>=10000 除以 10000、
//       保留 2 位小数、去末尾 0（484499→48.45万、12500→1.25万、10000→1万，<10000 原样；>=1亿用亿）；
//     - 设置键全部换成 DYYY 前缀（DYYYLivePreview*），走 NSUserDefaults + DYYYGetBool/DYYYGetString；
//     - 不搬 DY778 的自定义设置控制器，设置入口沿用 DYYY 现有的 AWESetting 模型 + 自定义面板。
//   自己重做的（GitHub 1.0-3 源码里没有，用户截图那版才有）：
//     - 卡片胶囊样式：对齐（左/中/右）、上下顺序（人数在上/时长在上）、大小（小/中/大）；
//     - 卡片位置：两个胶囊整体可拖动，拖完保存位置，横屏/竖屏分别记忆；设置里可一键恢复默认位置。
//   不搬：DY778 其他功能（消息防撤回、编辑历史、特别关注、福袋、自动点赞、操作确认、星牌、
//   数字自定义等）一律不搬；直播间浮层不另做一套胶囊，沿用 DYYY 已有的 DYYYLiveDurationView，
//   只在 DYYY.xm 里给它加样式调节（字号/文字色/背景色/不透明度）。
//   不动：DYYY.xm 里已有的 AWELiveNewPreStreamViewController 文案防重复上移（-23）与全屏判断，
//   这里只加预览控制器的生命周期钩子；-48 全屏分页、玻璃（-52）、长按竖排/黄色（-55）都不动。
//   注意：绝对不要在 layoutSubviews 里改帧（-53 教训）；这里定位只在 refresh/layoutBadgeInView
//   里按保存的位置算一次，拖动只用手势改 badge.frame，拖动期间 refresh 跳过布局。
//   2.2-9-60（胶囊出得慢，约 2 秒）：时间线见 refresh/prefetch 注释——模型常不带
//   人数/开播时间，须等 HTSLiveRoomAPI 网络回来（约 0.5–1.5 秒），再加停稳 0.20 秒，
//   0.5 秒重试跑完后又要等主定时器下一跳。修法只用 -59 已有触发集：activate 时预取
//   一次（请求提前到卡片出现时发，RTT 与滚动重叠）+ 数据缺失时最多两发单次延时补刷
//   （0.35/0.90 秒，代际守卫、有上限）。不加回状态标签钩、NSUserDefaults 订阅、
//   layoutRetryRearms。模型没数且网络慢时 1 秒左右是下限，做不到 0 秒。

#import "AwemeHeaders.h"
#import "DYYYUtils.h"
#import <QuartzCore/QuartzCore.h>
#import <errno.h>
#import <limits.h>
#import <math.h>
#import <objc/runtime.h>
#import <stdlib.h>
#import <string.h>

#pragma mark - 设置键

static NSString *const kDYYYLivePreviewViewersKey = @"DYYYLivePreviewViewers";
static NSString *const kDYYYLivePreviewCountFormatKey = @"DYYYLivePreviewCountFormat";
static NSString *const kDYYYLivePreviewRefreshKey = @"DYYYLivePreviewRefresh";
static NSString *const kDYYYLivePreviewCardDurationKey = @"DYYYLivePreviewCardDuration";
static NSString *const kDYYYLivePreviewCapsuleAlignKey = @"DYYYLivePreviewCapsuleAlign";
static NSString *const kDYYYLivePreviewCapsuleOrderKey = @"DYYYLivePreviewCapsuleOrder";
static NSString *const kDYYYLivePreviewCapsuleSizeKey = @"DYYYLivePreviewCapsuleSize";
static NSString *const kDYYYLivePreviewCardPortraitXKey = @"DYYYLivePreviewCardPortraitX";
static NSString *const kDYYYLivePreviewCardPortraitYKey = @"DYYYLivePreviewCardPortraitY";
static NSString *const kDYYYLivePreviewCardLandscapeXKey = @"DYYYLivePreviewCardLandscapeX";
static NSString *const kDYYYLivePreviewCardLandscapeYKey = @"DYYYLivePreviewCardLandscapeY";

#pragma mark - 安全取值与格式化

static id DYYYLivePreviewValueForKey(id object, NSString *key) {
    if (!object || object == [NSNull null] || key.length == 0) {
        return nil;
    }
    if ([object isKindOfClass:[NSDictionary class]]) {
        id value = [object objectForKey:key];
        return value == [NSNull null] ? nil : value;
    }
    Class objectClass = [object class];
    if (![object respondsToSelector:NSSelectorFromString(key)] &&
        !class_getInstanceVariable(objectClass, key.UTF8String) &&
        !class_getInstanceVariable(objectClass, [@"_" stringByAppendingString:key].UTF8String)) {
        return nil;
    }
    @try {
        id value = [object valueForKey:key];
        return value == [NSNull null] ? nil : value;
    } @catch (__unused NSException *exception) {
        return nil;
    }
}

static NSNumber *DYYYLivePreviewOnlineCount(id value) {
    if ([value isKindOfClass:[NSNumber class]]) {
        value = [value stringValue];
    }
    if (![value isKindOfClass:[NSString class]] || [value length] == 0) {
        return nil;
    }
    const char *digits = [value UTF8String];
    if (!digits || strlen(digits) != [value lengthOfBytesUsingEncoding:NSUTF8StringEncoding]) {
        return nil;
    }
    for (const char *cursor = digits; *cursor; ++cursor) {
        if (*cursor < '0' || *cursor > '9') {
            return nil;
        }
    }
    errno = 0;
    char *end = NULL;
    unsigned long long count = strtoull(digits, &end, 10);
    if (errno == ERANGE || end == digits || *end || count > LLONG_MAX) {
        return nil;
    }
    return @((long long)count);
}

static double DYYYLivePreviewDoubleOrDefault(NSString *raw, double fallback) {
    if (!raw || raw.length == 0) {
        return fallback;
    }
    double value = [raw doubleValue];
    return (value == 0 && ![raw isEqualToString:@"0"] && ![raw isEqualToString:@"0.0"]) ? fallback : value;
}

// DYYY 万规则（与直播间已有的万显示一致）：>=10000 除以 10000、保留 2 位小数、去末尾 0；
// >=1亿用亿、同样 2 位小数；<10000 原样。不要用 DY778 的 1 位小数规则。
static NSString *DYYYLivePreviewFormatCountCompact(long long count) {
    if (count < 0) {
        return @"0";
    }
    if (count < 10000) {
        return [NSString stringWithFormat:@"%lld", count];
    }
    double value = (double)count / 10000.0;
    NSString *unit = @"万";
    if (value >= 10000.0) {
        value /= 10000.0;
        unit = @"亿";
    }
    NSString *number = [NSString stringWithFormat:@"%.2f", value];
    while ([number hasSuffix:@"0"]) {
        number = [number substringToIndex:number.length - 1];
    }
    if ([number hasSuffix:@"."]) {
        number = [number substringToIndex:number.length - 1];
    }
    return [number stringByAppendingString:unit];
}

static NSString *DYYYLivePreviewFormatCountPrecise(long long count) {
    if (count < 0) {
        return @"0";
    }
    return [NSString stringWithFormat:@"%lld", count];
}

static double DYYYLivePreviewNormalizeTimestamp(double value) {
    if (!isfinite(value) || value <= 0) {
        return 0;
    }
    if (value > 1e17) {
        value /= 1e9;
    } else if (value > 1e14) {
        value /= 1e6;
    } else if (value > 1e11) {
        value /= 1e3;
    }
    return value >= 1e9 && value < 1e11 ? value : 0;
}

static double DYYYLivePreviewElapsed(double start, double now) {
    start = DYYYLivePreviewNormalizeTimestamp(start);
    if (!start || !isfinite(now) || start > now + 5 || now - start > 366 * 86400) {
        return -1;
    }
    return fmax(0, now - start);
}

static NSString *DYYYLivePreviewElapsedDigits(double start) {
    double elapsed = DYYYLivePreviewElapsed(start, [[NSDate date] timeIntervalSince1970]);
    if (!isfinite(elapsed) || elapsed < 0 || elapsed > 366 * 86400) {
        return nil;
    }
    unsigned long long seconds = (unsigned long long)elapsed;
    return [NSString stringWithFormat:@"%02llu:%02llu:%02llu", seconds / 3600, (seconds / 60) % 60, seconds % 60];
}

static BOOL DYYYLivePreviewRoomAPIAvailable(Class cls) {
    if (!cls) {
        return NO;
    }
    Method initialize = class_getInstanceMethod(cls, @selector(initWithRoomID:));
    Method fetch = class_getInstanceMethod(cls, @selector(fetchRoomInfoWithRoomID:completion:));
    if (!initialize || !fetch) {
        return NO;
    }
    NSMethodSignature *a = [NSMethodSignature signatureWithObjCTypes:method_getTypeEncoding(initialize)];
    NSMethodSignature *b = [NSMethodSignature signatureWithObjCTypes:method_getTypeEncoding(fetch)];
    return a.numberOfArguments == 3 && a.methodReturnType[0] == '@' && [a getArgumentTypeAtIndex:2][0] == '@' &&
           b.numberOfArguments == 4 && b.methodReturnType[0] == 'v' && [b getArgumentTypeAtIndex:2][0] == '@' &&
           !strcmp([b getArgumentTypeAtIndex:3], "@?");
}

static NSString *DYYYLivePreviewRoomIdentifier(id room) {
    for (NSString *key in @[@"roomID", @"idStr", @"id_str", @"id"]) {
        NSString *value = nil;
        id raw = DYYYLivePreviewValueForKey(room, key);
        if ([raw isKindOfClass:[NSNumber class]]) {
            value = [raw stringValue];
        } else if ([raw isKindOfClass:[NSString class]]) {
            value = raw;
        }
        if (value.length && ![value isEqual:@"0"] &&
            [value rangeOfCharacterFromSet:NSCharacterSet.decimalDigitCharacterSet.invertedSet].location == NSNotFound) {
            return value;
        }
    }
    return nil;
}

static double DYYYLivePreviewRoomStart(id room, NSString *roomID, NSUInteger depth) {
    if (!room || depth > 5) {
        return 0;
    }
    if ([room isKindOfClass:NSString.class] || [room isKindOfClass:NSData.class]) {
        NSData *data = [room isKindOfClass:NSString.class] ? [room dataUsingEncoding:NSUTF8StringEncoding] : room;
        if (data.length > 1024 * 1024) {
            return 0;
        }
        room = [NSJSONSerialization JSONObjectWithData:data options:0 error:nil];
        if (!room) {
            return 0;
        }
    }
    NSString *identifier = DYYYLivePreviewRoomIdentifier(room);
    if (identifier.length && roomID.length && ![identifier isEqual:roomID]) {
        return 0;
    }
    if (identifier.length) {
        for (NSString *key in @[@"startTime", @"start_time", @"liveStartTime", @"createTime", @"create_time"]) {
            id value = DYYYLivePreviewValueForKey(room, key);
            double time = [value respondsToSelector:@selector(doubleValue)] ? DYYYLivePreviewNormalizeTimestamp([value doubleValue]) : 0;
            if (DYYYLivePreviewElapsed(time, [[NSDate date] timeIntervalSince1970]) >= 0) {
                return time;
            }
        }
    }
    if ([room isKindOfClass:[NSArray class]]) {
        for (id item in room) {
            double time = DYYYLivePreviewRoomStart(item, roomID, depth + 1);
            if (time) {
                return time;
            }
        }
    }
    for (NSString *key in @[@"rawRoom", @"room", @"roomModel", @"rawHTSLiveRoomModel", @"rawDataRoomModel", @"data", @"room_info", @"roomInfo", @"liveRoom", @"rooms"]) {
        id nested = DYYYLivePreviewValueForKey(room, key);
        if (!nested || nested == room) {
            continue;
        }
        double time = DYYYLivePreviewRoomStart(nested, roomID, depth + 1);
        if (time) {
            return time;
        }
    }
    return 0;
}

#pragma mark - 胶囊视图

// 大小三档：小（字 11、高 24）、中（字 12、高 28，DY778 默认）、大（字 14、高 32）。
typedef NS_ENUM(NSInteger, DYYYLivePreviewCapsuleSize) {
    DYYYLivePreviewCapsuleSizeSmall = 0,
    DYYYLivePreviewCapsuleSizeMedium = 1,
    DYYYLivePreviewCapsuleSizeLarge = 2,
};

@interface DYYYLivePreviewCapsule : UIView
@property(nonatomic, strong) UILabel *label;
@property(nonatomic, strong) UIImageView *symbol;
@property(nonatomic, assign) BOOL clock;
@property(nonatomic, assign) DYYYLivePreviewCapsuleSize capsuleSize;
- (void)setViewerCountString:(NSString *)text;
- (void)setElapsedString:(NSString *)text;
- (void)applyCapsuleSize:(DYYYLivePreviewCapsuleSize)size;
@end

@implementation DYYYLivePreviewCapsule

- (instancetype)initWithFrame:(CGRect)frame {
    if ((self = [super initWithFrame:frame])) {
        self.userInteractionEnabled = YES;
        self.backgroundColor = [UIColor.blackColor colorWithAlphaComponent:.64];
        self.layer.cornerRadius = 14;
        self.layer.cornerCurve = kCACornerCurveContinuous;
        _label = [UILabel new];
        _label.textColor = UIColor.whiteColor;
        _label.font = [UIFont monospacedDigitSystemFontOfSize:12 weight:UIFontWeightSemibold];
        _label.textAlignment = NSTextAlignmentCenter;
        _label.numberOfLines = 1;
        _label.adjustsFontSizeToFitWidth = YES;
        _label.minimumScaleFactor = .8;
        _symbol = [[UIImageView alloc] initWithImage:[UIImage systemImageNamed:@"person.2.fill"
            withConfiguration:[UIImageSymbolConfiguration configurationWithPointSize:11 weight:UIImageSymbolWeightSemibold]]];
        _symbol.tintColor = UIColor.whiteColor;
        _symbol.contentMode = UIViewContentModeScaleAspectFit;
        [self addSubview:_symbol];
        [self addSubview:_label];
        self.isAccessibilityElement = YES;
        _capsuleSize = DYYYLivePreviewCapsuleSizeMedium;
    }
    return self;
}

- (void)applyCapsuleSize:(DYYYLivePreviewCapsuleSize)size {
    _capsuleSize = size;
    CGFloat fontSize = size == DYYYLivePreviewCapsuleSizeSmall ? 11 : (size == DYYYLivePreviewCapsuleSizeLarge ? 14 : 12);
    CGFloat iconSize = size == DYYYLivePreviewCapsuleSizeSmall ? 10 : (size == DYYYLivePreviewCapsuleSizeLarge ? 13 : 11);
    self.label.font = [UIFont monospacedDigitSystemFontOfSize:fontSize weight:UIFontWeightSemibold];
    self.symbol.image = [UIImage systemImageNamed:(self.clock ? @"clock" : @"person.2.fill")
        withConfiguration:[UIImageSymbolConfiguration configurationWithPointSize:iconSize weight:UIImageSymbolWeightSemibold]];
    [self invalidateIntrinsicContentSize];
    [self setNeedsLayout];
}

- (void)setViewerCountString:(NSString *)text {
    if ([self.label.text isEqualToString:text]) {
        return;
    }
    self.label.text = text;
    self.accessibilityLabel = [NSString stringWithFormat:@"在线人数 %@", text];
    [self invalidateIntrinsicContentSize];
    [self setNeedsLayout];
}

- (void)setElapsedString:(NSString *)text {
    if (!self.clock) {
        self.clock = YES;
        [self applyCapsuleSize:self.capsuleSize];
    }
    if ([self.label.text isEqualToString:text]) {
        return;
    }
    self.label.text = text;
    self.accessibilityLabel = [NSString stringWithFormat:@"开播时长 %@", text];
    [self invalidateIntrinsicContentSize];
    [self setNeedsLayout];
}

- (CGSize)intrinsicContentSize {
    CGFloat height = self.capsuleSize == DYYYLivePreviewCapsuleSizeSmall ? 24 : (self.capsuleSize == DYYYLivePreviewCapsuleSizeLarge ? 32 : 28);
    CGFloat padding = self.capsuleSize == DYYYLivePreviewCapsuleSizeSmall ? 30 : (self.capsuleSize == DYYYLivePreviewCapsuleSizeLarge ? 38 : 34);
    CGSize size = [self.label sizeThatFits:CGSizeMake(260, 20)];
    return CGSizeMake(MIN(294, MAX(18, ceil(size.width)) + padding), height);
}

- (void)layoutSubviews {
    // 只排胶囊内部的图标与文字，绝不改自己的 frame（-53 教训）。
    [super layoutSubviews];
    CGFloat iconSide = self.capsuleSize == DYYYLivePreviewCapsuleSizeSmall ? 10 : (self.capsuleSize == DYYYLivePreviewCapsuleSizeLarge ? 13 : 12);
    self.symbol.frame = CGRectMake(8, (self.bounds.size.height - iconSide) / 2, iconSide, iconSide);
    self.label.frame = CGRectMake(24, 1, MAX(1, self.bounds.size.width - 34), self.bounds.size.height - 2);
    self.layer.cornerRadius = self.bounds.size.height / 2;
}

@end

#pragma mark - 房间模型收集

static id DYYYLivePreviewDecodeRoomData(id object) {
    NSData *data = nil;
    if ([object isKindOfClass:[NSString class]]) {
        data = [object dataUsingEncoding:NSUTF8StringEncoding];
    } else if ([object isKindOfClass:[NSData class]]) {
        data = object;
    } else {
        return object;
    }
    if (data.length == 0 || data.length > 1024 * 1024) {
        return nil;
    }
    id decoded = [NSJSONSerialization JSONObjectWithData:data options:0 error:NULL];
    return [decoded isKindOfClass:[NSDictionary class]] ? decoded : nil;
}

static void DYYYLivePreviewAppendRoom(NSMutableArray *rooms, id room) {
    if (room && room != [NSNull null] && [rooms indexOfObjectIdenticalTo:room] == NSNotFound) {
        [rooms addObject:room];
    }
}

static void DYYYLivePreviewAppendAwemeRooms(NSMutableArray *rooms, id model) {
    id rawModel = DYYYLivePreviewValueForKey(model, @"rawDataRoomModel");
    DYYYLivePreviewAppendRoom(rooms, DYYYLivePreviewValueForKey(model, @"rawHTSLiveRoomModel"));
    DYYYLivePreviewAppendRoom(rooms, DYYYLivePreviewValueForKey(rawModel, @"rawRoom"));
    DYYYLivePreviewAppendRoom(rooms, rawModel);
    DYYYLivePreviewAppendRoom(rooms, DYYYLivePreviewValueForKey(model, @"roomModel"));
}

static NSArray *DYYYLivePreviewPreviewRooms(UIViewController *controller, UIView *statusLabel,
                                             NSString *__autoreleasing *currentRoomID) {
    *currentRoomID = nil;
    id viewModel = DYYYLivePreviewValueForKey(controller, @"viewModel");
    id model = DYYYLivePreviewValueForKey(controller, @"model") ?: DYYYLivePreviewValueForKey(viewModel, @"model");
    id cellRoom = DYYYLivePreviewValueForKey(model, @"cellRoom");
    NSMutableArray *feedRooms = [NSMutableArray array];
    DYYYLivePreviewAppendAwemeRooms(feedRooms, model);
    DYYYLivePreviewAppendAwemeRooms(feedRooms, cellRoom);
    DYYYLivePreviewAppendRoom(feedRooms, DYYYLivePreviewDecodeRoomData(DYYYLivePreviewValueForKey(model, @"liveRoomRawData")));
    DYYYLivePreviewAppendRoom(feedRooms, DYYYLivePreviewDecodeRoomData(DYYYLivePreviewValueForKey(cellRoom, @"liveRoomRawData")));
    NSString *roomID = DYYYLivePreviewRoomIdentifier(model);
    for (id room in feedRooms) {
        if (!roomID) {
            roomID = DYYYLivePreviewRoomIdentifier(room);
        }
    }
    if (model && !roomID) {
        return @[];
    }

    id streamView = DYYYLivePreviewValueForKey(controller, @"streamView");
    id statusModel = DYYYLivePreviewValueForKey(statusLabel, @"viewModel");
    NSMutableArray *rooms = [NSMutableArray array];
    DYYYLivePreviewAppendRoom(rooms, DYYYLivePreviewValueForKey(viewModel, @"room"));
    DYYYLivePreviewAppendRoom(rooms, DYYYLivePreviewValueForKey(controller, @"roomService"));
    DYYYLivePreviewAppendRoom(rooms, DYYYLivePreviewValueForKey(streamView, @"room"));
    for (id room in feedRooms) {
        DYYYLivePreviewAppendRoom(rooms, room);
    }
    DYYYLivePreviewAppendRoom(rooms, DYYYLivePreviewValueForKey(statusModel, @"roomModel"));
    for (id room in rooms) {
        if (!roomID) {
            roomID = DYYYLivePreviewRoomIdentifier(room);
        }
    }
    if (!roomID) {
        return @[];
    }
    *currentRoomID = roomID;
    NSMutableArray *matchingRooms = [NSMutableArray array];
    for (id room in rooms) {
        if ([DYYYLivePreviewRoomIdentifier(room) isEqualToString:roomID]) {
            [matchingRooms addObject:room];
        }
    }
    return matchingRooms;
}

static NSNumber *DYYYLivePreviewViewerCount(NSArray *rooms) {
    NSArray<NSString *> *keys = @[@"onlineCountByIM", @"userCount", @"user_count"];
    for (id room in rooms) {
        for (NSString *key in keys) {
            NSNumber *count = DYYYLivePreviewOnlineCount(DYYYLivePreviewValueForKey(room, key));
            if (count.longLongValue > 0) {
                return count;
            }
        }
    }
    return nil;
}

static NSNumber *DYYYLivePreviewNetworkViewerCount(id object, NSString *roomID, NSUInteger depth) {
    if (!object || object == [NSNull null] || depth > 5) {
        return nil;
    }
    NSString *responseRoomID = DYYYLivePreviewRoomIdentifier(object);
    if (responseRoomID && ![responseRoomID isEqualToString:roomID]) {
        return nil;
    }
    NSNumber *direct = DYYYLivePreviewViewerCount(@[object]);
    if (direct) {
        return direct;
    }
    NSArray<NSString *> *nestedKeys = @[
        @"data", @"room", @"roomModel", @"room_info", @"roomInfo", @"liveRoom",
        @"live_room", @"stats", @"roomViewStats", @"response", @"result", @"data_list", @"rooms"
    ];
    for (NSString *key in nestedKeys) {
        id nested = DYYYLivePreviewValueForKey(object, key);
        NSNumber *count = DYYYLivePreviewNetworkViewerCount(nested, roomID, depth + 1);
        if (count) {
            return count;
        }
    }
    if ([object isKindOfClass:[NSArray class]]) {
        for (id item in (NSArray *)object) {
            NSNumber *count = DYYYLivePreviewNetworkViewerCount(item, roomID, depth + 1);
            if (count) {
                return count;
            }
        }
    }
    return nil;
}

static BOOL DYYYLivePreviewIsRecommendationPreview(UIViewController *controller) {
    id viewModel = DYYYLivePreviewValueForKey(controller, @"viewModel");
    if ([DYYYLivePreviewValueForKey(controller, @"showInSearchResult") boolValue] ||
        [DYYYLivePreviewValueForKey(viewModel, @"showInSearchResult") boolValue]) {
        return NO;
    }
    NSNumber *isHomepageHot = DYYYLivePreviewValueForKey(viewModel, @"isFromHomepageHot");
    if (isHomepageHot) {
        return isHomepageHot.boolValue;
    }
    for (id object in @[controller, viewModel ?: [NSNull null],
                        DYYYLivePreviewValueForKey(controller, @"model") ?: [NSNull null]]) {
        NSString *source = DYYYLivePreviewValueForKey(object, @"referString");
        if (![source isKindOfClass:[NSString class]] || source.length == 0) {
            continue;
        }
        source = source.lowercaseString;
        return [source isEqualToString:@"homepage_hot"] ||
               [source hasPrefix:@"homepage_hot_"] ||
               [source isEqualToString:@"homepage_recommend"] ||
               [source isEqualToString:@"recommend"];
    }
    return NO;
}

static UIView *DYYYLivePreviewFindStatusLabel(UIView *root, NSUInteger depth) {
    if (!root || depth > 20) {
        return nil;
    }
    Class labelClass = NSClassFromString(@"AWELiveFeedStatusLabel");
    if (labelClass && [root isKindOfClass:labelClass]) {
        return root;
    }
    for (UIView *subview in root.subviews) {
        UIView *label = DYYYLivePreviewFindStatusLabel(subview, depth + 1);
        if (label) {
            return label;
        }
    }
    return nil;
}

static BOOL DYYYLivePreviewUsableRect(CGRect rect) {
    return !CGRectIsNull(rect) && !CGRectIsInfinite(rect) && !CGRectIsEmpty(rect) &&
           isfinite(rect.origin.x) && isfinite(rect.origin.y) &&
           isfinite(rect.size.width) && isfinite(rect.size.height);
}

static BOOL DYYYLivePreviewIsMostlyVisible(UIViewController *controller) {
    UIView *root = controller.viewIfLoaded;
    UIWindow *window = root.window;
    if (!window) {
        return NO;
    }
    for (UIViewController *child = controller; child; child = child.parentViewController) {
        UIViewController *parent = child.parentViewController;
        if ([parent isKindOfClass:UINavigationController.class] &&
            ((UINavigationController *)parent).visibleViewController != child) {
            return NO;
        }
        if ([parent isKindOfClass:UITabBarController.class] &&
            ((UITabBarController *)parent).selectedViewController != child) {
            return NO;
        }
        UIViewController *presented = child.presentedViewController;
        if (presented.viewIfLoaded.window && !presented.isBeingDismissed) {
            return NO;
        }
    }
    CGRect frame = [root convertRect:root.bounds toView:window];
    if (!DYYYLivePreviewUsableRect(frame)) {
        return NO;
    }
    CGRect visible = CGRectIntersection(frame, window.bounds);
    for (UIView *view = root; view; view = view.superview) {
        if (view.hidden || view.alpha <= 0.01) {
            return NO;
        }
        if (view.clipsToBounds) {
            CGRect clip = [view convertRect:view.bounds toView:window];
            if (!DYYYLivePreviewUsableRect(clip)) {
                return NO;
            }
            visible = CGRectIntersection(visible, clip);
        }
    }
    return DYYYLivePreviewUsableRect(visible) &&
        visible.size.width >= frame.size.width * 0.5 &&
        visible.size.height >= frame.size.height * 0.5;
}

static BOOL DYYYLivePreviewScrollIsMoving(UIScrollView *scrollView) {
    return scrollView.tracking || scrollView.dragging || scrollView.decelerating;
}

static UIScrollView *DYYYLivePreviewScrollView(UIView *root) {
    UIScrollView *nearest = nil;
    for (UIView *view = root.superview; view; view = view.superview) {
        if ([view isKindOfClass:UIScrollView.class]) {
            UIScrollView *scrollView = (UIScrollView *)view;
            if (DYYYLivePreviewScrollIsMoving(scrollView)) {
                return scrollView;
            }
            if (!nearest) {
                nearest = scrollView;
            }
        }
    }
    return nearest;
}

static BOOL DYYYLivePreviewCapsuleStack(double minimumY, double maximumY, double anchorTop, double anchorBottom,
                                        double firstHeight, double secondHeight, double *top, double *secondTop) {
    if (!top || !secondTop || !isfinite(minimumY) || !isfinite(maximumY) || !isfinite(anchorTop) || !isfinite(anchorBottom) ||
        !isfinite(firstHeight) || !isfinite(secondHeight) || maximumY <= minimumY || anchorBottom < anchorTop || firstHeight < 0 || secondHeight < 0) {
        return NO;
    }
    double total = firstHeight + secondHeight + (firstHeight > 0 && secondHeight > 0 ? 6 : 0);
    if (total <= 0 || total > maximumY - minimumY) {
        return NO;
    }
    double y = anchorTop - 8 - total;
    if (y < minimumY || y + total > maximumY) {
        y = anchorBottom + 8;
    }
    if (y < minimumY || y + total > maximumY) {
        return NO;
    }
    *top = y;
    *secondTop = y + (firstHeight > 0 ? firstHeight + (secondHeight > 0 ? 6 : 0) : 0);
    return YES;
}

#pragma mark - 设置快照（每次 refresh 读一次，不在热路径反复解析）

typedef NS_ENUM(NSInteger, DYYYLivePreviewAlign) {
    DYYYLivePreviewAlignLeft = 0,
    DYYYLivePreviewAlignCenter = 1,
    DYYYLivePreviewAlignRight = 2,
};

@interface DYYYLivePreviewSettings : NSObject
@property(nonatomic, assign) BOOL viewersOn;
@property(nonatomic, assign) BOOL cardDurationOn;
@property(nonatomic, assign) BOOL exactFormat;
@property(nonatomic, assign) NSTimeInterval refreshInterval;
@property(nonatomic, assign) DYYYLivePreviewAlign align;
@property(nonatomic, assign) BOOL durationFirst;
@property(nonatomic, assign) DYYYLivePreviewCapsuleSize size;
+ (instancetype)currentSettings;
@end

@implementation DYYYLivePreviewSettings

+ (instancetype)currentSettings {
    DYYYLivePreviewSettings *settings = [DYYYLivePreviewSettings new];
    settings.viewersOn = DYYYGetBool(kDYYYLivePreviewViewersKey);
    settings.cardDurationOn = DYYYGetBool(kDYYYLivePreviewCardDurationKey);
    NSString *format = DYYYGetString(kDYYYLivePreviewCountFormatKey);
    settings.exactFormat = [format isEqualToString:@"完整"] || [format isEqualToString:@"exact"];
    settings.refreshInterval = fmin(10, fmax(2, DYYYLivePreviewDoubleOrDefault(DYYYGetString(kDYYYLivePreviewRefreshKey), 3)));
    NSString *align = DYYYGetString(kDYYYLivePreviewCapsuleAlignKey);
    if ([align containsString:@"左"] || [align isEqualToString:@"left"]) {
        settings.align = DYYYLivePreviewAlignLeft;
    } else if ([align containsString:@"右"] || [align isEqualToString:@"right"]) {
        settings.align = DYYYLivePreviewAlignRight;
    } else {
        settings.align = DYYYLivePreviewAlignCenter;
    }
    NSString *order = DYYYGetString(kDYYYLivePreviewCapsuleOrderKey);
    settings.durationFirst = [order containsString:@"时长在上"] || [order isEqualToString:@"durationFirst"];
    NSString *size = DYYYGetString(kDYYYLivePreviewCapsuleSizeKey);
    if ([size isEqualToString:@"小"] || [size isEqualToString:@"small"]) {
        settings.size = DYYYLivePreviewCapsuleSizeSmall;
    } else if ([size isEqualToString:@"大"] || [size isEqualToString:@"large"]) {
        settings.size = DYYYLivePreviewCapsuleSizeLarge;
    } else {
        settings.size = DYYYLivePreviewCapsuleSizeMedium;
    }
    return settings;
}

@end

#pragma mark - 预览卡片状态机

@protocol DYYYLivePreviewRoomAPI <NSObject>
- (instancetype)initWithRoomID:(id)roomID;
- (void)fetchRoomInfoWithRoomID:(id)roomID completion:(id)completion;
@end

static char kDYYYLivePreviewStateKey;

@interface DYYYLivePreviewState : NSObject <UIGestureRecognizerDelegate>
@property(nonatomic, weak) UIViewController *controller;
@property(nonatomic, weak) UIView *statusLabel;
@property(nonatomic, strong) DYYYLivePreviewCapsule *badge;
@property(nonatomic, strong) DYYYLivePreviewCapsule *durationBadge;
@property(nonatomic, strong) DYYYLivePreviewSettings *settings;
@property(nonatomic) double roomStart, lastRequestAt, stableAt;
@property(nonatomic) CGRect stableRect;
@property(nonatomic, strong) NSTimer *timer;
@property(nonatomic, strong) NSTimer *visibilityTimer;
@property(nonatomic, strong) NSTimer *layoutRetryTimer;
@property(nonatomic, weak) UIScrollView *disappearingScrollView;
@property(nonatomic, assign) BOOL disappearancePending;
@property(nonatomic, assign) BOOL transitionInProgress;
@property(nonatomic, assign) NSUInteger disappearanceGeneration;
@property(nonatomic, assign) NSUInteger settledVisibilityPasses;
@property(nonatomic, assign) NSUInteger layoutRetriesRemaining;
@property(nonatomic, assign) CGRect lastVisibilityRect;
@property(nonatomic, assign) CGRect badgeAnchor;
@property(nonatomic, assign) CGRect badgeAnchorBounds;
@property(nonatomic, assign) UIEdgeInsets badgeAnchorInsets;
@property(nonatomic, strong) id roomAPI;
@property(nonatomic, strong) NSTimer *requestTimeoutTimer;
@property(nonatomic, copy) NSString *viewerRoomID;
@property(nonatomic, copy) NSString *requestRoomID;
@property(nonatomic, strong) NSNumber *lastViewerCount;
@property(nonatomic, assign) BOOL active;
@property(nonatomic, assign) BOOL refreshScheduled;
@property(nonatomic, assign) BOOL sampleRequested;
@property(nonatomic, assign) BOOL requestInFlight;
@property(nonatomic, assign) BOOL hasNetworkCount;
@property(nonatomic, assign) NSUInteger requestGeneration;
// 卡片拖动（自己重做，GitHub 1.0-3 没有）：拖动期间 refresh 跳过布局，松手保存位置。
@property(nonatomic, assign) BOOL dragging;
@property(nonatomic, assign) CGPoint dragOrigin;
@property(nonatomic, assign) CGSize dragGroupSize;
@property(nonatomic, assign) CGPoint dragGroupOrigin;
@property(nonatomic, assign) CGPoint dragLastOrigin;
// 2.2-9-57：本房间是否已完成一轮网络请求（成功或超时都算）。用于“预留位置”：
@property(nonatomic, assign) BOOL networkRoundDone;
// 2.2-9-59：-57 的 layoutRetryRearms（多给两轮重试）已删，见 retryInitialLayout。
// 2.2-9-60（胶囊出得慢）：数据缺失时最多两发单次延时补刷（0.35 秒、0.90 秒），
// 有代际守卫、有上限，不是常驻定时器；catchUpGeneration 只在换房间/停用时加 1，
// 旧房间的延时块到期后直接丢弃。catchUpLastArmedAt 限制同一房间两次补刷链
// 之间至少隔 2 秒，免得主定时器每跳都重开一条链。
@property(nonatomic, assign) NSUInteger catchUpGeneration;
@property(nonatomic, assign) BOOL catchUpArmed;
@property(nonatomic, assign) NSUInteger catchUpShotsRemaining;
@property(nonatomic, assign) double catchUpLastArmedAt;
- (instancetype)initWithController:(UIViewController *)controller;
- (void)scheduleRefresh;
- (void)refresh;
- (void)prefetchViewerCountIfNeeded;
- (void)armCatchUpRefreshIfNeeded;
- (void)fireCatchUpShotWithGeneration:(NSUInteger)generation;
- (void)activate;
- (void)beginDisappearance;
- (void)deactivate;
- (void)clearContent;
- (void)resetViewerCount;
- (void)handleBadgePan:(UIPanGestureRecognizer *)pan;
@end

@implementation DYYYLivePreviewState

- (instancetype)initWithController:(UIViewController *)controller {
    self = [super init];
    if (self) {
        _controller = controller;
        _badgeAnchor = CGRectNull;
        _layoutRetriesRemaining = 15;
        __weak DYYYLivePreviewState *weakSelf = self;
        [[NSNotificationCenter defaultCenter] addObserverForName:UIApplicationWillResignActiveNotification
                                                          object:nil
                                                           queue:nil
                                                      usingBlock:^(__unused NSNotification *note) {
                                                          dispatch_async(dispatch_get_main_queue(), ^{
                                                              [weakSelf pauseForApplicationState];
                                                          });
                                                      }];
        [[NSNotificationCenter defaultCenter] addObserverForName:UIApplicationDidBecomeActiveNotification
                                                          object:nil
                                                           queue:nil
                                                      usingBlock:^(__unused NSNotification *note) {
                                                          dispatch_async(dispatch_get_main_queue(), ^{
                                                              [weakSelf resumeForApplicationState];
                                                          });
                                                      }];
        // 2.2-9-59：删掉 NSUserDefaultsDidChangeNotification 订阅。-57 加它是为了
        // 设置改了即时刷新，但它是 -57 冻屏的头号嫌疑：任何一次 defaults 写入
        // （抖音自己也会写）都会让所有活动卡片 state 各调一次 scheduleRefresh，
        // 每刷一次都要走整棵视图树查找 + layoutIfNeeded，写得越频主线程越满；
        // 星牌那边还有一个同名订阅，会再给每个个人主页 owner 各跑一次
        // DYYYFansUpdateProfile。-56 没有这个订阅所以能操作。-59 回到 -56 的
        // 做法：设置改了等下一次生命周期回调/定时器刷新才生效，慢一拍但不冻。
    }
    return self;
}

- (void)dealloc {
    [[NSNotificationCenter defaultCenter] removeObserver:self];
    [_timer invalidate];
    [_visibilityTimer invalidate];
    [_layoutRetryTimer invalidate];
    [_requestTimeoutTimer invalidate];
    [_badge removeFromSuperview];
    [_durationBadge removeFromSuperview];
}

- (void)stopLayoutRetry {
    [self.layoutRetryTimer invalidate];
    self.layoutRetryTimer = nil;
}

- (void)removeBadge {
    [self stopLayoutRetry];
    [self.badge removeFromSuperview];
    self.badge = nil;
    [self.durationBadge removeFromSuperview];
    self.durationBadge = nil;
}

- (void)stopTimer {
    [self.timer invalidate];
    self.timer = nil;
}

- (void)cancelDisappearance {
    [self.visibilityTimer invalidate];
    self.visibilityTimer = nil;
    self.disappearancePending = NO;
    self.transitionInProgress = NO;
    self.disappearingScrollView = nil;
    self.settledVisibilityPasses = 0;
    self.disappearanceGeneration += 1;
}

- (void)activate {
    BOOL wasActive = self.active;
    [self cancelDisappearance];
    self.active = YES;
    if (!wasActive) {
        self.sampleRequested = YES;
    }
    [self scheduleRefresh];
    // 2.2-9-60（胶囊出得慢）：卡片刚露面就预取一次。网络请求原来要等卡片停稳
    // 0.20 秒后的第一次稳定刷新才发，RTT 全算在用户等待里；预取把请求提前到
    // 卡片出现时（prepareForDisplay/pageDidAppear/viewDidAppear）发，让 RTT 和
    // 滚动/停稳重叠。只在 inactive→active 时做一次，请求本身有 in-flight/
    // 节流守卫，不会重复发；模型里已有数就不发请求。
    if (!wasActive) {
        [self prefetchViewerCountIfNeeded];
    }
}

- (void)prefetchViewerCountIfNeeded {
    if (![NSThread isMainThread]) {
        __weak DYYYLivePreviewState *weakSelf = self;
        dispatch_async(dispatch_get_main_queue(), ^{
            [weakSelf prefetchViewerCountIfNeeded];
        });
        return;
    }
    if (!self.active) {
        return;
    }
    self.settings = [DYYYLivePreviewSettings currentSettings];
    if (!self.settings.viewersOn && !self.settings.cardDurationOn) {
        return;
    }
    UIViewController *controller = self.controller;
    if ([DYYYLivePreviewValueForKey(controller, @"roomEntered") boolValue] ||
        [DYYYLivePreviewValueForKey(controller, @"willEnterLiveRoom") boolValue]) {
        return;
    }
    if (!DYYYLivePreviewIsRecommendationPreview(controller)) {
        return;
    }
    NSString *roomID = nil;
    NSArray *rooms = DYYYLivePreviewPreviewRooms(controller, self.statusLabel, &roomID);
    if (!roomID) {
        return;
    }
    if (![self.viewerRoomID isEqualToString:roomID]) {
        [self resetViewerCount];
        self.viewerRoomID = roomID;
    }
    if (self.settings.cardDurationOn) {
        for (id room in rooms) {
            double start = DYYYLivePreviewRoomStart(room, roomID, 0);
            if (start) {
                self.roomStart = start;
                break;
            }
        }
    }
    if (self.settings.viewersOn && !self.hasNetworkCount) {
        NSNumber *sample = DYYYLivePreviewViewerCount(rooms);
        if (sample) {
            self.lastViewerCount = sample;
        }
    }
    if ((self.settings.viewersOn && !self.lastViewerCount) ||
        (self.settings.cardDurationOn && !self.roomStart)) {
        [self requestViewerCountForRoomID:roomID];
    }
}

- (void)armCatchUpRefreshIfNeeded {
    // 2.2-9-60：只补两发单次延时刷新（0.35 秒、0.90 秒），有代际守卫、有上限，
    // 不是常驻定时器。覆盖“重试 15 次（0.5 秒）跑完后、主定时器（1 秒/3 秒）
    // 下一跳到来之前，模型数据刚解码出来”的窗口。-59 摘掉的 layoutRetryRearms
    // 是无上限重装，不加回。同一房间两次补刷链之间至少隔 2 秒。
    if (!self.active || self.catchUpArmed) {
        return;
    }
    double now = CACurrentMediaTime();
    if (now - self.catchUpLastArmedAt < 2.0) {
        return;
    }
    BOOL viewersMissing = self.settings.viewersOn && !self.lastViewerCount;
    BOOL durationMissing = self.settings.cardDurationOn && !self.roomStart;
    if (!viewersMissing && !durationMissing) {
        return;
    }
    self.catchUpArmed = YES;
    self.catchUpShotsRemaining = 2;
    self.catchUpLastArmedAt = now;
    NSUInteger generation = self.catchUpGeneration;
    __weak DYYYLivePreviewState *weakSelf = self;
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.35 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        [weakSelf fireCatchUpShotWithGeneration:generation];
    });
}

- (void)fireCatchUpShotWithGeneration:(NSUInteger)generation {
    if (!self.active || generation != self.catchUpGeneration) {
        self.catchUpArmed = NO;
        return;
    }
    BOOL viewersMissing = self.settings.viewersOn && !self.lastViewerCount;
    BOOL durationMissing = self.settings.cardDurationOn && !self.roomStart;
    if (!viewersMissing && !durationMissing) {
        self.catchUpArmed = NO;
        return;
    }
    [self scheduleRefresh];
    if (self.catchUpShotsRemaining > 1) {
        self.catchUpShotsRemaining -= 1;
        __weak DYYYLivePreviewState *weakSelf = self;
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.55 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
            [weakSelf fireCatchUpShotWithGeneration:generation];
        });
    } else {
        self.catchUpShotsRemaining = 0;
        self.catchUpArmed = NO;
    }
}

- (void)checkVisibilityAfterTransition {
    if (!self.active || !self.disappearancePending) {
        return;
    }
    UIView *root = self.controller.viewIfLoaded;
    UIScrollView *scrollView = DYYYLivePreviewScrollView(root);
    if (self.transitionInProgress || DYYYLivePreviewScrollIsMoving(scrollView) ||
        DYYYLivePreviewScrollIsMoving(self.disappearingScrollView)) {
        self.settledVisibilityPasses = 0;
        return;
    }
    CGRect frame = root.window ? [root convertRect:root.bounds toView:root.window] : CGRectNull;
    self.settledVisibilityPasses = CGRectEqualToRect(frame, self.lastVisibilityRect)
        ? self.settledVisibilityPasses + 1 : 1;
    self.lastVisibilityRect = frame;
    if (self.settledVisibilityPasses < 2) {
        return;
    }
    if (DYYYLivePreviewIsMostlyVisible(self.controller)) {
        [self cancelDisappearance];
        [self scheduleRefresh];
    } else {
        [self deactivate];
    }
}

- (void)beginDisappearance {
    if (!self.active) {
        return;
    }
    if (!self.disappearancePending) {
        self.disappearancePending = YES;
        self.disappearanceGeneration += 1;
        self.settledVisibilityPasses = 0;
        self.lastVisibilityRect = CGRectNull;
    }
    self.disappearingScrollView = DYYYLivePreviewScrollView(self.controller.viewIfLoaded)
        ?: self.disappearingScrollView;
    if ([UIApplication sharedApplication].applicationState != UIApplicationStateActive) {
        return;
    }
    __weak DYYYLivePreviewState *weakSelf = self;
    if (!self.visibilityTimer) {
        self.visibilityTimer = [NSTimer timerWithTimeInterval:0.05 repeats:YES block:^(NSTimer *timer) {
            DYYYLivePreviewState *state = weakSelf;
            if (!state) {
                [timer invalidate];
                return;
            }
            [state checkVisibilityAfterTransition];
        }];
        [[NSRunLoop mainRunLoop] addTimer:self.visibilityTimer forMode:NSRunLoopCommonModes];
    }
    id<UIViewControllerTransitionCoordinator> coordinator = self.controller.transitionCoordinator;
    if (coordinator.isAnimated && !self.transitionInProgress) {
        self.transitionInProgress = YES;
        NSUInteger generation = self.disappearanceGeneration;
        BOOL registered = [coordinator animateAlongsideTransition:nil
            completion:^(id<UIViewControllerTransitionCoordinatorContext> context) {
                DYYYLivePreviewState *state = weakSelf;
                if (!state.active || state.disappearanceGeneration != generation) {
                    return;
                }
                state.transitionInProgress = NO;
                if (context.isCancelled) {
                    [state cancelDisappearance];
                    [state scheduleRefresh];
                } else {
                    [state checkVisibilityAfterTransition];
                }
            }];
        if (!registered) {
            self.transitionInProgress = NO;
        }
    }
}

- (void)deactivate {
    self.active = NO;
    [self cancelDisappearance];
    [self stopTimer];
    [self clearContent];
    [self resetViewerCount];
}

- (void)resetViewerCount {
    [self.requestTimeoutTimer invalidate];
    self.requestTimeoutTimer = nil;
    self.viewerRoomID = nil;
    self.requestRoomID = nil;
    self.lastViewerCount = nil;
    self.requestInFlight = NO;
    self.hasNetworkCount = NO;
    self.roomStart = 0;
    self.lastRequestAt = 0;
    self.requestGeneration += 1;
    self.roomAPI = nil;
    self.sampleRequested = YES;
    self.networkRoundDone = NO;
    // 2.2-9-60：换房间/停用时补刷链作废（代际 +1，旧延时块到期丢弃），
    // 新房间的 refresh 到稳定分支后可重新开一条链。
    self.catchUpArmed = NO;
    self.catchUpShotsRemaining = 0;
    self.catchUpGeneration += 1;
}

- (void)clearContent {
    [self resetViewerCount];
    self.stableAt = 0;
    [self removeBadge];
    self.statusLabel = nil;
    self.badgeAnchor = CGRectNull;
    self.badgeAnchorBounds = CGRectZero;
    self.badgeAnchorInsets = UIEdgeInsetsZero;
    self.layoutRetriesRemaining = 15;
    self.sampleRequested = YES;
}

- (void)scheduleRefresh {
    if (!self.active || self.refreshScheduled) {
        return;
    }
    self.refreshScheduled = YES;
    __weak DYYYLivePreviewState *weakSelf = self;
    dispatch_async(dispatch_get_main_queue(), ^{
        DYYYLivePreviewState *state = weakSelf;
        state.refreshScheduled = NO;
        if (state.active) {
            [state refresh];
        }
    });
}

- (void)startTimer {
    NSTimeInterval interval = self.settings.cardDurationOn ? 1 : self.settings.refreshInterval;
    if (self.timer.isValid && fabs(self.timer.timeInterval - interval) < 0.01) {
        return;
    }
    [self stopTimer];
    self.sampleRequested = YES;
    __weak DYYYLivePreviewState *weakSelf = self;
    self.timer = [NSTimer timerWithTimeInterval:interval repeats:YES block:^(NSTimer *timer) {
        DYYYLivePreviewState *state = weakSelf;
        if (!state) {
            [timer invalidate];
            return;
        }
        state.sampleRequested = YES;
        [state scheduleRefresh];
    }];
    self.timer.tolerance = 0.25;
    [[NSRunLoop mainRunLoop] addTimer:self.timer forMode:NSRunLoopCommonModes];
}

- (void)pauseForApplicationState {
    [self stopTimer];
    [self.visibilityTimer invalidate];
    self.visibilityTimer = nil;
    self.transitionInProgress = NO;
    self.disappearanceGeneration += 1;
    [self.requestTimeoutTimer invalidate];
    self.requestTimeoutTimer = nil;
    self.requestInFlight = NO;
    self.requestGeneration += 1;
    self.requestRoomID = nil;
    self.roomAPI = nil;
    [self removeBadge];
}

- (void)resumeForApplicationState {
    if (self.active) {
        if (self.disappearancePending) {
            [self beginDisappearance];
        }
        self.sampleRequested = YES;
        [self scheduleRefresh];
    }
}

- (void)requestViewerCountForRoomID:(NSString *)roomID {
    if (!self.active || self.requestInFlight || roomID.length == 0 ||
        CACurrentMediaTime() - self.lastRequestAt < self.settings.refreshInterval) {
        return;
    }
    NSNumber *roomNumber = DYYYLivePreviewOnlineCount(roomID);
    if (roomNumber.longLongValue <= 0) {
        return;
    }
    Class apiClass = NSClassFromString(@"HTSLiveRoomAPI");
    if (!DYYYLivePreviewRoomAPIAvailable(apiClass)) {
        return;
    }
    id<DYYYLivePreviewRoomAPI> api = [(id<DYYYLivePreviewRoomAPI>)[apiClass alloc] initWithRoomID:roomNumber];
    if (!api) {
        return;
    }
    self.roomAPI = api;
    self.lastRequestAt = CACurrentMediaTime();
    self.requestRoomID = roomID;
    self.requestInFlight = YES;
    self.requestGeneration += 1;
    NSUInteger generation = self.requestGeneration;
    NSTimeInterval timeout = MAX(5.0, self.settings.refreshInterval * 1.5);
    __weak DYYYLivePreviewState *timeoutState = self;
    self.requestTimeoutTimer = [NSTimer timerWithTimeInterval:timeout repeats:NO block:^(__unused NSTimer *timer) {
        DYYYLivePreviewState *state = timeoutState;
        if (!state || !state.requestInFlight || state.requestGeneration != generation ||
            ![state.requestRoomID isEqualToString:roomID]) {
            return;
        }
        state.requestInFlight = NO;
        state.requestRoomID = nil;
        state.roomAPI = nil;
        state.requestGeneration += 1;
        state.networkRoundDone = YES;
        state.sampleRequested = YES;
        [state scheduleRefresh];
    }];
    [[NSRunLoop mainRunLoop] addTimer:self.requestTimeoutTimer forMode:NSRunLoopCommonModes];
    __weak DYYYLivePreviewState *weakSelf = self;
    void (^completion)(id, id) = ^(id first, id second) {
        dispatch_async(dispatch_get_main_queue(), ^{
            DYYYLivePreviewState *state = weakSelf;
            if (!state) {
                return;
            }
            BOOL sameRequest = state.requestInFlight && state.requestGeneration == generation &&
                [state.requestRoomID isEqualToString:roomID];
            if (sameRequest) {
                // 2.2-9-57：这一轮网络请求回来了（无论有没有拿到数），“预留位置”可以
                // 收起来了——再没数据的项说明这次真拿不到，不用一直给它留空位。
                state.networkRoundDone = YES;
                NSNumber *count = DYYYLivePreviewNetworkViewerCount(first, roomID, 0) ?: DYYYLivePreviewNetworkViewerCount(second, roomID, 0);
                [state.requestTimeoutTimer invalidate];
                state.requestTimeoutTimer = nil;
                state.requestInFlight = NO;
                state.requestRoomID = nil;
                state.roomAPI = nil;
                double start = DYYYLivePreviewRoomStart(first, roomID, 0);
                if (!start) {
                    start = DYYYLivePreviewRoomStart(second, roomID, 0);
                }
                if (start && state.active && [state.viewerRoomID isEqual:roomID]) {
                    state.roomStart = start;
                    [state scheduleRefresh];
                }
                if (count && state.active && [state.viewerRoomID isEqualToString:roomID]) {
                    state.lastViewerCount = count;
                    state.hasNetworkCount = YES;
                    [state scheduleRefresh];
                }
            }
        });
    };
    [api fetchRoomInfoWithRoomID:roomNumber completion:completion];
}

- (void)retryInitialLayout {
    if (self.layoutRetryTimer || self.layoutRetriesRemaining == 0) {
        return;
    }
    __weak DYYYLivePreviewState *weakSelf = self;
    // 2.2-9-57（症状 1 出得慢）：-56 的重试定时器只跑 15 次（约 0.5 秒），数据要是
    // 0.5 秒后才到（模型刚解码、网络刚回来），下一次机会就是 1–3 秒的主定时器，
    // 胶囊就显得出得慢。-57 为此多给了两轮重试（再约 1 秒）；2.2-9-59 摘掉这两轮，
    // 回到 -56 的行为：15 次跑完就停，靠主定时器兜底。-58 仍冻，说明多给的这两轮
    // 也是嫌疑之一（卡片一直不稳定时，refresh 的不稳定分支会把剩余次数重置回
    // 15，定时器可能一直 30fps 空转），先摘掉再定位。
    self.layoutRetryTimer = [NSTimer timerWithTimeInterval:1.0 / 30.0 repeats:YES block:^(NSTimer *timer) {
        DYYYLivePreviewState *state = weakSelf;
        if (!state) {
            [timer invalidate];
            return;
        }
        if (!state.active || !state.controller.viewIfLoaded.window ||
            [UIApplication sharedApplication].applicationState != UIApplicationStateActive) {
            [state stopLayoutRetry];
            return;
        }
        if (state.layoutRetriesRemaining == 0) {
            // 2.2-9-59：-57 的多给两轮已删，回到 -56：次数跑完就停。
            [state stopLayoutRetry];
            return;
        }
        state.layoutRetriesRemaining -= 1;
        [state scheduleRefresh];
    }];
    [[NSRunLoop mainRunLoop] addTimer:self.layoutRetryTimer forMode:NSRunLoopCommonModes];
}

#pragma mark 卡片位置（自己重做）

- (BOOL)isLandscapeRoot:(UIView *)root {
    return CGRectGetWidth(root.bounds) > CGRectGetHeight(root.bounds);
}

- (NSString *)cardPositionXKeyForRoot:(UIView *)root {
    return [self isLandscapeRoot:root] ? kDYYYLivePreviewCardLandscapeXKey : kDYYYLivePreviewCardPortraitXKey;
}

- (NSString *)cardPositionYKeyForRoot:(UIView *)root {
    return [self isLandscapeRoot:root] ? kDYYYLivePreviewCardLandscapeYKey : kDYYYLivePreviewCardPortraitYKey;
}

- (BOOL)savedCardPositionForRoot:(UIView *)root available:(CGRect)available groupSize:(CGSize)groupSize origin:(CGPoint *)origin {
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    NSString *xKey = [self cardPositionXKeyForRoot:root];
    NSString *yKey = [self cardPositionYKeyForRoot:root];
    if (![defaults objectForKey:xKey] || ![defaults objectForKey:yKey]) {
        return NO;
    }
    double relX = fmin(1, fmax(0, [defaults doubleForKey:xKey]));
    double relY = fmin(1, fmax(0, [defaults doubleForKey:yKey]));
    *origin = CGPointMake(available.origin.x + relX * MAX(0, available.size.width - groupSize.width),
                          available.origin.y + relY * MAX(0, available.size.height - groupSize.height));
    return YES;
}

- (void)saveCardPositionForRoot:(UIView *)root available:(CGRect)available groupSize:(CGSize)groupSize origin:(CGPoint)origin {
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    double relX = fmin(1, fmax(0, (origin.x - available.origin.x) / MAX(1, available.size.width - groupSize.width)));
    double relY = fmin(1, fmax(0, (origin.y - available.origin.y) / MAX(1, available.size.height - groupSize.height)));
    [defaults setDouble:relX forKey:[self cardPositionXKeyForRoot:root]];
    [defaults setDouble:relY forKey:[self cardPositionYKeyForRoot:root]];
}

+ (void)resetCardPosition {
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    [defaults removeObjectForKey:kDYYYLivePreviewCardPortraitXKey];
    [defaults removeObjectForKey:kDYYYLivePreviewCardPortraitYKey];
    [defaults removeObjectForKey:kDYYYLivePreviewCardLandscapeXKey];
    [defaults removeObjectForKey:kDYYYLivePreviewCardLandscapeYKey];
}

- (BOOL)gestureRecognizer:(UIGestureRecognizer *)gestureRecognizer shouldRecognizeSimultaneouslyWithGestureRecognizer:(UIGestureRecognizer *)otherGestureRecognizer {
    // 2.2-9-57（症状 3 拖不动）：-56 只拦 UIScrollView 的 pan，但推荐页的分页容器
    // 未必是 UIScrollView，任何跟踪同一触摸的 pan 手势都会抢走拖动。改成：任何
    // 其他 pan 手势都不并行（胶囊的拖动一旦识别，滚动就停下）；只有点按这类非
    // pan 手势才允许并行。注意：纵向拖动仍要和推荐页滚动抢优先权——胶囊在更深的
    // 视图层级上，系统一般先把触摸交给它，实测仍以真机为准；横向拖动不受纵向
    // 滚动影响，一定能用。
    if ([otherGestureRecognizer isKindOfClass:[UIPanGestureRecognizer class]]) {
        return NO;
    }
    return YES;
}

- (void)handleBadgePan:(UIPanGestureRecognizer *)pan {
    UIView *root = self.controller.viewIfLoaded;
    if (!root || !self.badge && !self.durationBadge) {
        return;
    }
    // 两个胶囊整体一起拖：取两个胶囊的外接矩形作为整组。
    CGRect groupFrame = CGRectNull;
    for (DYYYLivePreviewCapsule *badge in @[self.badge, self.durationBadge]) {
        if (badge && badge.superview == root) {
            groupFrame = CGRectIsNull(groupFrame) ? badge.frame : CGRectUnion(groupFrame, badge.frame);
        }
    }
    if (CGRectIsNull(groupFrame)) {
        return;
    }
    CGRect available = CGRectInset(UIEdgeInsetsInsetRect(root.bounds, root.safeAreaInsets), 12, 8);
    if (pan.state == UIGestureRecognizerStateBegan) {
        self.dragging = YES;
        self.dragOrigin = [pan locationInView:root];
        self.dragGroupSize = groupFrame.size;
        // 2.2-9-57：-56 在每次 Changed 里都把 dragGroupOrigin 更新成 newOrigin，
        // 但 newOrigin 又是用“起点 + 从按下到现在的总位移”算的，等于每报一次事件
        // 就把累计位移多加一遍，胶囊越拖越快、跑得比手指快。修法：拖动起点固定不变，
        // 只用 dragLastOrigin 记录最新位置，松手保存它。
        self.dragGroupOrigin = groupFrame.origin;
        self.dragLastOrigin = groupFrame.origin;
    }
    if (pan.state == UIGestureRecognizerStateBegan || pan.state == UIGestureRecognizerStateChanged) {
        CGPoint location = [pan locationInView:root];
        CGPoint newOrigin = CGPointMake(self.dragGroupOrigin.x + (location.x - self.dragOrigin.x),
                                        self.dragGroupOrigin.y + (location.y - self.dragOrigin.y));
        newOrigin.x = fmin(fmax(newOrigin.x, CGRectGetMinX(available)), CGRectGetMaxX(available) - groupFrame.size.width);
        newOrigin.y = fmin(fmax(newOrigin.y, CGRectGetMinY(available)), CGRectGetMaxY(available) - groupFrame.size.height);
        CGPoint offset = CGPointMake(newOrigin.x - groupFrame.origin.x, newOrigin.y - groupFrame.origin.y);
        for (DYYYLivePreviewCapsule *badge in @[self.badge, self.durationBadge]) {
            if (badge && badge.superview == root) {
                badge.frame = CGRectOffset(badge.frame, offset.x, offset.y);
            }
        }
        self.dragLastOrigin = newOrigin;
    }
    if (pan.state == UIGestureRecognizerStateEnded) {
        [self saveCardPositionForRoot:root available:available groupSize:self.dragGroupSize origin:self.dragLastOrigin];
        self.dragging = NO;
        [self scheduleRefresh];
    } else if (pan.state == UIGestureRecognizerStateCancelled || pan.state == UIGestureRecognizerStateFailed) {
        self.dragging = NO;
        [self scheduleRefresh];
    }
}

- (void)attachPanGestureToBadge:(DYYYLivePreviewCapsule *)badge {
    if (!badge) {
        return;
    }
    for (UIGestureRecognizer *gesture in badge.gestureRecognizers) {
        if ([gesture isKindOfClass:[UIPanGestureRecognizer class]] && gesture.delegate == (id<UIGestureRecognizerDelegate>)self) {
            return;
        }
    }
    UIPanGestureRecognizer *pan = [[UIPanGestureRecognizer alloc] initWithTarget:self action:@selector(handleBadgePan:)];
    pan.delegate = self;
    // 2.2-9-57：-56 写的是 cancelsTouchesInView=NO，胶囊手势识别后触摸仍继续发给
    // 推荐页滚动，拖胶囊的同时 feed 也在滑。改成 YES，胶囊拖动一旦识别就取消滚动
    // 的触摸；单指拖动（DY778 直播间浮层也是 maximumNumberOfTouches=1）。
    pan.cancelsTouchesInView = YES;
    pan.maximumNumberOfTouches = 1;
    [badge addGestureRecognizer:pan];
}

#pragma mark 布局与刷新

- (void)layoutBadgeInView:(UIView *)root {
    DYYYLivePreviewCapsule *first = self.settings.durationFirst ? self.durationBadge : self.badge;
    DYYYLivePreviewCapsule *second = self.settings.durationFirst ? self.badge : self.durationBadge;
    NSMutableArray<DYYYLivePreviewCapsule *> *badges = [NSMutableArray array];
    if (first) {
        [badges addObject:first];
    }
    if (second) {
        [badges addObject:second];
    }
    CGRect available = CGRectInset(UIEdgeInsetsInsetRect(root.bounds, root.safeAreaInsets), 12, 8);
    // 2.2-9-57（症状 2 闪一下）：-56 按“已存在的胶囊”算高度，两个胶囊不是同时
    // 出现——先到的那个先摆在单胶囊的位置，后到的那个一出现，整组重新排布，先到
    // 的那个被顶走，看起来就是闪/跳一下。改法：本轮网络请求还没回来时，给还没
    // 出现的那一项预留一个胶囊高度（小 24 / 中 28 / 大 32），先到的胶囊直接摆在
    // 它最终的位置上；等网络回来、确认那项真没数据，才收起预留位（只动一次）。
    CGFloat capsuleHeight = self.settings.size == DYYYLivePreviewCapsuleSizeSmall ? 24 : (self.settings.size == DYYYLivePreviewCapsuleSizeLarge ? 32 : 28);
    BOOL firstIsDuration = self.settings.durationFirst;
    BOOL firstEnabled = firstIsDuration ? self.settings.cardDurationOn : self.settings.viewersOn;
    BOOL secondEnabled = firstIsDuration ? self.settings.viewersOn : self.settings.cardDurationOn;
    CGFloat firstHeight = first ? first.intrinsicContentSize.height : (firstEnabled && !self.networkRoundDone ? capsuleHeight : 0);
    CGFloat secondHeight = second ? second.intrinsicContentSize.height : (secondEnabled && !self.networkRoundDone ? capsuleHeight : 0);
    CGFloat total = firstHeight + secondHeight + (firstHeight > 0 && secondHeight > 0 ? 6 : 0);
    if (!DYYYLivePreviewUsableRect(available) || available.size.width < 60 || available.size.height < total) {
        for (UIView *badge in badges) {
            badge.hidden = YES;
        }
        [self retryInitialLayout];
        return;
    }
    if (!CGRectEqualToRect(root.bounds, self.badgeAnchorBounds) || !UIEdgeInsetsEqualToEdgeInsets(root.safeAreaInsets, self.badgeAnchorInsets)) {
        self.badgeAnchor = CGRectNull;
        self.badgeAnchorBounds = root.bounds;
        self.badgeAnchorInsets = root.safeAreaInsets;
        self.layoutRetriesRemaining = 15;
    }
    CGRect anchor = CGRectNull;
    UIView *label = self.statusLabel;
    if (label && [label isDescendantOfView:root]) {
        UIView *container = label.superview.superview;
        if (container && container != root && [container isDescendantOfView:root]) {
            CGRect rect = [container convertRect:container.bounds toView:root];
            if (DYYYLivePreviewUsableRect(rect) && rect.size.height <= 100 && CGRectIntersectsRect(rect, available)) {
                anchor = rect;
            }
        }
    }
    if (DYYYLivePreviewUsableRect(anchor)) {
        self.badgeAnchor = anchor;
    } else {
        anchor = self.badgeAnchor;
    }
    if (!DYYYLivePreviewUsableRect(anchor) || !CGRectIntersectsRect(anchor, available)) {
        for (UIView *badge in badges) {
            badge.hidden = YES;
        }
        [self retryInitialLayout];
        return;
    }
    // 拖动保存的位置优先于自动锚点；没有保存位置时按对齐设置摆在锚点附近。
    CGSize groupSize = CGSizeMake(0, total);
    for (DYYYLivePreviewCapsule *badge in badges) {
        groupSize.width = MAX(groupSize.width, MIN(badge.intrinsicContentSize.width, available.size.width));
    }
    CGPoint savedOrigin = CGPointZero;
    if ([self savedCardPositionForRoot:root available:available groupSize:groupSize origin:&savedOrigin]) {
        for (DYYYLivePreviewCapsule *badge in badges) {
            CGSize size = badge.intrinsicContentSize;
            size.width = MIN(size.width, available.size.width);
            // 预留位也要算进去：排在下面的胶囊按预留后的 top 摆，不然后到的胶囊
            // 一出现，上面的不动、下面的会跳一格。
            CGFloat badgeY = badge == second ? savedOrigin.y + firstHeight + (firstHeight > 0 && secondHeight > 0 ? 6 : 0) : savedOrigin.y;
            CGRect frame = CGRectMake(round(savedOrigin.x), round(badgeY), ceil(size.width), size.height);
            // 2.2-9-57（症状 2）：frame 没变就别重写，避免每 1 秒刷新都触发一次布局。
            if (!CGRectEqualToRect(badge.frame, frame)) {
                badge.frame = frame;
            }
            if (badge.hidden) {
                badge.hidden = NO;
            }
            [root bringSubviewToFront:badge];
        }
        [self stopLayoutRetry];
        return;
    }
    double top = 0, secondTop = 0;
    if (!DYYYLivePreviewCapsuleStack(CGRectGetMinY(available), CGRectGetMaxY(available), CGRectGetMinY(anchor), CGRectGetMaxY(anchor), firstHeight, secondHeight, &top, &secondTop)) {
        for (UIView *badge in badges) {
            badge.hidden = YES;
        }
        return;
    }
    [self stopLayoutRetry];
    for (DYYYLivePreviewCapsule *badge in badges) {
        CGSize size = badge.intrinsicContentSize;
        size.width = MIN(size.width, available.size.width);
        CGFloat x;
        if (self.settings.align == DYYYLivePreviewAlignLeft) {
            x = CGRectGetMinX(available);
        } else if (self.settings.align == DYYYLivePreviewAlignRight) {
            x = CGRectGetMaxX(available) - size.width;
        } else {
            x = MAX(CGRectGetMinX(available), MIN(CGRectGetMidX(anchor) - size.width / 2, CGRectGetMaxX(available) - size.width));
        }
        CGFloat y = badge == second ? secondTop : top;
        CGRect frame = CGRectMake(round(x), round(y), ceil(size.width), size.height);
        // 2.2-9-57（症状 2）：frame 没变就别重写，避免每 1 秒刷新都触发一次布局。
        if (!CGRectEqualToRect(badge.frame, frame)) {
            badge.frame = frame;
        }
        if (badge.hidden) {
            badge.hidden = NO;
        }
        [root bringSubviewToFront:badge];
    }
}

- (void)refresh {
    UIViewController *controller = self.controller;
    UIView *root = controller.viewIfLoaded;
    if (!self.active || !root.window || [UIApplication sharedApplication].applicationState != UIApplicationStateActive) {
        [self stopTimer];
        [self removeBadge];
        return;
    }
    // 2.2-9-57：-56 只在 layoutBadgeInView 前判了 !dragging，但 refresh 里滚动/稳定
    // 判定失败的分支会直接把两个胶囊 hidden=YES；拖动时 1/30 秒重试定时器和 1–3 秒
    // 主定时器仍在触发 refresh，胶囊拖着拖着就消失。拖动期间整段 refresh 跳过，
    // 松手后再由 handleBadgePan 的 scheduleRefresh 重新布局。
    if (self.dragging) {
        return;
    }
    // 每次刷新读一次设置快照，热路径（布局/滚动回调）不再反复读解析。
    self.settings = [DYYYLivePreviewSettings currentSettings];
    BOOL viewersEnabled = self.settings.viewersOn;
    BOOL cardDurationEnabled = self.settings.cardDurationOn;
    if (!viewersEnabled && !cardDurationEnabled) {
        [self stopTimer];
        [self removeBadge];
        [self resetViewerCount];
        return;
    }
    if ([DYYYLivePreviewValueForKey(controller, @"roomEntered") boolValue] ||
        [DYYYLivePreviewValueForKey(controller, @"willEnterLiveRoom") boolValue]) {
        [self stopTimer];
        [self removeBadge];
        return;
    }

    [self startTimer];
    id viewModel = DYYYLivePreviewValueForKey(controller, @"viewModel");
    if (!DYYYLivePreviewIsRecommendationPreview(controller) ||
        [DYYYLivePreviewValueForKey(viewModel, @"didEndedLive") boolValue]) {
        [self removeBadge];
        [self resetViewerCount];
        return;
    }
    for (UIView *view = root; view; view = view.superview) {
        if (view.hidden || view.alpha <= 0.01) {
            [self removeBadge];
            return;
        }
    }
    CGRect windowRect = [root convertRect:root.bounds toView:root.window];
    if (!DYYYLivePreviewUsableRect(windowRect) || !CGRectIntersectsRect(windowRect, root.window.bounds)) {
        [self removeBadge];
        return;
    }

    BOOL moving = DYYYLivePreviewScrollIsMoving(DYYYLivePreviewScrollView(root));
    double now = CACurrentMediaTime();
    if (moving || !DYYYLivePreviewIsMostlyVisible(controller) || !CGRectEqualToRect(self.stableRect, windowRect)) {
        self.stableRect = windowRect;
        self.stableAt = now;
        self.layoutRetriesRemaining = 15;
        self.badge.hidden = YES;
        self.durationBadge.hidden = YES;
        [self retryInitialLayout];
        return;
    }
    if (now - self.stableAt < .20) {
        self.badge.hidden = YES;
        self.durationBadge.hidden = YES;
        [self retryInitialLayout];
        return;
    }
    [root layoutIfNeeded];
    if (!self.statusLabel || ![self.statusLabel isDescendantOfView:root]) {
        id tipView = DYYYLivePreviewValueForKey(controller, @"getLiveStatusTipView");
        UIView *label = [tipView isKindOfClass:[UIView class]] ? DYYYLivePreviewFindStatusLabel(tipView, 0) : nil;
        self.statusLabel = label && [label isDescendantOfView:root] ? label : DYYYLivePreviewFindStatusLabel(root, 0);
    }
    NSString *roomID = nil;
    NSArray *rooms = DYYYLivePreviewPreviewRooms(controller, self.statusLabel, &roomID);
    if (!roomID || ![self.viewerRoomID isEqualToString:roomID]) {
        [self resetViewerCount];
        self.viewerRoomID = roomID;
    }
    if (cardDurationEnabled) {
        for (id room in rooms) {
            double start = DYYYLivePreviewRoomStart(room, roomID, 0);
            if (start) {
                self.roomStart = start;
                break;
            }
        }
    }
    if ((viewersEnabled && (self.sampleRequested || !self.lastViewerCount)) || (cardDurationEnabled && !self.roomStart)) {
        NSNumber *sample = self.hasNetworkCount ? nil : DYYYLivePreviewViewerCount(rooms);
        if (sample) {
            self.lastViewerCount = sample;
        }
        self.sampleRequested = NO;
        [self requestViewerCountForRoomID:roomID];
    }
    NSNumber *count = self.lastViewerCount;
    if (viewersEnabled && count) {
        if (!self.badge) {
            self.badge = [[DYYYLivePreviewCapsule alloc] initWithFrame:CGRectZero];
            [self attachPanGestureToBadge:self.badge];
        }
        if (self.badge.superview != root) {
            [root addSubview:self.badge];
        }
        [self.badge applyCapsuleSize:self.settings.size];
        NSString *text = self.settings.exactFormat ? DYYYLivePreviewFormatCountPrecise(count.longLongValue)
                                                   : DYYYLivePreviewFormatCountCompact(count.longLongValue);
        [self.badge setViewerCountString:text];
    } else {
        [self.badge removeFromSuperview];
        self.badge = nil;
    }
    NSString *elapsed = cardDurationEnabled ? DYYYLivePreviewElapsedDigits(self.roomStart) : nil;
    if (elapsed.length) {
        if (!self.durationBadge) {
            self.durationBadge = [[DYYYLivePreviewCapsule alloc] initWithFrame:CGRectZero];
            [self attachPanGestureToBadge:self.durationBadge];
        }
        if (self.durationBadge.superview != root) {
            [root addSubview:self.durationBadge];
        }
        [self.durationBadge applyCapsuleSize:self.settings.size];
        [self.durationBadge setElapsedString:elapsed];
    } else {
        [self.durationBadge removeFromSuperview];
        self.durationBadge = nil;
    }
    // 拖动期间不重新布局，免得手势和刷新互相拉扯（-53 教训）。
    if ((self.badge || self.durationBadge) && !self.dragging) {
        [self layoutBadgeInView:root];
    }
    // 2.2-9-60：稳定刷新跑完了、数据还缺（模型没数、网络还没回来），开一条
    // 最多两发的延时补刷链，免得干等主定时器下一跳。
    [self armCatchUpRefreshIfNeeded];
}

@end

static DYYYLivePreviewState *DYYYLivePreviewStateForController(UIViewController *controller, BOOL create) {
    if (!controller) {
        return nil;
    }
    DYYYLivePreviewState *state = objc_getAssociatedObject(controller, &kDYYYLivePreviewStateKey);
    if (!state && create) {
        state = [[DYYYLivePreviewState alloc] initWithController:controller];
        objc_setAssociatedObject(controller, &kDYYYLivePreviewStateKey, state, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
    }
    return state;
}

// 2.2-9-57（症状 2 闪一下）：从传入的模型里取房间号。宿主在卡片出现前后会多次
// 调 configureWithModel/setModel/setViewModel，-56 每次都先 clearContent（清掉
// 两个胶囊、重置计数、丢掉锚点）再重建，同房间重复绑定时胶囊闪灭一次再出现。
// 同房间时跳过 clearContent、只刷新；房间变了仍走原来的 clearContent。
static NSString *DYYYLivePreviewRoomIDForModel(id model) {
    if (!model) {
        return nil;
    }
    NSString *roomID = DYYYLivePreviewRoomIdentifier(model);
    if (roomID) {
        return roomID;
    }
    for (NSString *key in @[@"model", @"room", @"rawDataRoomModel", @"rawHTSLiveRoomModel", @"roomModel", @"cellRoom"]) {
        id nested = DYYYLivePreviewValueForKey(model, key);
        roomID = DYYYLivePreviewRoomIdentifier(nested);
        if (roomID) {
            return roomID;
        }
    }
    return nil;
}

static void DYYYLivePreviewClearContentIfRoomChanged(UIViewController *controller, id model) {
    DYYYLivePreviewState *state = DYYYLivePreviewStateForController(controller, NO);
    NSString *newRoomID = DYYYLivePreviewRoomIDForModel(model);
    if (!newRoomID || !state.viewerRoomID || ![newRoomID isEqualToString:state.viewerRoomID]) {
        [state clearContent];
    }
}

static void DYYYLivePreviewActivatePreview(UIViewController *controller) {
    DYYYLivePreviewState *state = DYYYLivePreviewStateForController(controller, YES);
    [state activate];
}

#pragma mark - Hook：推荐页直播预览控制器

// 只钩生命周期与模型设置方法；DYYY.xm 里已有的文案防重复上移（-23）与全屏判断都在
// layoutSubviews/响应链里，这里不碰 AWELiveNewPreStreamViewController 的 layoutSubviews。
%hook AWELiveNewPreStreamViewController

- (void)configureWithModel:(id)model {
    DYYYLivePreviewClearContentIfRoomChanged(self, model);
    %orig;
    [DYYYLivePreviewStateForController(self, NO) scheduleRefresh];
}

- (void)setModel:(id)model {
    DYYYLivePreviewClearContentIfRoomChanged(self, model);
    %orig;
    [DYYYLivePreviewStateForController(self, NO) scheduleRefresh];
}

- (void)setViewModel:(id)viewModel {
    DYYYLivePreviewClearContentIfRoomChanged(self, viewModel);
    %orig;
    [DYYYLivePreviewStateForController(self, NO) scheduleRefresh];
}

- (void)setRoomEntered:(BOOL)roomEntered {
    %orig;
    [DYYYLivePreviewStateForController(self, NO) scheduleRefresh];
}

- (void)setWillEnterLiveRoom:(BOOL)willEnterLiveRoom {
    %orig;
    [DYYYLivePreviewStateForController(self, NO) scheduleRefresh];
}

- (void)prepareForDisplay {
    %orig;
    DYYYLivePreviewActivatePreview(self);
}

- (void)pageWillAppear:(BOOL)animated {
    %orig;
    DYYYLivePreviewActivatePreview(self);
}

- (void)pageDidAppear:(BOOL)animated {
    %orig;
    DYYYLivePreviewActivatePreview(self);
}

- (void)viewWillAppear:(BOOL)animated {
    %orig;
    DYYYLivePreviewActivatePreview(self);
}

- (void)viewDidAppear:(BOOL)animated {
    %orig;
    DYYYLivePreviewActivatePreview(self);
}

- (void)viewDidLayoutSubviews {
    %orig;
    [DYYYLivePreviewStateForController(self, NO) scheduleRefresh];
}

- (void)viewWillDisappear:(BOOL)animated {
    %orig;
    [DYYYLivePreviewStateForController(self, NO) beginDisappearance];
}

- (void)viewDidDisappear:(BOOL)animated {
    %orig;
    [DYYYLivePreviewStateForController(self, NO) beginDisappearance];
}

- (void)pageWillDisappear:(BOOL)animated {
    %orig;
    [DYYYLivePreviewStateForController(self, NO) beginDisappearance];
}

- (void)pageDidDisappear:(BOOL)animated {
    %orig;
    [DYYYLivePreviewStateForController(self, NO) beginDisappearance];
}

- (void)didEndDisplaying {
    %orig;
    [DYYYLivePreviewStateForController(self, NO) beginDisappearance];
}

- (void)prepareForReuse {
    [DYYYLivePreviewStateForController(self, NO) deactivate];
    %orig;
}

- (void)reset {
    [DYYYLivePreviewStateForController(self, NO) deactivate];
    %orig;
}

%end

#pragma mark - Hook：直播状态标签（-59 已整段删掉）

// 2.2-9-59：-58 只删了这组钩里的 layoutSubviews，用户反馈 -58 仍冻，说明 -58 的
// 定罪是错的，或者 layoutSubviews 只是循环的一条路。-59 把这组钩剩下三处
// （setViewModel / didMoveToWindow / didMoveToSuperview）也全部删掉，不再靠状态
// 标签触发刷新；锚点改回由 refresh 里 DYYYLivePreviewFindStatusLabel 现找
// （-56 的做法）。同时 -59 还摘了 NSUserDefaultsDidChangeNotification 订阅、
// 重试多给的两轮、星牌 constructor 安装（见各处注释）。若 -59 仍冻，根因在保留
// 的逻辑修法或 -56 本身里，下一步逐项摘预留位置/同房间跳过/拖动修法。
