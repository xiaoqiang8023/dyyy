#import "DYYYFansModel.h"
#import "DYYYFansPolicy.h"

static NSString *DYYYFansTrim(NSString *text) { return [text stringByTrimmingCharactersInSet:NSCharacterSet.whitespaceAndNewlineCharacterSet]; }
BOOL DYYYFansShareURL(NSURL *url) {
    if (![url.scheme.lowercaseString isEqual:@"https"] || url.user.length || url.password.length || (url.port && url.port.integerValue != 443)) return NO;
    NSString *host = url.host.lowercaseString;
    for (NSString *domain in @[@"douyin.com", @"iesdouyin.com", @"amemv.com"]) {
        if ([host isEqual:domain] || [host hasSuffix:[@"." stringByAppendingString:domain]]) return YES;
    }
    return NO;
}
static NSDictionary *DYYYFansURLTarget(NSURL *url) {
    NSURLComponents *parts = [NSURLComponents componentsWithURL:url resolvingAgainstBaseURL:NO];
    NSMutableDictionary *query = [NSMutableDictionary dictionary];
    for (NSURLQueryItem *item in parts.queryItems) if (item.value.length) query[item.name] = item.value;
    NSArray *path = [parts.path componentsSeparatedByString:@"/"];
    for (NSUInteger i = 0; i + 1 < path.count; i++) {
        NSString *kind = path[i], *value = path[i + 1];
        if (([kind isEqual:@"video"] || [kind isEqual:@"note"] || [kind isEqual:@"slides"]) && DYYYFansUID(value)) return @{@"kind": @"video", @"value": value};
        if ([kind isEqual:@"user"]) {
            if (DYYYFansSecUID(value)) return @{@"kind": @"secUID", @"value": value};
            if (DYYYFansUID(value)) return @{@"kind": @"uid", @"value": value};
        }
    }
    for (NSString *key in @[@"modal_id", @"aweme_id", @"item_id"]) if (DYYYFansUID(query[key])) return @{@"kind": @"video", @"value": query[key]};
    for (NSString *key in @[@"sec_uid", @"sec_user_id"]) if (DYYYFansSecUID(query[key])) return @{@"kind": @"secUID", @"value": query[key]};
    if (DYYYFansUID(query[@"user_id"])) return @{@"kind": @"uid", @"value": query[@"user_id"]};
    return @{@"kind": @"url", @"value": url.absoluteString};
}
NSDictionary *DYYYFansParseInput(NSString *input, DYYYFansInputMode mode, NSError **error) {
    NSString *text = [input isKindOfClass:NSString.class] ? DYYYFansTrim(input) : @"";
    if (!text.length || text.length > 8192) { if (error) *error = DYYYFansError(400, @"请输入分享链接、抖音号或 UID。"); return nil; }
    if (mode == DYYYFansInputUID || [text.lowercaseString hasPrefix:@"uid:"]) {
        NSString *uid = [text.lowercaseString hasPrefix:@"uid:"] ? DYYYFansTrim([text substringFromIndex:4]) : text;
        if (DYYYFansUID(uid)) return @{@"kind": @"uid", @"value": uid};
        if (error) *error = DYYYFansError(400, @"UID 应为纯数字；主页显示的抖音号请使用“抖音号”模式。"); return nil;
    }
    if ([text.lowercaseString hasPrefix:@"sec_uid:"]) text = DYYYFansTrim([text substringFromIndex:8]);
    if (DYYYFansSecUID(text)) return @{@"kind": @"secUID", @"value": text};
    if (mode != DYYYFansInputHandle) {
        NSRegularExpression *regex = [NSRegularExpression regularExpressionWithPattern:@"https?://[^\\s<>\\\"，。]+" options:NSRegularExpressionCaseInsensitive error:nil];
        NSTextCheckingResult *match = [regex firstMatchInString:text options:0 range:NSMakeRange(0, text.length)];
        if (match) {
            NSString *link = [[text substringWithRange:match.range] stringByTrimmingCharactersInSet:[NSCharacterSet characterSetWithCharactersInString:@".,;!?)）】〕}]"]];
            NSURLComponents *parts = [NSURLComponents componentsWithString:link];
            if ([parts.scheme.lowercaseString isEqual:@"http"]) parts.scheme = @"https";
            if (DYYYFansShareURL(parts.URL)) return DYYYFansURLTarget(parts.URL);
            if (error) *error = DYYYFansError(400, @"请使用抖音作品或用户主页的分享链接。"); return nil;
        }
    }
    if ([text hasPrefix:@"抖音号："] || [text hasPrefix:@"抖音号:"]) text = DYYYFansTrim([text substringFromIndex:4]);
    if ([text hasPrefix:@"@"]) text = [text substringFromIndex:1];
    if (DYYYFansASCIIHandle(text.UTF8String, [text lengthOfBytesUsingEncoding:NSUTF8StringEncoding])) return @{@"kind": @"handle", @"value": text};
    if (error) *error = DYYYFansError(400, @"无法识别输入，请粘贴完整分享内容，或输入准确的抖音号。");
    return nil;
}
NSString *DYYYFansImageURL(id object) {
    if ([object isKindOfClass:NSURL.class]) object = [object absoluteString];
    if ([object isKindOfClass:NSString.class]) {
        NSURL *url = [NSURL URLWithString:object];
        return [url.scheme.lowercaseString isEqual:@"https"] && url.host.length && [object length] <= 4096 ? object : @"";
    }
    id list = [object isKindOfClass:NSArray.class] ? object : DYYYFansFirst(object, @[@"url_list", @"urlListArray", @"originURLList", @"URLList", @"urlList"]);
    if ([list isKindOfClass:NSArray.class]) for (id item in list) {
        if (![item isKindOfClass:NSString.class]) continue;
        NSString *url = DYYYFansImageURL(item); if (url.length) return url;
    }
    return @"";
}
NSDictionary *DYYYFansPerson(id object) {
    if (!object) return nil;
    id nested = DYYYFansFirst(object, @[@"user", @"user_info", @"userInfo"]); if (nested) object = nested;
    if ([DYYYFansString(DYYYFansFirst(object,@[@"secUID",@"sec_uid",@"sec_user_id",@"secUserID",@"secUid"])) isEqual:@"111111"]) return nil;
    NSString *uid = @"", *sec = @"";
    for (NSString *key in @[@"uid", @"userID", @"id_str", @"idStr", @"id_p", @"id"]) {
        NSString *value = DYYYFansString(DYYYFansRead(object, key)); if (DYYYFansUID(value)) { uid = value; break; }
    }
    for (NSString *key in @[@"secUID", @"sec_uid", @"sec_user_id", @"secUserID", @"secUid"]) {
        NSString *value = DYYYFansString(DYYYFansRead(object, key)); if (DYYYFansSecUID(value)) { sec = value; break; }
    }
    if ((!uid.length && !sec.length) || [uid isEqual:@"111111"] || [sec isEqual:@"111111"] || [DYYYFansRead(object,@"is_anonymous") boolValue]) return nil;
    NSString *handle = @"";
    for (NSString *key in @[@"handle", @"unique_id", @"uniqueIDForShow", @"uniqueID", @"display_id", @"customID", @"short_id", @"shortID", @"shortId"]) {
        NSString *value = DYYYFansTrim(DYYYFansString(DYYYFansRead(object, key)));
        if (value.length && ![value isEqual:@"0"]) { handle = value; break; }
    }
    if (!handle.length) {
        NSString *display = DYYYFansTrim(DYYYFansString(DYYYFansCall(object, @"uniqueIDForShow", @[])));
        if (display.length && ![display isEqual:@"0"]) handle = display;
    }
    NSString *avatar = DYYYFansImageURL(DYYYFansFirst(object, @[@"avatarURL", @"avatar_medium", @"avatarMedium", @"avatar_thumb", @"avatarThumb"]));
    NSString *room = DYYYFansString(DYYYFansFirst(object, @[@"roomID", @"room_id", @"roomId"]));
    if (!DYYYFansUID(room)) {
        id details = DYYYFansFirst(object, @[@"roomDict", @"room_data", @"roomData", @"roomDataInfo"]);
        if ([details isKindOfClass:NSString.class] && [details length] < 131072) details = [NSJSONSerialization JSONObjectWithData:[details dataUsingEncoding:NSUTF8StringEncoding] options:0 error:nil];
        room = DYYYFansString(DYYYFansFirst(details, @[@"id_str", @"id", @"id_p", @"room_id", @"roomID"]));
    }
    NSMutableDictionary *person = [@{@"uid": uid, @"secUID": sec, @"name": DYYYFansString(DYYYFansFirst(object, @[@"name", @"nickname", @"nickName"])), @"handle": handle, @"avatarURL": avatar, @"roomID": DYYYFansUID(room) ? room : @"0", @"signature": DYYYFansString(DYYYFansFirst(object,@[@"signature",@"bio"])), @"ipLocation": DYYYFansString(DYYYFansFirst(object,@[@"ip_location",@"ipLocation"]))} mutableCopy];
    NSDictionary *keys = @{@"followers":@[@"followers",@"follower_count",@"followerCount"], @"following":@[@"following",@"following_count",@"followingCount"], @"likes":@[@"likes",@"total_favorited",@"totalFavorited"], @"works":@[@"works",@"aweme_count",@"awemeCount"]};
    for (NSString *key in keys) { NSNumber *value = DYYYFansInteger(DYYYFansFirst(object,keys[key])); if (value) person[key] = value; }
    return person;
}
BOOL DYYYFansHandleMatches(id object, NSString *handle) {
    if (!handle.length) return NO;
    NSDictionary *person = DYYYFansPerson(object);
    if (!person) return NO;
    if ([DYYYFansString(person[@"handle"]) caseInsensitiveCompare:handle] == NSOrderedSame) return YES;
    for (NSString *key in @[@"short_id", @"shortID", @"shortId", @"customID", @"unique_id", @"uniqueIDForShow", @"uniqueID"]) {
        NSString *value = DYYYFansTrim(DYYYFansString(DYYYFansRead(object, key)));
        if (value.length && ![value isEqual:@"0"] && [value caseInsensitiveCompare:handle] == NSOrderedSame) return YES;
    }
    return NO;
}
static void DYYYFansCollectSearchPeople(id value, NSMutableDictionary *people, NSUInteger depth, NSUInteger *budget) {
    if (!value || depth > 6 || !*budget) return;
    (*budget)--;
    if ([value isKindOfClass:NSArray.class]) {
        for (id item in value) { if (!*budget) break; DYYYFansCollectSearchPeople(item, people, depth + 1, budget); }
        return;
    }
    NSDictionary *person = DYYYFansPerson(value);
    if (person) {
        NSString *key = [person[@"uid"] length] ? person[@"uid"] : person[@"secUID"];
        if (key.length) people[key] = @{ @"person": person, @"raw": DYYYFansFirst(value, @[@"userInfo", @"user_info", @"user"]) ?: value };
    }
    for (NSString *key in @[@"user_list", @"users", @"data", @"items", @"user_info", @"userInfo", @"user"]) {
        if (!*budget) break; DYYYFansCollectSearchPeople(DYYYFansRead(value, key), people, depth + 1, budget);
    }
}
NSArray<NSDictionary *> *DYYYFansSearchPeople(id response) {
    NSMutableDictionary *people = [NSMutableDictionary dictionary]; NSUInteger budget = 800;
    DYYYFansCollectSearchPeople(response, people, 0, &budget); return people.allValues;
}
BOOL DYYYFansSamePerson(NSDictionary *expected, NSDictionary *actual) {
    if (!expected || !actual) return NO;
    if ([actual[@"uid"] isEqual:@"111111"] || [actual[@"secUID"] isEqual:@"111111"]) return NO;
    BOOL uid = DYYYFansUID(expected[@"uid"]) && DYYYFansUID(actual[@"uid"]);
    BOOL sec = DYYYFansSecUID(expected[@"secUID"]) && DYYYFansSecUID(actual[@"secUID"]);
    if (uid && ![expected[@"uid"] isEqual:actual[@"uid"]]) return NO;
    if (sec && ![expected[@"secUID"] isEqual:actual[@"secUID"]]) return NO;
    return uid || sec;
}
NSString *DYYYFansPersonName(NSDictionary *person) {
    for (NSString *key in @[@"name", @"handle", @"uid", @"secUID"]) if (DYYYFansString(person[key]).length) return person[key];
    return @"用户";
}
static NSDictionary *DYYYFansClub(id raw) {
    if (!raw) return nil;
    NSNumber *level = DYYYFansInteger(DYYYFansRead(raw, @"level"));
    NSString *anchor = DYYYFansString(DYYYFansFirst(raw, @[@"anchor_id", @"anchorId", @"anchorID"]));
    NSString *name = DYYYFansString(DYYYFansFirst(raw, @[@"club_name", @"clubName"]));
    if ((!DYYYFansUID(anchor) && !name.length) || (level && level.integerValue > 1000)) return nil;
    if ((!level || !level.integerValue) && !name.length) return nil;
    NSMutableDictionary *club = [@{@"anchorUID": DYYYFansUID(anchor) ? anchor : @"", @"clubName": name, @"anchorName": @"", @"avatarURL": @""} mutableCopy];
    if (level) club[@"level"] = level;
    NSNumber *status = DYYYFansInteger(DYYYFansFirst(raw, @[@"user_fans_club_status", @"userFansClubStatus"]));
    if (status) club[@"status"] = status;
    return club;
}
@implementation DYYYFansResult
+ (instancetype)fromUser:(id)user target:(NSDictionary *)target error:(NSError **)error {
    return [self fromUser:user target:target anchor:nil error:error];
}
+ (instancetype)fromUser:(id)user target:(NSDictionary *)target anchor:(NSDictionary *)anchor error:(NSError **)error {
    NSDictionary *identity = DYYYFansPerson(user);
    if (!DYYYFansSamePerson(target, identity)) { if (error) *error = DYYYFansError(409, @"返回的用户与查询对象不一致，已忽略这次结果。"); return nil; }
    DYYYFansResult *result = [self new];
    NSMutableDictionary *person = [target mutableCopy];
    for (NSString *key in identity) if (DYYYFansString(identity[key]).length) person[key] = identity[key];
    result.person = person; result.anchor = anchor; result.date = NSDate.date;
    id grade = DYYYFansFirst(user, @[@"pay_grade", @"payGrade"]);
    if (DYYYFansRead(user, @"hasPayGrade") && ![DYYYFansRead(user, @"hasPayGrade") boolValue]) grade = nil;
    NSNumber *level = DYYYFansInteger(DYYYFansRead(grade, @"level"));
    if (level && level.integerValue <= 1000) result.level = level;
    NSNumber *minimum = DYYYFansInteger(DYYYFansFirst(grade, @[@"this_grade_min_diamond", @"thisGradeMinDiamond"]));
    NSNumber *maximum = DYYYFansInteger(DYYYFansFirst(grade, @[@"this_grade_max_diamond", @"thisGradeMaxDiamond"]));
    if (result.level && minimum && maximum && maximum.longLongValue > minimum.longLongValue) { result.minimum = minimum; result.maximum = maximum; }
    id fans = DYYYFansFirst(user, @[@"fans_club", @"fansClub"]);
    if (DYYYFansRead(user, @"hasFansClub") && ![DYYYFansRead(user, @"hasFansClub") boolValue]) fans = nil;
    NSMutableArray *rawClubs = [NSMutableArray array];
    BOOL currentPresent = !DYYYFansRead(fans, @"hasData_p") || [DYYYFansRead(fans, @"hasData_p") boolValue];
    id current = currentPresent ? ([fans isKindOfClass:NSDictionary.class] ? DYYYFansRead(fans, @"data") : DYYYFansRead(fans, @"data_p")) : nil;
    if (current) [rawClubs addObject:current];
    id preferred = DYYYFansFirst(fans, @[@"prefer_data", @"preferData"]);
    if ([preferred isKindOfClass:NSDictionary.class]) [rawClubs addObjectsFromArray:[preferred allValues]];
    else if (DYYYFansHas(preferred, @"enumerateKeysAndObjectsUsingBlock:", "v", "@")) {
        // 闪退修 6：原移植把枚举块的 key 参数写成 int32_t，键是对象时类型对不上。
        // 虽然旧代码没解引用 key、一般不会直接崩，但属于明确的类型错误，改成对象类型。
        void (^each)(id, id, BOOL *) = ^(id key, id value, BOOL *stop) {
            (void)key;
            if (value) [rawClubs addObject:value]; if (rawClubs.count >= 300) *stop = YES;
        };
        DYYYFansCall(preferred, @"enumerateKeysAndObjectsUsingBlock:", @[each]);
    }
    NSMutableDictionary *clubs = [NSMutableDictionary dictionary];
    for (id raw in rawClubs) {
        NSDictionary *club = DYYYFansClub(raw); if (!club) continue;
        if (raw == current && anchor && DYYYFansUID(anchor[@"uid"]) && DYYYFansUID(anchor[@"roomID"]) && ![club[@"anchorUID"] length] && [club[@"level"] integerValue] > 0) {
            NSMutableDictionary *contextual = [club mutableCopy]; contextual[@"anchorUID"] = anchor[@"uid"]; contextual[@"anchorName"] = DYYYFansPersonName(anchor); contextual[@"avatarURL"] = anchor[@"avatarURL"] ?: @""; club = contextual;
        }
        NSString *key = [club[@"anchorUID"] length] ? club[@"anchorUID"] : [@"name:" stringByAppendingString:club[@"clubName"]];
        NSDictionary *old = clubs[key];
        if (!old || [club[@"level"] integerValue] > [old[@"level"] integerValue]) clubs[key] = club;
    }
    result.clubs = [clubs.allValues sortedArrayUsingComparator:^NSComparisonResult(NSDictionary *a, NSDictionary *b) {
        NSComparisonResult order = [@( [b[@"level"] integerValue]) compare:@([a[@"level"] integerValue])];
        return order == NSOrderedSame ? [a[@"clubName"] compare:b[@"clubName"]] : order;
    }];
    result.source = @"抖音直播服务";
    result.diagnostic = [NSString stringWithFormat:@"pay_grade=%@; fans_club=%@; current_badge=%@; preferred_map=%@; records=%lu; recognized=%lu", grade ? @"present" : @"absent", fans ? @"present" : @"absent", current ? @"present" : @"absent", preferred ? NSStringFromClass([preferred class]) : @"absent", (unsigned long)rawClubs.count, (unsigned long)result.clubs.count];
    NSNumber *badgeLevel = DYYYFansInteger(DYYYFansRead(current, @"level"));
    NSString *badgeName = DYYYFansString(DYYYFansFirst(current, @[@"club_name", @"clubName"]));
    NSString *badgeAnchor = DYYYFansString(DYYYFansFirst(current, @[@"anchor_id", @"anchorId", @"anchorID"]));
    NSNumber *badgeStatus = DYYYFansInteger(DYYYFansFirst(current, @[@"user_fans_club_status", @"userFansClubStatus"]));
    result.diagnostic = [result.diagnostic stringByAppendingFormat:@"; badge_type=%@; badge_level=%@; badge_name=%@; badge_anchor=%@; badge_status=%@; preferred_entries=%lu",
        current ? NSStringFromClass([current class]) : @"absent", badgeLevel ? badgeLevel.stringValue : @"absent",
        badgeName.length ? @"present" : @"empty", DYYYFansUID(badgeAnchor) ? @"present" : @"empty", badgeStatus ? badgeStatus.stringValue : @"absent",
        (unsigned long)(rawClubs.count - (current ? 1 : 0))];
    result.notice = result.clubs.count ? @"已取得本次可查询的灯牌。" : @"暂未取得可确认的灯牌，不代表未加入。";
    return result;
}
+ (instancetype)fromProfileResponse:(id)response target:(NSDictionary *)target anchor:(NSDictionary *)anchor error:(NSError **)error {
    id data = DYYYFansRead(response,@"data") ?: response;
    id raw = DYYYFansFirst(data,@[@"user_data",@"userData",@"user"]);
    DYYYFansResult *result = raw ? [self fromUser:raw target:target anchor:anchor error:nil] : nil;
    id profile = DYYYFansFirst(data,@[@"user_profile",@"userProfile"]);
    id base = DYYYFansFirst(profile,@[@"base_info",@"baseInfo"]) ?: profile;
    NSDictionary *identity = DYYYFansPerson(base);
    if (DYYYFansSamePerson(target,identity)) {
        NSMutableDictionary *combined = [identity mutableCopy];
        id fans = DYYYFansFirst(profile,@[@"fans_club",@"fansClub"]); if (fans) combined[@"fans_club"] = fans;
        id grade = DYYYFansFirst(profile,@[@"pay_grade",@"payGrade"]); if (grade) combined[@"pay_grade"] = grade;
        DYYYFansResult *card = [self fromUser:combined target:target anchor:anchor error:nil];
        if (!result) result = card;
        else {
            if (!result.level && card.level) { result.level = card.level; result.minimum = card.minimum; result.maximum = card.maximum; }
            NSMutableDictionary *clubs = [NSMutableDictionary dictionary];
            for (NSDictionary *club in [result.clubs arrayByAddingObjectsFromArray:card.clubs ?: @[]]) {
                NSString *key = [club[@"anchorUID"] length] ? club[@"anchorUID"] : [@"name:" stringByAppendingString:club[@"clubName"]];
                clubs[key] = club;
            }
            result.clubs = clubs.allValues;
        }
    }
    if (!result && error) *error = DYYYFansError(409,@"暂未取得对应用户的资料，请稍后重试。");
    return result;
}
// 2.2-9-65：钻石换算人民币，10 钻石=1 元。1 钻石=0.1 元，用整数十分位算避免浮点误差。
+ (NSString *)rmbStringForDiamonds:(NSNumber *)diamonds {
    if (!diamonds) return nil;
    long long tenths = diamonds.longLongValue; // 人民币的十分位数
    if (tenths < 0) return nil;
    if (tenths >= 100000) { // ≥ ¥10000 用“万”，最多 1 位小数
        long long wanTenths = (tenths + 5000) / 10000; // 四舍五入到 0.1 万
        if (wanTenths % 10 == 0) return [NSString stringWithFormat:@"%lld万", wanTenths / 10];
        return [NSString stringWithFormat:@"%lld.%lld万", wanTenths / 10, wanTenths % 10];
    }
    long long yuan = tenths / 10, rem = tenths % 10;
    if (rem == 0) return [NSString stringWithFormat:@"%lld", yuan];
    return [NSString stringWithFormat:@"%lld.%lld", yuan, rem];
}
+ (NSString *)rmbRangeFromMinimum:(NSNumber *)minimum maximum:(NSNumber *)maximum {
    NSString *low = [self rmbStringForDiamonds:minimum];
    if (!low) return nil;
    if (!maximum) return [NSString stringWithFormat:@"¥%@ 以上", low];
    NSString *high = [self rmbStringForDiamonds:maximum];
    if (!high) return [NSString stringWithFormat:@"¥%@ 以上", low];
    return [NSString stringWithFormat:@"¥%@–%@", low, high];
}
- (NSString *)shareText {
    NSMutableArray *lines = [NSMutableArray arrayWithObjects:DYYYFansPersonName(self.person), [@"UID：" stringByAppendingString:DYYYFansString(self.person[@"uid"])], nil];
    if ([self.person[@"handle"] length]) [lines addObject:[@"抖音号：" stringByAppendingString:self.person[@"handle"]]];
    [lines addObject:self.level ? [NSString stringWithFormat:@"消费等级：Lv.%@", self.level] : @"消费等级：未返回"];
    if (self.minimum && self.maximum) [lines addObject:[NSString stringWithFormat:@"等级钻石区间：%@–%@（非实际消费金额）", self.minimum, self.maximum]];
    // 2.2-9-65：复制结果里也加人民币约算；只有下限（最高等级）时写“¥X 以上”，没有区间时不编数字。
    NSString *rmbRange = [DYYYFansResult rmbRangeFromMinimum:self.minimum maximum:self.maximum];
    if (rmbRange) [lines addObject:[NSString stringWithFormat:@"约合人民币：%@（按 10 钻=1 元）", rmbRange]];
    for (NSDictionary *club in self.clubs) {
        NSString *name = [club[@"anchorName"] length] ? club[@"anchorName"] : [club[@"clubName"] length] ? club[@"clubName"] : club[@"anchorUID"];
        [lines addObject:[NSString stringWithFormat:@"%@ · 灯牌 %@", name, club[@"level"] ? [@"Lv." stringByAppendingString:[club[@"level"] stringValue]] : @"未返回"]];
    }
    if (self.notice.length) [lines addObject:self.notice];
    // 2.2-9-63：复制结果里带上诊断串（pay_grade/fans_club/current_badge/preferred_map/
    // records/recognized），灯牌查不到时用户贴回复制结果才能判断数据到底回没回来。
    if (self.diagnostic.length) [lines addObject:[@"诊断：" stringByAppendingString:self.diagnostic]];

    NSDateFormatter *format = [NSDateFormatter new]; format.dateFormat = @"yyyy-MM-dd HH:mm:ss";
    if (self.date) [lines addObject:[@"查询时间：" stringByAppendingString:[format stringFromDate:self.date]]];
    return [lines componentsJoinedByString:@"\n"];
}
@end
