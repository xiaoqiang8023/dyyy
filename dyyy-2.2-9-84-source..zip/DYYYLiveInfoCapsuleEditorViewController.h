// DYYYLiveInfoCapsuleEditorViewController.h — “卡片胶囊样式”编辑子页（2.2-9-68）。
// 对齐 / 上下顺序 / 大小三项 + 实时预览，点“保存”后才写入三键。
#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface DYYYLiveInfoCapsuleEditorViewController : UITableViewController
@end

NS_ASSUME_NONNULL_END
