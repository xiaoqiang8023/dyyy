// DYYYRecallReentry.h
// 由 DY778RecallReentry.h 移植（DY778 → DYYY 前缀重命名，逻辑不变）。
// 线程局部的重入帧栈：防止防撤回 Hook 在读写 TIMXOMessage 自身属性时递归触发自己。
// 读/写 content、recalled 等属性前先查帧，Hook 内部的原生调用看到的是真实值。
#ifndef DYYY_RECALL_REENTRY_H
#define DYYY_RECALL_REENTRY_H
#include <stdbool.h>

typedef struct DYYYRecallFrame {
    const void *object;
    unsigned int operation;
    struct DYYYRecallFrame *previous;
} DYYYRecallFrame;

enum {
    DYYYRecallReadContent = 1,
    DYYYRecallReadFlag,
    DYYYRecallWriteContent,
    DYYYRecallWriteFlag,
    DYYYRecallWriteOriginal,
    DYYYRecallApply,
    DYYYRecallApplyV2,
    DYYYRecallWriteEdit
};

static inline bool DYYYRecallFrameContains(const DYYYRecallFrame *frame, const void *object, unsigned int operation) {
    for (; frame; frame = frame->previous)
        if (frame->object == object && frame->operation == operation) return true;
    return false;
}

static inline bool DYYYRecallFrameIsMutating(const DYYYRecallFrame *frame, const void *object) {
    for (; frame; frame = frame->previous)
        if (frame->object == object && frame->operation >= DYYYRecallWriteContent) return true;
    return false;
}

#endif
