// DYYYRadarUI.h — 特别关注：共用 UI 帮助与表控制器基类。
// 由 DY778RadarUI.h 移植，仅重命名；DY778Core 的外观/Toast/导航帮助改为 DYYY 自带实现
//（强调色沿用星牌移植的 systemTeal；Toast 走 DYYYUtils）。
#import <UIKit/UIKit.h>
#import "DYYYRadarMonitor.h"

UIWindow *DYYYRadarActiveWindow(void);
UIViewController *DYYYRadarTopController(UIViewController *controller);
UIUserInterfaceStyle DYYYRadarStyle(void);
UIColor *DYYYRadarAccent(void);
UIColor *DYYYRadarButtonColor(void);
UIColor *DYYYRadarAccentForeground(void);
UIColor *DYYYRadarBackground(void);
UIColor *DYYYRadarCardBackground(void);
UILabel *DYYYRadarLabel(NSString *text, CGFloat size, UIFontWeight weight);
UITableViewCell *DYYYRadarCell(NSString *title, NSString *subtitle, NSString *symbol, BOOL disclosure);
UITableViewCell *DYYYRadarPersonCell(NSDictionary *person, NSString *subtitle, BOOL disclosure);
void DYYYRadarToast(UIViewController *presenter, NSString *message);
void DYYYRadarMessage(UIViewController *presenter, NSString *title, NSString *message);
void DYYYRadarConfirm(UIViewController *presenter, NSString *title, NSString *message, NSString *button, dispatch_block_t action);
void DYYYRadarSheet(UIViewController *presenter, NSString *title, NSArray<NSString *> *options, void (^chosen)(NSUInteger index));
void DYYYRadarCopy(UIViewController *presenter, NSString *text);
void DYYYRadarCopySignature(UIViewController *presenter, id signature);
void DYYYRadarOpenVideo(UIViewController *presenter, NSString *videoID);
void DYYYRadarOpenSettings(void);
void DYYYRadarPresentController(UIViewController *source, UIViewController *controller);

@interface DYYYRadarTableController : UITableViewController
- (void)refresh;
- (void)updateTheme;
- (BOOL)checkAccount:(NSString *)account;
@end

@interface DYYYRadarSettingsViewController : DYYYRadarTableController
@end

@interface DYYYRadarPeoplePicker : DYYYRadarTableController
@end

@interface DYYYRadarHistoryController : DYYYRadarTableController
@property(nonatomic, copy) NSString *personID;
@end

@interface DYYYRadarPersonViewController : DYYYRadarTableController
@property(nonatomic, copy) NSString *personID;
@end

@interface DYYYRadarRecordController : DYYYRadarTableController
@property(nonatomic, copy) NSDictionary *record;
@end

void DYYYRadarShowNotice(NSArray<NSDictionary *> *events);
void DYYYRadarDismissNotice(void);
