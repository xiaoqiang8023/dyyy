#ifndef DYYYFans_POLICY_H
#define DYYYFans_POLICY_H
#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>

bool DYYYFansParseUnsigned(const char *text, size_t length, uint64_t maximum, uint64_t *value);
bool DYYYFansASCIIHandle(const char *text, size_t length);
bool DYYYFansASCIIUID(const char *text, size_t length);
bool DYYYFansASCIISECUid(const char *text, size_t length);
int DYYYFansProfileButtonWidth(double freeWidth);
bool DYYYFansCallbackCurrent(uint64_t expectedGeneration, uint64_t generation, uint64_t expectedOperation, uint64_t operation, bool pending);
#endif
