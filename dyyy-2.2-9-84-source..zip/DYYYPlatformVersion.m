#import <Foundation/Foundation.h>
#include <stdint.h>

// Linux-build-only shim for compiler-rt's __isPlatformVersionAtLeast, which
// Linux clang does not provide for iOS targets. Hidden visibility so it is
// never exported from the dylib and never interposes libSystem on device.
// Only iOS (platform 2) is used by DYYY's @available(iOS x, *) checks;
// other platforms return 0. When building with an Apple toolchain, remove
// this file from DYYY_FILES — compiler-rt provides the symbol there.
__attribute__((visibility("hidden")))
int __isPlatformVersionAtLeast(uint32_t platform, uint32_t major, uint32_t minor, uint32_t subminor) {
    if (platform != 2) return 0;
    NSOperatingSystemVersion v = [[NSProcessInfo processInfo] operatingSystemVersion];
    if ((uint32_t)v.majorVersion != major) return (uint32_t)v.majorVersion > major;
    if ((uint32_t)v.minorVersion != minor) return (uint32_t)v.minorVersion > minor;
    return (uint32_t)v.patchVersion >= subminor;
}
