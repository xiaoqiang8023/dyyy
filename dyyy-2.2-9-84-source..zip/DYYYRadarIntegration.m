// DYYYRadarIntegration.m — 由 DY778RadarIntegration.m 移植。
// 改动：删掉了上游订阅 DY778PreferencesChangedNotification 转发主题的那段观察者
//（DYYY 没有该通知；且全局 defaults 订阅正是 -57/-60 冻屏的教训，本模块只用自己的
// DYYYRadarStoreChanged / DYYYRadarMonitorAlert / DYYYRadarMonitorStatusChanged）。
// 聊天开关帮助只在父代理显式调用时运行，本身不 Hook 任何类。
#import "DYYYRadarIntegration.h"
#import "DYYYRadarUI.h"
#import "DYYYRadarNetwork.h"
#import <objc/runtime.h>

@protocol DYYYRadarChatItem <NSObject>
- (instancetype)initWithIdentifier:(NSString *)identifier;
@end

static NSDictionary *DYYYRadarChatPerson(id provider) {
    id context = DYYYRadarRead(provider, @"context");
    id conversation = DYYYRadarRead(context, @"conversation") ?: DYYYRadarRead(context, @"con");
    if ([DYYYRadarRead(conversation, @"isGroupChat") boolValue] || [DYYYRadarRead(conversation, @"isGroup") boolValue]) return nil;
    NSDictionary *person = DYYYRadarProfile(DYYYRadarRead(context, @"peerUser"));
    return [person[@"uid"] isEqual:DYYYRadarCurrentAccount()] ? nil : person;
}
void DYYYRadarAppendChatItem(id provider, NSMutableArray *items) {
    [DYYYRadarMonitor.shared synchronizeAccount];
    NSDictionary *person = DYYYRadarChatPerson(provider);
    NSString *uid = person[@"uid"], *account = DYYYRadarStore.shared.accountID;
    if (!uid.length || !account.length) return;
    Class cls = NSClassFromString(@"IESIMChatSettingsItemSwitchViewModel");
    Method initializer = class_getInstanceMethod(cls, @selector(initWithIdentifier:));
    if (!initializer || method_getNumberOfArguments(initializer) != 3) return;
    NSMethodSignature *signature = [NSMethodSignature signatureWithObjCTypes:method_getTypeEncoding(initializer)];
    if (signature.methodReturnType[0] != '@' || [signature getArgumentTypeAtIndex:2][0] != '@') return;
    id toggle = [(id<DYYYRadarChatItem>)[cls alloc] initWithIdentifier:@"com.dyyy.radar-switch"];
    NSDictionary *target = [DYYYRadarStore.shared target:uid];
    BOOL master = [DYYYRadarStore.shared.options[@"enabled"] boolValue];
    DYYYRadarSet(toggle, @"title", @"对此人特别关注");
    DYYYRadarSet(toggle, @"describe", master ? @"前台检测可见数据变化，记录新发现的喜欢作品" : @"先在 DYYY → 特别关注开启总开关");
    DYYYRadarSet(toggle, @"isOn", @(master && target && ![target[@"paused"] boolValue]));
    __weak id weakProvider = provider, weakToggle = toggle;
    void (^changed)(BOOL) = ^(BOOL on) {
        [DYYYRadarMonitor.shared synchronizeAccount];
        if (![account isEqual:DYYYRadarStore.shared.accountID] || ![uid isEqual:DYYYRadarChatPerson(weakProvider)[@"uid"]]) return;
        if (![DYYYRadarStore.shared.options[@"enabled"] boolValue]) {
            DYYYRadarSet(weakToggle, @"isOn", @NO);
            DYYYRadarToast(nil, @"请先在 DYYY → 特别关注开启总开关"); return;
        }
        NSError *error = nil;
        if (on && ![DYYYRadarStore.shared target:uid] && ![DYYYRadarStore.shared addProfiles:@[person] error:&error]) {
            DYYYRadarSet(weakToggle, @"isOn", @NO); DYYYRadarToast(nil, error.localizedDescription ?: @"暂时无法添加此人"); return;
        }
        [DYYYRadarStore.shared updateTarget:uid values:@{@"paused": @(!on)}];
        DYYYRadarSet(weakToggle, @"isOn", @(on));
        DYYYRadarToast(nil, on ? @"已开启对此人的特别关注" : @"已暂停对此人的特别关注");
    };
    if (toggle && DYYYRadarSet(toggle, @"manualSwitchChanged", changed)) [items addObject:toggle];
}
void DYYYInstallRadar(void) {
    [DYYYRadarMonitor.shared start];
    static dispatch_once_t once;
    dispatch_once(&once, ^{
        [NSNotificationCenter.defaultCenter addObserverForName:DYYYRadarMonitorAlert object:nil queue:NSOperationQueue.mainQueue usingBlock:^(NSNotification *note) {
            DYYYRadarShowNotice(note.object);
        }];
    });
}
