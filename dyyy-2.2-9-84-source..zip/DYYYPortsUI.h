// DYYYPortsUI.h — 移植功能（特别关注 / 消息留存 / 缓存管理）设置页共用外观。
// 样式照抄 DYYYRadarUI.m 的 DYYYRadarCell：UIListContentConfiguration、28pt 深青色
// systemTeal 图标、标题 Body 黑字、副标题 Footnote 灰字、上下边距 14、图标到文字间距 14。
// 只管外观，不管任何功能逻辑。
#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

// Subtitle 样式带图标行（开关行用它；开关由调用方设为 accessoryView）。
UITableViewCell *DYYYPortsIconCell(NSString *title, NSString * _Nullable subtitle, NSString * _Nullable symbol, BOOL disclosure);
// Value1 样式带图标行（右侧灰字数值 + 箭头）。
UITableViewCell *DYYYPortsValueCell(NSString *title, NSString * _Nullable value, NSString * _Nullable symbol, BOOL disclosure);
// 按“基本设置”页标准配表：浅灰底、自动行高、自动组头组尾。
void DYYYPortsConfigureTable(UITableView *tableView);

NS_ASSUME_NONNULL_END
