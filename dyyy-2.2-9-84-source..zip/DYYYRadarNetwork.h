// DYYYRadarNetwork.h — 特别关注：串行网络代理（一次一个请求，前台才跑）。
// 由 DY778RadarNetwork.h 移植，仅重命名。
#import "DYYYRadarModel.h"
#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

typedef void (^DYYYRadarReply)(id _Nullable value, NSError * _Nullable error);
typedef BOOL (^DYYYRadarIsCurrent)(void);
// 在主线程启动；返回的取消只作用于本次操作（绝非宿主共享服务）。
typedef dispatch_block_t _Nullable (^DYYYRadarStartOperation)(DYYYRadarReply reply, DYYYRadarIsCurrent isCurrent);

// .xm 按 ObjC++ 编译：C 函数声明必须包在 extern "C" 里，否则调用方
// 链接不到（-71：DYYYSettings.xm 调 DYYYRadarCurrentAccount 报未定义符号）。
#ifdef __cplusplus
extern "C" {
#endif

NSString *DYYYRadarCurrentAccount(void);
NSString *DYYYRadarDiagnosticText(NSError *error);

#ifdef __cplusplus
}
#endif

@interface DYYYRadarNetwork : NSObject
+ (instancetype)shared;
- (void)get:(NSString *)url parameters:(NSDictionary *)parameters owner:(NSString *)owner completion:(DYYYRadarReply)completion;
- (void)perform:(NSString *)stage owner:(NSString *)owner start:(DYYYRadarStartOperation)start completion:(DYYYRadarReply)completion;
- (void)cancelOwner:(NSString *)owner;
- (void)cancelAll;
@end

NS_ASSUME_NONNULL_END
