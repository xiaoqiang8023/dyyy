//  DYYYCacheSettingsViewController.m
//
//  缓存管理设置页（DY778 1.0-3 缓存页移植，文案与分组沿用上游截图）。
//  分组：本机缓存 / 打开时清理 / 自动整理 / 文件存放时间。
//  只订阅自家 DYYYCacheStatisticsChangedNotification；不碰 layoutSubviews，
//  不改任何 frame；全部文件操作都在 DYYYCacheCleaner 的后台队列里做。

#import "DYYYCacheSettingsViewController.h"
#import "DYYYCacheCleaner.h"
#import "DYYYPortsUI.h"

#pragma mark - 行标识

typedef NS_ENUM(NSInteger, DYYYCacheSection) {
    DYYYCacheSectionUsage = 0,   // 本机缓存
    DYYYCacheSectionLaunch,      // 打开时清理
    DYYYCacheSectionAuto,        // 自动整理
    DYYYCacheSectionAge,         // 文件存放时间
    DYYYCacheSectionCount
};

@interface DYYYCacheSettingsViewController ()

@property(nonatomic, strong, nullable) NSDictionary *cacheStatistics;
@property(nonatomic) BOOL cacheStatisticsPending;

@end

@implementation DYYYCacheSettingsViewController

#pragma mark - 生命周期

- (instancetype)init {
    return [super initWithStyle:UITableViewStyleInsetGrouped];
}

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"缓存管理";
    DYYYPortsConfigureTable(self.tableView);
    self.refreshControl = [[UIRefreshControl alloc] init];
    [self.refreshControl addTarget:self action:@selector(refreshCacheUsage) forControlEvents:UIControlEventValueChanged];
    [NSNotificationCenter.defaultCenter addObserver:self
                                           selector:@selector(cacheStatisticsChanged:)
                                               name:DYYYCacheStatisticsChangedNotification
                                             object:nil];
    [self loadCacheUsage:NO];
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    [self.tableView reloadData];
    [self loadCacheUsage:NO];
}

- (void)dealloc {
    [NSNotificationCenter.defaultCenter removeObserver:self];
}

#pragma mark - 分组与行

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return DYYYCacheSectionCount;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    switch ((DYYYCacheSection)section) {
        case DYYYCacheSectionUsage: return 3;   // 缓存用量 / 清理全部缓存 / 最近清理
        case DYYYCacheSectionLaunch: return 2;  // 启动时清理 / 从后台返回时清理
        case DYYYCacheSectionAuto: return 2;    // 按规则自动清理 / 可管理缓存上限
        case DYYYCacheSectionAge: return 2;     // 超过多久清理 / 自定义小时数
        case DYYYCacheSectionCount: return 0;
    }
}

- (NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section {
    switch ((DYYYCacheSection)section) {
        case DYYYCacheSectionUsage: return @"本机缓存";
        case DYYYCacheSectionLaunch: return @"打开时清理";
        case DYYYCacheSectionAuto: return @"自动整理";
        case DYYYCacheSectionAge: return @"文件存放时间";
        case DYYYCacheSectionCount: return nil;
    }
}

- (NSString *)tableView:(UITableView *)tableView titleForFooterInSection:(NSInteger)section {
    switch ((DYYYCacheSection)section) {
        case DYYYCacheSectionUsage:
            return @"清空应用缓存、临时文件、页面资源、投屏缓存和日志，仅保留识别到的插件配置。下拉刷新用量。";
        case DYYYCacheSectionLaunch:
            return @"两个开关独立生效，每次触发都会清空上述缓存。与下方容量、时间规则无关。";
        case DYYYCacheSectionAuto:
            return @"上限针对上述目录中的缓存，插件配置不计入。超限时先清理最旧文件；手动清空无需开启此项。";
        case DYYYCacheSectionAge:
            return @"时间与容量分别生效。“从不”只关闭按时间清理，容量超限仍会整理。使用抖音时新产生的缓存会计入下一次检查。";
        case DYYYCacheSectionCount: return nil;
    }
}

#pragma mark - Cell

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    // 图标只在这里设一次；configureCell 只改文字和标题颜色，不碰配置里的图标。
    UITableViewCell *cell = nil;
    switch ((DYYYCacheSection)indexPath.section) {
        case DYYYCacheSectionUsage:
            if (indexPath.row == 0) {
                cell = DYYYPortsIconCell(@"缓存用量", @"正在统计…", @"internaldrive", NO);
                cell.selectionStyle = UITableViewCellSelectionStyleNone;
            } else if (indexPath.row == 1) {
                cell = DYYYPortsIconCell(@"清理全部缓存", @"清空缓存目录，仅保留插件配置", @"sparkles", NO);
            } else {
                cell = DYYYPortsIconCell(@"最近清理", @"尚未清理", @"clock.arrow.circlepath", NO);
                cell.selectionStyle = UITableViewCellSelectionStyleNone;
            }
            break;
        case DYYYCacheSectionLaunch:
            if (indexPath.row == 0) {
                cell = DYYYPortsIconCell(@"启动抖音时清理", @"抖音重新启动后执行一次", @"power", NO);
                cell.accessoryView = [self switchForKey:DYYYCacheOnLaunchKey];
            } else {
                cell = DYYYPortsIconCell(@"从后台返回时清理", @"从其他应用返回抖音后执行一次", @"arrow.clockwise.circle", NO);
                cell.accessoryView = [self switchForKey:DYYYCacheOnReturnKey];
            }
            cell.selectionStyle = UITableViewCellSelectionStyleNone;
            break;
        case DYYYCacheSectionAuto:
            if (indexPath.row == 0) {
                cell = DYYYPortsIconCell(@"按规则自动清理", @"按容量与时间整理，最旧文件优先", @"arrow.triangle.2.circlepath", NO);
                cell.accessoryView = [self switchForKey:DYYYCacheEnabledKey];
                cell.selectionStyle = UITableViewCellSelectionStyleNone;
            } else {
                cell = DYYYPortsValueCell(@"可管理缓存上限", nil, @"internaldrive", YES);
            }
            break;
        case DYYYCacheSectionAge:
            if (indexPath.row == 0) {
                cell = DYYYPortsValueCell(@"超过多久清理", nil, @"slider.horizontal.3", YES);
            } else {
                cell = DYYYPortsValueCell(@"自定义小时数", nil, @"clock.badge.checkmark", YES);
            }
            break;
        case DYYYCacheSectionCount:
            break;
    }
    if (!cell) cell = DYYYPortsIconCell(@"", nil, nil, NO);
    [self configureCell:cell forIndexPath:indexPath];
    return cell;
}

// 开关：直接绑定 DYYYCache* 键；值变化走 DYYYCacheSetValue（会发自家偏好变更通知）。
- (UISwitch *)switchForKey:(NSString *)key {
    UISwitch *toggle = [[UISwitch alloc] init];
    toggle.on = DYYYCacheBoolForKey(key);
    toggle.accessibilityIdentifier = key;
    [toggle addTarget:self action:@selector(switchChanged:) forControlEvents:UIControlEventValueChanged];
    return toggle;
}

- (void)switchChanged:(UISwitch *)sender {
    NSString *key = sender.accessibilityIdentifier;
    if (!key.length) return;
    DYYYCacheSetValue(key, @(sender.isOn));
    // 开关只影响清理器内部状态，不需要整表刷新；只刷新可能受影响的上限/时间行文案。
    [self.tableView reloadData];
}

#pragma mark - Cell 动态文案（用量 / 最近清理 / 上限 / 时间）

// 行已用 UIListContentConfiguration（含图标），文字和标题颜色必须写回同一份配置才
// 会显示；这里只改 text / secondaryText / 标题颜色，图标原样保留。
static void DYYYCacheSetCellText(UITableViewCell *cell, NSString *title, NSString *detail, UIColor *titleColor) {
    if ([cell.contentConfiguration isKindOfClass:UIListContentConfiguration.class]) {
        UIListContentConfiguration *config = (UIListContentConfiguration *)cell.contentConfiguration;
        if (title) config.text = title;
        if (detail) config.secondaryText = detail;
        if (titleColor) config.textProperties.color = titleColor;
        cell.contentConfiguration = config;
    } else {
        if (title) cell.textLabel.text = title;
        if (detail) cell.detailTextLabel.text = detail;
        if (titleColor) cell.textLabel.textColor = titleColor;
    }
}

- (void)configureCell:(UITableViewCell *)cell forIndexPath:(NSIndexPath *)indexPath {
    NSDictionary *statistics = self.cacheStatistics;
    BOOL busy = [statistics[@"busy"] boolValue];
    BOOL manual = [statistics[@"manual"] boolValue];
    uint64_t available = [statistics[@"bytes"] unsignedLongLongValue];

    if (indexPath.section == DYYYCacheSectionUsage && indexPath.row == 0) {
        BOOL initial = !statistics || ([statistics[@"phase"] isEqualToString:@"scanning"] && !available);
        DYYYCacheSetCellText(cell,
            initial ? @"缓存用量"
                : [NSString stringWithFormat:@"缓存用量  %@", DYYYCacheFormatBytes(available)],
            statistics[@"status"] ?: @"正在统计…", nil);
    } else if (indexPath.section == DYYYCacheSectionUsage && indexPath.row == 1) {
        BOOL enabled = busy ? manual : (statistics && available > 0 && !self.cacheStatisticsPending);
        DYYYCacheSetCellText(cell,
            busy && manual ? @"停止本次清理" : @"清理全部缓存",
            busy
                ? (manual ? @"随时停止，已清理的空间不会回退" : @"正在检查缓存，请稍候")
                : (statistics ? (available ? @"清空缓存目录，仅保留插件配置" : @"暂无缓存") : @"统计完成后即可清理"),
            enabled ? (busy ? UIColor.systemRedColor : UIColor.labelColor)
                    : UIColor.tertiaryLabelColor);
        cell.selectionStyle = enabled ? UITableViewCellSelectionStyleDefault : UITableViewCellSelectionStyleNone;
    } else if (indexPath.section == DYYYCacheSectionUsage && indexPath.row == 2) {
        NSDictionary *last = statistics[@"lastCleanup"];
        NSDate *date = last[@"date"];
        if ([date isKindOfClass:NSDate.class]) {
            NSDateFormatter *formatter = [NSDateFormatter new];
            formatter.dateFormat = @"MM-dd HH:mm";
            NSString *summary;
            if ([last[@"deletedCount"] unsignedLongLongValue]) {
                summary = [NSString stringWithFormat:@"释放 %@ · %@ 个文件",
                           DYYYCacheFormatBytes([last[@"deletedBytes"] unsignedLongLongValue]), last[@"deletedCount"]];
            } else if ([last[@"cancelled"] boolValue]) {
                summary = @"本次已停止";
            } else if ([last[@"partial"] boolValue]) {
                summary = @"未释放空间 · 部分文件未能清理";
            } else {
                summary = @"无需清理 · 未发现可清理缓存";
            }
            DYYYCacheSetCellText(cell, nil, [NSString stringWithFormat:@"%@ · %@", [formatter stringFromDate:date], summary], nil);
        } else {
            DYYYCacheSetCellText(cell, nil, @"尚未清理", nil);
        }
    } else if (indexPath.section == DYYYCacheSectionAuto && indexPath.row == 1) {
        double mb = DYYYCacheNumberForKey(DYYYCacheMaxMBKey);
        DYYYCacheSetCellText(cell, nil, mb > 0
            ? [NSString stringWithFormat:@"%@ · 点击修改", DYYYCacheFormatBytes((uint64_t)(mb * 1048576))]
            : @"不限制 · 点击自定义", nil);
    } else if (indexPath.section == DYYYCacheSectionAge && indexPath.row == 0) {
        DYYYCacheSetCellText(cell, nil, [self ageDescription], nil);
    } else if (indexPath.section == DYYYCacheSectionAge && indexPath.row == 1) {
        double hours = DYYYCacheNumberForKey(DYYYCacheMaxAgeHoursKey);
        DYYYCacheSetCellText(cell, nil, hours > 0
            ? [NSString stringWithFormat:@"当前 %.0f 小时 · 点击修改", hours]
            : @"从不按时间清理 · 点击输入", nil);
    }
}

// “超过多久清理”当前值文案：预设档直接显示，自定义小时数显示具体值。
- (NSString *)ageDescription {
    double hours = DYYYCacheNumberForKey(DYYYCacheMaxAgeHoursKey);
    if (hours <= 0) return @"从不";
    if (hours == 24) return @"1 天";
    if (hours == 168) return @"1 周";
    if (hours == 720) return @"1 个月（30 天）";
    return [NSString stringWithFormat:@"%.0f 小时", hours];
}

- (void)updateVisibleCells {
    for (NSIndexPath *path in self.tableView.indexPathsForVisibleRows) {
        UITableViewCell *cell = [self.tableView cellForRowAtIndexPath:path];
        if (cell) [self configureCell:cell forIndexPath:path];
    }
}

#pragma mark - 统计刷新

- (void)cacheStatisticsChanged:(NSNotification *)notification {
    self.cacheStatistics = notification.userInfo;
    if (!self.isViewLoaded || !self.view.window) return;
    [self updateVisibleCells];
    if (![self.cacheStatistics[@"busy"] boolValue] && !self.tableView.dragging && !self.tableView.decelerating) {
        [UIView performWithoutAnimation:^{ [self.tableView beginUpdates]; [self.tableView endUpdates]; }];
    }
}

- (void)loadCacheUsage:(BOOL)refresh {
    if (self.cacheStatisticsPending) { [self.refreshControl endRefreshing]; return; }
    self.cacheStatisticsPending = YES;
    [self updateVisibleCells];
    __weak typeof(self) weakSelf = self;
    void (^completion)(NSDictionary *) = ^(NSDictionary *statistics) {
        DYYYCacheSettingsViewController *strongSelf = weakSelf;
        if (!strongSelf) return;
        strongSelf.cacheStatistics = statistics;
        strongSelf.cacheStatisticsPending = NO;
        [strongSelf.refreshControl endRefreshing];
        [strongSelf updateVisibleCells];
    };
    if (refresh) DYYYRefreshCacheStatistics(completion);
    else DYYYCacheStatistics(completion);
}

- (void)refreshCacheUsage {
    [self loadCacheUsage:YES];
}

#pragma mark - 点击

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    if (indexPath.section == DYYYCacheSectionUsage && indexPath.row == 1) {
        [self cleanHostCacheTapped];
    } else if (indexPath.section == DYYYCacheSectionAuto && indexPath.row == 1) {
        [self editMaxMBSheet];
    } else if (indexPath.section == DYYYCacheSectionAge && indexPath.row == 0) {
        [self editMaxAgeSheet];
    } else if (indexPath.section == DYYYCacheSectionAge && indexPath.row == 1) {
        [self editCustomHours];
    }
}

// 清理全部缓存：忙时（手动清理中）点按即停止；否则先确认再清理。
- (void)cleanHostCacheTapped {
    if ([self.cacheStatistics[@"busy"] boolValue]) {
        if ([self.cacheStatistics[@"manual"] boolValue]) DYYYCancelHostCacheCleanup();
        return;
    }
    uint64_t available = [self.cacheStatistics[@"bytes"] unsignedLongLongValue];
    if (self.cacheStatisticsPending || !available) return;
    NSString *message = [NSString stringWithFormat:
        @"当前用量 %@。将清空应用缓存、临时文件、页面资源、投屏缓存和日志，仅保留识别到的插件配置。清理后会重新统计，继续使用时可能产生新缓存。",
        DYYYCacheFormatBytes(available)];
    __weak typeof(self) weakSelf = self;
    UIAlertController *confirm = [UIAlertController alertControllerWithTitle:@"清空全部缓存？"
                                                                     message:message
                                                              preferredStyle:UIAlertControllerStyleAlert];
    [confirm addAction:[UIAlertAction actionWithTitle:@"取消" style:UIAlertActionStyleCancel handler:nil]];
    [confirm addAction:[UIAlertAction actionWithTitle:@"开始清理" style:UIAlertActionStyleDefault handler:^(__unused UIAlertAction *action) {
        DYYYCacheSettingsViewController *strongSelf = weakSelf;
        if (!strongSelf || [strongSelf.cacheStatistics[@"busy"] boolValue]) return;
        NSMutableDictionary *pending = [strongSelf.cacheStatistics mutableCopy] ?: [NSMutableDictionary dictionary];
        pending[@"busy"] = @YES;
        pending[@"manual"] = @YES;
        pending[@"status"] = @"正在重新检查可清理文件";
        strongSelf.cacheStatistics = pending;
        [strongSelf updateVisibleCells];
        DYYYCleanHostCache(^(NSDictionary *result) {
            DYYYCacheSettingsViewController *innerSelf = weakSelf;
            if (!innerSelf) return;
            innerSelf.cacheStatistics = result;
            [innerSelf updateVisibleCells];
        });
    }]];
    [self presentViewController:confirm animated:YES completion:nil];
}

#pragma mark - 上限 / 时间编辑

// 可管理缓存上限：预设档 + 自定义 MB。0 表示不限制。
- (void)editMaxMBSheet {
    UIAlertController *sheet = [UIAlertController alertControllerWithTitle:@"可管理缓存上限"
                                                                   message:@"单位 MB，0 表示不限制。超限时先清理最旧文件。"
                                                            preferredStyle:UIAlertControllerStyleActionSheet];
    NSArray<NSNumber *> *presets = @[@0, @256, @512, @1024, @2048, @4096];
    for (NSNumber *preset in presets) {
        NSString *title = preset.doubleValue > 0
            ? DYYYCacheFormatBytes((uint64_t)(preset.doubleValue * 1048576))
            : @"不限制";
        if (preset.doubleValue == 1024) title = @"1.00 GB（默认）";
        [sheet addAction:[UIAlertAction actionWithTitle:title style:UIAlertActionStyleDefault handler:^(__unused UIAlertAction *action) {
            DYYYCacheSetValue(DYYYCacheMaxMBKey, preset);
            [self.tableView reloadData];
        }]];
    }
    [sheet addAction:[UIAlertAction actionWithTitle:@"自定义…" style:UIAlertActionStyleDefault handler:^(__unused UIAlertAction *action) {
        [self editNumberForKey:DYYYCacheMaxMBKey
                         title:@"自定义缓存上限"
                       message:@"输入 MB 数。0 表示不限制，最大 1048576。"
                   currentText:[NSString stringWithFormat:@"%.0f", DYYYCacheNumberForKey(DYYYCacheMaxMBKey)]];
    }]];
    [sheet addAction:[UIAlertAction actionWithTitle:@"取消" style:UIAlertActionStyleCancel handler:nil]];
    [self presentViewController:sheet animated:YES completion:nil];
}

// 超过多久清理：预设档 + 自定义小时数。0 / 从不 = 只关按时间清理，容量超限仍整理。
- (void)editMaxAgeSheet {
    UIAlertController *sheet = [UIAlertController alertControllerWithTitle:@"超过多久清理"
                                                                   message:@"按文件存放时间计算。时间与容量分别生效。"
                                                            preferredStyle:UIAlertControllerStyleActionSheet];
    NSArray *options = @[
        @{@"title": @"从不", @"hours": @0},
        @{@"title": @"1 天", @"hours": @24},
        @{@"title": @"1 周", @"hours": @168},
        @{@"title": @"1 个月（30 天）", @"hours": @720},
    ];
    for (NSDictionary *option in options) {
        [sheet addAction:[UIAlertAction actionWithTitle:option[@"title"] style:UIAlertActionStyleDefault handler:^(__unused UIAlertAction *action) {
            DYYYCacheSetValue(DYYYCacheMaxAgeHoursKey, option[@"hours"]);
            [self.tableView reloadData];
        }]];
    }
    [sheet addAction:[UIAlertAction actionWithTitle:@"自定义…" style:UIAlertActionStyleDefault handler:^(__unused UIAlertAction *action) {
        [self editCustomHours];
    }]];
    [sheet addAction:[UIAlertAction actionWithTitle:@"取消" style:UIAlertActionStyleCancel handler:nil]];
    [self presentViewController:sheet animated:YES completion:nil];
}

- (void)editCustomHours {
    [self editNumberForKey:DYYYCacheMaxAgeHoursKey
                     title:@"自定义小时数"
                   message:@"输入小时数。0 表示从不按时间清理，容量限制仍独立生效。"
               currentText:[NSString stringWithFormat:@"%.0f", DYYYCacheNumberForKey(DYYYCacheMaxAgeHoursKey)]];
}

// 数字输入框：只接受整数，超范围时钳制（上限 0–1048576 MB，时间 0–876000 小时）。
- (void)editNumberForKey:(NSString *)key title:(NSString *)title message:(NSString *)message currentText:(NSString *)currentText {
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:title
                                                                   message:message
                                                            preferredStyle:UIAlertControllerStyleAlert];
    [alert addTextFieldWithConfigurationHandler:^(UITextField *textField) {
        textField.keyboardType = UIKeyboardTypeNumberPad;
        textField.text = currentText;
        textField.clearButtonMode = UITextFieldViewModeWhileEditing;
    }];
    __weak UIAlertController *weakAlert = alert;
    [alert addAction:[UIAlertAction actionWithTitle:@"取消" style:UIAlertActionStyleCancel handler:nil]];
    [alert addAction:[UIAlertAction actionWithTitle:@"保存" style:UIAlertActionStyleDefault handler:^(__unused UIAlertAction *action) {
        NSString *text = weakAlert.textFields.firstObject.text ?: @"";
        NSScanner *scanner = [NSScanner scannerWithString:text];
        double number = 0;
        BOOL valid = text.length > 0 && [scanner scanDouble:&number] && scanner.isAtEnd && isfinite(number);
        if (!valid) return;
        DYYYCacheSetValue(key, @(number));
        [self.tableView reloadData];
    }]];
    [self presentViewController:alert animated:YES completion:nil];
}

@end
