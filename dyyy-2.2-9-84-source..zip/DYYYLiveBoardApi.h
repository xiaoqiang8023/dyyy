// DYYYLiveBoardApi.h — 直播间人气榜取数（2.2-9-71，取数瀑布 2.2-9-74）。
// 每位主播一轮只做：① 星牌解析拿 roomID（原生资料 + 网页资料，
// 不走 DYYYFansService 单例、不调 prepare:，星牌开关关着也不影响）；
// ② room_data 副判；③ reflow 兜底（需 secUID）；
// ④ 在播才调 HTSLiveRoomAPI fetchRoomInfoWithRoomID 拿人数和开播时间。
// completion 在主线程回，result：
//   @{@"live": @YES/@NO, @"viewers": NSNumber?, @"start": NSNumber?,
//     @"totalViewers": NSNumber?（2.2-9-81 场观，读不到时不加键）,
//     @"roomID": NSString?, @"source": @"fans"/@"profile"/@"reflow", @"checkedAt": @时间戳}
// live=NO 且无 error 表示确认未开播；error 非空表示本轮没查到（保留上次状态），
// 错误描述里拼着三路各自的失败短记（如“原生资料失败(-11001)；…；无 secUID 可走 reflow”）。
#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface DYYYLiveBoardApi : NSObject
+ (void)checkAnchor:(NSDictionary *)anchor owner:(NSString *)owner completion:(void (^)(NSDictionary * _Nullable result, NSError * _Nullable error))completion;
@end

NS_ASSUME_NONNULL_END
