#import "DYYYCacheCleaner.h"
#import <UIKit/UIKit.h>
#import "DYYYCachePolicy.h"
#import <stdatomic.h>
#import <mach-o/dyld.h>

NSNotificationName const DYYYCacheStatisticsChangedNotification = @"DYYYCacheStatisticsChanged";
NSNotificationName const DYYYCachePreferencesChangedNotification = @"DYYYCachePreferencesChanged";

// 设置全部走 NSUserDefaults standardUserDefaults（与 DYYYSettingsHelper / DYYYFans 一致）。
// 上游 DY778 用的是独立 suite com.dy778.douyin；移植到 DYYY 后改用标准 defaults。
NSUserDefaults *DYYYCachePreferences(void) { return NSUserDefaults.standardUserDefaults; }
BOOL DYYYCacheBoolForKey(NSString *key) { return [DYYYCachePreferences() boolForKey:key]; }
double DYYYCacheNumberForKey(NSString *key) {
    id value = [DYYYCachePreferences() objectForKey:key];
    // 上限缺省 1.00 GB；显式写 0 才是“不限制”（objectForKey 非 nil，不会误判）。
    if (!value && [key isEqualToString:DYYYCacheMaxMBKey]) return DYYYCacheDefaultMaxMB;
    return [value respondsToSelector:@selector(doubleValue)] ? [value doubleValue] : 0;
}
void DYYYCacheRegisterDefaults(void) {
    [DYYYCachePreferences() registerDefaults:@{
        DYYYCacheEnabledKey: @NO, DYYYCacheOnLaunchKey: @NO, DYYYCacheOnReturnKey: @NO,
        DYYYCacheMaxMBKey: @(DYYYCacheDefaultMaxMB), DYYYCacheMaxAgeHoursKey: @0}];
}
void DYYYCacheSetValue(NSString *key, id value) {
    if (!key.length) return;
    if ([key isEqualToString:DYYYCacheMaxMBKey] || [key isEqualToString:DYYYCacheMaxAgeHoursKey]) {
        double number = [value respondsToSelector:@selector(doubleValue)] ? [value doubleValue] : 0;
        if (!isfinite(number)) return;
        // 上游钳制范围：maxMB 0–1048576，maxAgeHours 0–876000。
        double max = [key isEqualToString:DYYYCacheMaxMBKey] ? 1048576 : 876000;
        value = @(MIN(max, MAX(0, number)));
    }
    if (value) [DYYYCachePreferences() setObject:value forKey:key];
    else [DYYYCachePreferences() removeObjectForKey:key];
    dispatch_async(dispatch_get_main_queue(), ^{
        [NSNotificationCenter.defaultCenter postNotificationName:DYYYCachePreferencesChangedNotification
                                                        object:nil userInfo:@{@"key": key}];
    });
}
static dispatch_queue_t DYYYCacheQueue;
static atomic_bool DYYYCacheEnabled, DYYYCacheOnLaunch, DYYYCacheOnReturn, DYYYCacheForeground, DYYYCachePending, DYYYCacheManualPending, DYYYCacheCancelled;
static DYYYCacheLifecycle DYYYCacheLifecycleState;
static int DYYYCacheCurrentEvent;
static _Atomic(NSUInteger) DYYYCacheOpenGeneration;
static _Atomic(double) DYYYCacheMaxMB, DYYYCacheMaxAge;
static NSDictionary *DYYYLastCacheStatistics, *DYYYLastCacheResult, *DYYYVisibleCacheStatistics, *DYYYLastCompleteCacheStatistics;
static CFAbsoluteTime DYYYCacheLastScan;
static dispatch_source_t DYYYCacheTimer;

@interface DYYYCacheRoot : NSObject
@property(nonatomic, copy) NSString *path;
@property(nonatomic) int descriptor;
@property(nonatomic) int scope;
@property(nonatomic) uint64_t bytes;
@property(nonatomic) uint64_t reclaimable;
@end
@implementation DYYYCacheRoot
- (instancetype)init { if ((self = [super init])) _descriptor = -1; return self; }
- (void)dealloc { if (_descriptor >= 0) close(_descriptor); }
@end
@interface DYYYCacheFile : NSObject
@property(nonatomic, strong) DYYYCacheRoot *root;
@property(nonatomic, copy) NSString *relative;
@property(nonatomic) struct stat snapshot;
@property(nonatomic) double newestWrite;
@property(nonatomic) int kind;
@end
@implementation DYYYCacheFile @end

@interface DYYYCacheJob : NSObject { @public DYYYCacheWalker walker; }
@property(nonatomic, strong) NSArray<DYYYCacheRoot *> *roots;
@property(nonatomic, strong) NSMutableArray<DYYYCacheFile *> *oldest;
@property(nonatomic, strong) NSMutableArray *completions;
@property(nonatomic, strong) NSMutableSet<NSString *> *skippedFiles;
@property(nonatomic) NSUInteger rootIndex;
@property(nonatomic) NSUInteger count;
@property(nonatomic) uint64_t bytes;
@property(nonatomic) uint64_t managedBytes;
@property(nonatomic) uint64_t reclaimableBytes;
@property(nonatomic) uint64_t deletedBytes;
@property(nonatomic) NSUInteger deletedCount;
@property(nonatomic) NSUInteger passDeleted;
@property(nonatomic) NSUInteger passSkipped;
@property(nonatomic) NSUInteger deleteIndex;
@property(nonatomic) NSUInteger skipped;
@property(nonatomic) BOOL remove;
@property(nonatomic) BOOL manual;
@property(nonatomic) BOOL byRules;
@property(nonatomic) int activationEvent;
@property(nonatomic) NSUInteger activationGeneration;
@property(nonatomic) BOOL incomplete;
@property(nonatomic) BOOL overflow;
@property(nonatomic) BOOL cancelled;
@property(nonatomic) BOOL scanFinished;
@property(nonatomic) BOOL needsSafetyScan;
@property(nonatomic) BOOL verifying;
@property(nonatomic, copy) NSArray<NSString *> *pluginNames;
@property(nonatomic) CFAbsoluteTime started;
@property(nonatomic) CFAbsoluteTime published;
@end
@implementation DYYYCacheJob
- (instancetype)init { if ((self = [super init])) { _oldest = [NSMutableArray array]; _completions = [NSMutableArray array]; _skippedFiles = [NSMutableSet set]; _started = CFAbsoluteTimeGetCurrent(); } return self; }
- (void)dealloc { DYYYCacheWalkClose(&walker); }
@end
static DYYYCacheJob *DYYYActiveCacheJob;

NSDictionary *DYYYCachedCacheStatistics(void) { return NSThread.isMainThread ? DYYYVisibleCacheStatistics : nil; }
NSString *DYYYCacheFormatBytes(uint64_t bytes) {
    if (!bytes) return @"0 MB";
    if (bytes < 104858) return @"<0.1 MB";
    if (bytes < 1073741824ULL) return [NSString stringWithFormat:@"%.1f MB", (double)bytes / 1048576.0];
    return [NSString stringWithFormat:@"%.2f GB", (double)bytes / 1073741824.0];
}
static NSArray<NSString *> *DYYYCachePluginNames(void) {
    NSMutableSet *names = [NSMutableSet set];
    for (uint32_t i = 0; i < _dyld_image_count(); i++) {
        const char *raw = _dyld_get_image_name(i); if (!raw) continue;
        NSString *path = [NSString stringWithUTF8String:raw];
        BOOL bundled = [path hasPrefix:[NSBundle.mainBundle.bundlePath stringByAppendingString:@"/"]] &&
            [path.pathExtension.lowercaseString isEqual:@"dylib"];
        if (![path containsString:@"/DynamicLibraries/"] && ![path containsString:@"/TweakInject/"] &&
            ![path containsString:@"/tweaksupport/"] && !bundled) continue;
        NSString *name = path.lastPathComponent.stringByDeletingPathExtension.lowercaseString;
        if (name.length >= 3) [names addObject:name];
        if ([name hasPrefix:@"lib"] && name.length > 5) [names addObject:[name substringFromIndex:3]];
    }
    NSString *preferences = [NSHomeDirectory() stringByAppendingPathComponent:@"Library/Preferences"];
    for (NSString *file in [NSFileManager.defaultManager contentsOfDirectoryAtPath:preferences error:nil]) {
        NSString *name = file.stringByDeletingPathExtension.lowercaseString;
        if (![file.pathExtension.lowercaseString isEqual:@"plist"] || [name hasPrefix:@"com.apple."] ||
            [name hasPrefix:@"com.ss."] || [name hasPrefix:@"com.bytedance."]) continue;
        if (name.length >= 3) [names addObject:name];
    }
    return names.allObjects;
}
static BOOL DYYYCacheIsPluginConfiguration(NSString *relative, NSArray<NSString *> *names) {
    const char *plugins[names.count ?: 1];
    for (NSUInteger index = 0; index < names.count; index++) plugins[index] = names[index].UTF8String;
    return DYYYCachePluginConfiguration(relative.UTF8String, plugins, names.count);
}
static NSString *DYYYCacheIdentity(struct stat st) { return [NSString stringWithFormat:@"%llu:%llu", (unsigned long long)st.st_dev, (unsigned long long)st.st_ino]; }
static NSArray<DYYYCacheRoot *> *DYYYCacheRoots(BOOL *incomplete) {
    NSString *home = NSHomeDirectory().stringByResolvingSymlinksInPath;
    int container = open(home.fileSystemRepresentation, O_RDONLY | O_DIRECTORY | O_NOFOLLOW | O_CLOEXEC);
    if (container < 0) { *incomplete = YES; return @[]; }
    NSMutableArray *roots = [NSMutableArray array];
    for (NSString *relative in @[@"Library/Caches", @"tmp", @"Library/Application Support/gurd_cache", @"Library/BDByteCast", @"Library/kitelog"]) {
        int scope = DYYYCacheRootScope(relative.UTF8String); if (!scope) continue;
        char leaf[256]; NSString *anchor = [relative stringByAppendingPathComponent:@".dyyy-check"];
        int descriptor = DYYYCacheOpenParent(container, anchor.fileSystemRepresentation, leaf);
        if (descriptor < 0) { if (errno != ENOENT) *incomplete = YES; continue; }
        DYYYCacheRoot *root = [DYYYCacheRoot new]; root.descriptor = descriptor; root.scope = scope;
        root.path = [home stringByAppendingPathComponent:relative];
        [roots addObject:root];
    }
    close(container); return roots;
}
static BOOL DYYYCacheOpenAllowed(DYYYCacheJob *job) {
    return job.activationGeneration == atomic_load_explicit(&DYYYCacheOpenGeneration, memory_order_relaxed) && DYYYCacheEventEnabled(job.activationEvent, atomic_load_explicit(&DYYYCacheOnLaunch, memory_order_relaxed), atomic_load_explicit(&DYYYCacheOnReturn, memory_order_relaxed)) && atomic_load_explicit(&DYYYCacheForeground, memory_order_relaxed);
}
static BOOL DYYYCacheJobCanRemove(DYYYCacheJob *job) {
    return job.remove && (job.manual ? !atomic_load_explicit(&DYYYCacheCancelled, memory_order_acquire) : DYYYCacheOpenAllowed(job) || (job.byRules && atomic_load_explicit(&DYYYCacheEnabled, memory_order_relaxed)));
}
static BOOL DYYYCacheFileAllowed(DYYYCacheFile *file, DYYYCacheJob *job) {
    return DYYYCacheJobCanRemove(job) && DYYYCacheDeletionAllowed(job.manual || DYYYCacheOpenAllowed(job), atomic_load_explicit(&DYYYCacheEnabled, memory_order_relaxed),
        (job.manual && atomic_load_explicit(&DYYYCacheCancelled, memory_order_acquire)), file.root.scope, job.managedBytes,
        DYYYCacheByteLimit(atomic_load_explicit(&DYYYCacheMaxMB, memory_order_relaxed)), file.newestWrite,
        NSDate.date.timeIntervalSince1970, atomic_load_explicit(&DYYYCacheMaxAge, memory_order_relaxed));
}
static BOOL DYYYCacheRemoveFile(DYYYCacheFile *file, DYYYCacheJob *job, uint64_t *bytes) {
    if (DYYYCacheIsPluginConfiguration(file.relative, job.pluginNames) || !DYYYCacheFileAllowed(file, job)) return NO;
    struct stat expected = file.snapshot;
    if (job.manual || DYYYCacheOpenAllowed(job))
        return DYYYCacheUnlinkCurrent(file.root.descriptor, file.relative.fileSystemRepresentation, &expected, bytes);
    return DYYYCacheUnlinkVerified(file.root.descriptor, file.relative.fileSystemRepresentation, &expected);
}
static NSDictionary *DYYYCacheSnapshot(DYYYCacheJob *job, NSString *phase) {
    NSMutableArray *categories = [NSMutableArray array];
    NSArray *names = @[@"", @"应用缓存", @"临时文件", @"页面资源", @"投屏缓存", @"诊断日志"];
    NSArray *keys = @[@"", @"media", @"temporary", @"resources", @"cast", @"logs"];
    for (DYYYCacheRoot *root in job.roots) [categories addObject:@{@"key": keys[root.scope], @"title": names[root.scope], @"bytes": @(root.bytes), @"reclaimableBytes": @(root.reclaimable)}];
    BOOL busy = ![phase isEqualToString:@"idle"];
    NSString *status = @"用量已更新，清理范围内仅保留插件配置";
    if ([phase isEqualToString:@"scanning"]) status = [NSString stringWithFormat:@"正在统计 · 已检查 %lu 个文件", (unsigned long)job.count];
    else if ([phase isEqualToString:@"cleaning"]) status = [NSString stringWithFormat:@"正在清理 · 已释放 %@", DYYYCacheFormatBytes(job.deletedBytes)];
    else if (job.cancelled) status = job.scanFinished ? @"本次清理已停止，已释放的空间会保留" : @"已停止，当前仅为已统计用量，可下拉刷新";
    else if (!job.roots.count) status = @"暂时无法读取缓存目录，可稍后刷新";
    else if (job.incomplete) status = @"部分目录不可读取，以下仅为已统计用量";
    else if (job.remove && job.skipped) status = [NSString stringWithFormat:@"已清理 %@ · %lu 个文件暂未删除", DYYYCacheFormatBytes(job.deletedBytes), (unsigned long)job.skipped];
    else if (job.manual && job.overflow && job.reclaimableBytes) status = [NSString stringWithFormat:@"已释放 %@，仍有缓存未清理", DYYYCacheFormatBytes(job.deletedBytes)];
    else if (job.remove) status = job.deletedCount ? [NSString stringWithFormat:@"已释放 %@ · %lu 个文件", DYYYCacheFormatBytes(job.deletedBytes), (unsigned long)job.deletedCount] : @"没有待清理缓存，插件配置已保留";
    NSMutableDictionary *result = [@{@"bytes": @(job.bytes), @"managedBytes": @(job.managedBytes), @"count": @(job.count),
        @"reclaimableBytes": @(job.reclaimableBytes), @"protectedBytes": @(job.bytes >= job.reclaimableBytes ? job.bytes - job.reclaimableBytes : 0),
        @"rootCount": @(job.roots.count), @"categories": categories, @"deletedBytes": @(job.deletedBytes), @"deletedCount": @(job.deletedCount),
        @"skippedActive": @(job.skipped), @"partial": @(job.incomplete || !job.scanFinished || job.skipped > 0), @"busy": @(busy), @"manual": @(job.manual),
        @"cancelled": @(job.cancelled), @"phase": phase, @"status": status, @"scannedCount": @(job.count), @"scanDate": NSDate.date} mutableCopy];
    if (DYYYLastCacheResult) result[@"lastCleanup"] = DYYYLastCacheResult;
    if ([phase isEqualToString:@"scanning"] && DYYYLastCompleteCacheStatistics) {
        for (NSString *key in @[@"bytes", @"managedBytes", @"reclaimableBytes", @"protectedBytes", @"categories", @"scanDate"])
            if (!job.deletedCount && DYYYLastCompleteCacheStatistics[key]) result[key] = DYYYLastCompleteCacheStatistics[key];
    }
    return result;
}
static void DYYYCachePublish(DYYYCacheJob *job, NSString *phase, BOOL force) {
    if (!force && CFAbsoluteTimeGetCurrent() - job.published < .35) return;
    job.published = CFAbsoluteTimeGetCurrent();
    NSDictionary *snapshot = DYYYCacheSnapshot(job, phase); DYYYLastCacheStatistics = snapshot;
    dispatch_async(dispatch_get_main_queue(), ^{
        DYYYVisibleCacheStatistics = snapshot;
        [NSNotificationCenter.defaultCenter postNotificationName:DYYYCacheStatisticsChangedNotification object:nil userInfo:snapshot];
    });
}
static void DYYYCacheFinish(DYYYCacheJob *job) {
    DYYYCacheWalkClose(&job->walker);
    if (DYYYCacheRecordCleanup(job.remove, job.manual || job.activationEvent != DYYYCacheEventNone,
        job.deletedCount, job.incomplete || job.skipped || job.cancelled)) {
        DYYYLastCacheResult = @{@"date": NSDate.date, @"deletedBytes": @(job.deletedBytes),
            @"deletedCount": @(job.deletedCount), @"partial": @(job.incomplete || job.skipped > 0 || !job.scanFinished),
            @"cancelled": @(job.cancelled), @"skipped": @(job.skipped)};
        [DYYYCachePreferences() setObject:DYYYLastCacheResult forKey:DYYYCacheLastCleanupKey];
    }
    DYYYCachePublish(job, @"idle", YES);
    NSDictionary *statistics = DYYYLastCacheStatistics;
    if (job.scanFinished) DYYYLastCompleteCacheStatistics = statistics;
    DYYYCacheLastScan = job.scanFinished ? CFAbsoluteTimeGetCurrent() : 0;
    NSArray *callbacks = job.completions.copy; DYYYActiveCacheJob = nil;
    atomic_store_explicit(&DYYYCachePending, false, memory_order_release);
    atomic_store_explicit(&DYYYCacheManualPending, false, memory_order_release);
    dispatch_async(dispatch_get_main_queue(), ^{ for (void (^completion)(NSDictionary *) in callbacks) completion(statistics); });
}
static void DYYYCacheStep(DYYYCacheJob *job);
static void DYYYCacheDeleteStep(DYYYCacheJob *job) {
    @autoreleasepool {
        CFAbsoluteTime deadline = CFAbsoluteTimeGetCurrent() + .04; NSUInteger examined = 0;
        while (job.deleteIndex < job.oldest.count && examined++ < 256 && CFAbsoluteTimeGetCurrent() < deadline) {
            if (!DYYYCacheJobCanRemove(job)) { job.cancelled = job.manual; DYYYCacheFinish(job); return; }
            DYYYCacheFile *file = job.oldest[job.deleteIndex++];
            if (!DYYYCacheFileAllowed(file, job)) continue;
            uint64_t size = (uint64_t)file.snapshot.st_size;
            job.reclaimableBytes -= MIN(job.reclaimableBytes, size); file.root.reclaimable -= MIN(file.root.reclaimable, size);
            if (!DYYYCacheRemoveFile(file, job, &size)) {
                [job.skippedFiles addObject:DYYYCacheIdentity(file.snapshot)]; job.skipped++; job.passSkipped++; continue;
            }
            job.bytes -= MIN(job.bytes, size); file.root.bytes -= MIN(file.root.bytes, size);
            job.managedBytes -= MIN(job.managedBytes, size); job.count--;
            job.deletedBytes = DYYYCacheAddBytes(job.deletedBytes, size); job.deletedCount++; job.passDeleted++;
        }
        DYYYCachePublish(job, @"cleaning", NO);
        if (job.deleteIndex >= job.oldest.count) {
            if (job.overflow && (job.passDeleted || job.passSkipped) && DYYYCacheJobCanRemove(job)) {
                job.rootIndex = 0; job.bytes = 0; job.count = 0; job.managedBytes = 0; job.reclaimableBytes = 0;
                job.passDeleted = 0; job.passSkipped = 0; job.deleteIndex = 0; job.overflow = NO; job.scanFinished = NO; [job.oldest removeAllObjects];
                for (DYYYCacheRoot *root in job.roots) { root.bytes = 0; root.reclaimable = 0; }
                dispatch_after(dispatch_time(DISPATCH_TIME_NOW, 100 * NSEC_PER_MSEC), DYYYCacheQueue, ^{ DYYYCacheStep(job); }); return;
            }
            job.verifying = YES; job.rootIndex = 0; job.bytes = 0; job.count = 0;
            job.managedBytes = 0; job.reclaimableBytes = 0; job.scanFinished = NO;
            [job.oldest removeAllObjects];
            for (DYYYCacheRoot *root in job.roots) { root.bytes = 0; root.reclaimable = 0; }
            dispatch_async(DYYYCacheQueue, ^{ DYYYCacheStep(job); }); return;
        }
    }
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, 10 * NSEC_PER_MSEC), DYYYCacheQueue, ^{ DYYYCacheDeleteStep(job); });
}
static void DYYYCacheStep(DYYYCacheJob *job) {
    @autoreleasepool {
        if (job.manual && atomic_load_explicit(&DYYYCacheCancelled, memory_order_acquire)) { job.cancelled = YES; DYYYCacheFinish(job); return; }
        CFAbsoluteTime deadline = CFAbsoluteTimeGetCurrent() + (job.remove ? .04 : .06); NSUInteger entries = 0;
        while (job.rootIndex < job.roots.count && entries++ < (job.remove ? 1000 : 12000) && CFAbsoluteTimeGetCurrent() < deadline) {
            DYYYCacheRoot *root = job.roots[job.rootIndex];
            if (!job->walker.frames && !DYYYCacheWalkStart(&job->walker, root.descriptor)) { job.incomplete = YES; job.rootIndex++; continue; }
            job->walker.pruneEmpty = job.verifying && DYYYCacheJobCanRemove(job);
            char path[4096]; struct stat st; int parent = -1;
            int result = DYYYCacheWalkNext(&job->walker, NULL, NULL, path, &st, &parent);
            if (!result) { job.incomplete |= job->walker.incomplete; DYYYCacheWalkClose(&job->walker); job.rootIndex++; continue; }
            if (result != 1 || st.st_size < 0) continue;
            uint64_t size = (uint64_t)st.st_size; job.bytes = DYYYCacheAddBytes(job.bytes, size); root.bytes = DYYYCacheAddBytes(root.bytes, size); job.count++;
            if (!job.remove || job.needsSafetyScan) continue;
            NSString *relative = [NSString stringWithUTF8String:path]; if (!relative || DYYYCacheIsPluginConfiguration(relative, job.pluginNames)) continue;
            int kind = DYYYCacheFileKind(root.scope, path); if (!kind) continue;
            if (!job.verifying && [job.skippedFiles containsObject:DYYYCacheIdentity(st)]) continue;
            job.managedBytes = DYYYCacheAddBytes(job.managedBytes, size);
            DYYYCacheFile *file = [DYYYCacheFile new]; file.root = root; file.relative = relative; file.snapshot = st; file.kind = kind;
            file.newestWrite = MAX((double)st.st_mtime, (double)st.st_ctime);
            if (!DYYYCacheIdle(root.scope, file.newestWrite, NSDate.date.timeIntervalSince1970)) continue;
            job.reclaimableBytes = DYYYCacheAddBytes(job.reclaimableBytes, size); root.reclaimable = DYYYCacheAddBytes(root.reclaimable, size);
            if (job.verifying) continue;
            if (job.manual || DYYYCacheOpenAllowed(job)) {
                uint64_t deleted = size;
                if (DYYYCacheRemoveFile(file, job, &deleted)) {
                    job.bytes -= MIN(job.bytes, size); root.bytes -= MIN(root.bytes, size);
                    job.managedBytes -= MIN(job.managedBytes, size); job.count--;
                    job.reclaimableBytes -= MIN(job.reclaimableBytes, size); root.reclaimable -= MIN(root.reclaimable, size);
                    job.deletedBytes = DYYYCacheAddBytes(job.deletedBytes, deleted); job.deletedCount++;
                } else {
                    job.skipped++; [job.skippedFiles addObject:DYYYCacheIdentity(st)];
                }
                continue;
            }
            NSUInteger position = [job.oldest indexOfObject:file inSortedRange:NSMakeRange(0, job.oldest.count) options:NSBinarySearchingInsertionIndex usingComparator:^NSComparisonResult(DYYYCacheFile *a, DYYYCacheFile *b) {
                if (a.newestWrite != b.newestWrite) return a.newestWrite < b.newestWrite ? NSOrderedAscending : NSOrderedDescending;
                return [a.relative compare:b.relative];
            }];
            if (position < 4096) [job.oldest insertObject:file atIndex:position]; else job.overflow = YES;
            if (job.oldest.count > 4096) { [job.oldest removeLastObject]; job.overflow = YES; }
        }
        if (job.rootIndex >= job.roots.count) {
            job.scanFinished = YES;
            if (job.needsSafetyScan) {
                DYYYCachePublish(job, @"scanning", YES);
                BOOL incomplete = NO; job.roots = DYYYCacheRoots(&incomplete);
                job.incomplete = incomplete; job.needsSafetyScan = NO;
                job.rootIndex = 0; job.bytes = 0; job.count = 0; job.managedBytes = 0; job.reclaimableBytes = 0;
                job.scanFinished = NO;
                dispatch_async(DYYYCacheQueue, ^{ DYYYCacheStep(job); }); return;
            }
            if (!job.remove || job.verifying) { DYYYCacheFinish(job); return; }
            DYYYCachePublish(job, @"cleaning", YES); DYYYCacheDeleteStep(job); return;
        }
        DYYYCachePublish(job, job.deletedCount ? @"cleaning" : @"scanning", NO);
    }
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (job.remove ? 10 : 1) * NSEC_PER_MSEC), DYYYCacheQueue, ^{ DYYYCacheStep(job); });
}
static void DYYYCacheStart(int mode, NSUInteger generation, NSArray<NSString *> *plugins, void (^completion)(NSDictionary *)) {
    if (DYYYActiveCacheJob) {
        if (plugins.count) {
            NSMutableSet *names = [NSMutableSet setWithArray:DYYYActiveCacheJob.pluginNames ?: @[]];
            [names addObjectsFromArray:plugins]; DYYYActiveCacheJob.pluginNames = names.allObjects;
        }
        if (mode > 0 && !DYYYActiveCacheJob.remove) { DYYYActiveCacheJob.needsSafetyScan = YES; }
        DYYYActiveCacheJob.remove |= mode > 0; DYYYActiveCacheJob.manual |= mode == 2; DYYYActiveCacheJob.byRules |= mode == 1; if (mode >= DYYYCacheEventLaunch) { DYYYActiveCacheJob.activationEvent = mode; DYYYActiveCacheJob.activationGeneration = generation; }
        if (completion) [DYYYActiveCacheJob.completions addObject:[completion copy]];
        DYYYCachePublish(DYYYActiveCacheJob, DYYYActiveCacheJob.scanFinished ? @"cleaning" : @"scanning", YES); return;
    }
    DYYYCacheJob *job = [DYYYCacheJob new]; BOOL incomplete = NO; job.roots = DYYYCacheRoots(&incomplete);
    job.incomplete = incomplete; job.remove = mode > 0; job.manual = mode == 2; job.byRules = mode == 1; job.activationEvent = mode >= DYYYCacheEventLaunch ? mode : DYYYCacheEventNone; job.activationGeneration = generation;
    if (completion) [job.completions addObject:[completion copy]];
    job.pluginNames = plugins;
    DYYYActiveCacheJob = job; DYYYCachePublish(job, @"scanning", YES); DYYYCacheStep(job);
}
static void DYYYCacheRequest(int mode, BOOL refresh, void (^completion)(NSDictionary *)) {
    NSUInteger generation = atomic_load_explicit(&DYYYCacheOpenGeneration, memory_order_relaxed);
    dispatch_async(dispatch_get_main_queue(), ^{
        DYYYInstallCacheCleanerHooks();
        NSArray *plugins = mode ? DYYYCachePluginNames() : @[];
        dispatch_async(DYYYCacheQueue, ^{
            if (!mode && !refresh && !DYYYActiveCacheJob && DYYYLastCacheStatistics && CFAbsoluteTimeGetCurrent() - DYYYCacheLastScan < 30) {
                NSDictionary *snapshot = DYYYLastCacheStatistics;
                if (completion) dispatch_async(dispatch_get_main_queue(), ^{ completion(snapshot); });
                return;
            }
            DYYYCacheStart(mode, generation, plugins, completion);
        });
    });
}
void DYYYRunCacheMaintenance(void) {
    if (!atomic_load_explicit(&DYYYCacheEnabled, memory_order_relaxed) ||
        (atomic_load_explicit(&DYYYCacheMaxMB, memory_order_relaxed) <= 0 && atomic_load_explicit(&DYYYCacheMaxAge, memory_order_relaxed) <= 0)) return;
    if (atomic_exchange_explicit(&DYYYCachePending, true, memory_order_acq_rel)) return;
    DYYYCacheRequest(1, YES, nil);
}
void DYYYCacheStatistics(void (^completion)(NSDictionary *)) { if (completion) DYYYCacheRequest(0, NO, completion); }
void DYYYRefreshCacheStatistics(void (^completion)(NSDictionary *)) { if (completion) DYYYCacheRequest(0, YES, completion); }
void DYYYCleanHostCache(void (^completion)(NSDictionary *)) {
    if (!atomic_exchange_explicit(&DYYYCacheManualPending, true, memory_order_acq_rel)) atomic_store_explicit(&DYYYCacheCancelled, false, memory_order_release);
    DYYYCacheRequest(2, YES, completion);
}
void DYYYCancelHostCacheCleanup(void) { atomic_store_explicit(&DYYYCacheCancelled, true, memory_order_release); }
static void DYYYCacheOpened(void) {
    atomic_store_explicit(&DYYYCacheForeground, true, memory_order_relaxed);
    int event = DYYYCacheActivationEvent(&DYYYCacheLifecycleState); if (!event) return;
    DYYYCacheCurrentEvent = event;
    NSUInteger generation = ++DYYYCacheOpenGeneration;
    NSString *key = event == DYYYCacheEventLaunch ? DYYYCacheOnLaunchKey : DYYYCacheOnReturnKey;
    if (!DYYYCacheBoolForKey(key)) return;
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, 3 * NSEC_PER_SEC), dispatch_get_main_queue(), ^{
        if (generation != DYYYCacheOpenGeneration || !DYYYCacheBoolForKey(key) || UIApplication.sharedApplication.applicationState != UIApplicationStateActive) return;
        NSLog(@"[DYYYCache] 正在自动清理缓存");
        DYYYCacheRequest(event, YES, ^(NSDictionary *result) {
            if (generation != DYYYCacheOpenGeneration || !DYYYCacheBoolForKey(key) || UIApplication.sharedApplication.applicationState != UIApplicationStateActive) return;
            NSString *message = [NSString stringWithFormat:@"自动清理完成 · 本次已清理 %@", DYYYCacheFormatBytes([result[@"deletedBytes"] unsignedLongLongValue])];
            if (![result[@"deletedCount"] unsignedLongLongValue]) message = @"缓存已检查 · 暂无需要清理的内容";
            if ([result[@"partial"] boolValue]) message = [NSString stringWithFormat:@"本次已清理 %@ · 部分文件已跳过", DYYYCacheFormatBytes([result[@"deletedBytes"] unsignedLongLongValue])];
            NSLog(@"[DYYYCache] %@", message);
        });
    });
}
static void DYYYCacheReload(void) {
    double mb = DYYYCacheNumberForKey(DYYYCacheMaxMBKey), age = DYYYCacheNumberForKey(DYYYCacheMaxAgeHoursKey);
    atomic_store_explicit(&DYYYCacheMaxMB, isfinite(mb) && mb > 0 ? mb : 0, memory_order_relaxed);
    atomic_store_explicit(&DYYYCacheMaxAge, isfinite(age) && age > 0 ? age : 0, memory_order_relaxed);
    atomic_store_explicit(&DYYYCacheEnabled, DYYYCacheBoolForKey(DYYYCacheEnabledKey), memory_order_relaxed);
    atomic_store_explicit(&DYYYCacheOnLaunch, DYYYCacheBoolForKey(DYYYCacheOnLaunchKey), memory_order_relaxed);
    atomic_store_explicit(&DYYYCacheOnReturn, DYYYCacheBoolForKey(DYYYCacheOnReturnKey), memory_order_relaxed);
    if (DYYYCacheCurrentEvent && !DYYYCacheEventEnabled(DYYYCacheCurrentEvent, DYYYCacheBoolForKey(DYYYCacheOnLaunchKey), DYYYCacheBoolForKey(DYYYCacheOnReturnKey))) { DYYYCacheOpenGeneration++; }
    DYYYRunCacheMaintenance();
}
void DYYYInstallCacheCleanerHooks(void) {
    if (!NSThread.isMainThread) { dispatch_async(dispatch_get_main_queue(), ^{ DYYYInstallCacheCleanerHooks(); }); return; }
    static dispatch_once_t once; dispatch_once(&once, ^{
        DYYYCacheRegisterDefaults();
        DYYYCacheQueue = dispatch_queue_create("com.dyyy.cache-maintenance", dispatch_queue_attr_make_with_qos_class(DISPATCH_QUEUE_SERIAL, QOS_CLASS_UTILITY, 0));
        NSDictionary *stored = [DYYYCachePreferences() dictionaryForKey:DYYYCacheLastCleanupKey];
        if ([stored[@"date"] isKindOfClass:NSDate.class] && [stored[@"deletedBytes"] isKindOfClass:NSNumber.class] &&
            [stored[@"deletedCount"] isKindOfClass:NSNumber.class]) DYYYLastCacheResult = stored;
        DYYYCacheReload();
        if (UIApplication.sharedApplication.applicationState == UIApplicationStateActive) DYYYCacheOpened();
        [NSNotificationCenter.defaultCenter addObserverForName:DYYYCachePreferencesChangedNotification object:nil queue:NSOperationQueue.mainQueue usingBlock:^(NSNotification *note) {
            NSString *key = note.userInfo[@"key"]; if (!key.length || [key hasPrefix:@"DYYYCache"]) DYYYCacheReload();
        }];
        [NSNotificationCenter.defaultCenter addObserverForName:UIApplicationDidEnterBackgroundNotification object:nil queue:NSOperationQueue.mainQueue usingBlock:^(__unused NSNotification *note) { DYYYCacheLifecycleState.backgrounded = 1; DYYYCacheOpenGeneration++; atomic_store_explicit(&DYYYCacheForeground, false, memory_order_relaxed); DYYYRunCacheMaintenance(); }];
        [NSNotificationCenter.defaultCenter addObserverForName:UIApplicationDidBecomeActiveNotification object:nil queue:NSOperationQueue.mainQueue usingBlock:^(__unused NSNotification *note) { DYYYCacheOpened(); dispatch_after(dispatch_time(DISPATCH_TIME_NOW, 20 * NSEC_PER_SEC), dispatch_get_main_queue(), ^{ DYYYRunCacheMaintenance(); }); }];
        DYYYCacheTimer = dispatch_source_create(DISPATCH_SOURCE_TYPE_TIMER, 0, 0, dispatch_get_main_queue());
        dispatch_source_set_timer(DYYYCacheTimer, dispatch_time(DISPATCH_TIME_NOW, 300 * NSEC_PER_SEC), 300 * NSEC_PER_SEC, 30 * NSEC_PER_SEC);
        dispatch_source_set_event_handler(DYYYCacheTimer, ^{ DYYYRunCacheMaintenance(); }); dispatch_resume(DYYYCacheTimer);
    });
}
