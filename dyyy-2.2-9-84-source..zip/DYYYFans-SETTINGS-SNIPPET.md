# DYYY 星牌查询 — 设置页接入说明（给主代理）

> 只写要加的设置行与 Makefile 行。本文件不改任何代码。
> 开关键统一为 `DYYYFansEnabled`（`NSUserDefaults standardUserDefaults`，未写过时 `boolForKey:` 返回 NO，即默认关闭，无需另行注册默认值）。
> 原版两个检查点 `DY778FansC.Profile`（主页按钮）与 `DY778FansC.Enabled`（查询服务）都已映射到这一个开关（见 `DYYYFansRuntime.m` 的 `DYYYFansEnabled()`，参数忽略）。

## 1. 原生设置（DYYYSettings.xm）— 新增“星牌查询”一组

仿照约 805–1003 行“直播信息 · 推荐页卡片”（2.2-9-56 移植）的写法：在 `livePreviewItems` / `liveFloatItems` 同类位置新建一个数组，建完后用 `createSectionWithTitle:footerTitle:items:` 加进 `sections`（锚点：`createSectionWithTitle:@"直播信息 · 推荐页卡片" …` 那一行附近）。

```objc
// （DY778 星牌查询移植）
NSMutableArray<AWESettingItemModel *> *fansItems = [NSMutableArray array];
NSArray *fansSettings = @[
@{@"identifier": @"DYYYFansEnabled",
@"title": @"启用星牌查询",
@"subTitle": @"在用户主页查询消费等级与粉丝灯牌",
@"detail": @"",
@"cellType": @37,
@"imageName": @"ic_star_outlined_20"},
];
for (NSDictionary *dict in fansSettings) {
AWESettingItemModel *item = [DYYYSettingsHelper createSettingItem:dict];
[fansItems addObject:item];
}
// …在 sections 组装处（与“直播信息 · 推荐页卡片”同一区域）加：
[sections addObject:[DYYYSettingsHelper createSectionWithTitle:@"星牌查询"
footerTitle:@"开启后，用户主页会显示查询按钮；只展示当前可查询且归属匹配的资料。"
items:fansItems]];
```

要点：

- 只有这一个开关，不要再加子项。`cellType` 37 就是开关型（`DYYYLivePreviewViewers`、`DYYYShowLiveDuration` 同款）；`identifier` 必须与 `NSUserDefaults` 的键 `DYYYFansEnabled` 完全一致，开关值才能直通。
- 组标题 `星牌查询`、页脚文案用原版截图那句：“开启后，用户主页会显示查询按钮；只展示当前可查询且归属匹配的资料。”
- 开关即时生效：主页按钮通过 `NSUserDefaultsDidChangeNotification` 刷新（`DYYYFansHooks.m` 已接好，无需另写联动）；查询页内开关关闭会立即停掉当前任务（`DYYYFansUI.m` 的 `preferencesChanged` 已处理）。

## 2. 自定义面板（DYYYSettingViewController.m）— “直播信息”分组里加一行

锚点：约 386 行、`sectionTitles` 里的 `@"直播信息"` 分组（与 `DYYYLivePreviewViewers` 等同一数组）。在该数组内加一行（建议放最前）：

```objc
[DYYYSettingItem itemWithTitle:@"启用星牌查询" key:@"DYYYFansEnabled" type:DYYYSettingItemTypeSwitch],
```

## 3. Makefile — DYYY_FILES 里追加新文件

只加 7 个 `.m`（头文件不用列）。建议追加在 `DYYYLivePreview.xm` 之后：

```make
DYYY_FILES = … DYYYLivePreview.xm DYYYFansHooks.m DYYYFansModel.m DYYYFansPolicy.m DYYYFansRuntime.m DYYYFansService.m DYYYFansUI.m DYYYFansWeb.m
```

注意：`DYYYFansHooks.m` 是 `.m`，其安装入口用的是 `__attribute__((constructor))`（不是 `%ctor`，见报告 § 编译风险点 1），无需 Logos 处理，放在 `DYYY_FILES` 里即可。

## 4. 不需要动的地方

- 不用在 `DYYYSettingsHelper` 的 `settingsDependencyConfig` 里加依赖（本功能无依赖/冲突项）。
- 不用给 `DYYYFansEnabled` 写 `registerDefaults`（缺省即 NO = 默认关闭）。
- 最近查询主播历史存在 `NSUserDefaults`，键为 `DYYYFansAnchors.<当前登录 UID>`（每账号最多 8 个，只存本次查询里选过的主播，不作长期历史），无需设置项。
