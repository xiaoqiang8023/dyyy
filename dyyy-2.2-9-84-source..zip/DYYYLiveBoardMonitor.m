// DYYYLiveBoardMonitor.m — 见 DYYYLiveBoardMonitor.h。
// 调度照抄 DYYYRadarMonitor.m：单发 NSTimer 链、按 remainingFor 选最到期的一位、
// generation 守卫、失败退避（DYYYRadarRetryInterval）。不订阅全局
// NSUserDefaultsDidChangeNotification（-57/-60 冻住的教训）；设置变化只靠
// 自家 DYYYLiveBoardStoreChanged 通知与生命周期钩子。
#import "DYYYLiveBoardMonitor.h"
#import "DYYYLiveBoardApi.h"
#import "DYYYLiveBoardModel.h"
#import "DYYYLiveBoardStore.h"
#import "DYYYRadarModel.h"
#import "DYYYRadarNetwork.h"
#import "DYYYRadarPolicy.h"
#import <float.h>

static NSString *const DYYYLiveBoardMonitorOwner = @"DYYYLiveBoard.Monitor";

@interface DYYYLiveBoardMonitor ()
@property(nonatomic) BOOL started;
@property(nonatomic) BOOL busy;
@property(nonatomic) NSUInteger generation;
@property(nonatomic, copy) NSString *flightUID;
@property(nonatomic, strong) NSTimer *timer;
@property(nonatomic, strong) NSMutableDictionary<NSString *, NSNumber *> *attempts;
@property(nonatomic, strong) NSMutableDictionary<NSString *, NSNumber *> *failures;
@property(nonatomic, strong) NSMutableDictionary<NSString *, NSDictionary *> *states;
@property(nonatomic) NSTimeInterval lastCheckAt;
@property(nonatomic, copy) NSString *lastSource;
// 2.2-9-74：最近一次查完的失败短记（三路步骤拼起来的，如
// “原生资料失败(-11001)；网页资料失败(502)；无 secUID 可走 reflow”），
// 成功时清掉；榜单页脚据此写最后实际断在哪一步。
@property(nonatomic, copy, nullable) NSString *lastFailureDetail;
@end

@implementation DYYYLiveBoardMonitor
+ (instancetype)shared {
    static DYYYLiveBoardMonitor *monitor; static dispatch_once_t once;
    dispatch_once(&once, ^{ monitor = [self new]; }); return monitor;
}
- (instancetype)init {
    if ((self = [super init])) {
        _attempts = [NSMutableDictionary dictionary]; _failures = [NSMutableDictionary dictionary];
        _states = [NSMutableDictionary dictionary]; _lastSource = @"—";
    }
    return self;
}
- (void)start {
    if (self.started) return;
    self.started = YES;
    [NSNotificationCenter.defaultCenter addObserver:self selector:@selector(becameActive) name:UIApplicationDidBecomeActiveNotification object:nil];
    [NSNotificationCenter.defaultCenter addObserver:self selector:@selector(becameActive) name:UIApplicationWillEnterForegroundNotification object:nil];
    [NSNotificationCenter.defaultCenter addObserver:self selector:@selector(resignedActive) name:UIApplicationWillResignActiveNotification object:nil];
    [NSNotificationCenter.defaultCenter addObserver:self selector:@selector(resignedActive) name:UIApplicationDidEnterBackgroundNotification object:nil];
    [NSNotificationCenter.defaultCenter addObserver:self selector:@selector(settingsChanged) name:DYYYLiveBoardStoreChanged object:nil];
    [self becameActive];
}
- (BOOL)active { return UIApplication.sharedApplication.applicationState == UIApplicationStateActive; }
- (void)notify { [NSNotificationCenter.defaultCenter postNotificationName:DYYYLiveBoardChanged object:self]; }
- (NSString *)status {
    if (!DYYYLiveBoardStore.shared.accountID.length) return @"请先登录抖音";
    if (![DYYYLiveBoardStore.shared enabled]) return @"人气榜已关闭";
    if (!self.active) return @"后台已暂停";
    if (!DYYYLiveBoardStore.shared.anchors.count) return @"添加一位主播，开始看人气";
    if (self.busy) return @"正在刷新…";
    return @"仅在前台轮询 · 等待下次刷新";
}
- (void)cancelCycle {
    self.generation++;
    [self.timer invalidate]; self.timer = nil; self.busy = NO; self.flightUID = nil;
    [DYYYRadarNetwork.shared cancelOwner:DYYYLiveBoardMonitorOwner];
}
- (void)synchronizeAccount {
    NSString *account = DYYYRadarCurrentAccount();
    if ([account isEqual:DYYYLiveBoardStore.shared.accountID]) return;
    [self cancelCycle]; [DYYYRadarNetwork.shared cancelAll];
    [DYYYLiveBoardStore.shared activateAccount:account];
    [self.attempts removeAllObjects]; [self.failures removeAllObjects]; [self.states removeAllObjects];
    self.lastCheckAt = 0; self.lastSource = @"—"; self.lastFailureDetail = nil;
    [self notify];
}
- (void)becameActive {
    if (!self.active) return;
    [self synchronizeAccount]; [self schedule];
}
- (void)resignedActive {
    [self cancelCycle]; [DYYYRadarNetwork.shared cancelAll]; [DYYYLiveBoardStore.shared flush]; [self notify];
}
- (BOOL)enabled {
    return self.active && DYYYLiveBoardStore.shared.accountID.length && [DYYYLiveBoardStore.shared enabled];
}
- (void)settingsChanged {
    if (self.busy && ![self enabled]) [self cancelCycle];
    [self schedule]; [self notify];
}
- (NSTimeInterval)remainingFor:(NSDictionary *)anchor {
    NSString *uid = anchor[@"uid"];
    double interval = DYYYRadarRetryInterval([DYYYLiveBoardStore.shared interval], [self.failures[uid] unsignedIntValue]);
    NSNumber *attempt = self.attempts[uid];
    if (!attempt) {
        NSDictionary *state = self.states[uid];
        NSTimeInterval checkedAt = [state[@"checkedAt"] doubleValue];
        if (checkedAt <= 0) return 0;
        double elapsed = MAX(0, NSDate.date.timeIntervalSince1970 - checkedAt);
        attempt = @(NSProcessInfo.processInfo.systemUptime - MIN(elapsed, 300.0)); self.attempts[uid] = attempt;
    }
    return MAX(0, interval - (NSProcessInfo.processInfo.systemUptime - attempt.doubleValue));
}
- (void)schedule {
    [self.timer invalidate]; self.timer = nil;
    if (self.busy || !self.enabled) return;
    NSTimeInterval next = DBL_MAX;
    for (NSDictionary *anchor in DYYYLiveBoardStore.shared.anchors) next = MIN(next, [self remainingFor:anchor]);
    if (next == DBL_MAX) return;
    __weak typeof(self) weakSelf = self;
    self.timer = [NSTimer timerWithTimeInterval:MAX(0.2, next) repeats:NO block:^(NSTimer *timer) {
        weakSelf.timer = nil; [weakSelf tick];
    }];
    self.timer.tolerance = MIN(2, MAX(0.1, next * 0.1));
    [NSRunLoop.mainRunLoop addTimer:self.timer forMode:NSRunLoopCommonModes];
}
- (void)checkNow {
    [self synchronizeAccount];
    if (!self.enabled) return;
    // 只催上次查完超过半个间隔的主播，不把整轮重跑一遍。
    NSTimeInterval half = [DYYYLiveBoardStore.shared interval] / 2;
    for (NSDictionary *anchor in DYYYLiveBoardStore.shared.anchors) {
        NSDictionary *state = self.states[anchor[@"uid"]];
        if (NSDate.date.timeIntervalSince1970 - [state[@"checkedAt"] doubleValue] > half) [self.attempts removeObjectForKey:anchor[@"uid"]];
    }
    if (!self.busy) [self tick];
}
- (void)invalidateTarget:(NSString *)uid {
    [self.attempts removeObjectForKey:uid];
    [self.states removeObjectForKey:uid];
    if ([self.flightUID isEqual:uid]) [self cancelCycle];
    [self schedule];
}
- (NSDictionary *)stateForUID:(NSString *)uid { return self.states[uid]; }
- (NSString *)lastSource { return _lastSource ?: @"—"; }
- (NSString *)lastFailure { return self.lastFailureDetail ?: @""; }
- (BOOL)valid:(NSUInteger)generation uid:(NSString *)uid account:(NSString *)account {
    return generation == self.generation && self.enabled && [account isEqual:DYYYRadarCurrentAccount()] &&
        [account isEqual:DYYYLiveBoardStore.shared.accountID] && [DYYYLiveBoardStore.shared anchor:uid] != nil;
}
- (void)tick {
    [self synchronizeAccount];
    if (!self.enabled || self.busy) return;
    // 2.2-9-74：-73 的 backfill 已删——主路（Api）解析到人时顺手把 secUID
    // 补回 store，不用另起一轮；backfill 那条星牌 resolveInput 路子
    // 在开关关着时 403、后备资料接口又撞 -11001，本来就补不上。
    NSDictionary *anchor;
    double oldest = DBL_MAX;
    for (NSDictionary *candidate in DYYYLiveBoardStore.shared.anchors) {
        if ([self remainingFor:candidate] > 0.05) continue;
        double attempt = [self.attempts[candidate[@"uid"]] doubleValue];
        if (!anchor || attempt < oldest) { oldest = attempt; anchor = candidate; }
    }
    if (!anchor) { [self schedule]; return; }
    self.busy = YES; self.flightUID = anchor[@"uid"];
    NSString *uid = self.flightUID, *account = DYYYLiveBoardStore.shared.accountID;
    NSUInteger generation = ++self.generation;
    self.attempts[uid] = @(NSProcessInfo.processInfo.systemUptime);
    [self notify];
    [DYYYLiveBoardApi checkAnchor:anchor owner:DYYYLiveBoardMonitorOwner completion:^(NSDictionary *result, NSError *error) {
        if (![self valid:generation uid:uid account:account]) { [self discard:generation]; return; }
        [self finish:generation uid:uid result:result error:error];
    }];
}
- (void)discard:(NSUInteger)generation {
    if (generation != self.generation) return;
    self.busy = NO; self.flightUID = nil; [self synchronizeAccount]; [self schedule]; [self notify];
}
- (void)finish:(NSUInteger)generation uid:(NSString *)uid result:(NSDictionary *)result error:(NSError *)error {
    if (generation != self.generation) return;
    self.busy = NO; self.flightUID = nil;
    self.lastCheckAt = NSDate.date.timeIntervalSince1970;
    if (error) {
        // 查不到：保留上次状态，只记失败次数用于退避，并在状态里挂错误文案。
        // 2.2-9-74：同时把三路步骤短记存下来，榜单页脚据此写最后断在哪一步。
        self.lastFailureDetail = error.localizedDescription ?: @"读取失败";
        self.failures[uid] = @(MIN(8, [self.failures[uid] unsignedIntValue] + 1));
        self.attempts[uid] = @(NSProcessInfo.processInfo.systemUptime);
        NSMutableDictionary *state = [(self.states[uid] ?: @{}) mutableCopy];
        state[@"error"] = error.localizedDescription ?: @"读取失败";
        state[@"checkedAt"] = @(NSDate.date.timeIntervalSince1970);
        self.states[uid] = state;
    } else {
        self.lastFailureDetail = nil;
        self.failures[uid] = @0;
        NSMutableDictionary *state = [result mutableCopy];
        state[@"error"] = nil;
        self.states[uid] = state;
        if (result[@"source"]) self.lastSource = DYYYRadarString(result[@"source"]);
    }
    [self schedule]; [self notify];
}
@end
