// DYYYRecall.h
// 由 DY778Recall.h 移植（DY778 → DYYY 前缀重命名）。
// 消息留存（防撤回）的公共入口：安装 Hook、读写开关、查询记录、打开撤回记录页。
// 全部开关默认关闭（NSUserDefaults 里没有对应 key 时即为 NO）。
#import <UIKit/UIKit.h>

// 本模块自有的通知名（只由本模块投递/订阅；绝不订阅 NSUserDefaultsDidChangeNotification）。
FOUNDATION_EXPORT NSNotificationName const DYYYRecallPreferencesChangedNotification;
FOUNDATION_EXPORT NSNotificationName const DYYYRecallChangedNotification;
FOUNDATION_EXPORT NSNotificationName const DYYYRecallDetectedNotification;

// NSUserDefaults 键（全部默认关闭；缺失即 NO / 0 / 空）。
FOUNDATION_EXPORT NSString *const DYYYRecallEnabledKey;              // 总开关：消息防撤回
FOUNDATION_EXPORT NSString *const DYYYRecallShowBadgeKey;           // 撤回标记：显示“已撤回”，点按查看记录
FOUNDATION_EXPORT NSString *const DYYYRecallBadgeTextKey;           // 标记文字，默认“已撤回”
FOUNDATION_EXPORT NSString *const DYYYRecallPositionKey;            // 标记位置：right / below / above，默认 right
FOUNDATION_EXPORT NSString *const DYYYRecallArchiveEntryKey;        // 聊天信息页记录入口
FOUNDATION_EXPORT NSString *const DYYYRecallNotificationsKey;       // 对方撤回时提醒
FOUNDATION_EXPORT NSString *const DYYYRecallNotificationPreviewKey; // 提醒显示消息摘要
FOUNDATION_EXPORT NSString *const DYYYRecallPlainBubbleOnSkinKey;   // 撤回后使用普通气泡
FOUNDATION_EXPORT NSString *const DYYYRecallTintBubbleKey;          // 自定义撤回气泡底色
FOUNDATION_EXPORT NSString *const DYYYRecallBubbleColorKey;         // 撤回气泡颜色（#RRGGBB），默认 #4A3038
FOUNDATION_EXPORT NSString *const DYYYRecallRetentionDaysKey;       // 记录保存天数，0 = 永久保存
FOUNDATION_EXPORT NSString *const DYYYRecallMaxRecordsKey;          // 记录数量上限，0 = 不限制
FOUNDATION_EXPORT NSString *const DYYYRecallDisabledConversationsKey; // 本账号下单独关闭防撤回的会话（@"account|conversation" 数组）
FOUNDATION_EXPORT NSString *const DYYYRecallEnableNoticeShownKey;   // 首次开启总开关时的提示是否已展示过

// 设置读写（读 NSUserDefaults.standardUserDefaults；写后投递 DYYYRecallPreferencesChangedNotification）。
FOUNDATION_EXPORT NSUserDefaults *DYYYRecallPreferences(void);
FOUNDATION_EXPORT BOOL DYYYRecallBool(NSString *key);
FOUNDATION_EXPORT NSString *DYYYRecallString(NSString *key);
FOUNDATION_EXPORT NSInteger DYYYRecallInteger(NSString *key);
FOUNDATION_EXPORT void DYYYRecallSet(NSString *key, id value);
FOUNDATION_EXPORT NSString *DYYYRecallMarkerText(void);

// 安装入口（幂等：dispatch_once / 静态守卫，重复调用无副作用；Hook 在运行时受总开关门控）。
FOUNDATION_EXPORT void DYYYInstallRecallHooks(void);
FOUNDATION_EXPORT void DYYYInstallRecallNotifications(void);
FOUNDATION_EXPORT void DYYYInstallMessageUIHooks(void);

// 消息观察与查询（供 Hook 与 MessageUI 调用）。
FOUNDATION_EXPORT void DYYYObserveMessage(id message);
FOUNDATION_EXPORT void DYYYObserveMessageContext(id viewModel);
FOUNDATION_EXPORT BOOL DYYYMessageWasRecalled(id message);
FOUNDATION_EXPORT NSDictionary *DYYYRecallRecordForMessage(id message);
FOUNDATION_EXPORT BOOL DYYYRecallEnabledForMessage(id message);
FOUNDATION_EXPORT BOOL DYYYRecallEnabledForConversation(NSString *conversationID);
FOUNDATION_EXPORT void DYYYSetConversationRecallEnabled(NSString *conversationID, BOOL enabled);

// 撤回记录页与清理。
FOUNDATION_EXPORT void DYYYPresentRecallArchive(UIViewController *source, NSString *conversationID);
FOUNDATION_EXPORT void DYYYClearRecallArchive(void);
FOUNDATION_EXPORT void DYYYClearConversationRecallArchive(NSString *conversationID);
FOUNDATION_EXPORT NSUInteger DYYYRecallCount(void);
FOUNDATION_EXPORT void DYYYRecallMaintenance(void);
FOUNDATION_EXPORT NSString *DYYYRecallStorageStatus(void);
FOUNDATION_EXPORT void DYYYRecallStorageStatistics(void (^completion)(NSDictionary *statistics));

// 消息身份（供内部与调试使用）。
FOUNDATION_EXPORT NSDictionary *DYYYMessageIdentity(id message);
FOUNDATION_EXPORT NSTimeInterval DYYYMessageTimestamp(id value);
FOUNDATION_EXPORT NSString *DYYYRecallCurrentAccountID(void);
