#import "DYYYFansService.h"
#import "DYYYFansPolicy.h"
FOUNDATION_EXPORT void DYYYFansOpenQuery(NSDictionary *person);
