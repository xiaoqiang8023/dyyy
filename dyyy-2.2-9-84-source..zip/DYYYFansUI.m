#import "DYYYFansUI.h"

@interface DYYYFansQueryController : UITableViewController
@property(nonatomic, copy) NSDictionary *person;
@property(nonatomic, copy) NSString *account;
@property(nonatomic, copy) NSString *status;
@property(nonatomic, strong) DYYYFansResult *result;
@property(nonatomic, strong) DYYYFansService *service;
@property(nonatomic) BOOL busy;
@property(nonatomic) NSUInteger generation;
@end
// 本地单元格（原 DY778RadarCell 的等价实现，只用系统图片与动态配色；不依赖 Radar）。
static UITableViewCell *DYYYFansCell(NSString *title, NSString *subtitle, NSString *symbol, BOOL disclosure) {
    UITableViewCell *cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:nil];
    cell.backgroundColor = [UIColor colorWithDynamicProvider:^UIColor *(UITraitCollection *trait) {
        return trait.userInterfaceStyle == UIUserInterfaceStyleDark ?
            [UIColor colorWithRed:.105 green:.119 blue:.13 alpha:1] : UIColor.whiteColor;
    }];
    UIListContentConfiguration *config = [UIListContentConfiguration subtitleCellConfiguration];
    config.text = title; config.secondaryText = subtitle;
    config.textProperties.font = [UIFont preferredFontForTextStyle:UIFontTextStyleBody]; config.textProperties.color = UIColor.labelColor;
    config.textProperties.numberOfLines = 0; config.secondaryTextProperties.numberOfLines = 0;
    config.secondaryTextProperties.font = [UIFont preferredFontForTextStyle:UIFontTextStyleFootnote];
    config.secondaryTextProperties.color = UIColor.secondaryLabelColor;
    config.textToSecondaryTextVerticalPadding = 5;
    config.directionalLayoutMargins = NSDirectionalEdgeInsetsMake(14, 20, 14, 20);
    if (symbol.length) {
        config.image = [UIImage systemImageNamed:symbol]; config.imageProperties.tintColor = DYYYFansAccent();
        config.imageProperties.maximumSize = CGSizeMake(28, 28); config.imageProperties.reservedLayoutSize = CGSizeMake(28, 28); config.imageToTextPadding = 14;
    }
    cell.contentConfiguration = config;
    cell.accessoryType = disclosure ? UITableViewCellAccessoryDisclosureIndicator : UITableViewCellAccessoryNone;
    return cell;
}

@implementation DYYYFansQueryController
- (instancetype)init { return [super initWithStyle:UITableViewStyleInsetGrouped]; }
- (void)viewDidLoad {
    [super viewDidLoad]; self.title = @"星牌查询"; self.account = DYYYFansAccount();
    self.service = [DYYYFansService new]; self.tableView.rowHeight = UITableViewAutomaticDimension; self.tableView.estimatedRowHeight = 78;
    self.tableView.sectionHeaderHeight = UITableViewAutomaticDimension; self.tableView.sectionFooterHeight = UITableViewAutomaticDimension;
    DYYYFansStyleController(self); self.tableView.backgroundColor = DYYYFansBackground(); self.tableView.separatorInset = UIEdgeInsetsMake(0,20,0,20);
    if (@available(iOS 15.0, *)) self.tableView.sectionHeaderTopPadding = 6;
    self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemRefresh target:self action:@selector(query)];
    [NSNotificationCenter.defaultCenter addObserver:self selector:@selector(preferencesChanged) name:NSUserDefaultsDidChangeNotification object:nil];
    [NSNotificationCenter.defaultCenter addObserver:self selector:@selector(preferencesChanged) name:UIApplicationDidBecomeActiveNotification object:nil];
    [NSNotificationCenter.defaultCenter addObserver:self selector:@selector(pause) name:UIApplicationWillResignActiveNotification object:nil];
    [self query];
}
- (void)dealloc { [self.service cancel]; [NSNotificationCenter.defaultCenter removeObserver:self]; }
- (BOOL)current { return DYYYFansEnabled(@"DYYYFansC.Enabled") && [self.account isEqual:DYYYFansAccount()]; }
- (void)pause {
    // 闪退修 1：通知可能在任意线程投递，UI 操作必须回主线程。NSUserDefaultsDidChangeNotification
    // 是由写 defaults 的线程同步投递的，抖音自己会在后台线程写 defaults，旧代码直接在这里
    // 改 UI/调 reloadData，是“有时闪退”的头号嫌疑。
    if (!NSThread.isMainThread) { dispatch_async(dispatch_get_main_queue(), ^{ [self pause]; }); return; }
    if (!self.busy) return;
    self.generation++; [self.service cancel]; self.busy=NO; self.status=@"查询已暂停，返回后可点击刷新";
    DYYYFansDismissToast(@"fans"); [self.tableView reloadData];
}
- (void)preferencesChanged {
    if (!NSThread.isMainThread) { dispatch_async(dispatch_get_main_queue(), ^{ [self preferencesChanged]; }); return; }
    DYYYFansStyleController(self);
    if (![self current]) { self.generation++; [self.service cancel]; self.busy = NO; self.result=nil; self.status = @"账号或设置已变化，请返回主页重新查询"; DYYYFansDismissToast(@"fans"); [self.tableView reloadData]; }
}
- (void)query {
    if (self.busy || ![self current]) return;
    self.busy = YES; self.status = @"正在读取可查询的资料…"; self.result = nil;
    NSUInteger generation = ++self.generation; __weak typeof(self) weakSelf = self;
    // 闪退修 2：progress/partialResult 由 Service 的 stage 同步调用，stage 一旦在非主线程被调
    // （原生 API 回调的线程不由我们控制），这里直接 reloadData 就会在后台线程改 UI。
    // 主线程直接跑，非主线程先切回主线程再跑，保持回调顺序。
    self.service.progress = ^(NSString *text) {
        void (^apply)(void) = ^{
            DYYYFansQueryController *strong = weakSelf;
            if (strong && strong.generation == generation && [strong current]) { strong.status = text; [strong.tableView reloadData]; }
        };
        if (NSThread.isMainThread) apply(); else dispatch_async(dispatch_get_main_queue(), apply);
    };
    self.service.partialResult = ^(DYYYFansResult *result) {
        void (^apply)(void) = ^{
            DYYYFansQueryController *strong = weakSelf;
            if (strong && strong.generation == generation && [strong current]) { strong.result = result; [strong.tableView reloadData]; }
        };
        if (NSThread.isMainThread) apply(); else dispatch_async(dispatch_get_main_queue(), apply);
    };
    DYYYFansShowToast(@"fans", @"正在查询星牌", YES, NO); [self.tableView reloadData];
    [self.service queryInput:@"" mode:DYYYFansInputAutomatic target:self.person anchor:nil completion:^(DYYYFansResult *result, NSError *error) {
        DYYYFansQueryController *self = weakSelf;
        if (!self || self.generation != generation || ![self current]) return;
        self.busy = NO; if (result) { self.result = result; self.person = result.person; }
        self.status = error.localizedDescription ?: (result.clubs.count ? @"本次查询已完成" : @"暂未取得可确认的灯牌");
        DYYYFansShowToast(@"fans", self.status, NO, error == nil); [self.tableView reloadData];
    }];
}
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView { return 3; }
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section { return section == 0 ? 4 : section == 1 ? MAX((NSUInteger)1,self.result.clubs.count) : 1; }
- (NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section { return @[@"当前用户", @"粉丝灯牌", @"本次结果"][(NSUInteger)section]; }
- (NSString *)tableView:(UITableView *)tableView titleForFooterInSection:(NSInteger)section {
    if (section == 0) return @"等级区间仅用于说明等级范围，不代表实际消费金额；人民币按 10 钻石=1 元换算，iOS 充值 1 元=7 钻，实际花费可能更多。";
    if (section == 1) return self.result.notice ?: @"只展示本次可查询到的灯牌。暂未返回不代表没有加入。";
    if (section == 2) return @"结果不保存为本地历史；切换账号或关闭功能会停止当前查询。";
    return nil;
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)path {
    if (path.section == 0) {
        NSDictionary *person = self.result.person ?: self.person;
        if (path.row == 0) return DYYYFansCell(DYYYFansPersonName(person), [NSString stringWithFormat:@"抖音号：%@", [person[@"handle"] length] ? person[@"handle"] : @"暂未提供"], @"person.crop.circle", NO);
        if (path.row == 1) {
            // 2.2-9-65：副标题后加人民币约算（10 钻石=1 元）；maximum 为空时写“约 ¥X 以上”，没有区间时不编数字。
            NSString *rmbRange = [DYYYFansResult rmbRangeFromMinimum:self.result.minimum maximum:self.result.maximum];
            NSString *range = self.result.minimum ? [NSString stringWithFormat:@"等级对应钻石区间：%@–%@%@", self.result.minimum, self.result.maximum ?: @"以上", rmbRange ? [NSString stringWithFormat:@"（约 %@）", rmbRange] : @""] : @"暂未返回等级区间";
            return DYYYFansCell(self.result.level ? [NSString stringWithFormat:@"消费等级 Lv.%@",self.result.level] : @"消费等级暂未返回",range,@"diamond",NO);
        }
        if (path.row == 2) return DYYYFansCell(@"个人简介", [person[@"signature"] length] ? person[@"signature"] : @"暂无可展示的简介", @"text.alignleft", NO);
        // 2.2-9-64：输入谁就查谁——点这里切换查询对象（抖音号、UID 或分享链接）。
        return DYYYFansCell(@"切换查询对象", @"输入抖音号、UID 或分享链接，查询其他人", @"person.crop.circle.badge.plus", YES);
    }
    if (path.section == 1) {
        if (!self.result.clubs.count) return DYYYFansCell(self.busy ? @"正在查询" : @"暂待确认", self.status ?: @"等待查询", @"star.circle", NO);
        // 闪退修 3：行数与取数据之间结果可能被换掉（刷新/取消/账号变化），下标前先判越界，
        // 越界就显示占位行而不是直接崩。
        if ((NSUInteger)path.row >= self.result.clubs.count) return DYYYFansCell(@"暂待确认", self.status ?: @"等待查询", @"star.circle", NO);
        NSDictionary *club = self.result.clubs[(NSUInteger)path.row];
        NSString *title = [club[@"clubName"] length] ? club[@"clubName"] : @"粉丝灯牌";
        NSString *state = [club[@"status"] integerValue] == 1 ? @"已点亮" : [club[@"status"] integerValue] == 2 ? @"未点亮" : @"点亮状态暂未提供";
        NSString *level = club[@"level"] ? [NSString stringWithFormat:@"Lv.%@ · %@",club[@"level"],state] : @"等级暂未提供";
        NSString *name = [club[@"anchorName"] length] ? club[@"anchorName"] : @"主播资料暂未返回";
        return DYYYFansCell(title,[NSString stringWithFormat:@"%@\n%@",level,name],@"star.fill",NO);
    }
    return DYYYFansCell(@"复制查询结果",self.busy ? @"查询完成后可复制" : self.status ?: @"等待查询",@"doc.on.doc",NO);
}
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)path {
    [tableView deselectRowAtIndexPath:path animated:YES]; if (self.busy || ![self current]) return;
    if (path.section == 0 && path.row == 3) [self selectTarget];
    else if (path.section == 2 && self.result) { UIPasteboard.generalPasteboard.string = self.result.shareText; DYYYFansToast(@"查询结果已复制"); }
    else if (path.section == 0 && path.row == 2 && [self.result.person[@"signature"] length]) { UIPasteboard.generalPasteboard.string = self.result.person[@"signature"]; DYYYFansToast(@"个人简介已复制"); }
}
- (NSString *)targetKey { return [@"DYYYFansTargets." stringByAppendingString:self.account ?: @""]; }
- (void)useTarget:(NSDictionary *)person {
    if (![self current] || !person) return;
    self.person = person;
    id stored = [[NSUserDefaults standardUserDefaults] objectForKey:self.targetKey]; NSMutableArray *recent = [NSMutableArray array];
    [recent addObject:person];
    if ([stored isKindOfClass:NSArray.class]) for (NSDictionary *old in stored) if ([old isKindOfClass:NSDictionary.class] && !DYYYFansSamePerson(person,old) && recent.count < 8) [recent addObject:old];
    [[NSUserDefaults standardUserDefaults] setObject:recent forKey:self.targetKey]; [self query];
}
- (void)selectTarget {
    id value = [[NSUserDefaults standardUserDefaults] objectForKey:self.targetKey]; NSArray *recent = [value isKindOfClass:NSArray.class] ? value : @[];
    UIAlertController *sheet = [UIAlertController alertControllerWithTitle:@"切换查询对象" message:@"查询其他人的消费等级与粉丝灯牌。" preferredStyle:UIAlertControllerStyleActionSheet];
    sheet.overrideUserInterfaceStyle = DYYYFansInterfaceStyle(); sheet.view.tintColor = DYYYFansAccent();
    __weak typeof(self) weakSelf = self;
    for (NSDictionary *person in recent) if ([person isKindOfClass:NSDictionary.class] && DYYYFansUID(person[@"uid"]))
        [sheet addAction:[UIAlertAction actionWithTitle:DYYYFansPersonName(person) style:UIAlertActionStyleDefault handler:^(__unused UIAlertAction *action) { [weakSelf useTarget:person]; }]];
    [sheet addAction:[UIAlertAction actionWithTitle:@"输入抖音号 / UID / 分享链接" style:UIAlertActionStyleDefault handler:^(__unused UIAlertAction *action) { [weakSelf enterTarget]; }]];
    [sheet addAction:[UIAlertAction actionWithTitle:@"取消" style:UIAlertActionStyleCancel handler:nil]];
    sheet.popoverPresentationController.sourceView = self.view; sheet.popoverPresentationController.sourceRect = CGRectMake(CGRectGetMidX(self.view.bounds),CGRectGetMidY(self.view.bounds),1,1);
    [self presentViewController:sheet animated:YES completion:nil];
}
- (void)enterTarget {
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"切换查询对象" message:@"输入抖音号、UID 或分享链接，查询后核对身份。" preferredStyle:UIAlertControllerStyleAlert];
    alert.overrideUserInterfaceStyle = DYYYFansInterfaceStyle(); alert.view.tintColor = DYYYFansAccent();
    [alert addTextFieldWithConfigurationHandler:^(UITextField *field) { field.placeholder = @"抖音号、UID 或分享链接"; field.autocorrectionType = UITextAutocorrectionTypeNo; field.autocapitalizationType = UITextAutocapitalizationTypeNone; }];
    [alert addAction:[UIAlertAction actionWithTitle:@"取消" style:UIAlertActionStyleCancel handler:nil]];
    __weak typeof(self) weakSelf = self; __weak UIAlertController *weakAlert=alert;
    [alert addAction:[UIAlertAction actionWithTitle:@"查询" style:UIAlertActionStyleDefault handler:^(__unused UIAlertAction *action) {
        DYYYFansQueryController *self = weakSelf; if (![self current]) return;
        self.busy = YES; NSUInteger generation = ++self.generation; DYYYFansShowToast(@"fans",@"正在查找账号",YES,NO);
        [self.service resolveInput:weakAlert.textFields.firstObject.text mode:DYYYFansInputAutomatic completion:^(id person,NSError *error) {
            if (![weakSelf current] || weakSelf.generation != generation) return;
            weakSelf.busy = NO; DYYYFansDismissToast(@"fans");
            NSArray *candidates = error.userInfo[@"DYYYFansCandidates"];
            if ([candidates isKindOfClass:NSArray.class] && candidates.count) { [weakSelf chooseCandidate:candidates]; return; }
            if (!person || error) { DYYYFansToast(error.localizedDescription ?: @"暂未找到该账号"); return; }
            [weakSelf chooseCandidate:@[person]];
        }];
    }]]; [self presentViewController:alert animated:YES completion:nil];
}
- (void)chooseCandidate:(NSArray *)people {
    if (![self current]) return;
    UIAlertController *sheet = [UIAlertController alertControllerWithTitle:@"核对查询对象" message:@"请选择正确的账号。" preferredStyle:UIAlertControllerStyleActionSheet];
    sheet.overrideUserInterfaceStyle = DYYYFansInterfaceStyle(); sheet.view.tintColor = DYYYFansAccent(); __weak typeof(self) weakSelf = self;
    for (NSDictionary *person in people) [sheet addAction:[UIAlertAction actionWithTitle:[NSString stringWithFormat:@"%@ · %@",DYYYFansPersonName(person),person[@"handle"] ?: @""] style:UIAlertActionStyleDefault handler:^(__unused UIAlertAction *action) { [weakSelf useTarget:person]; }]];
    [sheet addAction:[UIAlertAction actionWithTitle:@"取消" style:UIAlertActionStyleCancel handler:nil]];
    sheet.popoverPresentationController.sourceView = self.view; sheet.popoverPresentationController.sourceRect = CGRectMake(CGRectGetMidX(self.view.bounds),CGRectGetMidY(self.view.bounds),1,1);
    [self presentViewController:sheet animated:YES completion:nil];
}
- (void)viewDidDisappear:(BOOL)animated {
    [super viewDidDisappear:animated];
    if (self.isMovingFromParentViewController || self.navigationController.isBeingDismissed) { self.generation++; [self.service cancel]; DYYYFansDismissToast(@"fans"); }
}
@end
void DYYYFansOpenQuery(NSDictionary *person) {
    if (!DYYYFansEnabled(@"DYYYFansC.Enabled") || !person) return;
    DYYYFansQueryController *controller = [DYYYFansQueryController new]; controller.person = person;
    DYYYFansPresentController(DYYYFansTopController(),controller);
}
