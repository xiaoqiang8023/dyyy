// DYYYRecallNotifications.h
// 由 DY778RecallNotifications.h 移植（DY778 → DYYY 前缀重命名；只要撤回提醒，不要编辑提醒）。
// 对方撤回时提醒：前台显示提醒卡片，后台发系统通知；提醒可显示消息摘要（需另开摘要开关）。
#import "DYYYRecall.h"

FOUNDATION_EXPORT void DYYYInstallRecallNotifications(void);
FOUNDATION_EXPORT void DYYYRequestRecallNotificationPermission(UIViewController *source);
FOUNDATION_EXPORT void DYYYShowRecallNotificationStatus(UIViewController *source);
