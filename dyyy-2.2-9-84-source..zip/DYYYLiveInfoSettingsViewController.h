// DYYYLiveInfoSettingsViewController.h — “直播信息”独立设置页（2.2-9-68）。
// 照抄 DY778 作者原版：独立页、深青开关/图标、滑杆行、胶囊样式合一、颜色圆点。
// 只管设置页外观与写入，不管胶囊功能逻辑。
#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface DYYYLiveInfoSettingsViewController : UITableViewController

// 作者点缀色：#55CDB9，浅色下按 DY778Accent 逻辑 ×0.58 变深（约 #31776B）。
+ (UIColor *)accentColor;

@end

NS_ASSUME_NONNULL_END
