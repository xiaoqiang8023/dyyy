#import "DYYYFansModel.h"

typedef void (^DYYYFansReply)(id value, NSError *error);
NSString *DYYYFansLastDiagnostic(void);
@interface DYYYFansService : NSObject
@property(nonatomic, copy) void (^progress)(NSString *text);
@property(nonatomic, copy) void (^partialResult)(DYYYFansResult *result);
- (void)queryInput:(NSString *)input mode:(DYYYFansInputMode)mode target:(NSDictionary *)target anchor:(NSDictionary *)anchor completion:(void (^)(DYYYFansResult *, NSError *))completion;
- (void)resolveInput:(NSString *)input mode:(DYYYFansInputMode)mode completion:(DYYYFansReply)completion;
- (void)refreshPerson:(NSDictionary *)person completion:(DYYYFansReply)completion;
- (void)cancel;
@end
