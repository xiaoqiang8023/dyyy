// DYYYDetailPaging.xm
// 只扒上游 Wtrwx 1692 的创作者/直播进主页分页这一条（2026-11-04，用户真机确认 1692 修好了直播进主页）
// 其他功能一字不动：推荐页、首页全屏散钩、玻璃、万显示、开播时长、原画等全部保留原有代码。
//
// 上游做法（Wtrwx 2026-10-24 99b6599 + 10-25 d94e1c1 最终版，DYYYFullscreenCoordinator）：
//   详情控制器不分正常/直播/创作者，一律按 AWEAwemeDetailTableViewController 算详情布局，
//   不按导航栈有没有 Live、不按头像徽章、不按 referString 区分。
//   1) baseTableViewBottomInset：详情且全屏开时，有底边距就清 0。本地之前根本没钩这一处，
//      原生分页步长 = 表高 - 底边距（实测 956 - 45 = 911），而本地行高强制到表高 956，步长与行高差 45，
//      越滑越错、点第 9 出第 8/10/11，都是这个差在作怪。清 0 后步长 = 表高，与行高对齐。
//   2) reconcileDetailPaging：viewDidLayoutSubviews / viewDidAppear 时，若首末行高或行间距已不是表高倍数，
//      且行高方法本身已返回表高（说明只是早期数据源缓存了带输入栏占位的行高），就 begin/endUpdates 重新问
//      一遍原生行高，再用原生 updateTableViewLayoutForTargetPageIndex:当前可见序号 恢复分页偏移。
//      守卫：主线程、全屏开、表在窗口、没在拖/减速、单区、序号合法、没在评论、没在重入，否则原样返回。
//   本地已有的详情行高强制（表高/911）与偏移累加保留不动，清底边距后它们与原生步长一致，不再打架。

#import "AwemeHeaders.h"
#import <objc/runtime.h>

static char kDYYYDetailPagingApplyingKey;

static void DYYYDetailPagingReconcile(AWEAwemeDetailTableViewController *detail) {
    if (![NSThread isMainThread] || !DYYYGetBool(@"DYYYEnableFullScreen") || !detail) return;
    if (![detail respondsToSelector:@selector(tableView)] || ![detail respondsToSelector:@selector(currentVisibleCellIndex)] ||
        ![detail respondsToSelector:@selector(updateTableViewLayoutForTargetPageIndex:)]) return;
    UITableView *table = [detail tableView];
    if (!table) return;
    CGFloat height = table.bounds.size.height;
    if (!table.window || height <= 0 || table.bounds.size.width <= 0 ||
        table.tracking || table.dragging || table.decelerating || table.numberOfSections != 1) return;
    NSNumber *applying = objc_getAssociatedObject(table, &kDYYYDetailPagingApplyingKey);
    if (applying && applying.boolValue) return;
    NSInteger count = [table numberOfRowsInSection:0];
    NSUInteger index = [detail currentVisibleCellIndex];
    if (count <= 0 || index >= (NSUInteger)count) return;
    NSIndexPath *firstIndex = [NSIndexPath indexPathForRow:0 inSection:0];
    NSIndexPath *lastIndex = [NSIndexPath indexPathForRow:count - 1 inSection:0];
    CGRect first = [table rectForRowAtIndexPath:firstIndex];
    CGRect last = [table rectForRowAtIndexPath:lastIndex];
    if (fabs(first.size.height - height) < 0.5 && fabs(last.size.height - height) < 0.5 &&
        fabs(CGRectGetMinY(last) - CGRectGetMinY(first) - (count - 1) * height) < 0.5) return;
    if (![detail respondsToSelector:@selector(tableView:heightForRowAtIndexPath:)] ||
        fabs([detail tableView:table heightForRowAtIndexPath:firstIndex] - height) > 0.5 ||
        fabs([detail tableView:table heightForRowAtIndexPath:lastIndex] - height) > 0.5) return;
    objc_setAssociatedObject(table, &kDYYYDetailPagingApplyingKey, @(YES), OBJC_ASSOCIATION_RETAIN_NONATOMIC);
    @try {
        [UIView performWithoutAnimation:^{
            [table beginUpdates];
            [table endUpdates];
            [detail updateTableViewLayoutForTargetPageIndex:(NSInteger)index];
            [table layoutIfNeeded];
        }];
    } @finally {
        objc_setAssociatedObject(table, &kDYYYDetailPagingApplyingKey, @(NO), OBJC_ASSOCIATION_RETAIN_NONATOMIC);
    }
}

%hook AWEAwemeDetailTableViewController
- (CGFloat)baseTableViewBottomInset {
    CGFloat inset = %orig;
    if (!DYYYGetBool(@"DYYYEnableFullScreen")) return inset;
    return inset > 0 ? 0 : inset;
}
- (void)viewDidLayoutSubviews {
    %orig;
    DYYYDetailPagingReconcile(self);
}
- (void)viewDidAppear:(BOOL)animated {
    %orig;
    DYYYDetailPagingReconcile(self);
}
%end
