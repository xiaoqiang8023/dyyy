// DYYYRecallContent.m
// 由 DY778RecallContent.m 移植（DY778 → DYYY 前缀重命名）。
// 纯解析层：遍历消息 content 字典，抽出种类 / 标题 / 文本 / 媒体 / 分享作品 / 评论。
// 不做网络、不做磁盘、不调用任何抖音业务方法（除一次性的 notUserGeneratedMessageTypes 系统类型查询）。
#import "DYYYRecallContent.h"
#import <objc/runtime.h>
#import <objc/message.h>
#import <math.h>

#pragma mark - 小工具

static NSString *DYYYContentString(id value) {
    return [value isKindOfClass:NSString.class] ? value : ([value isKindOfClass:NSNumber.class] ? [value stringValue] : @"");
}

static BOOL DYYYContainsAny(NSString *text, NSArray *words) {
    for (NSString *word in words)
        if ([text containsString:word]) return YES;
    return NO;
}

static NSString *DYYYValueForKeys(NSDictionary *node, NSArray *keys) {
    for (NSString *key in keys) {
        NSString *value = DYYYContentString(node[key]);
        if (value.length && ![value isEqual:@"Recall Content Hided"]) return value;
    }
    return @"";
}

static BOOL DYYYHasContentValue(NSDictionary *node, NSArray *keys) {
    for (NSString *key in keys) {
        id value = node[key];
        if ([value isKindOfClass:NSString.class] && [value length]) return YES;
        if (([value isKindOfClass:NSDictionary.class] || [value isKindOfClass:NSArray.class]) && [value count]) return YES;
    }
    return NO;
}

static id DYYYUnpackContent(id node) {
    if (![node isKindOfClass:NSString.class] || [node length] > 1024 * 1024) return node;
    NSString *text = [node stringByTrimmingCharactersInSet:NSCharacterSet.whitespaceAndNewlineCharacterSet];
    if (![text hasPrefix:@"{"] && ![text hasPrefix:@"["]) return node;
    id parsed = [NSJSONSerialization JSONObjectWithData:[text dataUsingEncoding:NSUTF8StringEncoding] options:0 error:nil];
    return [parsed isKindOfClass:NSDictionary.class] || [parsed isKindOfClass:NSArray.class] ? parsed : node;
}

static NSString *DYYYMediaIdentity(NSDictionary *media) {
    for (NSString *key in @[@"remoteURL", @"cachedPath", @"sourcePath"]) {
        NSString *value = DYYYContentString(media[key]);
        if (value.length) return value;
    }
    return @"";
}

static BOOL DYYYUnrelatedMediaPath(NSString *path) {
    return DYYYContainsAny(path.lowercaseString, @[@".author", @".user", @".avatar", @".portrait", @".music", @".quote", @".reply", @".refer", @".comment", @".emoji_icon", @".blur", @".gaussian"]);
}

static NSInteger DYYYMediaQuality(NSString *path) {
    NSString *p = path.lowercaseString;
    if (DYYYContainsAny(p, @[@"origin", @"original", @"large", @"high_quality"])) return 600;
    if (DYYYContainsAny(p, @[@"thumb", @"small", @"preview"])) return 100;
    if (DYYYContainsAny(p, @[@"dynamic", @"animate"])) return 200;
    if (DYYYContainsAny(p, @[@"cover", @"poster"])) return 500;
    if (DYYYContainsAny(p, @[@"image", @"photo"])) return 400;
    return 300;
}

#pragma mark - 种类判定

NSString *DYYYRecallMessageKind(NSString *className) {
    if (![className isKindOfClass:NSString.class] || ![className hasPrefix:@"AWEIM"]) return @"";
    if ([className containsString:@"AudioMessage"]) return @"audio";
    if ([className containsString:@"ImageMessage"]) return @"image";
    if ([className containsString:@"VideoMessage"] && ![className containsString:@"Share"] && ![className containsString:@"Feed"]) return @"video";
    if ([className isEqual:@"AWEIMShareLocationMessage"]) return @"location";
    return @"";
}

static NSString *DYYYNodeKind(NSDictionary *node, NSString *inherited) {
    if (DYYYValueForKeys(node, @[@"recall_user_id", @"recallUserID", @"recalled_message_id", @"recall_message_id", @"custom_recall_text", @"customRecallText"]).length) return @"recall-notice";
    if ([@[@"image", @"audio", @"video", @"location"] containsObject:inherited]) return inherited;
    if (DYYYValueForKeys(node, @[@"room_id", @"roomId", @"roomID", @"room_owner_id"]).length) return @"live";
    if (DYYYValueForKeys(node, @[@"product_id", @"productId", @"promotion_id", @"promotionId", @"chatGoodsSchema"]).length) return @"goods";
    if (DYYYValueForKeys(node, @[@"sticker_type", @"stickerType", @"sticker_id", @"stickerID", @"giphy_name", @"giphyName", @"emoji_type", @"emojiType", @"animate_url", @"animateURL"]).length || node[@"giphy_url"] || node[@"giphyURL"]) return @"sticker";
    if (DYYYHasContentValue(node, @[@"res_origin_url_list", @"resOriginUrlList", @"res_thumb_url_list", @"resThumbUrlList", @"res_medium_url_list", @"resMediumUrlList", @"res_large_url_list", @"resLargeUrlList", @"res_long_url_list", @"resLongUrlList", @"res_still_url_list", @"resStillUrlList"])) return @"image";
    BOOL resource = DYYYHasContentValue(node, @[@"resource_url", @"resourceUrl"]);
    NSString *contentType = DYYYValueForKeys(node, @[@"content_type", @"contentType"]).lowercaseString;
    BOOL dimensions = (node[@"cover_width"] || node[@"coverWidth"]) && (node[@"cover_height"] || node[@"coverHeight"]);
    if ([contentType hasPrefix:@"audio/"] || [@[@"audio", @"voice"] containsObject:contentType] ||
        (resource && (node[@"average_power_arr"] || node[@"averagePowerArr"] || (node[@"duration"] && !dimensions)))) return @"audio";
    if (resource && dimensions) return @"image";
    NSString *workID = DYYYValueForKeys(node, @[@"aweme_id", @"awemeID", @"itemId", @"item_id"]);
    if (workID.length && ![workID isEqual:@"0"]) return @"work";
    id latitude = node[@"latitude"], longitude = node[@"longitude"] ?: node[@"lng"];
    if ([latitude respondsToSelector:@selector(doubleValue)] && [longitude respondsToSelector:@selector(doubleValue)]) {
        double lat = [latitude doubleValue], lon = [longitude doubleValue];
        BOOL described = DYYYHasContentValue(node, @[@"cover_resource_url", @"coverResourceUrl", @"poi_name", @"poiName", @"poi_address", @"poiAddress"]);
        if (described && isfinite(lat) && isfinite(lon) && fabs(lat) <= 90 && fabs(lon) <= 180) return @"location";
    }
    return inherited ?: @"";
}

static NSString *DYYYKindForURL(NSString *path, NSString *context, NSURL *url) {
    NSString *all = [NSString stringWithFormat:@"%@ %@", path.lowercaseString, url.pathExtension.lowercaseString];
    if (DYYYContainsAny(all, @[@"avatar", @"portrait"])) return nil;
    if (DYYYContainsAny(all, @[@"cover", @"thumb", @"display_icon", @"displayicon", @"static_url", @"staticurl"])) return @"image";
    if ([@[@"image", @"audio", @"video"] containsObject:context] && DYYYContainsAny(path.lowercaseString, @[@"resource", @"res_", @"resorigin", @"resmedium", @"reslarge", @"reslong", @"resstill"])) return context;
    if (DYYYContainsAny(all, @[@"audio", @"voice", @"mp3", @"m4a", @"aac", @"wav", @"amr", @"opus"])) return @"audio";
    if (DYYYContainsAny(all, @[@"video", @"play_addr", @"playurl", @"play_url", @"mp4", @"mov", @"m3u8"])) return @"video";
    if (DYYYContainsAny(all, @[@"image", @"photo", @"giphy", @"sticker", @"emoji", @"animate", @"jpg", @"jpeg", @"png", @"gif", @"webp", @"heic"])) return @"image";
    if (DYYYContainsAny(all, @[@"file_url", @"fileurl", @"download_url"])) return @"file";
    if ([@[@"sticker", @"goods", @"live"] containsObject:context]) return @"image";
    return nil;
}

#pragma mark - 内容遍历

// 递归遍历 content：抽 presentation 字段（kind/title/text/author/id/share）与 media 列表。
// 上限：深度 22、节点预算 4000；头像/引用/表情图标等无关路径直接跳过。
static void DYYYWalkContent(id raw, NSString *path, NSString *inherited, NSMutableDictionary *presentation,
                            NSMutableArray *media, NSMutableSet *seen, NSUInteger depth, NSUInteger *budget) {
    if (depth > 22 || !*budget || DYYYUnrelatedMediaPath(path)) return;
    (*budget)--;
    id node = DYYYUnpackContent(raw);
    if ([node isKindOfClass:NSDictionary.class]) {
        NSString *kind = DYYYNodeKind(node, inherited);
        NSDictionary *authorNode = [node[@"author"] isKindOfClass:NSDictionary.class] ? node[@"author"] : nil;
        NSString *authorName = DYYYValueForKeys(authorNode, @[@"nickname", @"name"]);
        if (authorName.length && ![presentation[@"author"] length]) presentation[@"author"] = authorName;
        if (kind.length && (![presentation[@"kind"] length] || [kind isEqual:@"recall-notice"])) presentation[@"kind"] = kind;
        NSString *title = DYYYValueForKeys(node, @[@"title", @"display_title"]);
        if (title.length && ![presentation[@"title"] length]) presentation[@"title"] = title;
        NSString *text = DYYYValueForKeys(node, @[@"text", @"content", @"display_content", @"desc", @"description"]);
        if (text.length && ![presentation[@"text"] length] && ![text hasPrefix:@"{"]) presentation[@"text"] = text;
        NSString *workID = DYYYValueForKeys(node, @[@"aweme_id", @"awemeID", @"itemId", @"item_id"]);
        if (workID.length && ![workID isEqual:@"0"] && ![presentation[@"id"] length]) presentation[@"id"] = workID;
        if (DYYYValueForKeys(node, @[@"recall_user_id", @"recallUserID", @"recalled_message_id", @"recall_message_id"]).length) {
            NSString *target = DYYYValueForKeys(node, @[@"recalled_message_id", @"recall_message_id"]);
            if (target.length) presentation[@"recallTargetID"] = target;
        }
        // 分享作品卡片：带 aweme_id 的节点同时记一份 share。
        if ([kind isEqual:@"work"] || workID.length) {
            NSMutableDictionary *share = [presentation[@"share"] isKindOfClass:NSMutableDictionary.class] ? presentation[@"share"] : [NSMutableDictionary dictionary];
            if (workID.length && ![share[@"id"] length]) share[@"id"] = workID;
            if (title.length && ![share[@"title"] length]) share[@"title"] = title;
            if (authorName.length && ![share[@"author"] length]) share[@"author"] = authorName;
            if (share.count) presentation[@"share"] = share;
        }
        for (NSString *key in node) {
            id child = node[key];
            NSString *childPath = path.length ? [path stringByAppendingFormat:@".%@", key] : key;
            if ([child isKindOfClass:NSDictionary.class] || [child isKindOfClass:NSArray.class]) {
                DYYYWalkContent(child, childPath, kind, presentation, media, seen, depth + 1, budget);
            } else if ([child isKindOfClass:NSString.class]) {
                NSString *string = (NSString *)child;
                if ([string hasPrefix:@"http://"] || [string hasPrefix:@"https://"]) {
                    NSURL *url = [NSURL URLWithString:string];
                    if (!url) continue;
                    NSString *mediaKind = DYYYKindForURL(childPath, kind, url);
                    if (!mediaKind) continue;
                    NSString *identity = string;
                    if ([seen containsObject:identity]) continue;
                    [seen addObject:identity];
                    NSMutableDictionary *item = [NSMutableDictionary dictionary];
                    item[@"kind"] = mediaKind;
                    item[@"remoteURL"] = string;
                    item[@"field"] = childPath;
                    item[@"quality"] = @(DYYYMediaQuality(childPath));
                    if ([childPath.lowercaseString containsString:@"cover"] || [childPath.lowercaseString containsString:@"thumb"]) item[@"cover"] = @YES;
                    [media addObject:item];
                }
            }
        }
        return;
    }
    if ([node isKindOfClass:NSArray.class]) {
        for (id child in (NSArray *)node) DYYYWalkContent(child, path, inherited, presentation, media, seen, depth + 1, budget);
    }
}

static NSDictionary *DYYYExtractPresentation(id content) {
    NSMutableDictionary *presentation = [NSMutableDictionary dictionary];
    NSMutableArray *media = [NSMutableArray array];
    NSMutableSet *seen = [NSMutableSet set];
    NSUInteger budget = 4000;
    DYYYWalkContent(content, @"", @"", presentation, media, seen, 0, &budget);
    if (media.count) presentation[@"media"] = media;
    return presentation;
}

static NSDictionary *DYYYExtractPresentationForKind(id content, NSString *declaredKind) {
    NSMutableDictionary *presentation = [DYYYExtractPresentation(content) mutableCopy];
    if (declaredKind.length && ![presentation[@"kind"] length]) presentation[@"kind"] = declaredKind;
    return presentation;
}

#pragma mark - 评论

static NSDictionary *DYYYCommentInContent(id raw, NSUInteger depth, BOOL insideComment) {
    if (depth > 12) return nil;
    id node = DYYYUnpackContent(raw);
    if ([node isKindOfClass:NSDictionary.class]) {
        NSDictionary *dict = (NSDictionary *)node;
        BOOL isComment = insideComment || [dict[@"comment_id"] length] || [dict[@"commentID"] length] ||
                         ([dict[@"text"] isKindOfClass:NSString.class] && [dict[@"author"] isKindOfClass:NSDictionary.class] && dict[@"aweme_id"]);
        if (isComment) {
            NSString *text = DYYYContentString(dict[@"text"]);
            if (text.length) {
                NSMutableDictionary *comment = [NSMutableDictionary dictionary];
                comment[@"text"] = text;
                NSString *author = DYYYValueForKeys([dict[@"author"] isKindOfClass:NSDictionary.class] ? dict[@"author"] : nil, @[@"nickname", @"name"]);
                if (author.length) comment[@"author"] = author;
                NSString *cid = DYYYValueForKeys(dict, @[@"comment_id", @"commentID", @"cid"]);
                if (cid.length) comment[@"id"] = cid;
                return comment;
            }
        }
        for (id key in @[@"comment", @"reply_comment", @"replyComment", @"quoted_comment", @"quotedComment"]) {
            NSDictionary *found = DYYYCommentInContent(dict[key], depth + 1, YES);
            if (found) return found;
        }
        for (id value in dict.allValues) {
            NSDictionary *found = DYYYCommentInContent(value, depth + 1, insideComment);
            if (found) return found;
        }
    } else if ([node isKindOfClass:NSArray.class]) {
        for (id child in (NSArray *)node) {
            NSDictionary *found = DYYYCommentInContent(child, depth + 1, insideComment);
            if (found) return found;
        }
    }
    return nil;
}

NSDictionary *DYYYRecallCommentFromContent(id content) {
    return DYYYCommentInContent(content, 0, NO);
}

NSDictionary *DYYYMergeCapturedComment(NSDictionary *previous, NSDictionary *candidate) {
    if (![candidate count]) return [previous isKindOfClass:NSDictionary.class] ? previous : nil;
    if (![previous isKindOfClass:NSDictionary.class] || ![previous count]) return candidate;
    NSMutableDictionary *merged = [previous mutableCopy];
    for (NSString *key in candidate)
        if (![merged[key] isKindOfClass:NSString.class] || ![(NSString *)merged[key] length]) merged[key] = candidate[key];
    return merged;
}

#pragma mark - 撤回提示判定

static BOOL DYYYHostIdentifiesRecallNotice(id type) {
    if ([type longLongValue] != 40001) return NO;
    static NSSet *systemTypes;
    static dispatch_once_t once;
    dispatch_once(&once, ^{
        Class cls = NSClassFromString(@"AWEIMMessage");
        SEL selector = NSSelectorFromString(@"notUserGeneratedMessageTypes");
        Method method = class_getClassMethod(cls, selector);
        char returned[8] = {0};
        if (method) method_getReturnType(method, returned, sizeof(returned));
        if (!method || method_getNumberOfArguments(method) != 2 || returned[0] != '@') return;
        @try {
            id values = ((id (*)(id, SEL))objc_msgSend)(cls, selector);
            if ([values isKindOfClass:NSSet.class]) systemTypes = [values copy];
            else if ([values isKindOfClass:NSArray.class]) systemTypes = [NSSet setWithArray:values];
        } @catch (__unused NSException *exception) {
        }
    });
    return [systemTypes containsObject:@40001] || [systemTypes containsObject:@"40001"];
}

BOOL DYYYRecallContentIsNotice(id content) {
    if (![content isKindOfClass:NSDictionary.class]) return NO;
    NSDictionary *presentation = DYYYExtractPresentation(content);
    if ([presentation[@"kind"] isEqual:@"recall-notice"]) return YES;
    return DYYYHostIdentifiesRecallNotice(content[@"type"]);
}

#pragma mark - 富化 / 摘要 / 作品 / 隐藏

NSArray *DYYYRecallMediaFromContent(id content) {
    return DYYYExtractPresentation(content)[@"media"] ?: @[];
}

NSDictionary *DYYYRecallEnrichRecord(NSDictionary *record) {
    if (![record isKindOfClass:NSDictionary.class]) return @{};
    if ([record[@"presentationVersion"] integerValue] == 8) return record;
    NSMutableDictionary *result = [record mutableCopy];
    NSDictionary *comment = DYYYMergeCapturedComment(record[@"comment"], DYYYRecallCommentFromContent(record[@"content"]));
    if (comment) result[@"comment"] = comment;
    NSString *declaredKind = DYYYRecallMessageKind(record[@"presentationClass"]);
    NSMutableDictionary *presentation = [DYYYExtractPresentationForKind(record[@"content"], declaredKind) mutableCopy];
    NSDictionary *native = [record[@"card"] isKindOfClass:NSDictionary.class] ? record[@"card"] : @{};
    for (NSString *key in native) {
        if ([key isEqual:@"kind"] && (declaredKind.length || [native[key] isEqual:@"location"])) continue;
        if ([DYYYContentString(native[key]) length]) presentation[key] = native[key];
    }
    NSMutableArray *media = [NSMutableArray array];
    NSMutableSet *seen = [NSMutableSet set];
    for (NSArray *items in @[presentation[@"media"] ?: @[], record[@"media"] ?: @[]])
        for (NSDictionary *__strong item in items) {
            if (![item isKindOfClass:NSDictionary.class]) continue;
            NSString *identity = DYYYMediaIdentity(item);
            if (DYYYUnrelatedMediaPath(DYYYContentString(item[@"field"]))) continue;
            if (identity.length && [seen containsObject:identity]) {
                NSUInteger index = [media indexOfObjectPassingTest:^BOOL(NSDictionary *candidate, NSUInteger i, BOOL *stop) {
                    return [DYYYMediaIdentity(candidate) isEqual:identity];
                }];
                if (index != NSNotFound) {
                    NSMutableDictionary *merged = [media[index] mutableCopy];
                    for (NSString *key in item)
                        if (!merged[key] || [key isEqual:@"cachedPath"] || [key isEqual:@"sourcePath"] ||
                            ([key isEqual:@"encrypted"] && [item[key] boolValue]) ||
                            ([item[@"native"] boolValue] && [@[@"kind", @"name", @"field"] containsObject:key]) ||
                            ([key isEqual:@"quality"] && [item[key] integerValue] > [merged[key] integerValue]))
                            merged[key] = item[key];
                    media[index] = merged;
                }
                continue;
            }
            if (identity.length) [seen addObject:identity];
            [media addObject:item];
        }
    [presentation removeObjectForKey:@"media"];
    BOOL direct = [@[@"image", @"audio", @"video"] containsObject:presentation[@"kind"]];
    BOOL encrypted = [presentation[@"encrypted"] boolValue] || (declaredKind.length && [DYYYContentString(record[@"presentationClass"]) containsString:@"Encrypt"]);
    if (direct)
        for (NSUInteger i = 0; i < media.count; i++) {
            NSMutableDictionary *item = [media[i] mutableCopy];
            if ([item[@"kind"] isEqual:@"file"]) item[@"kind"] = presentation[@"kind"];
            if (encrypted && [item[@"remoteURL"] length]) item[@"encrypted"] = @YES;
            media[i] = item;
        }
    if ([record[@"share"] count] && ![presentation[@"kind"] length]) presentation[@"kind"] = @"work";
    if (![presentation[@"kind"] length]) {
        for (NSDictionary *item in media)
            if ([@[@"image", @"audio", @"video"] containsObject:item[@"kind"]] && ![item[@"cover"] boolValue] && ![item[@"shared"] boolValue]) {
                presentation[@"kind"] = item[@"kind"];
                break;
            }
    }
    if ([@[@"image", @"audio", @"video", @"location"] containsObject:presentation[@"kind"]]) [result removeObjectForKey:@"share"];
    if ([presentation[@"kind"] isEqual:@"work"]) {
        NSMutableDictionary *share = [record[@"share"] isKindOfClass:NSDictionary.class] ? [record[@"share"] mutableCopy] : [NSMutableDictionary dictionary];
        for (NSString *field in @[@"id", @"title", @"author"])
            if (![DYYYContentString(share[field]) length] && [DYYYContentString(presentation[field]) length]) share[field] = presentation[field];
        if (share.count) result[@"share"] = share;
    }
    if ([presentation[@"kind"] isEqual:@"recall-notice"] || [record[@"systemRecallNotice"] boolValue] ||
        ([record[@"type"] longLongValue] == 60001 && [record[@"presentationClass"] isEqual:@"AWEIMRecallMessage"]) || DYYYHostIdentifiesRecallNotice(record[@"type"])) {
        presentation[@"kind"] = @"recall-notice";
        result[@"systemRecallNotice"] = @YES;
        result[@"available"] = @NO;
        if ([presentation[@"recallTargetID"] length]) result[@"recallTargetID"] = presentation[@"recallTargetID"];
    }
    result[@"card"] = presentation;
    result[@"media"] = media;
    result[@"presentationVersion"] = @8;
    return result;
}

NSString *DYYYRecallWorkIdentifier(NSDictionary *record) {
    record = DYYYRecallEnrichRecord(record);
    if ([record[@"systemRecallNotice"] boolValue]) return @"";
    NSDictionary *share = [record[@"share"] isKindOfClass:NSDictionary.class] ? record[@"share"] : @{};
    NSString *identifier = DYYYContentString(share[@"id"]);
    if (!identifier.length && [record[@"card"][@"kind"] isEqual:@"work"]) identifier = DYYYContentString(record[@"card"][@"id"]);
    if (!identifier.length || identifier.length > 40 || [identifier isEqual:@"0"]) return @"";
    for (NSUInteger i = 0; i < identifier.length; i++) {
        unichar c = [identifier characterAtIndex:i];
        if (c < '0' || c > '9') return @"";
    }
    return identifier;
}

NSString *DYYYRecallSummary(NSDictionary *record) {
    record = DYYYRecallEnrichRecord(record);
    NSString *comment = DYYYContentString(record[@"comment"][@"text"]);
    NSString *sharedTitle = DYYYContentString(record[@"share"][@"title"]);
    if (comment.length) return [NSString stringWithFormat:@"评论：%@%@", comment, sharedTitle.length ? [@"\n分享作品：" stringByAppendingString:sharedTitle] : @""];
    if (sharedTitle.length) return [@"分享作品 · " stringByAppendingString:sharedTitle];
    NSDictionary *card = record[@"card"];
    NSString *kind = card[@"kind"], *title = card[@"title"], *text = card[@"text"];
    if ([kind isEqual:@"recall-notice"]) return @"撤回提示 · 原始消息请查看对应记录";
    NSString *mediaLabel = @{@"image": @"图片消息", @"audio": @"语音消息", @"video": @"视频消息"}[kind ?: @""];
    if (mediaLabel) return [card[@"transcript"] length] ? [NSString stringWithFormat:@"%@\n转写：%@", mediaLabel, card[@"transcript"]] : mediaLabel;
    NSString *label = @{@"sticker": @"表情", @"work": @"分享作品", @"goods": @"商品", @"live": @"直播", @"location": @"位置"}[kind ?: @""];
    if (label) {
        NSString *detail = title.length ? title : text;
        return detail.length ? [NSString stringWithFormat:@"%@ · %@", label, detail] : label;
    }
    if (text.length) return text;
    if (title.length) return title;
    NSDictionary *content = [record[@"content"] isKindOfClass:NSDictionary.class] ? record[@"content"] : @{};
    NSString *plain = DYYYValueForKeys(content, @[@"text", @"content", @"title", @"display_content"]);
    if (plain.length && ![plain hasPrefix:@"{"]) return plain;
    NSDictionary *media = [record[@"media"] firstObject];
    NSString *name = @{@"image": @"图片消息", @"audio": @"语音消息", @"video": @"视频消息", @"file": @"文件消息"}[media[@"kind"] ?: @""];
    return name ?: ([record[@"available"] boolValue] ? @"未识别的消息" : @"未取得撤回前的内容");
}

BOOL DYYYRecallRecordShouldHide(NSDictionary *record) {
    record = DYYYRecallEnrichRecord(record);
    if ([record[@"systemRecallNotice"] boolValue]) return YES;
    if ([record[@"media"] count] || DYYYRecallWorkIdentifier(record).length) return NO;
    NSString *summary = DYYYRecallSummary(record);
    return [summary isEqual:@"未识别的消息"] || [summary isEqual:@"未取得撤回前的内容"];
}

NSArray *DYYYRecallPreviewCandidates(NSDictionary *record) {
    record = DYYYRecallEnrichRecord(record);
    NSMutableArray *candidates = [NSMutableArray array];
    for (NSDictionary *item in [record[@"media"] isKindOfClass:NSArray.class] ? record[@"media"] : @[]) {
        if (![item isKindOfClass:NSDictionary.class]) continue;
        if ([item[@"remoteURL"] length] || [item[@"cachedPath"] length] || [item[@"sourcePath"] length]) [candidates addObject:item];
    }
    [candidates sortUsingComparator:^NSComparisonResult(NSDictionary *a, NSDictionary *b) {
        BOOL aCover = [a[@"cover"] boolValue], bCover = [b[@"cover"] boolValue];
        if (aCover != bCover) return aCover ? NSOrderedDescending : NSOrderedAscending;
        NSInteger qa = [a[@"quality"] integerValue], qb = [b[@"quality"] integerValue];
        if (qa != qb) return qa > qb ? NSOrderedAscending : NSOrderedDescending;
        return NSOrderedSame;
    }];
    return candidates;
}

NSDictionary *DYYYRecallPrimaryMedia(NSDictionary *record) {
    return [DYYYRecallPreviewCandidates(record) firstObject];
}
