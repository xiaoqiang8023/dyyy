// DYYYRadarModel.m — 由 DY778RadarModel.m 移植，仅重命名（DY778→DYYY）。
#import "DYYYRadarModel.h"
#import "DYYYRadarPolicy.h"
#import <objc/runtime.h>
#import <math.h>
#import <stdlib.h>
#import <string.h>

NSString *const DYYYRadarVersion = @"1.0-3";
NSString *const DYYYRadarName = @"特别关注";
NSNotificationName const DYYYRadarStoreChanged = @"DYYYRadar.StoreChanged";
NSNotificationName const DYYYRadarThemeChanged = @"DYYYRadar.ThemeChanged";
NSUInteger const DYYYRadarSignatureLimit = 2048;

NSString *DYYYRadarSignatureText(id value) {
    if (![value isKindOfClass:NSString.class]) return @"暂未读取";
    return [value length] ? value : @"（空简介）";
}

id DYYYRadarRead(id object, NSString *key) {
    if (!object || object == NSNull.null) return nil;
    if ([object isKindOfClass:NSDictionary.class]) {
        id value = object[key];
        return value == NSNull.null ? nil : value;
    }
    if (![object respondsToSelector:NSSelectorFromString(key)]) return nil;
    @try { return [object valueForKey:key]; } @catch (__unused NSException *exception) { return nil; }
}
id DYYYRadarFirst(id object, NSArray<NSString *> *keys) {
    for (NSString *key in keys) { id value = DYYYRadarRead(object, key); if (value) return value; }
    return nil;
}
NSString *DYYYRadarString(id value) {
    NSString *text = [value isKindOfClass:NSString.class] ? value :
        [value isKindOfClass:NSNumber.class] ? [value stringValue] : @"";
    return text.length > 8192 ? [text substringToIndex:8192] : text;
}
NSNumber *DYYYRadarCount(id value) {
    if (![value isKindOfClass:NSString.class] && ![value isKindOfClass:NSNumber.class]) return nil;
    NSString *text = DYYYRadarString(value);
    if (!text.length || text.length > 16 || [text rangeOfCharacterFromSet:[[NSCharacterSet characterSetWithCharactersInString:@"0123456789"] invertedSet]].location != NSNotFound) return nil;
    long long number = text.longLongValue;
    return number >= 0 && number <= 9007199254740991LL ? @(number) : nil;
}
BOOL DYYYRadarIdentifier(id value) {
    if (![value isKindOfClass:NSString.class] || ![value length] || [value length] > 80) return NO;
    return [value rangeOfCharacterFromSet:[[NSCharacterSet characterSetWithCharactersInString:@"0123456789"] invertedSet]].location == NSNotFound;
}
BOOL DYYYRadarSet(id object, NSString *key, id value) {
    if (!object) return NO;
    @try { [object setValue:value forKey:key]; return YES; } @catch (__unused NSException *exception) { return NO; }
}
BOOL DYYYRadarHasMethod(id receiver, NSString *selector, const char *returns, const char *arguments) {
    NSMethodSignature *s = [receiver methodSignatureForSelector:NSSelectorFromString(selector)];
    if (!s || s.numberOfArguments != strlen(arguments) + 2 || !strchr(returns, s.methodReturnType[0])) return NO;
    for (NSUInteger i = 0; arguments[i]; i++) if ([s getArgumentTypeAtIndex:i + 2][0] != arguments[i]) return NO;
    return YES;
}
// 动态调用仅限已支持的 Objective-C ABI 类型。
id DYYYRadarCall(id receiver, NSString *selector, NSArray *arguments) {
    SEL sel = NSSelectorFromString(selector);
    if (!receiver || ![receiver respondsToSelector:sel]) return nil;
    NSMethodSignature *s = [receiver methodSignatureForSelector:sel];
    if (!s || s.numberOfArguments != arguments.count + 2) return nil;
    @try {
        NSInvocation *inv = [NSInvocation invocationWithMethodSignature:s];
        inv.target = receiver; inv.selector = sel;
        for (NSUInteger i = 0; i < arguments.count; i++) {
            id arg = arguments[i] == NSNull.null ? nil : arguments[i];
            const char *type = [s getArgumentTypeAtIndex:i + 2];
            switch (type[0]) {
                case '@': case '#': { id v = arg; [inv setArgument:&v atIndex:i + 2]; break; }
                case 'B': case 'c': { BOOL v = [arg boolValue]; [inv setArgument:&v atIndex:i + 2]; break; }
                case 'i': { int v = [arg intValue]; [inv setArgument:&v atIndex:i + 2]; break; }
                case 'I': { unsigned int v = [arg unsignedIntValue]; [inv setArgument:&v atIndex:i + 2]; break; }
                case 'q': { long long v = [arg longLongValue]; [inv setArgument:&v atIndex:i + 2]; break; }
                case 'Q': { unsigned long long v = [arg unsignedLongLongValue]; [inv setArgument:&v atIndex:i + 2]; break; }
                case 'd': { double v = [arg doubleValue]; [inv setArgument:&v atIndex:i + 2]; break; }
                default: return nil;
            }
        }
        [inv retainArguments];
        [inv invoke];
        switch (s.methodReturnType[0]) {
            case '@': case '#': { __unsafe_unretained id v = nil; [inv getReturnValue:&v]; return v; }
            case 'B': case 'c': { BOOL v = NO; [inv getReturnValue:&v]; return @(v); }
            case 'i': { int v = 0; [inv getReturnValue:&v]; return @(v); }
            case 'I': { unsigned int v = 0; [inv getReturnValue:&v]; return @(v); }
            case 'q': { long long v = 0; [inv getReturnValue:&v]; return @(v); }
            case 'Q': { unsigned long long v = 0; [inv getReturnValue:&v]; return @(v); }
            default: return nil;
        }
    } @catch (__unused NSException *exception) { return nil; }
}
static NSString *DYYYRadarURL(id model) {
    if ([model isKindOfClass:NSURL.class]) model = [model absoluteString];
    if ([model isKindOfClass:NSString.class]) {
        NSURL *url = [NSURL URLWithString:model];
        return [url.scheme isEqual:@"https"] && url.host.length && [model length] <= 2048 ? model : @"";
    }
    id list = [model isKindOfClass:NSArray.class] ? model : DYYYRadarFirst(model, @[@"url_list", @"URLList"]);
    if (![list isKindOfClass:NSArray.class]) return @"";
    for (id raw in list) { NSString *url = DYYYRadarURL(raw); if (url.length) return url; }
    return @"";
}
NSString *DYYYRadarDisplayName(NSDictionary *person) {
    for (NSString *key in @[@"note", @"remark", @"name", @"handle", @"uid"]) {
        NSString *text = [DYYYRadarString(person[key]) stringByTrimmingCharactersInSet:NSCharacterSet.whitespaceAndNewlineCharacterSet];
        if (text.length) return text;
    }
    return @"关注对象";
}
NSString *DYYYRadarPersonSearchText(NSDictionary *person) {
    NSMutableArray *parts = [NSMutableArray array];
    for (NSString *key in @[@"note", @"remark", @"name", @"handle"]) if (DYYYRadarString(person[key]).length) [parts addObject:person[key]];
    return [parts componentsJoinedByString:@" "];
}
NSDictionary *DYYYRadarProfile(id value) {
    id nested = DYYYRadarFirst(value, @[@"user", @"user_info", @"userInfo"]);
    if (nested) value = nested;
    NSString *uid = DYYYRadarString(DYYYRadarFirst(value, @[@"uid", @"userID"]));
    if (!DYYYRadarIdentifier(uid) || [uid isEqualToString:@"0"]) return nil;
    NSString *handle = @"";
    for (NSString *key in @[@"unique_id", @"uniqueIDForShow", @"uniqueID", @"userUniqueId", @"customID", @"short_id", @"shortID"]) {
        NSString *candidate = DYYYRadarString(DYYYRadarRead(value, key));
        if (candidate.length && ![candidate isEqualToString:@"0"]) { handle = candidate; break; }
    }
    if (handle.length > 64) handle = [handle substringToIndex:64];
    NSString *name = DYYYRadarString(DYYYRadarFirst(value, @[@"nickname", @"name"]));
    if (name.length > 120) name = [name substringToIndex:120];
    // 2.2-9-73：secUID 再加 "secUID" 键——星牌 person 的 secUID 就存在 secUID
    // 键里（DYYYFansModel.m:99），之前只认 sec_uid/secUserID，confirmAnchor
    // 过一遍 DYYYRadarProfile 就把 secUID 丢了，-72 三位主播全报
    // “没有 secUID 可走兜底”就是这么来的。
    NSMutableDictionary *result = [@{@"uid": uid, @"secUID": DYYYRadarString(DYYYRadarFirst(value, @[@"secUID", @"sec_uid", @"secUserID"])),
        @"handle": handle, @"name": name.length ? name : (handle.length ? handle : uid),
        @"avatar": DYYYRadarURL(DYYYRadarFirst(value, @[@"avatar_thumb", @"avatarThumb", @"avatarSmallStrUrl", @"avatarURLSmall"]))} mutableCopy];
    id remark = DYYYRadarFirst(value, @[@"alias", @"remark_name", @"remark"]);
    if ([remark isKindOfClass:NSString.class]) result[@"remark"] = [remark length] > 120 ? [remark substringToIndex:120] : remark;
    // 只有明确的空串才表示已清空；有效文本按原样比较。
    id signature = DYYYRadarRead(value, @"signature");
    if ([signature isKindOfClass:NSString.class] && [signature length] <= DYYYRadarSignatureLimit)
        result[@"signature"] = [signature copy];
    for (NSString *key in @[@"avatar_medium", @"avatarMedium", @"avatar_thumb", @"avatarThumb", @"avatarURLSmall", @"avatarSmallStrUrl", @"avatarStrUrls", @"avatarURLList", @"avatarURL", @"avatarLarger", @"avatar"])
        if (DYYYRadarURL(DYYYRadarRead(value, key)).length) { result[@"avatar"] = DYYYRadarURL(DYYYRadarRead(value, key)); break; }
    NSDictionary *mapping = @{@"received": @[@"total_favorited", @"favoritedCount"],
        @"following": @[@"following_count", @"followingCount"], @"followers": @[@"follower_count", @"followerCount"],
        @"likes": @[@"favoriting_count", @"favoritingCount"]};
    NSMutableDictionary *counts = [NSMutableDictionary dictionary];
    for (NSString *key in mapping) {
        for (NSString *field in mapping[key]) { NSNumber *n = DYYYRadarCount(DYYYRadarRead(value, field)); if (n) { counts[key] = n; break; } }
    }
    NSMutableArray *hidden = [NSMutableArray array];
    if ([DYYYRadarCount(DYYYRadarFirst(value, @[@"hide_total_favorited", @"hideTotalFavorited"])) boolValue]) { [counts removeObjectForKey:@"received"]; [hidden addObject:@"received"]; }
    result[@"counts"] = counts;
    id visible = DYYYRadarFirst(value, @[@"show_favorite_list", @"showFavoriteList"]);
    if ([visible isKindOfClass:NSNumber.class]) result[@"likesVisible"] = @([visible boolValue]);
    id tab = DYYYRadarFirst(value, @[@"tab_settings", @"tabSetting"]);
    if ([DYYYRadarCount(DYYYRadarFirst(tab, @[@"hide_like_tab", @"hideLikeTab"])) boolValue]) result[@"likesVisible"] = @NO;
    if (result[@"likesVisible"] && ![result[@"likesVisible"] boolValue] && [counts[@"likes"] longLongValue] == 0) { [counts removeObjectForKey:@"likes"]; [hidden addObject:@"likes"]; }
    result[@"hiddenMetrics"] = hidden;
    return result;
}
NSDictionary *DYYYRadarVideo(id value) {
    NSString *vid = DYYYRadarString(DYYYRadarFirst(value, @[@"aweme_id", @"itemID"]));
    if (!DYYYRadarIdentifier(vid)) return nil;
    NSDictionary *author = DYYYRadarProfile(DYYYRadarRead(value, @"author")) ?: @{};
    id video = DYYYRadarRead(value, @"video");
    NSString *caption = DYYYRadarString(DYYYRadarFirst(value, @[@"desc", @"descriptionString"]));
    if (caption.length > 2500) caption = [[caption substringToIndex:2500] stringByAppendingString:@"…"];
    return @{@"id": vid, @"text": caption,
        @"author": DYYYRadarString(author[@"name"]), @"authorAvatar": DYYYRadarString(author[@"avatar"]), @"authorHandle": DYYYRadarString(author[@"handle"]),
        @"authorUID": DYYYRadarString(author[@"uid"]), @"authorSecUID": DYYYRadarString(author[@"secUID"]),
        @"publishedAt": DYYYRadarCount(DYYYRadarFirst(value, @[@"create_time", @"createTime"])) ?: @0,
        @"url": [@"https://www.douyin.com/video/" stringByAppendingString:vid],
        @"cover": DYYYRadarURL(DYYYRadarFirst(video, @[@"cover", @"origin_cover"])),
        @"type": DYYYRadarCount(DYYYRadarFirst(value, @[@"aweme_type", @"awemeType"])) ?: @0};
}
NSString *DYYYRadarMetricName(NSString *key) {
    return (@{@"received": @"获赞", @"following": @"关注", @"followers": @"粉丝", @"likes": @"喜欢"})[key] ?: key;
}
NSArray<NSDictionary *> *DYYYRadarChanges(NSDictionary *previous, NSDictionary *current) {
    NSMutableArray *changes = [NSMutableArray array];
    for (NSString *key in @[@"received", @"following", @"followers", @"likes"]) {
        NSNumber *before = DYYYRadarCount(previous[key]), *after = DYYYRadarCount(current[key]);
        if (before && after && ![before isEqualToNumber:after])
            [changes addObject:@{@"key": key, @"before": before, @"after": after, @"delta": @(after.longLongValue - before.longLongValue)}];
    }
    return changes;
}
NSDictionary *DYYYRadarCompareLikes(NSDictionary *previous, NSArray<NSDictionary *> *videos, BOOL complete) {
    NSArray *old = [previous[@"head"] isKindOfClass:NSArray.class] ? previous[@"head"] : @[];
    NSArray *seen = [previous[@"seen"] isKindOfClass:NSArray.class] ? previous[@"seen"] : @[];
    NSArray *ids = [videos valueForKey:@"id"];
    NSUInteger count = ids.count;
    const char **cur = calloc(MAX(count, 1), sizeof(char *));
    const char **prior = calloc(MAX(old.count, 1), sizeof(char *));
    const char **known = calloc(MAX(seen.count, 1), sizeof(char *));
    bool *selected = calloc(MAX(count, 1), sizeof(bool));
    if (!cur || !prior || !known || !selected) { free(cur); free(prior); free(known); free(selected); return @{}; }
    for (NSUInteger i = 0; i < count; i++) cur[i] = DYYYRadarString(ids[i]).UTF8String;
    for (NSUInteger i = 0; i < old.count; i++) prior[i] = DYYYRadarString(old[i]).UTF8String;
    for (NSUInteger i = 0; i < seen.count; i++) known[i] = DYYYRadarString(seen[i]).UTF8String;
    bool gap = false;
    DYYYRadarNewItems(cur, count, prior, old.count, known, seen.count, [previous[@"valid"] boolValue], [previous[@"complete"] boolValue], selected, &gap);
    NSMutableArray *fresh = [NSMutableArray array];
    for (NSUInteger i = 0; i < count; i++) if (selected[i]) [fresh addObject:videos[i]];
    free(cur); free(prior); free(known); free(selected);
    NSMutableOrderedSet *recent = [NSMutableOrderedSet orderedSetWithArray:ids];
    [recent addObjectsFromArray:seen];
    NSArray *recentIDs = recent.array;
    if (recentIDs.count > 300) recentIDs = [recentIDs subarrayWithRange:NSMakeRange(0, 300)];
    return @{@"new": fresh, @"gap": @(gap), @"snapshot": @{@"head": ids, @"seen": recentIDs, @"complete": @(complete), @"valid": @YES}};
}
NSString *DYYYRadarDateText(NSTimeInterval timestamp) {
    if (timestamp <= 0) return @"尚未检测";
    NSDateFormatter *f = [NSDateFormatter new]; f.locale = [NSLocale localeWithLocaleIdentifier:@"zh_CN"];
    f.dateFormat = @"yyyy-MM-dd HH:mm:ss"; return [f stringFromDate:[NSDate dateWithTimeIntervalSince1970:timestamp]];
}
NSError *DYYYRadarError(NSInteger code, NSString *message) {
    return [NSError errorWithDomain:@"DYYYRadar" code:code userInfo:@{NSLocalizedDescriptionKey: message}];
}
