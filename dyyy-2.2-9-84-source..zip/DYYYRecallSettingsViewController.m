// DYYYRecallSettingsViewController.m
// 消息留存设置页：分组列表，文案跟随 DY778 设置页“recall”页（截图同款）。
// 全部开关默认关闭；总开关开启后全部会话默认生效，单个会话可在聊天信息页（···）单独关闭，立即生效。
#import "DYYYRecallSettingsViewController.h"
#import "DYYYPortsUI.h"
#import "DYYYRecall.h"
#import "DYYYRecallNotifications.h"

typedef NS_ENUM(NSInteger, DYYYRecallSettingsRow) {
    DYYYRecallRowMaster = 0,
    DYYYRecallRowBadge,
    DYYYRecallRowBadgeText,
    DYYYRecallRowPosition,
    DYYYRecallRowArchiveEntry,
};

@interface DYYYRecallSettingsViewController ()
@property(nonatomic) NSUInteger recallCount;
@end

@implementation DYYYRecallSettingsViewController

- (instancetype)init {
    return [super initWithStyle:UITableViewStyleInsetGrouped];
}

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"消息留存";
    DYYYPortsConfigureTable(self.tableView);
    [self.tableView registerClass:UITableViewCell.class forCellReuseIdentifier:@"DYYYRecallSettingsCell"];
    [NSNotificationCenter.defaultCenter addObserver:self selector:@selector(refreshCount) name:DYYYRecallChangedNotification object:nil];
    [self refreshCount];
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    [self refreshCount];
    [self.tableView reloadData];
}

- (void)dealloc {
    [NSNotificationCenter.defaultCenter removeObserver:self];
}

- (void)refreshCount {
    self.recallCount = DYYYRecallCount();
    if (self.isViewLoaded) {
        NSIndexPath *path = [NSIndexPath indexPathForRow:0 inSection:3];
        UITableViewCell *cell = [self.tableView cellForRowAtIndexPath:path];
        if (cell) {
            // 行用 UIListContentConfiguration，副标题写在配置里，不走 detailTextLabel。
            if ([cell.contentConfiguration isKindOfClass:UIListContentConfiguration.class]) {
                UIListContentConfiguration *config = (UIListContentConfiguration *)cell.contentConfiguration;
                config.secondaryText = [self archiveDetailText];
                cell.contentConfiguration = config;
            } else {
                cell.detailTextLabel.text = [self archiveDetailText];
            }
        }
    }
}

#pragma mark - 表格结构

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 4;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    switch (section) {
        case 0: return 5;
        case 1: return 3;
        case 2: return 3;
        case 3: return 4;
        default: return 0;
    }
}

- (NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section {
    switch (section) {
        case 0: return @"防撤回";
        case 1: return @"提醒";
        case 2: return @"气泡";
        case 3: return @"留存";
        default: return nil;
    }
}

- (NSString *)tableView:(UITableView *)tableView titleForFooterInSection:(NSInteger)section {
    switch (section) {
        case 0: return @"开启后，本机已接收到的对方消息会被留存，对方撤回后仍可查看原文。首次开启后，所有聊天默认生效。";
        case 1: return @"对方撤回消息时提醒你；摘要只在你允许时显示。";
        case 2: return @"撤回的消息默认保留原有气泡样式。";
        case 3: return @"记录只保存在本机，不会上传；0 表示不限制。";
        default: return nil;
    }
}

#pragma mark - Cell

- (UITableViewCell *)switchCellForRow:(NSInteger)row title:(NSString *)title subtitle:(NSString *)subtitle key:(NSString *)key symbol:(NSString *)symbol {
    UITableViewCell *cell = DYYYPortsIconCell(title, subtitle, symbol, NO);
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    UISwitch *toggle = [UISwitch new];
    toggle.on = DYYYRecallBool(key);
    toggle.tag = row;
    [toggle addTarget:self action:@selector(switchChanged:) forControlEvents:UIControlEventValueChanged];
    cell.accessoryView = toggle;
    return cell;
}

- (UITableViewCell *)actionCellWithTitle:(NSString *)title subtitle:(NSString *)subtitle detail:(NSString *)detail destructive:(BOOL)destructive symbol:(NSString *)symbol {
    UITableViewCell *cell = DYYYPortsValueCell(title, detail, symbol, YES);
    if (destructive) {
        // 红色 destructive 行：只改标题颜色，图标与右侧数值不动。
        if ([cell.contentConfiguration isKindOfClass:UIListContentConfiguration.class]) {
            UIListContentConfiguration *config = (UIListContentConfiguration *)cell.contentConfiguration;
            config.textProperties.color = UIColor.systemRedColor;
            cell.contentConfiguration = config;
        } else {
            cell.textLabel.textColor = UIColor.systemRedColor;
        }
    }
    return cell;
}

- (NSString *)archiveDetailText {
    return self.recallCount > 0 ? [NSString stringWithFormat:@"%lu 条", (unsigned long)self.recallCount] : @"暂无记录";
}

- (NSString *)positionDetailText {
    NSString *position = DYYYRecallString(DYYYRecallPositionKey) ?: @"right";
    if ([position isEqual:@"below"]) return @"消息下方";
    if ([position isEqual:@"above"]) return @"消息上方";
    return @"紧贴消息右侧";
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    if (indexPath.section == 0) {
        switch (indexPath.row) {
            case 0: return [self switchCellForRow:DYYYRecallRowMaster title:@"消息防撤回" subtitle:@"保留本机已接收到的对方消息" key:DYYYRecallEnabledKey symbol:@"arrow.uturn.backward.circle.fill"];
            case 1: return [self switchCellForRow:DYYYRecallRowBadge title:@"撤回标记" subtitle:@"显示已撤回状态，点按查看记录" key:DYYYRecallShowBadgeKey symbol:@"text.badge.checkmark"];
            case 2: return [self actionCellWithTitle:@"标记文字" subtitle:nil detail:DYYYRecallMarkerText() destructive:NO symbol:@"character.cursor.ibeam"];
            case 3: return [self actionCellWithTitle:@"标记位置" subtitle:nil detail:[self positionDetailText] destructive:NO symbol:@"slider.horizontal.3"];
            case 4: return [self switchCellForRow:DYYYRecallRowArchiveEntry title:@"聊天信息页记录入口" subtitle:@"在会话设置中查看对应的撤回记录" key:DYYYRecallArchiveEntryKey symbol:@"tray.full"];
            default: break;
        }
    }
    if (indexPath.section == 1) {
        switch (indexPath.row) {
            case 0: {
                UITableViewCell *cell = [self switchCellForRow:10 title:@"对方撤回时提醒" subtitle:@"前台提醒卡片 · 后台系统通知" key:DYYYRecallNotificationsKey symbol:@"bell.badge"];
                return cell;
            }
            case 1: return [self switchCellForRow:11 title:@"提醒显示消息摘要" subtitle:@"允许在通知中显示已保存的文字或作品标题" key:DYYYRecallNotificationPreviewKey symbol:@"text.bubble"];
            case 2: return [self actionCellWithTitle:@"通知状态" subtitle:nil detail:@"查看系统通知权限" destructive:NO symbol:@"bell"];
            default: break;
        }
    }
    if (indexPath.section == 2) {
        switch (indexPath.row) {
            case 0: return [self switchCellForRow:20 title:@"撤回后使用普通气泡" subtitle:@"默认保留皮肤；开启后恢复纯色气泡" key:DYYYRecallPlainBubbleOnSkinKey symbol:@"circle.lefthalf.filled"];
            case 1: return [self switchCellForRow:21 title:@"自定义撤回气泡底色" subtitle:@"让保留的消息更容易辨认" key:DYYYRecallTintBubbleKey symbol:@"paintbrush.pointed"];
            case 2: {
                NSString *color = DYYYRecallString(DYYYRecallBubbleColorKey) ?: @"#4A3038";
                return [self actionCellWithTitle:@"撤回气泡颜色" subtitle:nil detail:color destructive:NO symbol:@"eyedropper"];
            }
            default: break;
        }
    }
    if (indexPath.section == 3) {
        switch (indexPath.row) {
            case 0: return [self actionCellWithTitle:@"撤回记录" subtitle:nil detail:[self archiveDetailText] destructive:NO symbol:@"person.2"];
            case 1: {
                NSInteger days = DYYYRecallInteger(DYYYRecallRetentionDaysKey);
                return [self actionCellWithTitle:@"记录保存天数" subtitle:nil detail:days > 0 ? [NSString stringWithFormat:@"%ld 天", (long)days] : @"永久保存" destructive:NO symbol:@"calendar"];
            }
            case 2: {
                NSInteger max = DYYYRecallInteger(DYYYRecallMaxRecordsKey);
                return [self actionCellWithTitle:@"记录数量上限" subtitle:nil detail:max > 0 ? [NSString stringWithFormat:@"%ld 条", (long)max] : @"不限制" destructive:NO symbol:@"list.number"];
            }
            case 3: return [self actionCellWithTitle:@"清理全部记录" subtitle:nil detail:nil destructive:YES symbol:@"trash"];
            default: break;
        }
    }
    return [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"DYYYRecallSettingsCell"];
}

#pragma mark - 开关

- (void)switchChanged:(UISwitch *)toggle {
    BOOL on = toggle.on;
    NSString *key = nil;
    switch (toggle.tag) {
        case DYYYRecallRowMaster: key = DYYYRecallEnabledKey; break;
        case DYYYRecallRowBadge: key = DYYYRecallShowBadgeKey; break;
        case DYYYRecallRowArchiveEntry: key = DYYYRecallArchiveEntryKey; break;
        case 10: key = DYYYRecallNotificationsKey; break;
        case 11: key = DYYYRecallNotificationPreviewKey; break;
        case 20: key = DYYYRecallPlainBubbleOnSkinKey; break;
        case 21: key = DYYYRecallTintBubbleKey; break;
        default: break;
    }
    if (!key) return;
    DYYYRecallSet(key, @(on));
    if ([key isEqual:DYYYRecallEnabledKey] && on && !DYYYRecallBool(DYYYRecallEnableNoticeShownKey)) {
        DYYYRecallSet(DYYYRecallEnableNoticeShownKey, @YES);
        UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"防撤回已开启" message:@"首次开启后，所有聊天默认生效。想单独关闭某个聊天时，打开该聊天的右上角 ···，关闭“此聊天防撤回”即可，立即生效。" preferredStyle:UIAlertControllerStyleAlert];
        [alert addAction:[UIAlertAction actionWithTitle:@"知道了" style:UIAlertActionStyleDefault handler:nil]];
        [self presentViewController:alert animated:YES completion:nil];
    }
    if ([key isEqual:DYYYRecallNotificationsKey] && on) DYYYRequestRecallNotificationPermission(self);
    if ([key isEqual:DYYYRecallRetentionDaysKey] || [key isEqual:DYYYRecallMaxRecordsKey]) DYYYRecallMaintenance();
}

#pragma mark - 点按行

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    if (indexPath.section == 0 && indexPath.row == 2) {
        [self editMarkerText];
        return;
    }
    if (indexPath.section == 0 && indexPath.row == 3) {
        [self pickPosition];
        return;
    }
    if (indexPath.section == 1 && indexPath.row == 2) {
        DYYYShowRecallNotificationStatus(self);
        return;
    }
    if (indexPath.section == 2 && indexPath.row == 2) {
        [self pickBubbleColor];
        return;
    }
    if (indexPath.section == 3 && indexPath.row == 0) {
        DYYYPresentRecallArchive(self, nil);
        return;
    }
    if (indexPath.section == 3 && indexPath.row == 1) {
        [self editNumberWithTitle:@"记录保存天数" message:@"0 表示永久保存，直到手动清理" key:DYYYRecallRetentionDaysKey current:DYYYRecallInteger(DYYYRecallRetentionDaysKey)];
        return;
    }
    if (indexPath.section == 3 && indexPath.row == 2) {
        [self editNumberWithTitle:@"记录数量上限" message:@"0 表示不限制条数" key:DYYYRecallMaxRecordsKey current:DYYYRecallInteger(DYYYRecallMaxRecordsKey)];
        return;
    }
    if (indexPath.section == 3 && indexPath.row == 3) {
        [self confirmClearAll];
        return;
    }
}

- (void)editMarkerText {
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"标记文字" message:@"默认为已撤回，可自定义文字或表情" preferredStyle:UIAlertControllerStyleAlert];
    [alert addTextFieldWithConfigurationHandler:^(UITextField *field) {
        field.text = DYYYRecallMarkerText();
        field.placeholder = @"已撤回";
        field.clearButtonMode = UITextFieldViewModeWhileEditing;
    }];
    __weak typeof(self) weakSelf = self;
    [alert addAction:[UIAlertAction actionWithTitle:@"保存" style:UIAlertActionStyleDefault handler:^(__unused UIAlertAction *action) {
        NSString *text = [alert.textFields.firstObject.text stringByTrimmingCharactersInSet:NSCharacterSet.whitespaceAndNewlineCharacterSet];
        if (!text.length) text = @"已撤回";
        if (text.length > 12) text = [text substringToIndex:12];
        DYYYRecallSet(DYYYRecallBadgeTextKey, text);
        [weakSelf.tableView reloadData];
    }]];
    [alert addAction:[UIAlertAction actionWithTitle:@"取消" style:UIAlertActionStyleCancel handler:nil]];
    [self presentViewController:alert animated:YES completion:nil];
}

- (void)pickPosition {
    UIAlertController *sheet = [UIAlertController alertControllerWithTitle:@"标记位置" message:nil preferredStyle:UIAlertControllerStyleActionSheet];
    __weak typeof(self) weakSelf = self;
    NSArray *options = @[@[@"紧贴消息右侧", @"right"], @[@"消息下方", @"below"], @[@"消息上方", @"above"]];
    for (NSArray *option in options) {
        [sheet addAction:[UIAlertAction actionWithTitle:option[0] style:UIAlertActionStyleDefault handler:^(__unused UIAlertAction *action) {
            DYYYRecallSet(DYYYRecallPositionKey, option[1]);
            [weakSelf.tableView reloadData];
        }]];
    }
    [sheet addAction:[UIAlertAction actionWithTitle:@"取消" style:UIAlertActionStyleCancel handler:nil]];
    sheet.popoverPresentationController.sourceView = self.view;
    sheet.popoverPresentationController.sourceRect = CGRectMake(self.view.bounds.size.width / 2, self.view.bounds.size.height - 1, 1, 1);
    [self presentViewController:sheet animated:YES completion:nil];
}

- (void)pickBubbleColor {
    UIAlertController *sheet = [UIAlertController alertControllerWithTitle:@"撤回气泡颜色" message:@"选择适合当前聊天背景的颜色" preferredStyle:UIAlertControllerStyleActionSheet];
    __weak typeof(self) weakSelf = self;
    NSArray *options = @[@[@"默认（暗红 #4A3038）", @"#4A3038"], @[@"墨绿 #3A6558", @"#3A6558"], @[@"深灰 #3A3A3C", @"#3A3A3C"], @[@"深蓝 #2C4A6B", @"#2C4A6B"]];
    for (NSArray *option in options) {
        [sheet addAction:[UIAlertAction actionWithTitle:option[0] style:UIAlertActionStyleDefault handler:^(__unused UIAlertAction *action) {
            DYYYRecallSet(DYYYRecallBubbleColorKey, option[1]);
            [weakSelf.tableView reloadData];
        }]];
    }
    [sheet addAction:[UIAlertAction actionWithTitle:@"取消" style:UIAlertActionStyleCancel handler:nil]];
    sheet.popoverPresentationController.sourceView = self.view;
    sheet.popoverPresentationController.sourceRect = CGRectMake(self.view.bounds.size.width / 2, self.view.bounds.size.height - 1, 1, 1);
    [self presentViewController:sheet animated:YES completion:nil];
}

- (void)editNumberWithTitle:(NSString *)title message:(NSString *)message key:(NSString *)key current:(NSInteger)current {
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:title message:message preferredStyle:UIAlertControllerStyleAlert];
    [alert addTextFieldWithConfigurationHandler:^(UITextField *field) {
        field.keyboardType = UIKeyboardTypeNumberPad;
        field.text = current > 0 ? [NSString stringWithFormat:@"%ld", (long)current] : @"0";
    }];
    __weak typeof(self) weakSelf = self;
    [alert addAction:[UIAlertAction actionWithTitle:@"保存" style:UIAlertActionStyleDefault handler:^(__unused UIAlertAction *action) {
        NSInteger value = [alert.textFields.firstObject.text integerValue];
        if (value < 0) value = 0;
        if (value > 36500) value = 36500;
        DYYYRecallSet(key, @(value));
        DYYYRecallMaintenance();
        [weakSelf.tableView reloadData];
    }]];
    [alert addAction:[UIAlertAction actionWithTitle:@"取消" style:UIAlertActionStyleCancel handler:nil]];
    [self presentViewController:alert animated:YES completion:nil];
}

- (void)confirmClearAll {
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"清理全部记录？" message:@"将删除当前账号的全部本地撤回记录，此操作不可恢复。" preferredStyle:UIAlertControllerStyleAlert];
    __weak typeof(self) weakSelf = self;
    [alert addAction:[UIAlertAction actionWithTitle:@"删除全部" style:UIAlertActionStyleDestructive handler:^(__unused UIAlertAction *action) {
        DYYYClearRecallArchive();
        [weakSelf refreshCount];
        [weakSelf.tableView reloadData];
    }]];
    [alert addAction:[UIAlertAction actionWithTitle:@"取消" style:UIAlertActionStyleCancel handler:nil]];
    [self presentViewController:alert animated:YES completion:nil];
}

@end
