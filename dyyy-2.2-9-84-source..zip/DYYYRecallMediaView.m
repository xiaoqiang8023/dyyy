// DYYYRecallMediaView.m
// 由 DY778RecallMediaView.m 移植并简化：只保留图片封面 + 媒体行 + 点按打开。
// 简化点（见报告）：不做上游的媒体落盘缓存与转码，图片/视频/语音均用远程 URL 在线打开；
// 作品卡片点按走 AWERouter 原生详情（仅校验过的纯数字作品 ID，绝非任意 URL）。
#import "DYYYRecallMediaView.h"
#import "DYYYRecallContent.h"
#import <AVKit/AVKit.h>
#import <objc/runtime.h>

static UIViewController *DYYYMediaTopController(void) {
    UIWindow *window = nil;
    for (UIScene *scene in UIApplication.sharedApplication.connectedScenes) {
        if (![scene isKindOfClass:UIWindowScene.class]) continue;
        for (UIWindow *candidate in ((UIWindowScene *)scene).windows) {
            if (candidate.isKeyWindow) {
                window = candidate;
                break;
            }
        }
        if (window) break;
    }
    if (!window) window = UIApplication.sharedApplication.keyWindow;
    UIViewController *controller = window.rootViewController;
    while (controller.presentedViewController) controller = controller.presentedViewController;
    return controller;
}

static void DYYYMediaLoadImage(UIImageView *imageView, NSString *urlString, NSURLSessionDataTask **taskOut) {
    if (taskOut && *taskOut) {
        [*taskOut cancel];
        *taskOut = nil;
    }
    if (![urlString isKindOfClass:NSString.class] || !urlString.length) return;
    NSURL *url = [NSURL URLWithString:urlString];
    if (!url || (![url.scheme isEqual:@"http"] && ![url.scheme isEqual:@"https"])) return;
    __weak UIImageView *weakView = imageView;
    NSURLSessionDataTask *task = [NSURLSession.sharedSession dataTaskWithURL:url
                                                           completionHandler:^(NSData *data, NSURLResponse *response, NSError *error) {
                                                               if (error || !data.length) return;
                                                               UIImage *image = [UIImage imageWithData:data];
                                                               if (!image) return;
                                                               dispatch_async(dispatch_get_main_queue(), ^{
                                                                   if (weakView) weakView.image = image;
                                                               });
                                                           }];
    if (taskOut) *taskOut = task;
    [task resume];
}

#pragma mark - DYYYRecallCoverView

@interface DYYYRecallCoverView ()
@property(nonatomic, strong) NSURLSessionDataTask *task;
@end

@implementation DYYYRecallCoverView

- (instancetype)initWithFrame:(CGRect)frame {
    if ((self = [super initWithFrame:frame])) {
        self.contentMode = UIViewContentModeScaleAspectFill;
        self.clipsToBounds = YES;
        self.backgroundColor = UIColor.secondarySystemBackgroundColor;
    }
    return self;
}

- (void)configureRecord:(NSDictionary *)record {
    [self cancel];
    self.image = nil;
    NSDictionary *media = DYYYRecallPrimaryMedia(record);
    NSString *url = media[@"remoteURL"];
    if (!url.length && [record[@"card"] isKindOfClass:NSDictionary.class]) {
        // 作品卡片没有直出媒体时，用分享封面兜底。
        url = record[@"card"][@"coverURL"];
        if (![url isKindOfClass:NSString.class]) url = nil;
    }
    if (url.length) {
        // ARC 不允许把 ivar 地址直接传给 __autoreleasing 出参，先用局部变量接住再存起来。
        NSURLSessionDataTask *task = nil;
        DYYYMediaLoadImage(self, url, &task);
        _task = task;
    }
}

- (void)cancel {
    [self.task cancel];
    self.task = nil;
}

- (void)dealloc {
    [self.task cancel];
}

@end

@interface DYYYRecallImageViewer : UIViewController
@property(nonatomic, strong) UIImage *image;
@end

@implementation DYYYRecallImageViewer

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = UIColor.blackColor;
    UIImageView *imageView = [[UIImageView alloc] initWithFrame:self.view.bounds];
    imageView.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
    imageView.contentMode = UIViewContentModeScaleAspectFit;
    imageView.image = self.image;
    [self.view addSubview:imageView];
    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(dismissSelf)];
    [self.view addGestureRecognizer:tap];
}

- (void)dismissSelf {
    [self dismissViewControllerAnimated:YES completion:nil];
}

@end

#pragma mark - DYYYRecallMediaView

@interface DYYYRecallMediaView ()
@property(nonatomic, strong) DYYYRecallCoverView *cover;
@property(nonatomic, strong) UILabel *titleLabel;
@property(nonatomic, strong) UILabel *kindLabel;
@property(nonatomic, strong) UIButton *playButton;
@property(nonatomic, copy) NSDictionary *record;
@property(nonatomic, copy) NSDictionary *primaryMedia;
@end

@implementation DYYYRecallMediaView

- (instancetype)initWithFrame:(CGRect)frame {
    if ((self = [super initWithFrame:frame])) {
        self.backgroundColor = UIColor.secondarySystemBackgroundColor;
        self.layer.cornerRadius = 12;
        self.clipsToBounds = YES;
        _cover = [DYYYRecallCoverView new];
        _cover.translatesAutoresizingMaskIntoConstraints = NO;
        [self addSubview:_cover];
        _kindLabel = [UILabel new];
        _kindLabel.font = [UIFont systemFontOfSize:12 weight:UIFontWeightSemibold];
        _kindLabel.textColor = UIColor.whiteColor;
        _kindLabel.translatesAutoresizingMaskIntoConstraints = NO;
        [self addSubview:_kindLabel];
        _titleLabel = [UILabel new];
        _titleLabel.font = [UIFont systemFontOfSize:13];
        _titleLabel.textColor = UIColor.labelColor;
        _titleLabel.numberOfLines = 2;
        _titleLabel.translatesAutoresizingMaskIntoConstraints = NO;
        [self addSubview:_titleLabel];
        _playButton = [UIButton buttonWithType:UIButtonTypeSystem];
        [_playButton setImage:[UIImage systemImageNamed:@"play.circle.fill"] forState:UIControlStateNormal];
        _playButton.tintColor = UIColor.whiteColor;
        _playButton.translatesAutoresizingMaskIntoConstraints = NO;
        [_playButton addTarget:self action:@selector(didTapMedia) forControlEvents:UIControlEventTouchUpInside];
        [self addSubview:_playButton];
        UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(didTapMedia)];
        [self addGestureRecognizer:tap];
        [NSLayoutConstraint activateConstraints:@[
            [_cover.topAnchor constraintEqualToAnchor:self.topAnchor],
            [_cover.leadingAnchor constraintEqualToAnchor:self.leadingAnchor],
            [_cover.trailingAnchor constraintEqualToAnchor:self.trailingAnchor],
            [_cover.heightAnchor constraintEqualToConstant:180],
            [_playButton.centerXAnchor constraintEqualToAnchor:_cover.centerXAnchor],
            [_playButton.centerYAnchor constraintEqualToAnchor:_cover.centerYAnchor],
            [_playButton.widthAnchor constraintEqualToConstant:52],
            [_playButton.heightAnchor constraintEqualToConstant:52],
            [_kindLabel.leadingAnchor constraintEqualToAnchor:self.leadingAnchor constant:10],
            [_kindLabel.bottomAnchor constraintEqualToAnchor:_cover.bottomAnchor constant:-8],
            [_titleLabel.topAnchor constraintEqualToAnchor:_cover.bottomAnchor constant:8],
            [_titleLabel.leadingAnchor constraintEqualToAnchor:self.leadingAnchor constant:10],
            [_titleLabel.trailingAnchor constraintEqualToAnchor:self.trailingAnchor constant:-10],
            [_titleLabel.bottomAnchor constraintEqualToAnchor:self.bottomAnchor constant:-8],
        ]];
    }
    return self;
}

- (void)configureRecord:(NSDictionary *)record {
    self.record = record;
    self.primaryMedia = DYYYRecallPrimaryMedia(record);
    [self.cover configureRecord:record];
    NSString *kind = [record[@"card"] isKindOfClass:NSDictionary.class] ? record[@"card"][@"kind"] : @"";
    NSDictionary *kindNames = @{@"image": @"图片", @"video": @"视频", @"audio": @"语音", @"work": @"分享作品", @"sticker": @"表情", @"goods": @"商品", @"live": @"直播", @"location": @"位置"};
    self.kindLabel.text = kindNames[kind] ?: @"消息";
    self.kindLabel.hidden = NO;
    NSString *summary = DYYYRecallSummary(record);
    self.titleLabel.text = summary.length ? summary : @"已撤回的消息";
    BOOL playable = [@[@"video", @"audio"] containsObject:self.primaryMedia[@"kind"]];
    self.playButton.hidden = !playable;
}

- (void)didTapMedia {
    if (self.openMedia && self.primaryMedia) {
        self.openMedia(self.primaryMedia);
        return;
    }
    if (self.openOriginal) {
        self.openOriginal();
        return;
    }
    NSString *urlString = self.primaryMedia[@"remoteURL"];
    if (![urlString length]) return;
    NSURL *url = [NSURL URLWithString:urlString];
    if (!url) return;
    NSString *kind = self.primaryMedia[@"kind"];
    UIViewController *top = DYYYMediaTopController();
    if (!top) return;
    if ([kind isEqual:@"video"] || [kind isEqual:@"audio"]) {
        AVPlayerViewController *player = [AVPlayerViewController new];
        player.player = [AVPlayer playerWithURL:url];
        [top presentViewController:player animated:YES completion:^{
            [player.player play];
        }];
    } else if ([kind isEqual:@"image"]) {
        DYYYRecallImageViewer *viewer = [DYYYRecallImageViewer new];
        viewer.image = self.cover.image;
        [top presentViewController:viewer animated:YES completion:nil];
    }
}

- (void)cancel {
    [self.cover cancel];
}

- (void)dealloc {
    [self.cover cancel];
}

@end
