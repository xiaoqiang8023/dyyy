// DYYYRadarMonitor.h — 特别关注：前台轮询调度（一次一人、排队、失败退避）。
// 由 DY778RadarMonitor.h 移植，仅重命名。
#import "DYYYRadarStore.h"

NS_ASSUME_NONNULL_BEGIN

extern NSNotificationName const DYYYRadarMonitorStatusChanged;
extern NSNotificationName const DYYYRadarMonitorAlert;

@interface DYYYRadarMonitor : NSObject
+ (instancetype)shared;
@property(nonatomic, readonly) BOOL busy;
@property(nonatomic, readonly, copy) NSString *status;
- (void)start;
- (void)synchronizeAccount;
- (void)checkNow;
- (void)invalidateTarget:(NSString *)uid;
@end

NS_ASSUME_NONNULL_END
