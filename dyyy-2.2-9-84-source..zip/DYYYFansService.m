#import "DYYYFansService.h"
#import "DYYYFansPolicy.h"
#import "DYYYFansWeb.h"
#import "DYYYFansPrivate.h"
#import <UIKit/UIKit.h>

static NSString *DYYYFansDiagnosticSnapshot;
NSString *DYYYFansLastDiagnostic(void) { return DYYYFansDiagnosticSnapshot ?: @"尚无查询记录"; }

static NSString *DYYYFansAPIOrigin(void) {
    Class provider = NSClassFromString(@"NetworkProviderDomain");
    for (NSString *selector in @[@"apiDomain", @"apiHost"]) {
        id raw = DYYYFansCall(provider, selector, @[]);
        NSString *text = [raw isKindOfClass:NSURL.class] ? [raw absoluteString] : DYYYFansString(raw);
        if (!text.length) continue;
        if (![text containsString:@"://"]) text = [@"https://" stringByAppendingString:text];
        NSURLComponents *parts = [NSURLComponents componentsWithString:text];
        if (![parts.scheme.lowercaseString isEqual:@"https"] || !parts.host.length || parts.user.length || parts.password.length) continue;
        parts.path = @""; parts.query = nil; parts.fragment = nil; return parts.string;
    }
    return DYYYFansPrivate(DYYYFansAppOrigin);
}

static NSMutableDictionary *DYYYFansProfiles;
static NSString *DYYYFansProfilesAccount;
static NSMutableDictionary *DYYYFansProfileStore(void) {
    NSString *account = DYYYFansAccount() ?: @"";
    if (!DYYYFansProfiles || ![account isEqual:DYYYFansProfilesAccount]) { DYYYFansProfiles = [NSMutableDictionary dictionary]; DYYYFansProfilesAccount = account; }
    return DYYYFansProfiles;
}
static NSDictionary *DYYYFansCachedProfile(NSDictionary *person) {
    NSDictionary *cached = DYYYFansProfileStore()[DYYYFansString(person[@"uid"])] ?: DYYYFansProfileStore()[DYYYFansString(person[@"secUID"])];
    return cached && NSDate.date.timeIntervalSince1970 - [cached[@"time"] doubleValue] < 120 && DYYYFansSamePerson(person,cached[@"person"]) ? cached[@"person"] : nil;
}
static void DYYYFansCacheProfile(NSDictionary *person) {
    NSMutableDictionary *store = DYYYFansProfileStore(); if (store.count >= 160) [store removeAllObjects];
    NSDictionary *record = @{@"person":person,@"time":@(NSDate.date.timeIntervalSince1970)};
    if (DYYYFansUID(person[@"uid"])) store[person[@"uid"]] = record;
    if (DYYYFansSecUID(person[@"secUID"])) store[person[@"secUID"]] = record;
}

@interface DYYYFansRedirector : NSObject <NSURLSessionDataDelegate>
@property(nonatomic, copy) DYYYFansReply completion;
@property(nonatomic, strong) NSURLSession *session;
@property(nonatomic, strong) NSURLSessionDataTask *task;
@property(nonatomic) NSUInteger redirects;
- (void)open:(NSURL *)url completion:(DYYYFansReply)completion;
- (void)cancel;
@end
@implementation DYYYFansRedirector
- (void)open:(NSURL *)url completion:(DYYYFansReply)completion {
    self.completion = completion;
    NSURLSessionConfiguration *config = NSURLSessionConfiguration.ephemeralSessionConfiguration;
    config.timeoutIntervalForRequest = 12; config.timeoutIntervalForResource = 18;
    config.HTTPCookieStorage = nil; config.URLCache = nil;
    self.session = [NSURLSession sessionWithConfiguration:config delegate:self delegateQueue:NSOperationQueue.mainQueue];
    NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:url];
    [request setValue:@"Mozilla/5.0 (iPhone; CPU iPhone OS 16_0 like Mac OS X) AppleWebKit/605.1.15 Mobile/15E148" forHTTPHeaderField:@"User-Agent"];
    self.task = [self.session dataTaskWithRequest:request]; [self.task resume];
}
- (void)finish:(NSURL *)url error:(NSError *)error {
    DYYYFansReply callback = self.completion; self.completion = nil;
    [self.session invalidateAndCancel]; self.session = nil; self.task = nil;
    if (callback) callback(url, error);
}
- (void)cancel { self.completion = nil; [self.session invalidateAndCancel]; self.session = nil; self.task = nil; }
- (void)URLSession:(NSURLSession *)session task:(NSURLSessionTask *)task willPerformHTTPRedirection:(NSHTTPURLResponse *)response newRequest:(NSURLRequest *)request completionHandler:(void (^)(NSURLRequest *))completionHandler {
    if (!DYYYFansShareURL(request.URL) || ++self.redirects > 8) {
        completionHandler(nil); [self finish:nil error:DYYYFansError(400, @"分享链接跳转异常，请重新复制链接。")]; return;
    }
    NSDictionary *parsed = DYYYFansParseInput(request.URL.absoluteString, DYYYFansInputAutomatic, nil);
    if (parsed && ![parsed[@"kind"] isEqual:@"url"]) { completionHandler(nil); [self finish:request.URL error:nil]; return; }
    completionHandler(request);
}
- (void)URLSession:(NSURLSession *)session dataTask:(NSURLSessionDataTask *)task didReceiveResponse:(NSURLResponse *)response completionHandler:(void (^)(NSURLSessionResponseDisposition))completionHandler {
    completionHandler(NSURLSessionResponseCancel);
    NSInteger code = [response isKindOfClass:NSHTTPURLResponse.class] ? [(NSHTTPURLResponse *)response statusCode] : 0;
    if (code >= 400) [self finish:nil error:DYYYFansError(code, @"分享链接暂不可用，请检查链接后重试。")];
    else [self finish:response.URL error:nil];
}
- (void)URLSession:(NSURLSession *)session task:(NSURLSessionTask *)task didCompleteWithError:(NSError *)error {
    if (self.completion) [self finish:nil error:error ?: DYYYFansError(502, @"无法展开分享链接。")];
}
@end

@interface DYYYFansService ()
@property(nonatomic, copy) NSString *account;
@property(nonatomic, copy) DYYYFansReply terminal;
@property(nonatomic, strong) id task;
@property(nonatomic, strong) id native;
@property(nonatomic, strong) id search;
@property(nonatomic, strong) NSMutableDictionary *searchCandidates;
@property(nonatomic, strong) NSTimer *deadline;
@property(nonatomic, strong) DYYYFansRedirector *redirector;
@property(nonatomic, strong) DYYYFansWebClient *web;
@property(nonatomic) NSUInteger generation;
@property(nonatomic) NSUInteger operation;
@end

@implementation DYYYFansService
- (instancetype)init {
    if ((self = [super init])) [NSNotificationCenter.defaultCenter addObserver:self selector:@selector(background) name:UIApplicationDidEnterBackgroundNotification object:nil];
    return self;
}
- (void)dealloc { [self.web cancel]; [self.deadline invalidate]; [self.redirector cancel]; DYYYFansCall(self.task, @"cancel", @[]); }
- (void)background { if (self.terminal) [self finish:nil error:DYYYFansError(-999, @"查询已暂停，返回后可重新查询。")]; }
- (void)cancel {
    self.generation++; self.operation++; [self.web cancel]; self.web = nil;
    [self.deadline invalidate]; self.deadline = nil; [self.redirector cancel]; self.redirector = nil;
    DYYYFansCall(self.task, @"cancel", @[]); self.task = nil;
    DYYYFansCall(DYYYFansRead(self.search, @"task"), @"cancel", @[]); self.search = nil; self.searchCandidates = nil;
    id pool = DYYYFansRead(self.native, @"requestPool");
    if ([pool isKindOfClass:NSDictionary.class]) for (id request in [pool allValues]) { DYYYFansCall(request, @"cancel", @[]); DYYYFansCall(DYYYFansRead(request, @"task"), @"cancel", @[]); }
    self.native = nil; self.terminal = nil;
}
- (void)finish:(id)value error:(NSError *)error {
    if ([value isKindOfClass:DYYYFansResult.class]) DYYYFansDiagnosticSnapshot = [((DYYYFansResult *)value).diagnostic copy];
    else if (error) DYYYFansDiagnosticSnapshot = [NSString stringWithFormat:@"%@ / %ld%@", error.domain, (long)error.code, error.userInfo[@"DYYYFansDiagnostic"] ? [@"; " stringByAppendingString:error.userInfo[@"DYYYFansDiagnostic"]] : @""];
    DYYYFansReply completion = self.terminal;
    [self cancel];
    // 闪退修 4：finish 可能被后台通知（进入后台）或非主线程回调触发，completion 里是 UI 的
    // 终态刷新，必须回主线程再调；cancel 本身先同步做完，避免回调回来时任务还在跑。
    if (!completion) return;
    if (NSThread.isMainThread) completion(value, error);
    else dispatch_async(dispatch_get_main_queue(), ^{ completion(value, error); });
}
- (BOOL)prepare:(DYYYFansReply)completion {
    [self cancel]; self.terminal = completion; self.account = DYYYFansAccount();
    if (!DYYYFansEnabled(@"DYYYFansC.Enabled")) { [self finish:nil error:DYYYFansError(403, @"请先在 DYYY 设置中开启星牌查询。")]; return NO; }
    if (!DYYYFansUID(self.account)) { [self finish:nil error:DYYYFansError(401, @"请先登录抖音，再进行查询。")]; return NO; }
    if (UIApplication.sharedApplication.applicationState != UIApplicationStateActive) { [self background]; return NO; }
    return YES;
}
- (void)stage:(NSString *)name start:(void (^)(DYYYFansReply))start reply:(DYYYFansReply)reply {
    // 闪退修 5：stage 全程假设在主线程——progress 回调直接调 UI、18 秒超时定时器要挂主线程
    // RunLoop。原生 API（HTSLiveUserAPI / AWENetworkService）的回调线程不由我们控制，
    // 一旦某条链路在后台线程调进 stage，进度回调就会在后台线程改 UI，且定时器挂不到
    // 会跑的 RunLoop 上。非主线程进来时整段切回主线程重跑一次。
    if (!NSThread.isMainThread) {
        __weak typeof(self) weakSelf = self;
        dispatch_async(dispatch_get_main_queue(), ^{ [weakSelf stage:name start:start reply:reply]; });
        return;
    }
    NSUInteger generation = self.generation, operation = ++self.operation;
    [self.deadline invalidate]; self.deadline = nil;
    if (self.progress) self.progress(name);
    __weak typeof(self) weakSelf = self;
    DYYYFansReply receive = ^(id value, NSError *error) {
        dispatch_async(dispatch_get_main_queue(), ^{
            DYYYFansService *self = weakSelf;
            if (!self || !DYYYFansCallbackCurrent(generation, self.generation, operation, self.operation, self.terminal != nil)) return;
            self.operation++; [self.deadline invalidate]; self.deadline = nil; self.task = nil; self.native = nil;
            if (![self.account isEqual:DYYYFansAccount()] || !DYYYFansEnabled(@"DYYYFansC.Enabled")) { [self finish:nil error:DYYYFansError(-999, @"账号或设置已变化，请重新查询。")]; return; }
            reply(value, error);
        });
    };
    self.deadline = [NSTimer scheduledTimerWithTimeInterval:18 repeats:NO block:^(NSTimer *timer) {
        DYYYFansService *self = weakSelf;
        DYYYFansCall(self.task, @"cancel", @[]); [self.redirector cancel]; [self.web cancel];
        receive(nil, DYYYFansError(408, @"请求超时，请稍后重试。"));
    }];
    @try { start(receive); }
    @catch (__unused NSException *exception) { receive(nil, DYYYFansError(503, @"当前版本的数据服务暂不可用。")); }
}
- (void)get:(NSString *)path params:(NSDictionary *)params reply:(DYYYFansReply)reply {
    [self getURL:[DYYYFansAPIOrigin() stringByAppendingString:path] params:params progress:@"正在读取用户资料…" reply:reply];
}
- (void)getURL:(NSString *)url params:(NSDictionary *)params progress:(NSString *)progress reply:(DYYYFansReply)reply {
    [self stage:progress start:^(DYYYFansReply receive) {
        Class network = NSClassFromString(@"AWENetworkService");
        if (!DYYYFansHas(network, @"getWithURLString:params:timeout:completion:", "@", "@@d@")) { receive(nil, DYYYFansError(503, @"当前抖音版本不支持资料查询。")); return; }
        void (^callback)(id, NSError *) = ^(id value, NSError *error) {
            if (!error) {
                NSNumber *status = DYYYFansInteger(DYYYFansFirst(value, @[@"status_code", @"statusCode"]));
                if (status.longLongValue != 0) error = DYYYFansError(status.integerValue, @"抖音暂未返回可用资料，请稍后重试。");
                if (!value || value == NSNull.null) error = DYYYFansError(502, @"抖音返回了空数据。");
            }
            receive(value, error);
        };
        self.task = DYYYFansCall(network, @"getWithURLString:params:timeout:completion:", @[url, params, @14.0, callback]);
    } reply:reply];
}
- (void)resolveParsed:(NSDictionary *)parsed completion:(DYYYFansReply)completion {
    NSString *kind = parsed[@"kind"], *value = parsed[@"value"];
    if ([kind isEqual:@"url"]) {
        [self stage:@"正在展开分享链接…" start:^(DYYYFansReply receive) {
            self.redirector = [DYYYFansRedirector new]; [self.redirector open:[NSURL URLWithString:value] completion:receive];
        } reply:^(NSURL *url, NSError *error) {
            self.redirector = nil;
            NSDictionary *next = url ? DYYYFansParseInput(url.absoluteString, DYYYFansInputAutomatic, nil) : nil;
            if (error || !next || [next[@"kind"] isEqual:@"url"]) { completion(nil, error ?: DYYYFansError(404, @"链接中没有可识别的作者或作品，请重新复制分享链接。")); return; }
            [self resolveParsed:next completion:completion];
        }]; return;
    }
    if ([kind isEqual:@"handle"]) {
        self.searchCandidates = [NSMutableDictionary dictionary];
        [self web:@"lookup" params:@{@"unique_id":value} reply:^(id response,NSError *error) {
            if (!error && [self acceptSearch:response handle:value completion:completion]) return;
            self.search = [NSClassFromString(@"AWESearchUserManager") new];
            if (!DYYYFansHas(self.search, @"fetchUsersWithKeyword:cursor:isPullToRefresh:completion:", "v", "@@B@")) { [self searchWeb:value route:0 cursor:@0 page:0 completion:completion]; return; }
            DYYYFansSet(self.search,@"count",@30); DYYYFansSet(self.search,@"cursor",@0); DYYYFansSet(self.search,@"searchSource",@"normal_search"); DYYYFansSet(self.search,@"initialSearchSource",@"normal_search");
            [self searchHandle:value cursor:@0 page:0 completion:completion];
        }]; return;
    }
    if ([kind isEqual:@"video"]) {
        [self get:DYYYFansPrivate(DYYYFansVideoPath) params:@{@"aweme_id": value} reply:^(id response, NSError *error) {
            id video = DYYYFansFirst(response, @[@"aweme_detail", @"awemeDetail"]);
            NSDictionary *person = DYYYFansPerson(DYYYFansRead(video, @"author"));
            completion(person, error ?: (person ? nil : DYYYFansError(404, @"作品不可用或未返回作者信息。")));
        }]; return;
    }
    NSDictionary *expected = @{[kind isEqual:@"uid"] ? @"uid" : @"secUID":value};
    [self loadAnchor:expected completion:completion];
}
- (BOOL)acceptSearch:(id)value handle:(NSString *)handle completion:(DYYYFansReply)completion {
    NSMutableDictionary *matches = [NSMutableDictionary dictionary];
    for (NSDictionary *entry in DYYYFansSearchPeople(value)) {
        NSDictionary *person = entry[@"person"]; NSString *key = [person[@"uid"] length] ? person[@"uid"] : person[@"secUID"];
        if (!key.length) continue;
        if (self.searchCandidates.count < 60 || self.searchCandidates[key]) self.searchCandidates[key] = person;
        if (DYYYFansHandleMatches(entry[@"raw"],handle)) matches[key] = person;
    }
    if (matches.count == 1) { [self loadAnchor:matches.allValues.firstObject completion:completion]; return YES; }
    if (matches.count > 1) { completion(nil,[NSError errorWithDomain:@"DYYYFans" code:300 userInfo:@{NSLocalizedDescriptionKey:@"请选择要查询的账号。",@"DYYYFansCandidates":matches.allValues}]); return YES; }
    return NO;
}
- (void)finishSearch:(DYYYFansReply)completion error:(NSError *)error {
    if (self.searchCandidates.count) {
        NSArray *people = [self.searchCandidates.allValues sortedArrayUsingComparator:^NSComparisonResult(NSDictionary *a,NSDictionary *b) { return [DYYYFansPersonName(a) compare:DYYYFansPersonName(b)]; }];
        completion(nil,[NSError errorWithDomain:@"DYYYFans" code:300 userInfo:@{NSLocalizedDescriptionKey:@"请选择对应账号，确认头像与抖音号后继续。",@"DYYYFansCandidates":people}]);
    } else completion(nil,error ?: DYYYFansError(404,@"未匹配到该抖音号，请核对后重试；数字 UID 请使用 UID 模式。"));
}
- (void)searchHandle:(NSString *)handle cursor:(id)cursor page:(NSUInteger)page completion:(DYYYFansReply)completion {
    [self stage:@"正在匹配抖音号…" start:^(DYYYFansReply receive) {
        void (^callback)(id,NSError *) = ^(id users,NSError *error) { receive(users,error); };
        DYYYFansCall(self.search,@"fetchUsersWithKeyword:cursor:isPullToRefresh:completion:",@[handle,cursor,@(page == 0),callback]);
    } reply:^(id value,NSError *error) {
        if (!error && [self acceptSearch:value handle:handle completion:completion]) return;
        id data = DYYYFansRead(value,@"data");
        id next = DYYYFansRead(value,@"cursor") ?: DYYYFansRead(data,@"cursor") ?: DYYYFansRead(self.search,@"cursor");
        id more = DYYYFansRead(value,@"has_more") ?: DYYYFansRead(data,@"has_more") ?: DYYYFansRead(self.search,@"hasMore");
        if (!error && page < 2 && [more boolValue] && [DYYYFansInteger(next) longLongValue] > [DYYYFansInteger(cursor) longLongValue]) {
            [self searchHandle:handle cursor:next page:page + 1 completion:completion]; return;
        }
        [self searchWeb:handle route:0 cursor:@0 page:0 completion:completion];
    }];
}
- (void)searchWeb:(NSString *)handle route:(NSUInteger)route cursor:(NSNumber *)cursor page:(NSUInteger)page completion:(DYYYFansReply)completion {
    if (route >= 2) { [self finishSearch:completion error:nil]; return; }
    NSDictionary *params = @{@"keyword":handle,@"search_id":[NSUUID.UUID.UUIDString stringByReplacingOccurrencesOfString:@"-" withString:@""],@"search_channel":route == 0 ? @"aweme_user" : @"aweme_user_web",@"search_type":@"1",@"offset":cursor.stringValue,@"count":@"20",@"sort_type":@"0",@"publish_time":@"0",@"search_source":@"normal_search",@"query_correct_type":@"1",@"is_filter_search":@"0",@"pc_search_type":@"1",@"from_group_id":@"",@"need_filter_settings":@"1",@"list_type":@"single"};
    [self web:route == 0 ? @"search" : @"discover" params:params reply:^(id value,NSError *error) {
        if (!error && [self acceptSearch:value handle:handle completion:completion]) return;
        if (error.code == 401 || error.code == 403 || error.code == 429) { [self finishSearch:completion error:error]; return; }
        id data = DYYYFansRead(value,@"data"); NSNumber *next = DYYYFansInteger(DYYYFansRead(value,@"cursor") ?: DYYYFansRead(data,@"cursor"));
        BOOL more = [(DYYYFansRead(value,@"has_more") ?: DYYYFansRead(data,@"has_more")) boolValue];
        if (!error && page < 2 && more && next.longLongValue > cursor.longLongValue) { [self searchWeb:handle route:route cursor:next page:page+1 completion:completion]; return; }
        if (route == 1) { [self finishSearch:completion error:error]; return; }
        [self searchWeb:handle route:route+1 cursor:@0 page:0 completion:completion];
    }];
}
- (void)resolveInput:(NSString *)input mode:(DYYYFansInputMode)mode completion:(DYYYFansReply)completion {
    if (![self prepare:completion]) return;
    NSError *error; NSDictionary *parsed = DYYYFansParseInput(input, mode, &error);
    if (!parsed) { [self finish:nil error:error]; return; }
    [self resolveParsed:parsed completion:^(id person,NSError *failure) { if (failure) [self finish:nil error:failure]; else [self loadAnchor:person completion:^(id complete,NSError *error) { [self finish:complete error:error]; }]; }];
}
- (void)queryInput:(NSString *)input mode:(DYYYFansInputMode)mode target:(NSDictionary *)target anchor:(NSDictionary *)anchor completion:(void (^)(DYYYFansResult *, NSError *))completion {
    if (![self prepare:^(id value, NSError *error) { completion(value, error); }]) return;
    DYYYFansReply resolved = ^(NSDictionary *person, NSError *error) {
        if (error || !person) { [self finish:nil error:error ?: DYYYFansError(404, @"未找到作者。")]; return; }
        // 2.2-9-64：查询主播第二角色已去掉，输入谁就查谁——不再解析/核对主播，直接按
        // 没选主播查该人的全部灯牌。
        [self fetchLive:person anchor:nil];
    };
    if (target && DYYYFansUID(target[@"uid"])) [self loadAnchor:target completion:resolved];
    else {
        NSError *error; NSDictionary *parsed = target && DYYYFansSecUID(target[@"secUID"]) ? @{@"kind": @"secUID", @"value": target[@"secUID"]} : DYYYFansParseInput(input, mode, &error);
        if (!parsed) { [self finish:nil error:error]; return; }
        [self resolveParsed:parsed completion:^(NSDictionary *person,NSError *failure) { if (failure) resolved(nil,failure); else [self loadAnchor:person completion:resolved]; }];
    }
}
- (void)refreshPerson:(NSDictionary *)person completion:(DYYYFansReply)completion {
    if (![self prepare:completion]) return;
    [self loadAnchor:person force:YES completion:^(id value,NSError *error) { [self finish:value error:error]; }];
}
- (void)loadAnchor:(NSDictionary *)anchor completion:(DYYYFansReply)completion { [self loadAnchor:anchor force:NO completion:completion]; }
- (void)loadAnchor:(NSDictionary *)anchor force:(BOOL)force completion:(DYYYFansReply)completion {
    NSDictionary *cached = force ? nil : DYYYFansCachedProfile(anchor); if (cached) { completion(cached,nil); return; }
    NSMutableDictionary *params = [NSMutableDictionary dictionary];
    if (DYYYFansUID(anchor[@"uid"])) params[@"user_id"] = anchor[@"uid"];
    if (DYYYFansSecUID(anchor[@"secUID"])) params[@"sec_user_id"] = anchor[@"secUID"];
    if (!params.count) { completion(nil,DYYYFansError(400,@"账号标识无效，请重新复制主页链接。")); return; }
    DYYYFansReply accept = ^(id response,NSError *error) {
        NSDictionary *profile = DYYYFansPerson(DYYYFansRead(response,@"user") ?: DYYYFansRead(DYYYFansRead(response,@"data"),@"user") ?: response);
        if (error || !DYYYFansSamePerson(anchor,profile)) { completion(nil,error ?: DYYYFansError(409,@"返回资料与账号不一致，请重新选择。")); return; }
        NSMutableDictionary *complete = [anchor mutableCopy];
        for (NSString *key in profile) if ((![key isEqual:@"uid"] && ![key isEqual:@"secUID"]) || [profile[key] length]) complete[key] = profile[key];
        DYYYFansCacheProfile(complete); completion(complete,nil);
    };
    [self get:DYYYFansPrivate(DYYYFansNativeProfilePath) params:params reply:^(id response,NSError *error) {
        NSDictionary *profile = DYYYFansPerson(DYYYFansRead(response,@"user") ?: response);
        if (!error && DYYYFansSamePerson(anchor,profile)) { accept(response,nil); return; }
        NSMutableDictionary *webParams = [params mutableCopy]; webParams[@"publish_video_strategy_type"] = @"2";
        [self web:@"profile" params:webParams reply:accept];
    }];
}
- (DYYYFansResult *)emptyResult:(NSDictionary *)person anchor:(NSDictionary *)anchor {
    DYYYFansResult *result = [DYYYFansResult new]; result.person = person; result.anchor = anchor; result.clubs = @[]; result.date = NSDate.date; result.diagnostic = @"query=DYYYFans-1.0-3"; return result;
}
- (BOOL)hasBadge:(DYYYFansResult *)result anchor:(NSDictionary *)anchor {
    if (!anchor) return result.clubs.count > 0;
    for (NSDictionary *club in result.clubs) if ([club[@"anchorUID"] isEqual:anchor[@"uid"]] && [club[@"level"] integerValue] > 0) return YES;
    return NO;
}
- (void)merge:(DYYYFansResult *)extra into:(DYYYFansResult *)result {
    if (!extra || !DYYYFansSamePerson(result.person,extra.person)) return;
    if (extra.level) { result.level = extra.level; result.minimum = extra.minimum; result.maximum = extra.maximum; }
    NSMutableDictionary *person = [result.person mutableCopy];
    for (NSString *key in extra.person) if (DYYYFansString(extra.person[key]).length) person[key] = extra.person[key];
    result.person = person;
    NSMutableDictionary *clubs = [NSMutableDictionary dictionary];
    for (NSDictionary *club in [result.clubs arrayByAddingObjectsFromArray:extra.clubs ?: @[]]) {
        NSString *key = [club[@"anchorUID"] length] ? club[@"anchorUID"] : [@"name:" stringByAppendingString:club[@"clubName"]]; clubs[key] = club;
    }
    result.clubs = clubs.allValues;
    // 2.2-9-64：把模型层的灯牌诊断也带进汇总诊断（拼在 service 层诊断后面），复制结果里
    // 才能看到 pay_grade/fans_club/current_badge/preferred_map/records/recognized，分清
    // “他本来就没有灯牌”还是“接口没返回灯牌数据”；同一段诊断只拼一次，避免多次 merge 堆叠。
    if (extra.diagnostic.length && ![result.diagnostic containsString:extra.diagnostic])
        result.diagnostic = [result.diagnostic stringByAppendingFormat:@"; %@", extra.diagnostic];
}
- (void)web:(NSString *)route params:(NSDictionary *)params reply:(DYYYFansReply)reply {
    BOOL profile = [@[@"lookup",@"profile",@"search",@"discover"] containsObject:route];
    [self stage:profile ? @"正在查找账号资料…" : @"正在查询灯牌资料…" start:^(DYYYFansReply receive) {
        self.web = [DYYYFansWebClient new]; [self.web get:route params:params completion:receive];
    } reply:reply];
}
- (NSDictionary *)cardParams:(NSDictionary *)person anchor:(NSDictionary *)anchor {
    NSString *room=DYYYFansString(anchor[@"roomID"]);
    if (!room.length || !DYYYFansUID(room)) room=@"0";
    return @{@"target_uid":person[@"uid"] ?: @"0",@"sec_target_uid":person[@"secUID"] ?: @"",@"anchor_id":anchor[@"uid"] ?: @"0",@"sec_anchor_id":anchor[@"secUID"] ?: @"",@"current_room_id":room};
}
- (void)fetchLive:(NSDictionary *)person anchor:(NSDictionary *)anchor {
    DYYYFansResult *result = [self emptyResult:person anchor:anchor];
    if (anchor && DYYYFansWebConnected()) {
        [self web:anchor ? @"card" : @"user" params:[self cardParams:person anchor:anchor] reply:^(id response,NSError *error) {
            DYYYFansResult *card = !error ? [DYYYFansResult fromProfileResponse:response target:person anchor:anchor error:nil] : nil;
            [self merge:card into:result];
            result.diagnostic = [result.diagnostic stringByAppendingFormat:@"; web_card=%@",card ? @"valid" : @"unavailable"];
            if ([self hasBadge:result anchor:anchor]) [self completeBadge:result anchor:anchor];
            else [self nativeUser:person anchor:anchor result:result triedWeb:YES];
        }];
    } else [self nativeUser:person anchor:anchor result:result triedWeb:NO];
}
- (void)nativeUser:(NSDictionary *)person anchor:(NSDictionary *)anchor result:(DYYYFansResult *)result triedWeb:(BOOL)triedWeb {
    [self stage:@"正在读取消费等级…" start:^(DYYYFansReply receive) {
        self.native = [NSClassFromString(@"HTSLiveUserAPI") new];
        if (!DYYYFansHas(self.native,@"fetchUserInfoWithParams:tintTags:finished:","v","@@@")) { receive(nil,DYYYFansError(503,@"暂时无法读取资料。")); return; }
        NSMutableDictionary *params = [[self cardParams:person anchor:anchor] mutableCopy];
        [params addEntriesFromDictionary:@{@"room_id":params[@"current_room_id"],@"packed_level":@2,@"with_host_info":@1,@"source":@0,@"request_from":@"",@"target_display_role":@0}];
        void (^callback)(id,NSError *) = ^(id value,NSError *error) { receive(value,error); };
        DYYYFansCall(self.native,@"fetchUserInfoWithParams:tintTags:finished:",@[params,@{},callback]);
    } reply:^(id user,NSError *error) {
        DYYYFansResult *extra = !error ? [DYYYFansResult fromUser:user target:person anchor:anchor error:nil] : nil;
        [self merge:extra into:result]; result.diagnostic = [result.diagnostic stringByAppendingFormat:@"; native_user=%@",extra ? @"valid" : @"unavailable"];
        if (!anchor && self.partialResult && result.level) self.partialResult(result);
        // 2.2-9-63：没选主播时不要只凭等级就提前结束——第一次原生请求里的 fans_club
        // 往往只有当前那一个灯牌，prefer_data 里的多个灯牌可能在后面的 web user /
        // nativeCard 才返回；继续走完其余数据源再汇总。选了主播时保持原逻辑。
        if (anchor && [self hasBadge:result anchor:anchor]) { [self completeBadge:result anchor:anchor]; return; }
        if (!triedWeb && DYYYFansWebConnected()) {
            [self web:anchor ? @"card" : @"user" params:[self cardParams:person anchor:anchor] reply:^(id response,NSError *failure) {
                DYYYFansResult *card = !failure ? (anchor ? [DYYYFansResult fromProfileResponse:response target:person anchor:anchor error:nil] : [DYYYFansResult fromUser:DYYYFansRead(response,@"data") target:person error:nil]) : nil;
                [self merge:card into:result];
                // 2.2-9-63：没选主播时继续走 nativeCard 汇总其余灯牌，不要只凭等级提前结束。
                if (anchor && [self hasBadge:result anchor:anchor]) [self completeBadge:result anchor:anchor];
                else [self nativeCard:person anchor:anchor result:result];
            }];
        } else [self nativeCard:person anchor:anchor result:result];
    }];
}
- (void)nativeCard:(NSDictionary *)person anchor:(NSDictionary *)anchor result:(DYYYFansResult *)result {
    id request = [NSClassFromString(@"HTSLiveApiRequest") new]; id api = [NSClassFromString(@"HTSLiveApi") new];
    DYYYFansSet(request,@"path",@"/user/profile/");
    NSString *url = DYYYFansString(DYYYFansCall(api,@"urlWithRequest:",request ? @[request] : @[]));
    if (!url.length || ![[NSURL URLWithString:url].path isEqual:DYYYFansPrivate(DYYYFansCardPath)]) url = [DYYYFansPrivate(DYYYFansNativeOrigin) stringByAppendingString:DYYYFansPrivate(DYYYFansCardPath)];
    NSMutableDictionary *params = [[self cardParams:person anchor:anchor] mutableCopy]; [params addEntriesFromDictionary:@{@"packed_level":@2,@"scene":@0,@"request_from":@""}];
    [self getURL:url params:params progress:@"正在查询粉丝灯牌…" reply:^(id response,NSError *error) {
        DYYYFansResult *card = !error ? [DYYYFansResult fromProfileResponse:response target:person anchor:anchor error:nil] : nil;
        [self merge:card into:result]; result.diagnostic = [result.diagnostic stringByAppendingFormat:@"; native_card=%@",card ? @"valid" : @"unavailable"];
        if ([self hasBadge:result anchor:anchor] || !anchor || !DYYYFansWebConnected()) [self completeBadge:result anchor:anchor];
        else [self members:result anchor:anchor offset:0 page:0 previous:@""];
    }];
}
- (void)members:(DYYYFansResult *)result anchor:(NSDictionary *)anchor offset:(NSUInteger)offset page:(NSUInteger)page previous:(NSString *)previous {
    NSDictionary *params = @{@"anchor_id":anchor[@"uid"],@"sec_anchor_id":anchor[@"secUID"] ?: @"",@"source":@"1",@"type":@"1",@"offset":@(offset),@"count":@20};
    [self web:@"members" params:params reply:^(id response,NSError *error) {
        id data = DYYYFansRead(response,@"data"); id rows = DYYYFansFirst(data,@[@"club_user_list",@"user_list",@"members"]);
        if (error || ![rows isKindOfClass:NSArray.class]) { [self completeBadge:result anchor:anchor]; return; }
        NSMutableArray *fingerprints = [NSMutableArray array]; NSUInteger readable = 0, visited = 0;
        for (id row in rows) {
            if (++visited > 100) break;
            id raw = DYYYFansFirst(row,@[@"user_info",@"user"] ) ?: row; NSDictionary *person = DYYYFansPerson(raw);
            if (!person) continue; readable++; [fingerprints addObject:person[@"uid"] ?: person[@"secUID"]];
            if (!DYYYFansSamePerson(result.person,person)) continue;
            id info = DYYYFansFirst(row,@[@"user_fansclub_info",@"user_fans_club_info",@"fans_club"]) ?: DYYYFansRead(raw,@"fans_club") ?: row;
            id inner = DYYYFansRead(info,@"data"); if ([inner isKindOfClass:NSDictionary.class]) info = inner;
            if (![info isKindOfClass:NSDictionary.class]) continue;
            NSMutableDictionary *badge = [info mutableCopy]; NSString *owner = DYYYFansString(DYYYFansFirst(info,@[@"anchor_id",@"anchor_uid"]));
            if (DYYYFansUID(owner) && ![owner isEqual:anchor[@"uid"]]) continue;
            badge[@"anchor_id"] = anchor[@"uid"];
            if (!DYYYFansString(badge[@"club_name"]).length) badge[@"club_name"] = DYYYFansString(DYYYFansFirst(DYYYFansRead(data,@"club_info"),@[@"name",@"club_name"]));
            DYYYFansResult *match = [DYYYFansResult fromUser:@{@"uid":person[@"uid"],@"secUID":person[@"secUID"],@"fans_club":@{@"data":badge}} target:result.person anchor:anchor error:nil];
            [self merge:match into:result];
            if ([self hasBadge:result anchor:anchor]) { [self completeBadge:result anchor:anchor]; return; }
        }
        NSString *fingerprint = [fingerprints componentsJoinedByString:@"|"];
        id more = DYYYFansFirst(data,@[@"has_more",@"hasMore"]); NSNumber *cursor = DYYYFansInteger(DYYYFansFirst(data,@[@"next_offset",@"offset",@"cursor"]));
        NSUInteger next = cursor ? cursor.unsignedIntegerValue : offset + [rows count];
        if (!readable || ![rows count] || [fingerprint isEqual:previous] || (more && ![more boolValue]) || next <= offset || page >= 2) { [self completeBadge:result anchor:anchor]; return; }
        NSUInteger generation = self.generation;
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW,(int64_t)(0.65*NSEC_PER_SEC)),dispatch_get_main_queue(),^{
            if (self.terminal && self.generation == generation) [self members:result anchor:anchor offset:next page:page+1 previous:fingerprint];
        });
    }];
}
- (void)completeBadge:(DYYYFansResult *)result anchor:(NSDictionary *)anchor {
    // 2.2-9-64：查询主播第二角色已去掉，anchor 恒为 nil，这里不过滤，保留模型解析出来的
    // 全部灯牌（已去重）；merge: 会打乱顺序，这里按等级降序、灯牌名排序，保证列表稳定。
    result.clubs = [result.clubs sortedArrayUsingComparator:^NSComparisonResult(NSDictionary *a, NSDictionary *b) {
        NSComparisonResult order = [@([b[@"level"] integerValue]) compare:@([a[@"level"] integerValue])];
        return order == NSOrderedSame ? [a[@"clubName"] compare:b[@"clubName"]] : order;
    }];
    [self finishLiveResult:result anchor:anchor];
}
- (void)finishLiveResult:(DYYYFansResult *)result anchor:(NSDictionary *)anchor {
    result.date = NSDate.date;
    result.notice = result.clubs.count ? @"本次可查询到的灯牌如下，未列出的不代表没有加入。" : @"暂未取得可确认的灯牌，不代表未加入。";
    if (!result.level && !result.clubs.count && !anchor) { [self finish:nil error:DYYYFansError(424,@"暂未取得可确认的资料，请稍后重试。")]; return; }
    [self finish:result error:nil];
}
@end
