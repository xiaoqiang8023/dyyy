#import "DYYYDownloadPanelView.h"
#import <objc/runtime.h>
#import "DYYYUtils.h"

#pragma mark - 私有属性

@interface DYYYDownloadPanelView ()

@property(nonatomic, strong) NSArray<NSDictionary *> *qualities;
@property(nonatomic, copy, nullable) NSString *musicURL;
@property(nonatomic, strong, nullable) NSDictionary<NSString *, NSString *> *stats;
@property(nonatomic, copy) void (^downloadHandler)(NSString *url, NSString *_Nullable musicURL);

@property(nonatomic, assign) NSInteger selectedIndex;
@property(nonatomic, assign) NSInteger originalIndex;
@property(nonatomic, assign) BOOL dismissed;

@property(nonatomic, strong) UIView *dimView;
@property(nonatomic, strong) UIView *sheetView;
@property(nonatomic, strong) UIButton *closeButton;
@property(nonatomic, strong) NSMutableArray<UIView *> *rowViews;
@property(nonatomic, strong) NSMutableArray<UILabel *> *sizeLabels;
@property(nonatomic, strong) NSMutableArray<UIView *> *checkViews;
@property(nonatomic, strong) NSMutableArray<NSURLSessionTask *> *sizeTasks;
@property(nonatomic, strong) UIButton *linkCopyButton;
@property(nonatomic, strong) UIButton *downloadButton;

@end

@implementation DYYYDownloadPanelView

#pragma mark - 对外入口

+ (void)showWithQualities:(NSArray<NSDictionary *> *)qualities
                 musicURL:(NSString *)musicURL
                    stats:(NSDictionary<NSString *, NSString *> *)stats
          downloadHandler:(void (^)(NSString *url, NSString *_Nullable musicURL))downloadHandler {
    if (qualities.count == 0 || !downloadHandler) return;
    dispatch_async(dispatch_get_main_queue(), ^{
      UIWindow *window = [UIApplication sharedApplication].keyWindow;
      if (!window) window = [UIApplication sharedApplication].windows.firstObject;
      if (!window) return;
      DYYYDownloadPanelView *panel = [[DYYYDownloadPanelView alloc] initWithFrame:window.bounds
                                                                        qualities:qualities
                                                                         musicURL:musicURL
                                                                            stats:stats
                                                                  downloadHandler:downloadHandler];
      panel.frame = window.bounds;
      [window addSubview:panel];
      [panel presentAnimated];
    });
}

#pragma mark - 初始化与布局

- (instancetype)initWithFrame:(CGRect)frame
                    qualities:(NSArray<NSDictionary *> *)qualities
                     musicURL:(NSString *)musicURL
                        stats:(NSDictionary<NSString *, NSString *> *)stats
              downloadHandler:(void (^)(NSString *url, NSString *_Nullable musicURL))downloadHandler {
    self = [super initWithFrame:frame];
    if (!self) return nil;
    _qualities = qualities;
    _musicURL = [musicURL copy];
    _stats = stats;
    _downloadHandler = [downloadHandler copy];
    _rowViews = [NSMutableArray array];
    _sizeLabels = [NSMutableArray array];
    _checkViews = [NSMutableArray array];
    _sizeTasks = [NSMutableArray array];

    // 默认选中原画行，否则第一行
    _originalIndex = 0;
    for (NSInteger i = 0; i < (NSInteger)qualities.count; i++) {
        NSString *level = qualities[i][@"level"];
        if ([level rangeOfString:@"原画"].location != NSNotFound) {
            _originalIndex = i;
            break;
        }
    }
    _selectedIndex = _originalIndex;

    self.backgroundColor = [UIColor clearColor];

    _dimView = [[UIView alloc] initWithFrame:self.bounds];
    _dimView.backgroundColor = [[UIColor blackColor] colorWithAlphaComponent:0.55];
    _dimView.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
    UITapGestureRecognizer *dimTap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(dismiss)];
    [_dimView addGestureRecognizer:dimTap];
    [self addSubview:_dimView];

    // 左上角关闭按钮（设计稿里的 ×）
    _closeButton = [UIButton buttonWithType:UIButtonTypeCustom];
    _closeButton.frame = CGRectMake(16, 50, 40, 40);
    _closeButton.layer.cornerRadius = 20;
    _closeButton.backgroundColor = [[UIColor whiteColor] colorWithAlphaComponent:0.12];
    _closeButton.layer.borderColor = [[UIColor whiteColor] colorWithAlphaComponent:0.18].CGColor;
    _closeButton.layer.borderWidth = 1;
    [_closeButton setTitle:@"×" forState:UIControlStateNormal];
    [_closeButton setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    _closeButton.titleLabel.font = [UIFont systemFontOfSize:22];
    [_closeButton addTarget:self action:@selector(dismiss) forControlEvents:UIControlEventTouchUpInside];
    [self addSubview:_closeButton];

    _sheetView = [[UIView alloc] init];
    _sheetView.backgroundColor = [UIColor colorWithRed:16.0 / 255.0 green:20.0 / 255.0 blue:32.0 / 255.0 alpha:0.95];
    _sheetView.layer.cornerRadius = 28;
    _sheetView.layer.maskedCorners = kCALayerMinXMinYCorner | kCALayerMaxXMinYCorner;
    _sheetView.layer.borderColor = [[UIColor whiteColor] colorWithAlphaComponent:0.12].CGColor;
    _sheetView.layer.borderWidth = 1;
    _sheetView.clipsToBounds = YES;
    [self addSubview:_sheetView];

    [self buildSheetContents];
    return self;
}

- (void)buildSheetContents {
    CGFloat y = 12;
    UIView *handle = [[UIView alloc] initWithFrame:CGRectMake(0, y, 48, 5)];
    handle.backgroundColor = [[UIColor whiteColor] colorWithAlphaComponent:0.35];
    handle.layer.cornerRadius = 2.5;
    handle.tag = 1001;
    [_sheetView addSubview:handle];
    y += 5 + 16;

    // 统计卡片：仅在传入 stats 时显示，不伪造数字
    if (self.stats) {
        NSString *play = self.stats[@"play"] ?: @"—";
        NSString *digg = self.stats[@"digg"] ?: @"—";
        NSString *share = self.stats[@"share"] ?: @"—";
        UIView *card = [[UIView alloc] initWithFrame:CGRectMake(18, y, 0, 78)];
        card.backgroundColor = [[UIColor whiteColor] colorWithAlphaComponent:0.08];
        card.layer.cornerRadius = 18;
        card.layer.borderColor = [[UIColor whiteColor] colorWithAlphaComponent:0.12].CGColor;
        card.layer.borderWidth = 1;
        card.tag = 1002;
        [_sheetView addSubview:card];
        NSArray *values = @[play, digg, share];
        NSArray *labels = @[@"播放量", @"点赞", @"分享"];
        for (NSInteger i = 0; i < 3; i++) {
            UILabel *v = [[UILabel alloc] init];
            v.text = values[i];
            v.font = [UIFont boldSystemFontOfSize:(i == 0 ? 28 : 22)];
            v.textColor = [UIColor whiteColor];
            v.textAlignment = NSTextAlignmentCenter;
            v.tag = 2000 + i;
            [card addSubview:v];
            UILabel *l = [[UILabel alloc] init];
            l.text = labels[i];
            l.font = [UIFont systemFontOfSize:13];
            l.textColor = [[UIColor whiteColor] colorWithAlphaComponent:0.55];
            l.textAlignment = NSTextAlignmentCenter;
            l.tag = 2100 + i;
            [card addSubview:l];
            if (i > 0) {
                UIView *sep = [[UIView alloc] init];
                sep.backgroundColor = [[UIColor whiteColor] colorWithAlphaComponent:0.14];
                sep.tag = 2200 + i;
                [card addSubview:sep];
            }
        }
        y += 78 + 16;
    }

    UILabel *title = [[UILabel alloc] initWithFrame:CGRectMake(18, y, 200, 26)];
    title.text = @"视频下载";
    title.font = [UIFont boldSystemFontOfSize:20];
    title.textColor = [UIColor whiteColor];
    title.tag = 1003;
    [_sheetView addSubview:title];
    y += 26 + 12;

    // 画质行
    for (NSInteger i = 0; i < (NSInteger)self.qualities.count; i++) {
        NSDictionary *q = self.qualities[i];
        NSString *level = q[@"level"] ?: @"";
        UIButton *row = [UIButton buttonWithType:UIButtonTypeCustom];
        row.frame = CGRectMake(18, y, 0, 56);
        row.backgroundColor = [[UIColor whiteColor] colorWithAlphaComponent:0.06];
        row.layer.cornerRadius = 16;
        row.layer.borderWidth = 1;
        row.tag = 3000 + i;
        [row addTarget:self action:@selector(rowTapped:) forControlEvents:UIControlEventTouchUpInside];
        [_sheetView addSubview:row];
        [_rowViews addObject:row];

        UILabel *levelLabel = [[UILabel alloc] init];
        levelLabel.text = level;
        levelLabel.font = [UIFont boldSystemFontOfSize:17];
        levelLabel.textColor = [UIColor whiteColor];
        [row addSubview:levelLabel];

        // 标签：原画 -> 原画/推荐；宽度 >=720 -> 高清；否则标清/省流
        NSMutableArray<NSString *> *tagTexts = [NSMutableArray array];
        NSMutableArray<UIColor *> *tagColors = [NSMutableArray array];
        NSMutableArray<NSNumber *> *tagOutlines = [NSMutableArray array];
        if ([level rangeOfString:@"原画"].location != NSNotFound) {
            [tagTexts addObject:@"原画"];
            [tagColors addObject:[UIColor colorWithRed:0.0 green:0.71 blue:1.0 alpha:1.0]];
            [tagOutlines addObject:@(NO)];
            [tagTexts addObject:@"推荐"];
            [tagColors addObject:[UIColor colorWithRed:0.69 green:0.29 blue:1.0 alpha:1.0]];
            [tagOutlines addObject:@(NO)];
        } else if ([self widthFromLevel:level] >= 720) {
            [tagTexts addObject:@"高清"];
            [tagColors addObject:[UIColor clearColor]];
            [tagOutlines addObject:@(YES)];
        } else {
            [tagTexts addObject:@"标清"];
            [tagColors addObject:[UIColor clearColor]];
            [tagOutlines addObject:@(YES)];
            [tagTexts addObject:@"省流"];
            [tagColors addObject:[UIColor clearColor]];
            [tagOutlines addObject:@(YES)];
        }
        CGFloat tx = 0;
        // 先放标题，标签位置在 layoutRows 里按标题宽度排
        levelLabel.frame = CGRectMake(14, 0, 0, 56);
        [levelLabel sizeToFit];
        CGRect lf = levelLabel.frame;
        lf.origin.y = (56 - lf.size.height) / 2;
        levelLabel.frame = lf;
        tx = 14 + lf.size.width + 8;
        for (NSInteger t = 0; t < (NSInteger)tagTexts.count; t++) {
            UILabel *tag = [[UILabel alloc] init];
            tag.text = tagTexts[t];
            tag.font = [UIFont systemFontOfSize:12];
            tag.textAlignment = NSTextAlignmentCenter;
            tag.textColor = [UIColor whiteColor];
            [tag sizeToFit];
            CGFloat tw = tag.frame.size.width + 14;
            tag.frame = CGRectMake(tx, (56 - 22) / 2, tw, 22);
            tag.layer.cornerRadius = 7;
            tag.clipsToBounds = YES;
            if ([tagOutlines[t] boolValue]) {
                tag.layer.borderColor = [[UIColor whiteColor] colorWithAlphaComponent:0.35].CGColor;
                tag.layer.borderWidth = 1;
            } else {
                tag.backgroundColor = tagColors[t];
            }
            [row addSubview:tag];
            tx += tw + 6;
        }

        UILabel *sizeLabel = [[UILabel alloc] init];
        sizeLabel.text = @"…";
        sizeLabel.font = [UIFont systemFontOfSize:14];
        sizeLabel.textColor = [[UIColor whiteColor] colorWithAlphaComponent:0.6];
        sizeLabel.textAlignment = NSTextAlignmentRight;
        [row addSubview:sizeLabel];
        [_sizeLabels addObject:sizeLabel];

        UIView *check = [[UIView alloc] init];
        check.layer.cornerRadius = 11;
        check.layer.borderWidth = 1.5;
        check.layer.borderColor = [[UIColor whiteColor] colorWithAlphaComponent:0.4].CGColor;
        UILabel *tick = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, 22, 22)];
        tick.text = @"✓";
        tick.font = [UIFont boldSystemFontOfSize:13];
        tick.textAlignment = NSTextAlignmentCenter;
        tick.textColor = [UIColor blackColor];
        [check addSubview:tick];
        [row addSubview:check];
        [_checkViews addObject:check];

        y += 56 + 11;
    }

    if (self.musicURL.length > 0) {
        UILabel *music = [[UILabel alloc] initWithFrame:CGRectMake(18, y, 300, 20)];
        music.text = @"♫ 背景音乐";
        music.font = [UIFont systemFontOfSize:14];
        music.textColor = [[UIColor whiteColor] colorWithAlphaComponent:0.55];
        music.tag = 1004;
        [_sheetView addSubview:music];
        y += 20 + 8;
    }

    _linkCopyButton = [UIButton buttonWithType:UIButtonTypeCustom];
    _linkCopyButton.frame = CGRectMake(18, y, 0, 48);
    _linkCopyButton.layer.cornerRadius = 24;
    _linkCopyButton.layer.borderColor = [[UIColor whiteColor] colorWithAlphaComponent:0.28].CGColor;
    _linkCopyButton.layer.borderWidth = 1;
    [_linkCopyButton setTitle:@"🔗 复制原画链接" forState:UIControlStateNormal];
    [_linkCopyButton setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    _linkCopyButton.titleLabel.font = [UIFont systemFontOfSize:16];
    [_linkCopyButton addTarget:self action:@selector(copyTapped) forControlEvents:UIControlEventTouchUpInside];
    [_sheetView addSubview:_linkCopyButton];
    y += 48 + 11;

    _downloadButton = [UIButton buttonWithType:UIButtonTypeCustom];
    _downloadButton.frame = CGRectMake(18, y, 0, 56);
    _downloadButton.layer.cornerRadius = 28;
    _downloadButton.clipsToBounds = YES;
    [_downloadButton setTitle:@"立即下载" forState:UIControlStateNormal];
    [_downloadButton setTitleColor:[UIColor colorWithRed:6.0 / 255.0 green:18.0 / 255.0 blue:26.0 / 255.0 alpha:1.0] forState:UIControlStateNormal];
    _downloadButton.titleLabel.font = [UIFont boldSystemFontOfSize:19];
    [_downloadButton addTarget:self action:@selector(downloadTapped) forControlEvents:UIControlEventTouchUpInside];
    [_sheetView addSubview:_downloadButton];
    // 渐变背景
    CAGradientLayer *grad = [CAGradientLayer layer];
    grad.colors = @[(id)[UIColor colorWithRed:0.0 green:0.71 blue:1.0 alpha:1.0].CGColor,
                    (id)[UIColor colorWithRed:0.0 green:0.90 blue:0.63 alpha:1.0].CGColor];
    grad.startPoint = CGPointMake(0, 0.5);
    grad.endPoint = CGPointMake(1, 0.5);
    grad.frame = _downloadButton.bounds;
    [_downloadButton.layer insertSublayer:grad atIndex:0];
    y += 56 + 12;

    // 记录内容总高，供 layoutSubviews 定位 sheet
    self.sheetView.tag = 9999;
    objc_setAssociatedObject(self.sheetView, "contentHeight", @(y), OBJC_ASSOCIATION_RETAIN_NONATOMIC);
}

- (void)layoutSubviews {
    [super layoutSubviews];
    CGFloat width = self.bounds.size.width;
    CGFloat safeBottom = 0;
    if (@available(iOS 11.0, *)) {
        safeBottom = self.safeAreaInsets.bottom;
    }
    NSNumber *ch = objc_getAssociatedObject(self.sheetView, "contentHeight");
    CGFloat contentH = ch ? [ch doubleValue] : 400;
    CGFloat sheetH = contentH + safeBottom + 10;
    CGFloat maxH = self.bounds.size.height * 0.88;
    if (sheetH > maxH) sheetH = maxH;
    self.sheetView.frame = CGRectMake(0, self.bounds.size.height - sheetH, width, sheetH);
    // sheet 内宽度随屏宽变化
    for (UIView *v in self.sheetView.subviews) {
        if (v.tag == 1001) {
            v.center = CGPointMake(width / 2, v.center.y);
        } else if (v.tag == 1002) {
            CGRect f = v.frame;
            f.size.width = width - 36;
            v.frame = f;
            CGFloat cw = f.size.width / 3;
            for (NSInteger i = 0; i < 3; i++) {
                UIView *vv = [v viewWithTag:2000 + i];
                UIView *ll = [v viewWithTag:2100 + i];
                if (vv) vv.frame = CGRectMake(cw * i, 14, cw, 28);
                if (ll) ll.frame = CGRectMake(cw * i, 46, cw, 18);
                if (i > 0) {
                    UIView *sep = [v viewWithTag:2200 + i];
                    if (sep) sep.frame = CGRectMake(cw * i, 14, 1, 50);
                }
            }
        } else if (v.tag >= 3000 && v.tag < 4000) {
            NSInteger idx = v.tag - 3000;
            CGRect f = v.frame;
            f.size.width = width - 36;
            v.frame = f;
            UILabel *sizeLabel = self.sizeLabels[idx];
            UIView *check = self.checkViews[idx];
            check.frame = CGRectMake(f.size.width - 14 - 22, (56 - 22) / 2, 22, 22);
            sizeLabel.frame = CGRectMake(f.size.width - 14 - 22 - 8 - 80, (56 - 20) / 2, 80, 20);
        } else if (v == self.linkCopyButton || v == self.downloadButton) {
            CGRect f = v.frame;
            f.size.width = width - 36;
            v.frame = f;
            if (v == self.downloadButton && v.layer.sublayers.count > 0) {
                CAGradientLayer *g = (CAGradientLayer *)v.layer.sublayers[0];
                g.frame = v.bounds;
            }
        }
    }
    [self refreshSelection];
    [self fetchSizesIfNeeded];
}

#pragma mark - 交互

- (void)presentAnimated {
    CGRect finalFrame = self.sheetView.frame;
    // layoutSubviews 还没跑过时先按内容高估算
    if (finalFrame.size.height == 0) {
        NSNumber *ch = objc_getAssociatedObject(self.sheetView, "contentHeight");
        CGFloat h = ch ? [ch doubleValue] + 22 : 400;
        finalFrame = CGRectMake(0, self.bounds.size.height - h, self.bounds.size.width, h);
    }
    self.sheetView.frame = CGRectMake(0, self.bounds.size.height, finalFrame.size.width, finalFrame.size.height);
    self.dimView.alpha = 0;
    [UIView animateWithDuration:0.28
                     animations:^{
                       self.dimView.alpha = 1;
                       self.sheetView.frame = finalFrame;
                     }];
}

- (void)dismiss {
    if (self.dismissed) return;
    self.dismissed = YES;
    for (NSURLSessionTask *t in self.sizeTasks) [t cancel];
    [UIView animateWithDuration:0.25
        animations:^{
          self.dimView.alpha = 0;
          CGRect f = self.sheetView.frame;
          f.origin.y = self.bounds.size.height;
          self.sheetView.frame = f;
        }
        completion:^(BOOL finished) {
          [self removeFromSuperview];
        }];
}

- (void)rowTapped:(UIButton *)sender {
    NSInteger idx = sender.tag - 3000;
    if (idx >= 0 && idx < (NSInteger)self.qualities.count) {
        self.selectedIndex = idx;
        [self refreshSelection];
    }
}

- (void)refreshSelection {
    for (NSInteger i = 0; i < (NSInteger)self.rowViews.count; i++) {
        UIView *row = self.rowViews[i];
        UIView *check = self.checkViews[i];
        BOOL sel = (i == self.selectedIndex);
        row.layer.borderColor = sel ? [UIColor colorWithRed:0.63 green:0.86 blue:1.0 alpha:0.9].CGColor
                                    : [[UIColor whiteColor] colorWithAlphaComponent:0.12].CGColor;
        row.backgroundColor = sel ? [[UIColor whiteColor] colorWithAlphaComponent:0.09]
                                  : [[UIColor whiteColor] colorWithAlphaComponent:0.06];
        check.backgroundColor = sel ? [UIColor whiteColor] : [UIColor clearColor];
        check.layer.borderColor = sel ? [UIColor whiteColor].CGColor
                                      : [[UIColor whiteColor] colorWithAlphaComponent:0.4].CGColor;
        for (UIView *sub in check.subviews) sub.hidden = !sel;
    }
}

- (void)copyTapped {
    NSString *url = self.qualities[self.originalIndex][@"url"];
    if (url.length == 0) url = self.qualities[self.selectedIndex][@"url"];
    if (url.length == 0) return;
    [[UIPasteboard generalPasteboard] setString:url];
    [DYYYUtils showToast:@"分享链接已复制"];
}

- (void)downloadTapped {
    NSString *url = self.qualities[self.selectedIndex][@"url"];
    if (url.length == 0) return;
    void (^handler)(NSString *, NSString *) = self.downloadHandler;
    NSString *music = self.musicURL;
    [self dismiss];
    // 面板消失后再触发下载，避免下载进度 UI 被面板挡住
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.3 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
      if (handler) handler(url, music);
    });
}

#pragma mark - 画质大小

- (NSInteger)widthFromLevel:(NSString *)level {
    // 从 "1080x1920" 这类字符串里取第一个数字
    NSScanner *sc = [NSScanner scannerWithString:level];
    NSCharacterSet *digits = [NSCharacterSet decimalDigitCharacterSet];
    [sc scanUpToCharactersFromSet:digits intoString:nil];
    NSInteger v = 0;
    [sc scanInteger:&v];
    return v;
}

- (NSString *)formatBytes:(long long)bytes {
    if (bytes <= 0) return @"—";
    if (bytes >= 1024LL * 1024 * 1024) return [NSString stringWithFormat:@"%.1fGB", bytes / (1024.0 * 1024.0 * 1024.0)];
    if (bytes >= 1024LL * 1024) return [NSString stringWithFormat:@"%.1fMB", bytes / (1024.0 * 1024.0)];
    if (bytes >= 1024) return [NSString stringWithFormat:@"%.1fKB", bytes / 1024.0];
    return [NSString stringWithFormat:@"%lldB", bytes];
}

- (void)fetchSizesIfNeeded {
    static char kFetchedKey;
    if (objc_getAssociatedObject(self, &kFetchedKey)) return;
    objc_setAssociatedObject(self, &kFetchedKey, @(YES), OBJC_ASSOCIATION_RETAIN_NONATOMIC);
    for (NSInteger i = 0; i < (NSInteger)self.qualities.count; i++) {
        NSString *urlStr = self.qualities[i][@"url"];
        NSURL *url = [NSURL URLWithString:urlStr];
        if (!url) continue;
        __weak typeof(self) weakSelf = self;
        [self fetchSizeForURL:url
                   completion:^(long long bytes) {
                     __strong typeof(weakSelf) strongSelf = weakSelf;
                     if (!strongSelf || strongSelf.dismissed) return;
                     dispatch_async(dispatch_get_main_queue(), ^{
                       if (i < (NSInteger)strongSelf.sizeLabels.count) {
                           strongSelf.sizeLabels[i].text = [strongSelf formatBytes:bytes];
                       }
                     });
                   }];
    }
}

- (void)fetchSizeForURL:(NSURL *)url completion:(void (^)(long long))completion {
    NSMutableURLRequest *head = [NSMutableURLRequest requestWithURL:url];
    head.HTTPMethod = @"HEAD";
    head.timeoutInterval = 8;
    __weak typeof(self) weakSelf = self;
    NSURLSessionDataTask *task = [[NSURLSession sharedSession] dataTaskWithRequest:head
        completionHandler:^(NSData *data, NSURLResponse *response, NSError *error) {
          __strong typeof(weakSelf) strongSelf = weakSelf;
          long long len = -1;
          if ([response isKindOfClass:[NSHTTPURLResponse class]]) {
              len = [(NSHTTPURLResponse *)response expectedContentLength];
              if (len <= 0) {
                  NSString *cl = [(NSHTTPURLResponse *)response allHeaderFields][@"Content-Length"];
                  if (cl) len = [cl longLongValue];
              }
          }
          if (len > 0) {
              completion(len);
              return;
          }
          // HEAD 拿不到时，用 Range GET 读 Content-Range 总大小
          if (!strongSelf) {
              completion(-1);
              return;
          }
          NSMutableURLRequest *rangeReq = [NSMutableURLRequest requestWithURL:url];
          rangeReq.HTTPMethod = @"GET";
          [rangeReq setValue:@"bytes=0-0" forHTTPHeaderField:@"Range"];
          rangeReq.timeoutInterval = 8;
          NSURLSessionDataTask *t2 = [[NSURLSession sharedSession] dataTaskWithRequest:rangeReq
              completionHandler:^(NSData *d2, NSURLResponse *r2, NSError *e2) {
                long long total = -1;
                if ([r2 isKindOfClass:[NSHTTPURLResponse class]]) {
                    NSString *cr = [(NSHTTPURLResponse *)r2 allHeaderFields][@"Content-Range"];
                    // 形如 bytes 0-0/12345678
                    if (cr) {
                        NSArray *parts = [cr componentsSeparatedByString:@"/"];
                        if (parts.count == 2) total = [parts[1] longLongValue];
                    }
                    if (total <= 0) total = [(NSHTTPURLResponse *)r2 expectedContentLength];
                }
                completion(total);
              }];
          [strongSelf.sizeTasks addObject:t2];
          [t2 resume];
        }];
    [self.sizeTasks addObject:task];
    [task resume];
}

@end
