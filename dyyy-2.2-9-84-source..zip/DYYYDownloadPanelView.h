#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

/**
 * DYYY 下载面板视图（精简版）
 * 深色玻璃底弹窗：画质选择、画质大小、复制原画链接、立即下载。
 * 不含分享、收藏、不感兴趣按钮；播放量/点赞/分享仅在传入 stats 时显示，
 * 否则隐藏统计卡片，不伪造数字。
 *
 * qualities: 每项 NSDictionary，包含 @"url" 与 @"level"。
 * stats: 可选 NSDictionary，包含 @"play"、@"digg"、@"share"，值为已格式化
 *        的字符串（如 @"282.1万"），缺失的键显示为 @"—"。
 */
@interface DYYYDownloadPanelView : UIView

+ (void)showWithQualities:(NSArray<NSDictionary *> *)qualities
                 musicURL:(nullable NSString *)musicURL
                    stats:(nullable NSDictionary<NSString *, NSString *> *)stats
          downloadHandler:(void (^)(NSString *url, NSString *_Nullable musicURL))downloadHandler;

@end

NS_ASSUME_NONNULL_END
