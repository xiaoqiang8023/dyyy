#import "DYYYFansUI.h"
#import <objc/runtime.h>
static char DYYYFansProfileButtonKeyStorage;
static const void *DYYYFansProfileButtonKey = &DYYYFansProfileButtonKeyStorage;
static NSHashTable *DYYYFansProfileOwners;
static BOOL DYYYFansMatch(Method method, const char *returns, const char *arguments) {
    if (!method) return NO;
    NSMethodSignature *signature = [NSMethodSignature signatureWithObjCTypes:method_getTypeEncoding(method)];
    if (signature.methodReturnType[0] != returns[0] || signature.numberOfArguments != strlen(arguments)+2) return NO;
    for (NSUInteger i=0; arguments[i]; i++) if ([signature getArgumentTypeAtIndex:i+2][0] != arguments[i]) return NO;
    return YES;
}
@interface DYYYFansProfileButton : UIButton
@property(nonatomic, weak) id owner;
@end
@implementation DYYYFansProfileButton
- (instancetype)initWithFrame:(CGRect)frame {
    if ((self = [super initWithFrame:frame])) {
        [self setImage:[UIImage systemImageNamed:@"star.circle"] forState:UIControlStateNormal];
        [self setTitle:@" 星牌" forState:UIControlStateNormal]; self.titleLabel.font = [UIFont systemFontOfSize:14 weight:UIFontWeightSemibold];
        [self setTitleColor:UIColor.whiteColor forState:UIControlStateNormal]; self.tintColor = UIColor.whiteColor;
        self.backgroundColor = [UIColor.blackColor colorWithAlphaComponent:0.28]; self.layer.cornerRadius = 18;
        self.accessibilityLabel = @"查询此用户的消费等级与粉丝灯牌";
        [self addTarget:self action:@selector(open) forControlEvents:UIControlEventTouchUpInside];
    } return self;
}
- (BOOL)pointInside:(CGPoint)point withEvent:(UIEvent *)event { return CGRectContainsPoint(CGRectInset(self.bounds, 0, -4), point); }
- (void)open {
    if (!DYYYFansEnabled(@"DYYYFansC.Profile")) return;
    NSDictionary *person = DYYYFansPerson(DYYYFansCall(self.owner, @"userModel", @[]));
    if (person) DYYYFansOpenQuery(person);
}
@end

static void DYYYFansUpdateProfile(id owner) {
    UIView *container = DYYYFansRead(owner, @"navigationContainerView"); if (![container isKindOfClass:UIView.class]) return;
    DYYYFansProfileButton *button = objc_getAssociatedObject(container, DYYYFansProfileButtonKey);
    NSDictionary *person = DYYYFansPerson(DYYYFansCall(owner, @"userModel", @[]));
    if (!DYYYFansEnabled(@"DYYYFansC.Profile") || !person || container.bounds.size.width < 120) { button.hidden = YES; return; }
    if (!button) {
        button = [DYYYFansProfileButton new]; button.owner = owner; [container addSubview:button]; objc_setAssociatedObject(container, DYYYFansProfileButtonKey, button, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
        if (!DYYYFansProfileOwners) DYYYFansProfileOwners = [NSHashTable weakObjectsHashTable]; [DYYYFansProfileOwners addObject:owner];
    }
    CGFloat left = 12, right = container.bounds.size.width - 12, centerY = container.bounds.size.height / 2;
    button.owner = owner;
    button.backgroundColor = [UIColor.blackColor colorWithAlphaComponent:0.28]; button.tintColor = UIColor.whiteColor;
    [button setTitleColor:UIColor.whiteColor forState:UIControlStateNormal];
    id leftViews = DYYYFansCall(owner, @"currentLeftShowViews", @[]), rightViews = DYYYFansCall(owner, @"currentRightShowViews", @[]);
    if (![leftViews isKindOfClass:NSArray.class] || ![rightViews isKindOfClass:NSArray.class]) { button.hidden = YES; return; }
    for (id views in @[leftViews ?: @[], rightViews ?: @[]]) {
        if (![views isKindOfClass:NSArray.class]) continue;
        for (UIView *view in views) {
            if (![view isKindOfClass:UIView.class] || view.hidden || view.alpha < 0.05 || ![view isDescendantOfView:container] || view == button) continue;
            CGRect frame = [view convertRect:view.bounds toView:container];
            if (views == leftViews) { left = MAX(left, CGRectGetMaxX(frame) + 8); centerY = CGRectGetMidY(frame); }
            else right = MIN(right, CGRectGetMinX(frame) - 8);
        }
    }
    CGFloat width = DYYYFansProfileButtonWidth(right - left);
    button.hidden = width == 0 || container.bounds.size.height < 36;
    [button setTitle:width > 44 ? @" 星牌" : @"" forState:UIControlStateNormal];
    button.frame = CGRectMake(left, MAX(0, MIN(container.bounds.size.height - 36, centerY - 18)), width, 36);
    [container bringSubviewToFront:button];
}
static void DYYYFansInstallProfile(void) {
    static BOOL installed[4]; NSArray *selectors = @[@"viewDidLayoutSubviews", @"viewDidAppear", @"reloadData", @"viewDidDisappear"];
    Class cls = NSClassFromString(@"AWEProfileNavigationBaseComponent");
    for (NSUInteger i = 0; i < selectors.count; i++) {
        if (installed[i]) continue; SEL sel = NSSelectorFromString(selectors[i]); Method method = class_getInstanceMethod(cls, sel);
        if (!DYYYFansMatch(method, "v", "")) continue;
        IMP original = method_getImplementation(method); BOOL hiding = i == 3;
        IMP replacement = imp_implementationWithBlock(^(id owner) {
            ((void (*)(id, SEL))original)(owner, sel);
            if (hiding) { UIView *view = DYYYFansRead(owner, @"navigationContainerView"); UIView *button = objc_getAssociatedObject(view, DYYYFansProfileButtonKey); button.hidden = YES; }
            else DYYYFansUpdateProfile(owner);
        });
        class_replaceMethod(cls, sel, replacement, method_getTypeEncoding(method)); installed[i] = YES;
    }
    static BOOL hitInstalled; if (hitInstalled) return;
    Class container = NSClassFromString(@"AWEProfileNavigationContainerView"); SEL sel = @selector(hitTest:withEvent:); Method method = class_getInstanceMethod(container, sel);
    if (!method) return;
    NSMethodSignature *signature = [NSMethodSignature signatureWithObjCTypes:method_getTypeEncoding(method)];
    if (signature.numberOfArguments != 4 || signature.methodReturnType[0] != '@' || strcmp([signature getArgumentTypeAtIndex:2], @encode(CGPoint)) != 0 || [signature getArgumentTypeAtIndex:3][0] != '@') return;
    IMP original = method_getImplementation(method);
    IMP replacement = imp_implementationWithBlock(^UIView *(UIView *owner, CGPoint point, UIEvent *event) {
        DYYYFansProfileButton *button = objc_getAssociatedObject(owner, DYYYFansProfileButtonKey);
        if (DYYYFansEnabled(@"DYYYFansC.Profile") && owner.userInteractionEnabled && !owner.hidden && owner.alpha > 0.05 && button && !button.hidden && button.alpha > 0.05) {
            CGPoint local = [button convertPoint:point fromView:owner];
            if ([button pointInside:local withEvent:event]) return button;
        }
        return ((UIView *(*)(id, SEL, CGPoint, id))original)(owner, sel, point, event);
    });
    class_replaceMethod(container, sel, replacement, method_getTypeEncoding(method)); hitInstalled = YES;
}
void DYYYInstallFansHooks(void) {
    DYYYFansInstallProfile();
    // 2.2-9-61：删掉 -57 移植时引入的全局 NSUserDefaultsDidChangeNotification 订阅。
    // 定罪证据（-60 单变量测试）：-59 不冻，-60 只加回 constructor 就冻；constructor
    // 本身只做一次性的轻量装钩，唯一持续生效的东西就是这个订阅。
    // 移植 bug：上游 DY778 订的是自家自定义通知 DY778PreferencesChangedNotification，
    // 只在 DY778 自己改设置时才发（DY778Core.m 的 DY778Set）；移植时被换成了全局
    // NSUserDefaultsDidChangeNotification，抖音自己、DYYY、系统任何一次写 defaults
    // 都会触发，主队列块再给每个个人主页 owner 各跑一次 DYYYFansUpdateProfile
    // （视图遍历 + convertRect + 读 userModel），主线程被这个放大器占满就冻住。
    // 改法（选 a）：不再注册任何全局通知订阅。个人主页的更新只靠已有的生命周期钩
    // （viewDidLayoutSubviews/viewDidAppear/reloadData/viewDidDisappear 调
    // DYYYFansUpdateProfile），开关翻页回来后 viewDidAppear 会刷新，功能不受损；
    // 唯一损失是“已打开的个人主页页不会在设置里一拨开关就立刻刷新”，可接受。
    // DYYYFansUI.m:46 查询页里的同名订阅不动：它只在查询页打开时存在，且不是
    // 启动冻屏的原因（查询页启动时不在屏幕上）。
}

// 2.2-9-60：星牌 constructor 单独加回（单变量测试）。-59 为查冻屏一次性摘了
// 四样东西（状态标签钩、LivePreview 的 defaults 订阅、重试多给的两轮、星牌
// constructor），用户确认 -59 不冻；-60 只加回星牌这一项，其他三样不加回。
// 用户 2026-11-11 10:55 确认 -60 会冻住，星牌安装定罪为冻因之一。
// 2.2-9-61：constructor 保留（它本身只做一次性轻量装钩，是无辜的），
// 冻因是 DYYYInstallFansHooks 里那个全局 NSUserDefaultsDidChangeNotification
// 订阅（见上方的注释），已删掉；不再加回 -59 摘掉的其他三样东西。
// .m 不能用 Logos 的 %ctor，故用等价的 __attribute__((constructor))；安装逻辑
// 与原版 %ctor 方案完全相同。
__attribute__((constructor)) static void DYYYFansStart(void) {
    dispatch_async(dispatch_get_main_queue(), ^{ DYYYInstallFansHooks(); });
}
