# Linux build notes (this VM, verified 2026-11-02)

Toolchain (all under ~, not /tmp):
- Theos cloned to ~/theos, submodules updated, SDK iPhoneOS16.5.sdk
  copied to ~/theos/sdks/ (sparse checkout from theos/sdks).
- System clang 18 fails on SDK 16.5 libc++ modules; use clang-14:
  apt install clang-14 lld-14, symlinks in ~/toolchain-clang14/bin/:
  clang -> clang-14, clang++ -> clang++-14, ld/ld64/ld64.lld -> ld.lld-14,
  strip -> llvm-strip-14, lipo -> llvm-lipo-14, ldid -> Procursus ldid
  v2.1.5-procursus7 (downloaded binary, Ubuntu has no ldid package).
- DYYYPlatformVersion.m is a Linux-only hidden-visibility shim for
  __isPlatformVersionAtLeast (compiler-rt symbol missing on Linux clang).
  Remove it from DYYY_FILES when building with an Apple toolchain.
- Linux clang-14 emits cpusubtype 0 for both arm64 and arm64e, so a fat
  lipo merge refuses (same architecture). Workaround used here: build
  ARCHS=arm64 only (thin dylib, loads on arm64e devices as arm64 fallback).

Build command (from this directory, umask 022 matters for dm.pl):
  export THEOS=~/theos
  umask 022
  make package SDKBINPATH=~/toolchain-clang14/bin \
    DYYY_LDFLAGS="-fuse-ld=lld" ARCHS=arm64

Verified output: packages/com.huami.dyyy_2.2-9-2_iphoneos-arm.deb
(359,618 bytes, thin arm64, signed with ldid, layout
Library/MobileSubstrate/DynamicLibraries/DYYY.dylib + DYYY.plist).
Note: source is 2.2-9 (2026-05-31), NOT the installed 2.3-0 — any package
built from this source is a version downgrade vs the user's 2.3-0 build.
