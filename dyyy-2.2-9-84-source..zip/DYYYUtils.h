#import <Photos/Photos.h>
#import <QuartzCore/QuartzCore.h>
#import <UIKit/UIKit.h>
#import "AwemeHeaders.h"
#import "CityManager.h"

NS_ASSUME_NONNULL_BEGIN

@class YYAnimatedImageView;
@class AVAssetTrack;

@interface DYYYUtils : NSObject

/**
 * @brief 处理并更新UILabel以显示IP属地。
 * 该函数包含国内地址直接解析和国外地址API请求及缓存的完整逻辑。
 * 对于需要异步更新UI的情况（如API请求），该函数内部会处理dispatch到主线程。
 * @param label 需要更新的UILabel实例。
 * @param model 包含IP属地信息（如cityCode）的视频数据模型。
 * @param colorHexString 由于国外IP查询是异步的，颜色需要在此函数内部的回调中应用，以确保文本和颜色同步更新。
 */
+ (void)processAndApplyIPLocationToLabel:(UILabel *)label forModel:(AWEAwemeModel *)model withLabelColor:(NSString *)colorHexString;

#pragma mark - Public UI/Window/Controller Utilities (公共 UI/窗口/控制器 工具)

/**
 * 获取当前活动窗口
 */
+ (UIWindow *)getActiveWindow;

/**
 * 液态玻璃（iOS 26+ UIGlassEffect，运行时动态取，不依赖新 SDK 头文件）：
 * glassEffectAvailable 为真才表示当前系统有 UIGlassEffect；
 * regularGlassEffect 返回系统 Regular 玻璃（interactive=YES），无玻璃时返回 nil。
 * 调用方用开关控制、关时恢复原 effect，见 DYYYGlass.xm。
 */
+ (BOOL)glassEffectAvailable;
+ (UIVisualEffect *)regularGlassEffect;
+ (UIVisualEffect *)clearGlassEffect;

/**
 * 获取当前显示的顶层视图控制器
 * @return 顶层视图控制器
 */
+ (UIViewController *)topView;

/* 在视图控制器层级中查找指定类的控制器 */
+ (UIViewController *)firstAvailableViewControllerFromView:(UIView *)view;
+ (UIViewController *)findViewControllerOfClass:(Class)targetClass inViewController:(UIViewController *)vc;

+ (UIResponder *)findAncestorResponderOfClass:(Class)targetClass fromView:(UIView *)view;

/*
 * @brief 查找指定控制器/视图层级中所有属于特定类的视图。
 * @param targetClass 要查找的视图类。
 * @param container   要开始搜索的控制器或视图。
 * @return 包含所有匹配视图的数组，如果未找到则返回空数组。
 */
+ (NSArray<__kindof UIView *> *)findAllSubviewsOfClass:(Class)targetClass inContainer:(id)container;

/*
 * @brief 查找指定控制器/视图层级中首个属于特定类的视图。
 * @param targetClass 要查找的视图类。
 * @param container   要开始搜索的控制器或视图。
 * @return 第一个匹配的视图实例，如果未找到则返回 nil。
 */
+ (__kindof UIView *)findSubviewOfClass:(Class)targetClass inContainer:(id)container;

/*
 * @brief 计算视图组在其视图层级中最近的公共父视图。
 * @param views 包含多个 UIView 对象的数组。
 * @return 所有输入视图的最近公共父视图。如果数组为空或视图们没有公共父视图，则返回 nil。
 */
+ (__kindof UIView *)nearestCommonSuperviewOfViews:(NSArray<UIView *> *)views;

/*
 * @brief 查找指定控制器/视图层级中是否包含特定类的视图。
 * @param targetClass 要查找的视图类。
 * @param container   要开始搜索的控制器或视图。
 * @return 如果找到则返回 YES，否则返回 NO。
 */
+ (BOOL)containsSubviewOfClass:(Class)targetClass inContainer:(id)container;

+ (void)applyBlurEffectToView:(UIView *)view transparency:(float)userTransparency blurViewTag:(NSInteger)tag;
+ (void)clearBackgroundRecursivelyInView:(UIView *)view;

/**
 * 显示提示信息
 * @param text 要显示的文本
 */
+ (void)showToast:(NSString *)text;

/**
 * 检查当前是否为暗黑模式
 */
+ (BOOL)isDarkMode;

#pragma mark - Public File Management (公共文件管理)

/**格式化大小
 * 将大小转换为易读的格式
 * @param size 文件大小（字节数）
 * @return 格式化后的字符串，例如 "1.5 MB"
 */
+ (NSString *)formattedSize:(unsigned long long)size;

/**
 * 递归统计目录大小
 */
+ (unsigned long long)directorySizeAtPath:(NSString *)directoryPath;
/**
 * 递归删除目录下所有内容
 */
+ (void)removeAllContentsAtPath:(NSString *)directoryPath;

/**
 * 返回插件缓存目录路径，默认为 tmp/DYYY
 */
+ (NSString *)cacheDirectory;

/**
 * 清理插件缓存目录
 */
+ (void)clearCacheDirectory;

/**
 * 在缓存目录下生成指定文件名的完整路径
 */
+ (NSString *)cachePathForFilename:(NSString *)filename;

#pragma mark - Public Media Helper Methods (公共媒体工具方法)

/**
 * 根据文件头判断媒体格式（webp/heic/heif/gif/png/jpeg）
 */
+ (NSString *)detectFileFormat:(NSURL *)fileURL;

/**
 * 媒体类型文案
 */
+ (NSString *)mediaTypeDescription:(MediaType)mediaType;

/**
 * 缩放图片到指定尺寸
 */
+ (UIImage *)resizeImage:(UIImage *)image toSize:(CGSize)size;

/**
 * 计算图片在容器内按比例居中的绘制区域
 */
+ (CGRect)rectForImageAspectFit:(CGSize)imageSize inSize:(CGSize)containerSize;

/**
 * 计算视频轨道在目标尺寸下的等比变换
 */
+ (CGAffineTransform)transformForAssetTrack:(AVAssetTrack *)track targetSize:(CGSize)targetSize;

/**
 * 计算图片在目标尺寸下的等比变换
 */
+ (CGAffineTransform)transformForImage:(UIImage *)image targetSize:(CGSize)targetSize;

/**
 * 判断图片是否为带 heif/heic URL 的 BDImage
 */
+ (BOOL)isBDImageWithHeifURL:(UIImage *)image;

/**
 * 从 YYAnimatedImageView 提取帧数组
 */
+ (NSArray *)getImagesFromYYAnimatedImageView:(YYAnimatedImageView *)imageView;

/**
 * 获取 YYAnimatedImageView 动图总时长
 */
+ (CGFloat)getDurationFromYYAnimatedImageView:(YYAnimatedImageView *)imageView;

/**
 * 使用 YYImage 解码动图数据，返回帧图像和总时长
 */
+ (BOOL)framesFromAnimatedData:(NSData *)data
                         scale:(CGFloat)scale
                        images:(NSArray<UIImage *> *_Nullable *)images
                 totalDuration:(CGFloat *_Nullable)totalDuration;

/**
 * 根据帧数组生成 GIF 文件
 */
+ (BOOL)createGIFWithImages:(NSArray *)images duration:(CGFloat)duration path:(NSString *)path progress:(void (^)(float progress))progressBlock;

/**
 * 保存 GIF 到相册并清理临时文件
 */
+ (void)saveGIFToPhotoLibrary:(NSString *)path completion:(void (^)(BOOL success, NSError *error))completion;

/**
 * 保存 GIF(URL) 到相册并删除源文件
 */
+ (void)saveGifToPhotoLibrary:(NSURL *)gifURL completion:(void (^)(BOOL success))completion;

/**
 * 判断视频是否包含音频轨道
 */
+ (BOOL)videoHasAudio:(NSURL *)videoURL;

/**
 * 下载音频并合并到视频
 */
+ (void)downloadAudioAndMergeWithVideo:(NSURL *)videoURL
                              audioURL:(NSURL *)audioURL
                            completion:(void (^)(BOOL success, NSURL *mergedURL))completion;

/**
 * 合并视频和音频
 */
+ (void)mergeVideo:(NSURL *)videoURL
         withAudio:(NSURL *)audioURL
        completion:(void (^)(BOOL success, NSURL *mergedURL))completion;

/**
 * 将 WebP 转换为 GIF
 */
+ (void)convertWebpToGifSafely:(NSURL *)webpURL completion:(void (^)(NSURL *gifURL, BOOL success))completion;

/**
 * 将 HEIC/HEIF 转换为 GIF
 */
+ (void)convertHeicToGif:(NSURL *)heicURL completion:(void (^)(NSURL *gifURL, BOOL success))completion;

#pragma mark - Public Color Scheme Methods (公共颜色方案方法)

/**
 * @brief 递归地将指定的文本颜色应用到视图及其所有子视图中的 UILabel 和 UIButton。
 *        可以通过 shouldExcludeViewBlock 提供自定义的排除逻辑。
 * @param color 要应用的文本颜色。
 * @param view 起始视图。
 * @param excludeBlock 一个 Block，用于判断是否应该排除某个视图。如果 Block 返回 YES，则该视图不会被应用颜色。可以为 nil。
 */
+ (void)applyTextColorRecursively:(UIColor *)color inView:(UIView *)view shouldExcludeViewBlock:(BOOL (^)(UIView *subview))excludeBlock;

/**
 * @brief 将指定的颜色字符串方案应用到 UILabel 上，实现像素级渐变。
 *        此方法通过修改 UILabel 的 attributedText 来实现颜色效果。
 * @param label 要应用颜色的 UILabel。
 * @param colorHexString 颜色方案字符串
 *        - "rainbow" 或 "#rainbow": 七色渐变彩虹固定方案（红橙黄绿青蓝紫）。
 *        - "rainbow_rotating" 或 "#rainbow_rotating": 七色渐变彩虹旋转方案（每次调用时旋转起始颜色）。
 *        - "random_gradient" 或 "#random_gradient": 随机三色渐变方案（每次调用时随机生成三种颜色）。
 *        - "random" 或 "#random": 返回一个随机单色（每次调用时随机生成颜色）。
 *        - "HEX1,HEX2,..." 或 "#HEX1,#HEX2,...": 返回一个多色渐变方案，支持任意数量的十六进制颜色。
 *        - "HEX" 或 "#HEX": 返回一个单色方案。
 */
+ (void)applyColorSettingsToLabel:(UILabel *)label colorHexString:(NSString *)colorHexString;
+ (void)applyStrokeToLabel:(UILabel *)label strokeColor:(UIColor *)strokeColor strokeWidth:(CGFloat)strokeWidth;
+ (void)applyShadowToLabel:(UILabel *)label shadow:(NSShadow *)shadow;

/**
 * @brief 根据十六进制字符串返回一个适合用于图案填充的 UIColor。
 *        此方法主要用于 UILabel.textColor 等需要 UIColor 对象的场景。
 * @param hexString 颜色方案字符串，用法见 applyColorSettingsToLabel
 * @param targetWidth UIImage 需要的宽度
 * @return 配置好的 UIColor 实例。如果无法解析，返回白色。
 *         - 对于单色或随机色，直接返回对应的 UIColor 对象。
 *         - 对于渐变色，它会渲染一个单像素高度和 targetWidth 宽度的 UIImage 用于图案填充。
 */
+ (UIColor *)colorFromSchemeHexString:(NSString *)hexString targetWidth:(CGFloat)targetWidth;

/**
 * @brief 根据十六进制字符串返回一个配置好的 CALayer (纯色或渐变)。
 *        此方法适用于将颜色方案作为 CALayer 的 mask 或直接作为子层。
 * @param hexString 颜色方案字符串，用法见 applyColorSettingsToLabel
 * @param frame CALayer 的 frame。
 * @return 配置好的 CALayer 实例。如果无法解析或 frame 无效，返回 nil。
 *         - 对于纯色或随机色，返回一个 `CALayer` 实例，其 `backgroundColor` 已设置。
 *         - 对于渐变色返回一个 `CAGradientLayer` 实例。
 *         - 如果无法解析或 `frame` 无效，返回 `nil`。
 */
+ (CALayer *)layerFromSchemeHexString:(NSString *)hexString frame:(CGRect)frame;

#pragma mark - Version Utilities

/**
 * 按照点分格式比较版本号，例如 36.5.0
 * @return lhs < rhs 返回 NSOrderedAscending，lhs > rhs 返回 NSOrderedDescending，相等返回 NSOrderedSame
 */
+ (NSComparisonResult)compareVersion:(NSString *)lhs toVersion:(NSString *)rhs;

@end

#pragma mark - External C Functions (外部 C 函数)

#ifdef __cplusplus
extern "C" {
#endif

/**
 * 清除分享URL中的查询参数
 * @param url 需要清理的URL字符串
 * @return 清理后的URL字符串
 */
NSString *_Nullable cleanShareURL(NSString *_Nullable url);

/**
 * 获取当前显示的顶层视图控制器
 * @return 顶层视图控制器
 */
UIViewController *_Nullable topView(void);

/** 在视图控制器层级中查找指定类的控制器 */
UIViewController *_Nullable findViewControllerOfClass(UIViewController *_Nullable rootVC, Class _Nullable targetClass);

/** 根据设置应用顶栏透明度 */
void applyTopBarTransparency(UIView *_Nullable topBar);

/**
 * 递归将任意对象转换为 JSON 可序列化对象
 */
id DYYYJSONSafeObject(id _Nullable obj);

#ifdef __cplusplus
}
#endif

NS_ASSUME_NONNULL_END
