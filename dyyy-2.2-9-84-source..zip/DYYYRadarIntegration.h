// DYYYRadarIntegration.h — 特别关注安装入口。
// DYYYInstallRadar()：幂等（dispatch_once），只启动前台检测调度并订阅本模块自己的
// DYYYRadarMonitorAlert 提醒通知；不订阅全局 NSUserDefaultsDidChangeNotification，
// 不做任何 Hook、不改任何抖音类。开关默认关闭，运行时由 DYYYRadarEnabled 门控。
#import <Foundation/Foundation.h>

void DYYYInstallRadar(void);

// 可选接线（父代理在聊天设置 Hook 里调用，非 Hook 本身）：
// 把“对此人特别关注”开关追加到私信设置项列表。未接线时此函数不被调用，无任何影响。
void DYYYRadarAppendChatItem(id provider, NSMutableArray *items);
