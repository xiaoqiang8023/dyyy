// DYYYLiveInfoSettingsViewController.m — “直播信息”独立设置页（2.2-9-68）。
// 照抄 DY778 作者原版（DY778Settings.m liveInfo 页 + 用户 2026-11-11 发的作者截图）：
// 独立页、深青开关/图标、滑杆行、胶囊样式合一、颜色圆点。滑杆、颜色、选择行
// 的结构、标题、副标题、图标名、行顺序全部按原版；设置键、默认值、胶囊功能
// 逻辑保持 DYYY -56/-62 原样，只改设置页。
// 注意：作者 1.0-3 源码里没有“卡片胶囊样式”和“恢复直播卡片位置”这两行，
// 它们是作者新版截图里的行——按截图补上，键复用 DYYY 已有的三键 + 位置重置。
#import "DYYYLiveInfoSettingsViewController.h"
#import "DYYYLiveInfoCapsuleEditorViewController.h"
#import "DYYYOptionsSelectionView.h"
#import "AwemeHeaders.h"
#import "DYYYSettingsHelper.h"
#import "DYYYUtils.h"
#import <objc/runtime.h>

static UIColor *DYYYLiveInfoCardBackground(void) {
    // 照抄 DY778CardBackground：浅色白、深色 #1B1E21。
    return [UIColor colorWithDynamicProvider:^UIColor *(UITraitCollection *trait) {
        return trait.userInterfaceStyle == UIUserInterfaceStyleDark ?
            [UIColor colorWithRed:.105 green:.119 blue:.13 alpha:1] : UIColor.whiteColor;
    }];
}

// MARK: - 取值（键与默认值保持 DYYY 原样，值一律按字符串存取）

static double DYYYLiveInfoDouble(NSString *key, double fallback) {
    NSString *raw = DYYYGetString(key);
    if (!raw.length) return fallback;
    double value = [raw doubleValue];
    return (value == 0 && ![raw isEqualToString:@"0"] && ![raw isEqualToString:@"0.0"]) ? fallback : value;
}

static double DYYYLiveInfoRefresh(void) {
    return fmin(10, fmax(2, round(DYYYLiveInfoDouble(@"DYYYLivePreviewRefresh", 3))));
}

static double DYYYLiveInfoFontSize(void) {
    double value = DYYYLiveInfoDouble(@"DYYYLiveDurationFontSize", 13);
    if (value <= 0) value = 13;
    return fmin(19, fmax(11, round(value)));
}

static double DYYYLiveInfoOpacity(void) {
    double value = DYYYLiveInfoDouble(@"DYYYLiveDurationOpacity", 0.64);
    if (value <= 0) value = 0.64;
    return fmin(1, fmax(0.15, value));
}

// 颜色解析：十六进制或中文名（照抄 DYYY.xm 里 DYYYLiveDurationColorFromHexString 的映射）。
static UIColor *DYYYLiveInfoColorFromString(NSString *raw, UIColor *fallback) {
    NSString *hex = raw ? [raw stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]] : nil;
    if (!hex.length) return fallback;
    if ([hex hasPrefix:@"#"]) hex = [hex substringFromIndex:1];
    NSDictionary *names = @{@"白色":@"FFFFFF", @"黑色":@"000000", @"黄色":@"FFD84D", @"粉色":@"FF8FB3",
                            @"浅蓝":@"8FD0FF", @"红色":@"FF3B30", @"绿色":@"34C759"};
    NSString *mapped = names[hex];
    if (mapped) hex = mapped;
    if (hex.length != 6) return fallback;
    NSCharacterSet *invalid = [[NSCharacterSet characterSetWithCharactersInString:@"0123456789abcdefABCDEF"] invertedSet];
    if ([hex rangeOfCharacterFromSet:invalid].location != NSNotFound) return fallback;
    unsigned int rgb = 0;
    if (![[NSScanner scannerWithString:hex] scanHexInt:&rgb]) return fallback;
    return [UIColor colorWithRed:((rgb >> 16) & 0xFF) / 255.0 green:((rgb >> 8) & 0xFF) / 255.0 blue:(rgb & 0xFF) / 255.0 alpha:1.0];
}

static NSString *DYYYLiveInfoHexString(NSString *raw, NSString *fallbackHex) {
    UIColor *color = DYYYLiveInfoColorFromString(raw, nil);
    if (!color) return fallbackHex;
    CGFloat r = 0, g = 0, b = 0, a = 1;
    if (![color getRed:&r green:&g blue:&b alpha:&a]) return fallbackHex;
    return [NSString stringWithFormat:@"#%02X%02X%02X", (int)round(r * 255), (int)round(g * 255), (int)round(b * 255)];
}

// MARK: - 滑杆行（照抄 DY778SliderCell：标题 + 数值一行、滑杆在下，纯 Auto Layout）

@interface DYYYLiveInfoSliderCell : UITableViewCell
@property(nonatomic, strong) UILabel *nameLabel;
@property(nonatomic, strong) UILabel *valueLabel;
@property(nonatomic, strong) UISlider *slider;
@property(nonatomic, copy) NSString *preferenceKey;
@property(nonatomic, copy) NSString *unit;
@end

@implementation DYYYLiveInfoSliderCell

- (instancetype)init {
    if ((self = [super initWithStyle:UITableViewCellStyleDefault reuseIdentifier:nil])) {
        self.backgroundColor = DYYYLiveInfoCardBackground();
        self.selectionStyle = UITableViewCellSelectionStyleNone;
        _nameLabel = [UILabel new];
        _nameLabel.font = [UIFont preferredFontForTextStyle:UIFontTextStyleBody];
        _nameLabel.adjustsFontForContentSizeCategory = YES;
        _nameLabel.numberOfLines = 0;
        _nameLabel.textColor = UIColor.labelColor;
        _valueLabel = [UILabel new];
        _valueLabel.font = [UIFont monospacedDigitSystemFontOfSize:13 weight:UIFontWeightMedium];
        _valueLabel.textColor = [DYYYLiveInfoSettingsViewController accentColor];
        [_valueLabel setContentCompressionResistancePriority:UILayoutPriorityRequired forAxis:UILayoutConstraintAxisHorizontal];
        UIStackView *top = [[UIStackView alloc] initWithArrangedSubviews:@[_nameLabel, _valueLabel]];
        top.spacing = 12;
        _slider = [UISlider new];
        _slider.minimumTrackTintColor = [DYYYLiveInfoSettingsViewController accentColor];
        [_slider addTarget:self action:@selector(changed:) forControlEvents:UIControlEventValueChanged];
        UIStackView *stack = [[UIStackView alloc] initWithArrangedSubviews:@[top, _slider]];
        stack.axis = UILayoutConstraintAxisVertical;
        stack.spacing = 7;
        stack.translatesAutoresizingMaskIntoConstraints = NO;
        [self.contentView addSubview:stack];
        [NSLayoutConstraint activateConstraints:@[
            [stack.leadingAnchor constraintEqualToAnchor:self.contentView.leadingAnchor constant:20],
            [stack.trailingAnchor constraintEqualToAnchor:self.contentView.trailingAnchor constant:-20],
            [stack.topAnchor constraintEqualToAnchor:self.contentView.topAnchor constant:15],
            [stack.bottomAnchor constraintEqualToAnchor:self.contentView.bottomAnchor constant:-12],
            [_slider.heightAnchor constraintGreaterThanOrEqualToConstant:36]
        ]];
    }
    return self;
}

- (void)updateValue {
    if ([self.unit isEqualToString:@"%"]) {
        self.valueLabel.text = [NSString stringWithFormat:@"%.0f%%", self.slider.value * 100];
    } else if ([self.unit isEqualToString:@"pt"]) {
        self.valueLabel.text = [NSString stringWithFormat:@"%.0f pt", self.slider.value];
    } else {
        self.valueLabel.text = [NSString stringWithFormat:@"%.1f 秒", self.slider.value];
    }
    self.slider.accessibilityValue = self.valueLabel.text;
}

- (void)changed:(UISlider *)slider {
    // 秒 / pt 取整；不透明度保留 2 位小数。值一律按字符串存（DYYY 原有格式）。
    float value = slider.value;
    NSString *stored = nil;
    if ([self.unit isEqualToString:@"%"]) {
        value = roundf(value * 100) / 100;
        stored = [NSString stringWithFormat:@"%.2f", value];
    } else {
        value = roundf(value);
        stored = [NSString stringWithFormat:@"%.0f", value];
    }
    slider.value = value;
    [self updateValue];
    [DYYYSettingsHelper setUserDefaults:stored forKey:self.preferenceKey];
}

@end

// MARK: - 设置页

@interface DYYYLiveInfoSettingsViewController ()
@property(nonatomic, strong) NSArray *sections;
@end

@implementation DYYYLiveInfoSettingsViewController

+ (UIColor *)accentColor {
    // 照抄 DY778Accent：底色 #55CDB9，浅色下亮度 >.5 时 ×0.58 变深（约 #31776B）。
    static UIColor *accent;
    static dispatch_once_t once;
    dispatch_once(&once, ^{
        UIColor *base = [UIColor colorWithRed:0x55 / 255.0 green:0xCD / 255.0 blue:0xB9 / 255.0 alpha:1.0];
        accent = [UIColor colorWithDynamicProvider:^UIColor *(UITraitCollection *trait) {
            CGFloat r = 0, g = 0, b = 0, a = 1;
            [base getRed:&r green:&g blue:&b alpha:&a];
            if (trait.userInterfaceStyle != UIUserInterfaceStyleDark && (.2126 * r + .7152 * g + .0722 * b) > .5) {
                r *= .58; g *= .58; b *= .58;
            }
            return [UIColor colorWithRed:r green:g blue:b alpha:1];
        }];
    });
    return accent;
}

- (instancetype)init {
    if ((self = [super initWithStyle:UITableViewStyleInsetGrouped])) {
        self.title = @"直播信息";
    }
    return self;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    self.tableView.backgroundColor = UIColor.systemGroupedBackgroundColor;
    self.tableView.rowHeight = UITableViewAutomaticDimension;
    self.tableView.estimatedRowHeight = 72;
    self.tableView.sectionHeaderHeight = UITableViewAutomaticDimension;
    self.tableView.sectionFooterHeight = UITableViewAutomaticDimension;
    self.tableView.showsVerticalScrollIndicator = NO;
    self.tableView.separatorInset = UIEdgeInsetsMake(0, 20, 0, 20);
    if (@available(iOS 15.0, *)) self.tableView.sectionHeaderTopPadding = 6;
    [self buildSections];
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    [self buildSections];
    [self.tableView reloadData];
}

#pragma mark - 行模型（结构、标题、副标题、图标、行顺序全部照抄作者原版）

static NSDictionary *DYYYLiveInfoRow(NSString *title, NSString *subtitle, NSString *kind, NSString *key, NSString *icon) {
    return @{@"title": title ?: @"", @"subtitle": subtitle ?: @"", @"kind": kind, @"key": key ?: @"", @"icon": icon ?: @"circle"};
}

static NSDictionary *DYYYLiveInfoRange(NSString *title, NSString *key, double low, double high, NSString *unit) {
    NSMutableDictionary *row = [DYYYLiveInfoRow(title, @"", @"slider", key, @"slider.horizontal.3") mutableCopy];
    row[@"min"] = @(low);
    row[@"max"] = @(high);
    row[@"unit"] = unit;
    return row;
}

static NSDictionary *DYYYLiveInfoSection(NSString *title, NSString *footer, NSArray *rows) {
    return @{@"title": title, @"footer": footer ?: @"", @"rows": rows};
}

- (void)buildSections {
    self.sections = @[
        DYYYLiveInfoSection(@"推荐页直播卡片",
            @"卡片停稳且已开启项目的数据齐全后，整组显示在卡片中下方。拖动后优先使用保存的位置，横竖屏分别记忆。人数与时长上下排列；卡片不可见或进入后台暂停刷新。",
            @[
                DYYYLiveInfoRow(@"显示在线人数", @"无需进入直播间，查看当前可读取的人数", @"switch", @"DYYYLivePreviewViewers", @"person.2.fill"),
                DYYYLiveInfoRow(@"人数格式", @"", @"choice", @"DYYYLivePreviewCountFormat", @"slider.horizontal.3"),
                DYYYLiveInfoRange(@"人数刷新间隔", @"DYYYLivePreviewRefresh", 2, 10, @"秒"),
                DYYYLiveInfoRow(@"显示开播时长", @"独立于在线人数开关", @"switch", @"DYYYLivePreviewCardDuration", @"clock"),
                DYYYLiveInfoRow(@"卡片胶囊样式", @"对齐、上下顺序、大小 · 预览后保存", @"nav", @"DYYYLiveInfoCapsuleStyle", @"slider.horizontal.3"),
                DYYYLiveInfoRow(@"恢复直播卡片位置", @"重置横屏和竖屏的在线人数与时长位置", @"action", @"DYYYLivePreviewResetCardPosition", @"arrow.uturn.backward"),
            ]),
        DYYYLiveInfoSection(@"直播间浮层",
            @"默认在画面上方居中显示，可拖动避开直播内容。横屏、竖屏分别记忆位置；返回直播间继续使用对应位置。未取得有效开播时间时暂不显示。",
            @[
                DYYYLiveInfoRow(@"显示开播时长", @"在当前直播间显示可拖动的时间胶囊", @"switch", @"DYYYShowLiveDuration", @"clock.fill"),
                DYYYLiveInfoRange(@"文字大小", @"DYYYLiveDurationFontSize", 11, 19, @"pt"),
                DYYYLiveInfoRow(@"文字颜色", @"同时应用于直播间胶囊图标", @"color", @"DYYYLiveDurationTextColor", @"textformat"),
                DYYYLiveInfoRow(@"背景颜色", @"仅调整直播间浮层", @"color", @"DYYYLiveDurationBackgroundColor", @"paintpalette"),
                DYYYLiveInfoRange(@"背景不透明度", @"DYYYLiveDurationOpacity", .15, 1, @"%"),
                DYYYLiveInfoRow(@"恢复默认位置", @"同时重置横屏和竖屏位置", @"action", @"DYYYLiveDurationResetPosition", @"arrow.uturn.backward"),
            ]),
        DYYYLiveInfoSection(@"显示说明",
            @"在线人数以本次可读取的数据为准，可能随直播间刷新节奏变化；开播时长依据房间返回的开播时间计算。卡片胶囊使用统一样式，不跟随直播间浮层的自定义配色。",
            @[]),
    ];
}

- (NSDictionary *)rowAt:(NSIndexPath *)path {
    return self.sections[path.section][@"rows"][path.row];
}

#pragma mark - 表格

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return self.sections.count;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return [self.sections[section][@"rows"] count];
}

- (NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section {
    return self.sections[section][@"title"];
}

- (NSString *)tableView:(UITableView *)tableView titleForFooterInSection:(NSInteger)section {
    NSString *footer = self.sections[section][@"footer"];
    return footer.length ? footer : nil;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)path {
    NSDictionary *row = [self rowAt:path];
    NSString *kind = row[@"kind"];
    NSString *key = row[@"key"];

    if ([kind isEqualToString:@"slider"]) {
        DYYYLiveInfoSliderCell *cell = [DYYYLiveInfoSliderCell new];
        cell.nameLabel.text = row[@"title"];
        cell.preferenceKey = key;
        cell.unit = row[@"unit"];
        cell.slider.minimumValue = [row[@"min"] floatValue];
        cell.slider.maximumValue = [row[@"max"] floatValue];
        if ([key isEqualToString:@"DYYYLivePreviewRefresh"]) {
            cell.slider.value = (float)DYYYLiveInfoRefresh();
        } else if ([key isEqualToString:@"DYYYLiveDurationFontSize"]) {
            cell.slider.value = (float)DYYYLiveInfoFontSize();
        } else {
            cell.slider.value = (float)DYYYLiveInfoOpacity();
        }
        cell.slider.accessibilityLabel = row[@"title"];
        [cell updateValue];
        return cell;
    }

    UITableViewCell *cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:nil];
    cell.backgroundColor = DYYYLiveInfoCardBackground();
    cell.textLabel.textColor = UIColor.labelColor;
    cell.textLabel.font = [UIFont preferredFontForTextStyle:UIFontTextStyleBody];
    cell.textLabel.adjustsFontForContentSizeCategory = YES;
    cell.textLabel.numberOfLines = 0;
    cell.textLabel.text = row[@"title"];
    cell.detailTextLabel.font = [UIFont preferredFontForTextStyle:UIFontTextStyleFootnote];
    cell.detailTextLabel.adjustsFontForContentSizeCategory = YES;
    cell.detailTextLabel.numberOfLines = 0;
    cell.detailTextLabel.textColor = UIColor.secondaryLabelColor;
    cell.detailTextLabel.text = row[@"subtitle"];
    cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
    cell.imageView.image = [UIImage systemImageNamed:row[@"icon"]];
    cell.imageView.tintColor = [DYYYLiveInfoSettingsViewController accentColor];
    cell.contentView.directionalLayoutMargins = NSDirectionalEdgeInsetsMake(17, 20, 17, 16);

    if ([kind isEqualToString:@"switch"]) {
        UISwitch *toggle = [UISwitch new];
        toggle.on = DYYYGetBool(key);
        toggle.onTintColor = [DYYYLiveInfoSettingsViewController accentColor];
        toggle.accessibilityLabel = row[@"title"];
        toggle.accessibilityHint = row[@"subtitle"];
        objc_setAssociatedObject(toggle, @selector(toggleChanged:), key, OBJC_ASSOCIATION_COPY_NONATOMIC);
        [toggle addTarget:self action:@selector(toggleChanged:) forControlEvents:UIControlEventValueChanged];
        cell.accessoryView = toggle;
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
    } else if ([kind isEqualToString:@"choice"]) {
        NSString *saved = DYYYGetString(key);
        cell.detailTextLabel.text = [saved isEqualToString:@"完整"] ? @"完整 · 12345" : @"简洁 · 1.2万";
    } else if ([kind isEqualToString:@"color"]) {
        BOOL isText = [key isEqualToString:@"DYYYLiveDurationTextColor"];
        NSString *raw = DYYYGetString(key);
        cell.detailTextLabel.text = DYYYLiveInfoHexString(raw, isText ? @"#FFFFFF" : @"#000000");
        UIView *swatch = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 28, 28)];
        swatch.backgroundColor = DYYYLiveInfoColorFromString(raw, isText ? UIColor.whiteColor : UIColor.blackColor);
        swatch.layer.cornerRadius = 14;
        swatch.layer.borderWidth = 1;
        swatch.layer.borderColor = [UIColor.separatorColor resolvedColorWithTraitCollection:self.traitCollection].CGColor;
        cell.accessoryView = swatch;
    } else if ([kind isEqualToString:@"nav"] || [kind isEqualToString:@"action"]) {
        cell.selectionStyle = UITableViewCellSelectionStyleDefault;
    }
    return cell;
}

- (void)toggleChanged:(UISwitch *)toggle {
    NSString *key = objc_getAssociatedObject(toggle, @selector(toggleChanged:));
    if (!key.length) return;
    [DYYYSettingsHelper setUserDefaults:@(toggle.on) forKey:key];
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)path {
    [tableView deselectRowAtIndexPath:path animated:YES];
    NSDictionary *row = [self rowAt:path];
    NSString *kind = row[@"kind"];
    NSString *key = row[@"key"];

    if ([kind isEqualToString:@"switch"] || [kind isEqualToString:@"slider"]) return;

    if ([kind isEqualToString:@"nav"]) {
        DYYYLiveInfoCapsuleEditorViewController *editor = [DYYYLiveInfoCapsuleEditorViewController new];
        [self.navigationController pushViewController:editor animated:YES];
        return;
    }

    if ([key isEqualToString:@"DYYYLivePreviewResetCardPosition"]) {
        NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
        [defaults removeObjectForKey:@"DYYYLivePreviewCardPortraitX"];
        [defaults removeObjectForKey:@"DYYYLivePreviewCardPortraitY"];
        [defaults removeObjectForKey:@"DYYYLivePreviewCardLandscapeX"];
        [defaults removeObjectForKey:@"DYYYLivePreviewCardLandscapeY"];
        [DYYYUtils showToast:@"已恢复直播卡片默认位置"];
        return;
    }

    if ([key isEqualToString:@"DYYYLiveDurationResetPosition"]) {
        NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
        [defaults removeObjectForKey:@"DYYYLiveDurationCenterXPercent"];
        [defaults removeObjectForKey:@"DYYYLiveDurationCenterYPercent"];
        [defaults removeObjectForKey:@"DYYYLiveDurationLandscapeCenterXPercent"];
        [defaults removeObjectForKey:@"DYYYLiveDurationLandscapeCenterYPercent"];
        [DYYYUtils showToast:@"已恢复直播时长默认位置"];
        return;
    }

    if ([kind isEqualToString:@"choice"]) {
        // 沿用 DYYY 现有的选项组件（与基本设置页的选项行一致）；示例写在行副标题里。
        __weak typeof(self) weakSelf = self;
        [DYYYOptionsSelectionView showWithPreferenceKey:key
                                            optionsArray:@[@"简洁", @"完整"]
                                              headerText:row[@"title"]
                                          onPresentingVC:self
                                        selectionChanged:^(__unused NSString *selectedValue) {
                                            [weakSelf.tableView reloadData];
                                        }];
        return;
    }

    if ([kind isEqualToString:@"color"]) {
        BOOL isText = [key isEqualToString:@"DYYYLiveDurationTextColor"];
        NSString *raw = DYYYGetString(key) ?: @"";
        __weak typeof(self) weakSelf = self;
        // 沿用 DYYY 现有的颜色输入方式（DYYYCustomInputView 文本输入，十六进制或中文名）。
        [DYYYSettingsHelper showTextInputAlert:row[@"title"]
                                    defaultText:raw
                                    placeholder:@"十六进制，如 FFFFFF，也支持中文名"
                                      onConfirm:^(NSString *text) {
                                          [DYYYSettingsHelper setUserDefaults:text ?: @"" forKey:key];
                                          [weakSelf.tableView reloadData];
                                      }
                                       onCancel:nil];
        (void)isText;
        return;
    }
}

@end
