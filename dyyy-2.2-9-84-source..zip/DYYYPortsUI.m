// DYYYPortsUI.m — 见 DYYYPortsUI.h。样式照抄 DYYYRadarUI.m 的 DYYYRadarCell。
#import "DYYYPortsUI.h"
#import "DYYYRadarUI.h"

static void DYYYPortsApplyConfig(UITableViewCell *cell, UIListContentConfiguration *config, NSString *symbol, BOOL disclosure) {
    config.textProperties.font = [UIFont preferredFontForTextStyle:UIFontTextStyleBody];
    config.textProperties.color = UIColor.labelColor;
    config.textProperties.numberOfLines = 0;
    config.secondaryTextProperties.numberOfLines = 0;
    config.secondaryTextProperties.font = [UIFont preferredFontForTextStyle:UIFontTextStyleFootnote];
    config.secondaryTextProperties.color = UIColor.secondaryLabelColor;
    config.textToSecondaryTextVerticalPadding = 5;
    config.directionalLayoutMargins = NSDirectionalEdgeInsetsMake(14, 20, 14, 20);
    if (symbol.length) {
        config.image = [UIImage systemImageNamed:symbol];
        config.imageProperties.tintColor = DYYYRadarAccent();
        config.imageProperties.maximumSize = CGSizeMake(28, 28);
        config.imageProperties.reservedLayoutSize = CGSizeMake(28, 28);
        config.imageToTextPadding = 14;
    }
    cell.contentConfiguration = config;
    cell.accessoryType = disclosure ? UITableViewCellAccessoryDisclosureIndicator : UITableViewCellAccessoryNone;
}

UITableViewCell *DYYYPortsIconCell(NSString *title, NSString *subtitle, NSString *symbol, BOOL disclosure) {
    UITableViewCell *cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:nil];
    cell.backgroundColor = DYYYRadarCardBackground();
    UIListContentConfiguration *config = [UIListContentConfiguration subtitleCellConfiguration];
    config.text = title;
    config.secondaryText = subtitle;
    DYYYPortsApplyConfig(cell, config, symbol, disclosure);
    return cell;
}

UITableViewCell *DYYYPortsValueCell(NSString *title, NSString *value, NSString *symbol, BOOL disclosure) {
    UITableViewCell *cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleValue1 reuseIdentifier:nil];
    cell.backgroundColor = DYYYRadarCardBackground();
    UIListContentConfiguration *config = [UIListContentConfiguration valueCellConfiguration];
    config.text = title;
    config.secondaryText = value;
    DYYYPortsApplyConfig(cell, config, symbol, disclosure);
    return cell;
}

void DYYYPortsConfigureTable(UITableView *tableView) {
    tableView.backgroundColor = UIColor.systemGroupedBackgroundColor;
    tableView.rowHeight = UITableViewAutomaticDimension;
    tableView.estimatedRowHeight = 70;
    tableView.sectionHeaderHeight = UITableViewAutomaticDimension;
    tableView.sectionFooterHeight = UITableViewAutomaticDimension;
}
