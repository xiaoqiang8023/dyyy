// DYYYLiveBoardApi.m — 见 DYYYLiveBoardApi.h。
// 取数瀑布（2.2-9-74）：星牌解析 roomID（主）→ room_data 副判 → reflow 兜底。
// 2026-11-11 真机：四位全报 -11001（com.aweme.network.error，
// “Covert from NSData to NSDictionary failed”）——A 路宿主 GET 回来的不是 JSON 字典。
// 核对结果：URL 与星牌完全一致（同 apiDomain/apiHost 解析、同 fallback 主机
// https://aweme.snssdk.com、同路径 /aweme/v1/user/profile/other/；
// -74 把 DYYYLiveBoardProfileOtherURL() 里多余的收藏接口中转也去掉了，
// 与星牌 DYYYFansAPIOrigin() 逐字一致）。唯一请求差异是参数：
// 星牌 service 的原生资料请求只带 user_id/sec_user_id，
// 而榜单 A 路多带了一个 source=other_profile——这是 -11001 的头号嫌疑。
// 所以 -74 的主路照抄星牌 service 的取数链（原生资料 + 网页资料），但不走
// DYYYFansService 单例：不调 prepare:（星牌开关关着就 403，榜单不该被它卡住）、
// 不抢星牌查询的单发状态机、不碰 progress UI。原生那步走 DYYYRadarNetwork
// 的宿主 GET，参数与星牌完全一致（不带 source）；网页那步直接用
// DYYYFansWebClient（NSURLSession + a_bogus，与宿主解析 -11001 无关）。
// 瀑布里每一步失败都继续往下走，只有三路都走完才记 error；
// “未开播”只在解析成功且确实没房间时才下结论（原生资料在本版抖音上经常
// 不带房间信息，不能凭它判未开播；网页资料那步才能判）。
// 在播后统一调 HTSLiveRoomAPI fetchRoomInfoWithRoomID（DYYYLivePreview.xm
// -56/-60 同款取数与解析），人数/开播时间先严格按 roomID 对号，
// 对不上再放宽取一次；还拿不到就只报“在播”，人数/时长留空。
#import "DYYYLiveBoardApi.h"
#import "DYYYLiveBoardModel.h"
#import "DYYYFansModel.h"
#import "DYYYFansRuntime.h"
#import "DYYYFansWeb.h"
#import "DYYYLiveBoardStore.h"
#import "DYYYRadarModel.h"
#import "DYYYRadarNetwork.h"

@implementation DYYYLiveBoardApi

// 步骤失败短记：只留步骤名 + 错误码，榜单副标题和页脚都能放下。
+ (NSString *)shortStepError:(NSError *)error label:(NSString *)label {
    return [NSString stringWithFormat:@"%@失败(%ld)", label, (long)error.code];
}

// 对一次资料响应同时跑两套解析：星牌 person（roomID）与 room_data。
// 返回：resolved（解析到的人与要查的主播对上号）、roomID（任一解析给出的有效房间号）、
// roomIDSource（@"fans"/@"profile"）、roomDataPresent/roomDataLive（room_data 的结论）。
// 解析到人时顺手把 secUID 补回 store（-73 的 backfill 由此替代：
// 只要解析到人就补，不用另起一轮；只写 secUID 字段，不动名字/自定义名字/头像）。
+ (NSDictionary *)interpretProfileResponse:(id)value anchor:(NSDictionary *)anchor {
    id user = DYYYFansRead(value, @"user") ?:
        DYYYFansRead(DYYYFansRead(value, @"data"), @"user") ?:
        DYYYFansRead(DYYYFansRead(value, @"data"), @"user_info") ?:
        DYYYFansRead(value, @"user_info") ?: value;
    NSDictionary *person = DYYYFansPerson(user);
    BOOL resolved = person && DYYYFansSamePerson(anchor, person);
    if (resolved) {
        NSString *sec = DYYYRadarString(person[@"secUID"]);
        if (sec.length && !DYYYRadarString(anchor[@"secUID"]).length) {
            NSString *uid = anchor[@"uid"];
            dispatch_async(dispatch_get_main_queue(), ^{
                [DYYYLiveBoardStore.shared updateSecUID:sec forUID:uid];
            });
        }
    }
    NSString *roomID = nil, *source = nil;
    if (resolved) {
        NSString *fansRoom = DYYYRadarString(person[@"roomID"]);
        if (DYYYRadarIdentifier(fansRoom) && ![fansRoom isEqual:@"0"]) { roomID = fansRoom; source = @"fans"; }
    }
    NSDictionary *roomData = DYYYLiveBoardParseRoomData(value);
    if (!roomID.length) {
        NSString *dataRoom = DYYYRadarString(roomData[@"roomID"]);
        if (DYYYRadarIdentifier(dataRoom) && ![dataRoom isEqual:@"0"]) { roomID = dataRoom; source = @"profile"; }
    }
    NSMutableDictionary *interpreted = [@{@"resolved": @(resolved),
             @"roomID": roomID ?: @"",
             @"roomIDSource": source ?: @"",
             @"roomDataPresent": roomData[@"present"] ?: @NO,
             @"roomDataLive": roomData[@"live"] ?: @NO} mutableCopy];
    // 2.2-9-81：room_data 里带场观时透传（有才加键，没有不占位）。
    if ([roomData[@"totalViewers"] isKindOfClass:NSNumber.class] && [roomData[@"totalViewers"] longLongValue] > 0) {
        interpreted[@"totalViewers"] = roomData[@"totalViewers"];
    }
    return interpreted;
}

// 对一次资料响应做判定。返回 YES 表示已定论（已调 finish 或已发起 fetchRoom），
// NO 表示继续下一路。allowOffline 只有网页那步传 YES：原生资料在本版抖音上
// 经常不带房间信息，不能凭它判未开播；网页资料解析成功且没房间才能判未开播。
+ (BOOL)applyProfileInterpretation:(NSDictionary *)interpreted finish:(void (^)(NSDictionary *, NSError *))finish allowOffline:(BOOL)allowOffline {
    NSString *roomID = DYYYRadarString(interpreted[@"roomID"]);
    if (roomID.length) {
        [self fetchRoom:roomID source:DYYYRadarString(interpreted[@"roomIDSource"]) completion:finish];
        return YES;
    }
    if ([interpreted[@"roomDataLive"] boolValue]) {
        // room_data 说在播但没给房间号：报在播，人数/时长留空（-71 原有行为）。
        // 2.2-9-81：room_data 里带场观时一起带上。
        NSMutableDictionary *result = [@{@"live": @YES, @"source": @"profile", @"checkedAt": @(NSDate.date.timeIntervalSince1970)} mutableCopy];
        if ([interpreted[@"totalViewers"] isKindOfClass:NSNumber.class] && [interpreted[@"totalViewers"] longLongValue] > 0) {
            result[@"totalViewers"] = interpreted[@"totalViewers"];
        }
        finish(result, nil);
        return YES;
    }
    if ([interpreted[@"roomDataPresent"] boolValue]) {
        // room_data 在场且 status 不是在播：确认未开播。
        finish(@{@"live": @NO, @"source": @"profile", @"checkedAt": @(NSDate.date.timeIntervalSince1970)}, nil);
        return YES;
    }
    if (allowOffline && [interpreted[@"resolved"] boolValue]) {
        finish(@{@"live": @NO, @"source": @"fans", @"checkedAt": @(NSDate.date.timeIntervalSince1970)}, nil);
        return YES;
    }
    return NO;
}

+ (void)checkAnchor:(NSDictionary *)anchor owner:(NSString *)owner completion:(void (^)(NSDictionary *, NSError *))completion {
    if (!DYYYRadarIdentifier(anchor[@"uid"])) { completion(nil, DYYYRadarError(400, @"账号标识无效，请重新添加。")); return; }
    NSMutableArray<NSString *> *steps = [NSMutableArray array];
    __block BOOL done = NO;
    void (^finishOnce)(NSDictionary *, NSError *) = ^(NSDictionary *result, NSError *error) {
        if (done) return; done = YES;
        completion(result, error);
    };
    [self checkAnchorNative:anchor owner:owner steps:steps finish:finishOnce];
}

// 第 1 路：原生资料。参数与星牌 service 完全一致（user_id + sec_user_id，
// 不带 source）——-73 前多带的 source=other_profile 是 -11001 的头号嫌疑。
// 响应非字典也当本步失败处理，继续往下走，不直接记最终失败。
+ (void)checkAnchorNative:(NSDictionary *)anchor owner:(NSString *)owner steps:(NSMutableArray<NSString *> *)steps finish:(void (^)(NSDictionary *, NSError *))finish {
    NSMutableDictionary *params = [@{@"user_id": anchor[@"uid"]} mutableCopy];
    NSString *sec = DYYYRadarString(anchor[@"secUID"]);
    if (sec.length) params[@"sec_user_id"] = sec;
    [DYYYRadarNetwork.shared get:DYYYLiveBoardProfileOtherURL() parameters:params owner:owner completion:^(id value, NSError *error) {
        if (!error && [value isKindOfClass:NSDictionary.class]) {
            NSDictionary *interpreted = [self interpretProfileResponse:value anchor:anchor];
            if ([self applyProfileInterpretation:interpreted finish:finish allowOffline:NO]) return;
            [steps addObject:@"原生资料无房间信息"];
        } else if (error) {
            [steps addObject:[self shortStepError:error label:@"原生资料"]];
        } else {
            [steps addObject:@"原生资料非字典"];
        }
        [self checkAnchorWeb:anchor owner:owner steps:steps finish:finish];
    }];
}

// 第 2 路：网页资料。直接用 DYYYFansWebClient（星牌 web 路同款：
// NSURLSession + a_bogus，不走宿主 AWENetworkService，与 -11001 无关），
// 不走 DYYYFansService 单例（不调 prepare:，星牌开关关着也不影响）。
// 网页路不走 DYYYRadarNetwork，没有它那 15 秒看门狗，这里自己加一个，
// 超时按本步失败继续走 reflow，避免轮询卡住。
+ (void)checkAnchorWeb:(NSDictionary *)anchor owner:(NSString *)owner steps:(NSMutableArray<NSString *> *)steps finish:(void (^)(NSDictionary *, NSError *))finish {
    DYYYFansWebClient *web = [DYYYFansWebClient new];
    NSMutableDictionary *params = [@{@"user_id": anchor[@"uid"], @"publish_video_strategy_type": @"2"} mutableCopy];
    NSString *sec = DYYYRadarString(anchor[@"secUID"]);
    if (sec.length) params[@"sec_user_id"] = sec;
    __block BOOL webDone = NO;
    NSTimer *watchdog = [NSTimer timerWithTimeInterval:15 repeats:NO block:^(__unused NSTimer *timer) {
        if (webDone) return; webDone = YES;
        [web cancel];
        [steps addObject:@"网页资料超时"];
        [self checkAnchorReflow:anchor owner:owner steps:steps finish:finish];
    }];
    [NSRunLoop.mainRunLoop addTimer:watchdog forMode:NSRunLoopCommonModes];
    [web get:@"profile" params:params completion:^(id value, NSError *error) {
        if (webDone) return; webDone = YES;
        [watchdog invalidate];
        if (!error && [value isKindOfClass:NSDictionary.class]) {
            NSDictionary *interpreted = [self interpretProfileResponse:value anchor:anchor];
            if ([self applyProfileInterpretation:interpreted finish:finish allowOffline:YES]) return;
            [steps addObject:@"网页资料无房间信息"];
        } else if (error) {
            [steps addObject:[self shortStepError:error label:@"网页资料"]];
        } else {
            [steps addObject:@"网页资料非字典"];
        }
        [self checkAnchorReflow:anchor owner:owner steps:steps finish:finish];
    }];
}

// 第 3 路：reflow 兜底（-71 原有）。只有 secUID 时才能走；
// 三路都走完才记 error，步骤短记拼进错误描述供榜单页副标题和页脚显示。
+ (void)checkAnchorReflow:(NSDictionary *)anchor owner:(NSString *)owner steps:(NSMutableArray<NSString *> *)steps finish:(void (^)(NSDictionary *, NSError *))finish {
    void (^failAll)(void) = ^{
        finish(nil, DYYYRadarError(502, [steps componentsJoinedByString:@"；"]));
    };
    if (!DYYYRadarString(anchor[@"secUID"]).length) {
        [steps addObject:@"无 secUID 可走 reflow"];
        failAll();
        return;
    }
    [DYYYRadarNetwork.shared get:@"https://webcast.amemv.com/douyin/webcast/reflow/room_id"
        parameters:@{@"sec_user_id": anchor[@"secUID"]} owner:owner completion:^(id reflowValue, NSError *reflowError) {
        if (reflowError) {
            [steps addObject:[self shortStepError:reflowError label:@"reflow"]];
            failAll();
            return;
        }
        if (![reflowValue isKindOfClass:NSDictionary.class]) {
            [steps addObject:@"reflow 非字典"];
            failAll();
            return;
        }
        id reflowPayload = [reflowValue isKindOfClass:NSDictionary.class] && [reflowValue[@"data"] isKindOfClass:NSDictionary.class] ? reflowValue[@"data"] : reflowValue;
        NSString *roomID = nil;
        for (NSString *key in @[@"room_id", @"roomId", @"id", @"id_str", @"web_rid", @"webRid"]) {
            id raw = [reflowPayload isKindOfClass:NSDictionary.class] ? reflowPayload[key] : nil;
            NSString *value = [raw isKindOfClass:NSNumber.class] ? [raw stringValue] : DYYYRadarString(raw);
            if (DYYYRadarIdentifier(value) && ![value isEqualToString:@"0"]) { roomID = value; break; }
        }
        if (!roomID.length) {
            // reflow 明确没有房间号 = 未开播（与“查不到”区分开）。
            finish(@{@"live": @NO, @"source": @"reflow", @"checkedAt": @(NSDate.date.timeIntervalSince1970)}, nil);
            return;
        }
        [self fetchRoom:roomID source:@"reflow" completion:finish];
    }];
}

+ (void)fetchRoom:(NSString *)roomID source:(NSString *)source completion:(void (^)(NSDictionary *, NSError *))completion {
    NSNumber *roomNumber = [roomID isKindOfClass:NSString.class] ? @([roomID longLongValue]) : nil;
    if (!roomNumber || roomNumber.longLongValue <= 0) {
        completion(@{@"live": @YES, @"roomID": roomID, @"source": source, @"checkedAt": @(NSDate.date.timeIntervalSince1970)}, nil);
        return;
    }
    __block BOOL done = NO;
    NSTimer *watchdog = [NSTimer timerWithTimeInterval:15 repeats:NO block:^(__unused NSTimer *timer) {
        if (done) return; done = YES;
        completion(@{@"live": @YES, @"roomID": roomID, @"source": source, @"checkedAt": @(NSDate.date.timeIntervalSince1970)}, nil);
    }];
    [NSRunLoop.mainRunLoop addTimer:watchdog forMode:NSRunLoopCommonModes];
    DYYYLiveBoardFetchRoomInfo(roomNumber, ^(id first, id second) {
        // HTSLiveRoomAPI 的回调不保证在主线程，状态更新必须回主线程。
        dispatch_async(dispatch_get_main_queue(), ^{
        if (done) return; done = YES;
        [watchdog invalidate];
        NSNumber *count = DYYYLiveBoardViewerCount(first, roomID) ?: DYYYLiveBoardViewerCount(second, roomID);
        if (!count) count = DYYYLiveBoardViewerCountRelaxed(first) ?: DYYYLiveBoardViewerCountRelaxed(second);
        double start = DYYYLiveBoardRoomStart(first, roomID);
        if (!start) start = DYYYLiveBoardRoomStart(second, roomID);
        if (!start) start = DYYYLiveBoardRoomStartRelaxed(first) ?: DYYYLiveBoardRoomStartRelaxed(second);
        // 2.2-9-81：场观（累计进场人数），与在线人数同款严格匹配→放宽取法；
        // 读不到（字段不存在或为 0）时不加键，行上不显示场观，不显示“场观 0”。
        NSNumber *total = DYYYLiveBoardTotalViewers(first, roomID) ?: DYYYLiveBoardTotalViewers(second, roomID);
        if (!total) total = DYYYLiveBoardTotalViewersRelaxed(first) ?: DYYYLiveBoardTotalViewersRelaxed(second);
        NSMutableDictionary *result = [@{@"live": @YES, @"roomID": roomID, @"source": source,
            @"checkedAt": @(NSDate.date.timeIntervalSince1970)} mutableCopy];
        if (count) result[@"viewers"] = count;
        if (start > 0) result[@"start"] = @(start);
        if (total.longLongValue > 0) result[@"totalViewers"] = total;
        completion(result, nil);
        });
    });
}

@end
