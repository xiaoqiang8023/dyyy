#import "DYYYFansRuntime.h"

typedef NS_ENUM(NSInteger, DYYYFansInputMode) { DYYYFansInputAutomatic, DYYYFansInputHandle, DYYYFansInputUID };
NSDictionary *DYYYFansParseInput(NSString *input, DYYYFansInputMode mode, NSError **error);
BOOL DYYYFansShareURL(NSURL *url);
NSString *DYYYFansImageURL(id object);
NSDictionary *DYYYFansPerson(id object);
BOOL DYYYFansSamePerson(NSDictionary *expected, NSDictionary *actual);
NSString *DYYYFansPersonName(NSDictionary *person);
BOOL DYYYFansHandleMatches(id object, NSString *handle);
NSArray<NSDictionary *> *DYYYFansSearchPeople(id response);

@interface DYYYFansResult : NSObject
@property(nonatomic, copy) NSDictionary *person;
@property(nonatomic, copy) NSDictionary *anchor;
@property(nonatomic, strong) NSNumber *level;
@property(nonatomic, strong) NSNumber *minimum;
@property(nonatomic, strong) NSNumber *maximum;
@property(nonatomic, copy) NSArray<NSDictionary *> *clubs;
@property(nonatomic, strong) NSDate *date;
@property(nonatomic, copy) NSString *notice;
@property(nonatomic, copy) NSString *source;
@property(nonatomic, copy) NSString *diagnostic;
+ (instancetype)fromUser:(id)user target:(NSDictionary *)target error:(NSError **)error;
+ (instancetype)fromUser:(id)user target:(NSDictionary *)target anchor:(NSDictionary *)anchor error:(NSError **)error;
+ (instancetype)fromProfileResponse:(id)response target:(NSDictionary *)target anchor:(NSDictionary *)anchor error:(NSError **)error;
// 2.2-9-65：钻石换算人民币（10 钻石=1 元）。单值返回不带 ¥ 的数字串（“1.6”“1500”“7.6万”），
// 区间返回带 ¥ 的范围串（“¥1.6–2.9”“¥7.6万–9.3万”，maximum 为空时“¥1500 以上”）；minimum 为空返回 nil。
+ (NSString *)rmbStringForDiamonds:(NSNumber *)diamonds;
+ (NSString *)rmbRangeFromMinimum:(NSNumber *)minimum maximum:(NSNumber *)maximum;
- (NSString *)shareText;
@end
