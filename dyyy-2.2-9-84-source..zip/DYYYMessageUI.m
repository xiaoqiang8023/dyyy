// DYYYMessageUI.m
// 由 DY778MessageUI.m 移植并大幅简化（DY778 → DYYY 前缀重命名）：
//  只保留撤回标记（DY778RecallBadge / cell 装饰 / 气泡底色），不要时间水印与编辑标记。
//
// 定位方式（硬约束）：标记的 frame 只在 cell 展示路径
// （tableView:willDisplayCell:forRowAtIndexPath: 与防抖后的可见 cell 刷新）里算一次并赋值；
// 本文件不 Hook 任何 layoutSubviews，不在 layout 回调里改 frame，不制造布局循环。
// 刷新只订阅本模块自有通知（DYYYRecallPreferencesChangedNotification / DYYYRecallChangedNotification）
// 与系统生命周期通知；绝不订阅 NSUserDefaultsDidChangeNotification。
#import "DYYYMessageUI.h"
#import "DYYYRecall.h"
#import "DYYYRecallPolicy.h"
#import <objc/runtime.h>
#import <objc/message.h>

NSString *DYYYFormatMessageTime(NSTimeInterval timestamp) {
    NSDateFormatter *formatter = [NSDateFormatter new];
    formatter.dateFormat = @"HH:mm:ss";
    return [formatter stringFromDate:[NSDate dateWithTimeIntervalSince1970:timestamp]];
}

#pragma mark - 安全 KVC

static id DYYYUIRead(id object, NSString *key) {
    if (!object || object == NSNull.null || !key.length) return nil;
    if ([object isKindOfClass:NSDictionary.class]) {
        id value = object[key];
        return value == NSNull.null ? nil : value;
    }
    SEL selector = NSSelectorFromString(key);
    if (![object respondsToSelector:selector]) return nil;
    @try {
        id result = [object valueForKey:key];
        return result == NSNull.null ? nil : result;
    } @catch (__unused NSException *exception) {
        return nil;
    }
}

static BOOL DYYYUISignature(Class cls, SEL selector, const char *resultType, NSUInteger arguments) {
    Method method = class_getInstanceMethod(cls, selector);
    if (!method || method_getNumberOfArguments(method) != arguments + 2) return NO;
    char result[16] = {0};
    method_getReturnType(method, result, sizeof(result));
    return result[0] == resultType[0];
}

static BOOL DYYYUIHook(Class cls, SEL selector, IMP replacement, IMP *original) {
    if (!cls || !selector || !replacement || !original) return NO;
    Method method = class_getInstanceMethod(cls, selector);
    if (!method) return NO;
    IMP previous = method_getImplementation(method);
    if (previous == replacement) return YES;
    *original = previous;
    if (!class_addMethod(cls, selector, replacement, method_getTypeEncoding(method)))
        method_setImplementation(class_getInstanceMethod(cls, selector), replacement);
    return YES;
}

static UIColor *DYYYUIHexColor(NSString *hex, UIColor *fallback) {
    NSString *text = [[hex ?: @"" stringByTrimmingCharactersInSet:NSCharacterSet.whitespaceAndNewlineCharacterSet] stringByReplacingOccurrencesOfString:@"#" withString:@""];
    if (text.length != 6) return fallback;
    unsigned int value = 0;
    NSScanner *scanner = [NSScanner scannerWithString:text];
    if (![scanner scanHexInt:&value]) return fallback;
    return [UIColor colorWithRed:((value >> 16) & 0xFF) / 255.0 green:((value >> 8) & 0xFF) / 255.0 blue:(value & 0xFF) / 255.0 alpha:1];
}

#pragma mark - 撤回标记按钮

@interface DYYYRecallBadge : UIButton
@property(nonatomic, weak) UIViewController *source;
@property(nonatomic, copy) NSString *conversationID;
@end

@implementation DYYYRecallBadge

- (instancetype)initWithFrame:(CGRect)frame {
    if ((self = [super initWithFrame:frame])) {
        self.titleLabel.font = [UIFont systemFontOfSize:11 weight:UIFontWeightMedium];
        self.titleLabel.numberOfLines = 1;
        self.titleLabel.lineBreakMode = NSLineBreakByTruncatingTail;
        self.layer.cornerRadius = 9;
        self.layer.borderWidth = .5;
        self.layer.masksToBounds = YES;
        self.contentEdgeInsets = UIEdgeInsetsMake(2, 6, 2, 6);
        self.accessibilityIdentifier = @"DYYY.RecallBadge";
        [self addTarget:self action:@selector(open) forControlEvents:UIControlEventTouchUpInside];
    }
    return self;
}

- (void)open {
    if (!self.conversationID.length) return;
    DYYYPresentRecallArchive(self.source, self.conversationID);
}

@end

static void DYYYConfigureRecallBadge(DYYYRecallBadge *badge, BOOL available) {
    badge.titleLabel.font = [UIFont systemFontOfSize:11 weight:UIFontWeightMedium];
    [badge setTitle:DYYYRecallMarkerText() forState:UIControlStateNormal];
    UIColor *color = UIColor.systemTealColor;
    [badge setTitleColor:color forState:UIControlStateNormal];
    badge.tintColor = color;
    badge.backgroundColor = [UIColor colorWithDynamicProvider:^UIColor *(UITraitCollection *traits) {
        return traits.userInterfaceStyle == UIUserInterfaceStyleDark ? [UIColor.systemTealColor colorWithAlphaComponent:.16] : [UIColor.systemTealColor colorWithAlphaComponent:.10];
    }];
    badge.layer.borderColor = [[color colorWithAlphaComponent:.27] resolvedColorWithTraitCollection:badge.traitCollection].CGColor;
    badge.accessibilityLabel = available ? @"对方已撤回，原始内容已保留" : @"对方已撤回，原文未取得";
}

#pragma mark - Cell 状态与气泡查找

static char kDYYYCellStateKey;

@interface DYYYCellDecorationState : NSObject
@property(nonatomic, strong) DYYYRecallBadge *recallBadge;
@property(nonatomic, weak) UIViewController *controller;
@property(nonatomic, weak) id message;
@property(nonatomic, copy) NSString *conversationID;
@property(nonatomic) BOOL recalled;
@property(nonatomic) BOOL available;
@property(nonatomic) BOOL outgoing;
@property(nonatomic, weak) UIView *bubbleView;
@property(nonatomic, strong) UIColor *bubbleOriginalColor;
@property(nonatomic, copy) NSString *styleKey;
@end

@implementation DYYYCellDecorationState
@end

static DYYYCellDecorationState *DYYYCellState(UITableViewCell *cell, BOOL create) {
    if (!cell) return nil;
    DYYYCellDecorationState *state = objc_getAssociatedObject(cell, &kDYYYCellStateKey);
    if (!state && create) {
        state = [DYYYCellDecorationState new];
        objc_setAssociatedObject(cell, &kDYYYCellStateKey, state, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
    }
    return state;
}

static void DYYYHideCellDecorations(DYYYCellDecorationState *state) {
    if (!state) return;
    if (state.recallBadge && !state.recallBadge.hidden) state.recallBadge.hidden = YES;
    if (state.bubbleView && state.bubbleOriginalColor) {
        state.bubbleView.backgroundColor = state.bubbleOriginalColor;
        state.bubbleOriginalColor = nil;
    }
}

static id DYYYMessageForCell(UITableViewCell *cell) {
    id viewModel = DYYYUIRead(cell, @"messageViewModel") ?: DYYYUIRead(cell, @"viewModel");
    id message = DYYYUIRead(viewModel, @"iesMessage") ?: DYYYUIRead(viewModel, @"message");
    if (!message) message = DYYYUIRead(cell, @"message") ?: DYYYUIRead(cell, @"iesMessage");
    return message;
}

static id DYYYViewModelForCell(UITableViewCell *cell) {
    return DYYYUIRead(cell, @"messageViewModel") ?: DYYYUIRead(cell, @"viewModel");
}

// 在 cell.contentView 里找气泡：优先类名含 Bubble 的视图；否则取面积最大、
// 不是头像、不是整行的圆角视图。只读 frame，不改任何布局。
static UIView *DYYYFindBubbleView(UITableViewCell *cell) {
    UIView *contentView = cell.contentView;
    if (!contentView) return nil;
    CGFloat maxWidth = contentView.bounds.size.width * 0.8;
    UIView *best = nil;
    CGFloat bestArea = 0;
    UIView *bubbleNamed = nil;
    NSMutableArray *stack = [NSMutableArray arrayWithObject:contentView];
    NSUInteger depth = 0;
    while (stack.count && depth < 200) {
        UIView *view = stack.firstObject;
        [stack removeObjectAtIndex:0];
        depth++;
        NSString *className = NSStringFromClass([view class]);
        if ([className containsString:@"Avatar"] || [className containsString:@"avatar"]) continue;
        if (view != contentView && view.bounds.size.width > 0 && view.bounds.size.height > 0) {
            CGRect frame = [view convertRect:view.bounds toView:contentView];
            CGFloat area = frame.size.width * frame.size.height;
            if ([className containsString:@"Bubble"] && !bubbleNamed) bubbleNamed = view;
            if (frame.size.width <= maxWidth && frame.size.height < 220 && view.layer.cornerRadius > 0 && area > bestArea) {
                bestArea = area;
                best = view;
            }
        }
        [stack addObjectsFromArray:view.subviews];
    }
    return bubbleNamed ?: best;
}

#pragma mark - 标记摆放（只在展示/刷新路径调用，绝不在 layoutSubviews 里）

static void DYYYUpdateCellDecoration(UITableViewCell *cell) {
    if (!NSThread.isMainThread) return;
    DYYYCellDecorationState *state = DYYYCellState(cell, YES);
    id message = DYYYMessageForCell(cell);
    state.message = message;
    id viewModel = DYYYViewModelForCell(cell);
    NSString *conversationID = DYYYUIRead(DYYYUIRead(viewModel, @"conversation"), @"conversationID");
    if (!conversationID.length) conversationID = DYYYUIRead(message, @"belongingConversationIdentifier") ?: DYYYUIRead(message, @"conversationID");
    state.conversationID = conversationID;
    BOOL masterOn = DYYYRecallBool(DYYYRecallEnabledKey);
    BOOL badgeOn = DYYYRecallBool(DYYYRecallShowBadgeKey);
    BOOL recalled = masterOn && message && DYYYMessageWasRecalled(message);
    state.recalled = recalled;
    NSDictionary *record = recalled ? DYYYRecallRecordForMessage(message) : nil;
    state.available = recalled && [record[@"available"] boolValue];
    NSString *sender = DYYYUIRead(message, @"sender");
    NSString *account = @"";
    {
        Class cls = NSClassFromString(@"AWEUserService");
        SEL selector = NSSelectorFromString(@"sharedService");
        Method method = class_getClassMethod(cls, selector);
        if (method) {
            @try {
                id service = ((id (*)(id, SEL))objc_msgSend)(cls, selector);
                account = [DYYYUIRead(service, @"userID") isKindOfClass:NSString.class] ? DYYYUIRead(service, @"userID") : @"";
            } @catch (__unused NSException *exception) {
            }
        }
    }
    state.outgoing = [sender isKindOfClass:NSString.class] && account.length && [sender isEqualToString:account];
    BOOL tintOn = recalled && DYYYRecallBool(DYYYRecallTintBubbleKey);
    BOOL plainOn = recalled && DYYYRecallBool(DYYYRecallPlainBubbleOnSkinKey);
    BOOL showBadge = recalled && badgeOn;
    if (!showBadge && !tintOn && !plainOn) {
        DYYYHideCellDecorations(state);
        return;
    }
    UIView *bubble = DYYYFindBubbleView(cell);
    CGRect contentBounds = cell.contentView.bounds;
    CGRect bubbleRect = bubble ? [bubble convertRect:bubble.bounds toView:cell.contentView] : CGRectMake(0, 0, 0, 0);
    if (CGRectIsEmpty(bubbleRect) || bubbleRect.size.width <= 0) {
        // 找不到气泡时不硬摆：隐藏标记，避免遮挡或错位。
        DYYYHideCellDecorations(state);
        if (tintOn || plainOn) { /* 无气泡可染，不做任何事 */ }
        return;
    }
    state.bubbleView = bubble;
    if (tintOn || plainOn) {
        if (!state.bubbleOriginalColor) state.bubbleOriginalColor = bubble.backgroundColor;
        if (tintOn) bubble.backgroundColor = DYYYUIHexColor(DYYYRecallString(DYYYRecallBubbleColorKey), [UIColor.systemTealColor colorWithAlphaComponent:.12]);
        else if (plainOn) bubble.backgroundColor = cell.traitCollection.userInterfaceStyle == UIUserInterfaceStyleDark ? [UIColor colorWithRed:.22 green:.22 blue:.23 alpha:1] : [UIColor colorWithRed:.93 green:.93 blue:.94 alpha:1];
    } else if (state.bubbleOriginalColor) {
        bubble.backgroundColor = state.bubbleOriginalColor;
        state.bubbleOriginalColor = nil;
    }
    if (!showBadge) {
        if (state.recallBadge) state.recallBadge.hidden = YES;
        return;
    }
    if (!state.recallBadge) {
        state.recallBadge = [DYYYRecallBadge new];
        [cell.contentView addSubview:state.recallBadge];
    }
    if (state.recallBadge.superview != cell.contentView) [cell.contentView addSubview:state.recallBadge];
    NSString *styleKey = [NSString stringWithFormat:@"%@|%ld|%d", DYYYRecallMarkerText(), (long)cell.traitCollection.userInterfaceStyle, state.available];
    if (![state.styleKey isEqual:styleKey]) {
        state.styleKey = styleKey;
        DYYYConfigureRecallBadge(state.recallBadge, state.available);
    }
    state.recallBadge.source = state.controller;
    state.recallBadge.conversationID = state.conversationID;
    CGFloat badgeWidth = MIN(156, ceil([state.recallBadge.currentTitle sizeWithAttributes:@{NSFontAttributeName: state.recallBadge.titleLabel.font}].width) + 12);
    CGFloat badgeHeight = ceil(state.recallBadge.titleLabel.font.lineHeight) + 4;
    NSString *position = DYYYRecallString(DYYYRecallPositionKey) ?: @"right";
    CGRect badgeFrame = CGRectZero;
    if ([position isEqual:@"below"]) {
        CGFloat x = state.outgoing ? CGRectGetMinX(bubbleRect) : CGRectGetMaxX(bubbleRect) - badgeWidth;
        x = MAX(0, MIN(x, contentBounds.size.width - badgeWidth));
        badgeFrame = CGRectMake(x, CGRectGetMaxY(bubbleRect) + 4, badgeWidth, badgeHeight);
    } else if ([position isEqual:@"above"]) {
        CGFloat x = state.outgoing ? CGRectGetMinX(bubbleRect) : CGRectGetMaxX(bubbleRect) - badgeWidth;
        x = MAX(0, MIN(x, contentBounds.size.width - badgeWidth));
        badgeFrame = CGRectMake(x, MAX(0, CGRectGetMinY(bubbleRect) - badgeHeight - 4), badgeWidth, badgeHeight);
    } else {
        // 默认 right：紧贴消息右侧。对方消息气泡在左 → 标记在气泡右边；
        // 自己消息气泡在右 → 标记改贴气泡左边，避免出屏。
        CGFloat y = CGRectGetMinY(bubbleRect) + MAX(0, (CGRectGetHeight(bubbleRect) - badgeHeight) / 2);
        if (state.outgoing) {
            CGFloat x = CGRectGetMinX(bubbleRect) - badgeWidth - 6;
            if (x < 0) x = 0;
            badgeFrame = CGRectMake(x, y, badgeWidth, badgeHeight);
        } else {
            CGFloat x = CGRectGetMaxX(bubbleRect) + 6;
            if (x + badgeWidth > contentBounds.size.width) x = MAX(0, contentBounds.size.width - badgeWidth);
            badgeFrame = CGRectMake(x, y, badgeWidth, badgeHeight);
        }
    }
    state.recallBadge.frame = badgeFrame;
    state.recallBadge.hidden = NO;
    [cell.contentView bringSubviewToFront:state.recallBadge];
}

static void DYYYQueueCellUpdate(UITableViewCell *cell) {
    if (!cell || !NSThread.isMainThread) return;
    DYYYUpdateCellDecoration(cell);
}

#pragma mark - 协调器（防抖刷新可见 cell）

@interface DYYYMessageUICoordinator : NSObject
@property(nonatomic, strong) NSHashTable *controllers;
@property(nonatomic) BOOL scheduled;
@property(nonatomic) BOOL invalidationPending;
+ (instancetype)shared;
- (void)scheduleInvalidation:(BOOL)invalidate;
@end

@implementation DYYYMessageUICoordinator

+ (instancetype)shared {
    static DYYYMessageUICoordinator *coordinator;
    static dispatch_once_t once;
    dispatch_once(&once, ^{
        coordinator = [self new];
        coordinator.controllers = [NSHashTable weakObjectsHashTable];
        for (NSNotificationName name in @[DYYYRecallPreferencesChangedNotification, DYYYRecallChangedNotification, UIContentSizeCategoryDidChangeNotification, UIApplicationDidBecomeActiveNotification])
            [NSNotificationCenter.defaultCenter addObserver:coordinator selector:@selector(changed:) name:name object:nil];
    });
    return coordinator;
}

- (void)changed:(NSNotification *)notification {
    [self scheduleInvalidation:YES];
}

- (void)scheduleInvalidation:(BOOL)invalidate {
    if (!NSThread.isMainThread) {
        dispatch_async(dispatch_get_main_queue(), ^{
            [self scheduleInvalidation:invalidate];
        });
        return;
    }
    self.invalidationPending |= invalidate;
    if (self.scheduled) return;
    self.scheduled = YES;
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(.04 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        self.scheduled = NO;
        self.invalidationPending = NO;
        for (UIViewController *controller in self.controllers) {
            if (!controller.isViewLoaded || !controller.view.window) continue;
            UITableView *table = DYYYUIRead(controller, @"tableView");
            if (![table isKindOfClass:UITableView.class]) continue;
            for (UITableViewCell *cell in table.visibleCells) {
                DYYYCellState(cell, YES).controller = controller;
                DYYYQueueCellUpdate(cell);
            }
        }
    });
}

@end

void DYYYRefreshMessageDecorations(void) {
    [[DYYYMessageUICoordinator shared] scheduleInvalidation:YES];
}

#pragma mark - Hook

static void (*DYYYOriginalWillDisplay)(id, SEL, id, id, id);

static void DYYYWillDisplay(id controller, SEL selector, UITableView *table, UITableViewCell *cell, NSIndexPath *path) {
    DYYYOriginalWillDisplay(controller, selector, table, cell, path);
    if (![cell isKindOfClass:UITableViewCell.class]) return;
    [[DYYYMessageUICoordinator shared].controllers addObject:controller];
    DYYYCellState(cell, YES).controller = controller;
    DYYYQueueCellUpdate(cell);
}

static NSMutableSet *DYYYInstalledUIHooks;

static void DYYYInstallLifecycleHook(NSString *name) {
    NSString *key = [@"lifecycle:" stringByAppendingString:name];
    if ([DYYYInstalledUIHooks containsObject:key]) return;
    Class cls = NSClassFromString(@"AWEIMMessageListViewController");
    SEL selector = NSSelectorFromString(name);
    if (!DYYYUISignature(cls, selector, "v", 0)) return;
    __block IMP original = NULL;
    IMP replacement = imp_implementationWithBlock(^(UIViewController *controller) {
        ((void (*)(id, SEL))original)(controller, selector);
        [[DYYYMessageUICoordinator shared].controllers addObject:controller];
        [[DYYYMessageUICoordinator shared] scheduleInvalidation:NO];
    });
    if (DYYYUIHook(cls, selector, replacement, &original)) [DYYYInstalledUIHooks addObject:key];
    else imp_removeBlock(replacement);
}

static void DYYYInstallAppearanceHook(void) {
    NSString *key = @"lifecycle:viewDidAppear:";
    if ([DYYYInstalledUIHooks containsObject:key]) return;
    Class cls = NSClassFromString(@"AWEIMMessageListViewController");
    SEL selector = @selector(viewDidAppear:);
    Method method = class_getInstanceMethod(cls, selector);
    if (!method || method_getNumberOfArguments(method) != 3) return;
    char result[16] = {0}, argument[16] = {0};
    method_getReturnType(method, result, 16);
    method_getArgumentType(method, 2, argument, 16);
    if (result[0] != 'v' || (argument[0] != 'B' && argument[0] != 'c')) return;
    __block IMP original = NULL;
    IMP replacement = imp_implementationWithBlock(^(UIViewController *controller, BOOL animated) {
        ((void (*)(id, SEL, BOOL))original)(controller, selector, animated);
        [[DYYYMessageUICoordinator shared].controllers addObject:controller];
        [[DYYYMessageUICoordinator shared] scheduleInvalidation:YES];
    });
    if (DYYYUIHook(cls, selector, replacement, &original)) [DYYYInstalledUIHooks addObject:key];
    else imp_removeBlock(replacement);
}

static void DYYYInstallCellHooks(NSString *name) {
    Class cls = NSClassFromString(name);
    if (!cls || ![cls isSubclassOfClass:UITableViewCell.class]) return;
    // 只 Hook prepareForReuse（复用时隐藏标记、恢复气泡颜色）；绝不 Hook layoutSubviews。
    NSString *reuseKey = [name stringByAppendingString:@":prepareForReuse"];
    SEL reuse = @selector(prepareForReuse);
    if (![DYYYInstalledUIHooks containsObject:reuseKey] && DYYYUISignature(cls, reuse, "v", 0)) {
        __block IMP original = NULL;
        IMP replacement = imp_implementationWithBlock(^(UITableViewCell *cell) {
            DYYYCellDecorationState *state = DYYYCellState(cell, NO);
            DYYYHideCellDecorations(state);
            if (state) {
                state.controller = nil;
                state.message = nil;
                state.conversationID = nil;
                state.recalled = NO;
                state.available = NO;
                state.bubbleView = nil;
            }
            ((void (*)(id, SEL))original)(cell, reuse);
        });
        if (DYYYUIHook(cls, reuse, replacement, &original)) [DYYYInstalledUIHooks addObject:reuseKey];
        else imp_removeBlock(replacement);
    }
}

void DYYYInstallMessageUIHooks(void) {
    if (!NSThread.isMainThread) {
        dispatch_async(dispatch_get_main_queue(), ^{
            DYYYInstallMessageUIHooks();
        });
        return;
    }
    static dispatch_once_t once;
    dispatch_once(&once, ^{
        DYYYInstalledUIHooks = [NSMutableSet set];
    });
    [DYYYMessageUICoordinator shared];
    Class cls = NSClassFromString(@"AWEIMMessageListViewController");
    if (!DYYYOriginalWillDisplay) {
        SEL selector = NSSelectorFromString(@"tableView:willDisplayCell:forRowAtIndexPath:");
        if (DYYYUISignature(cls, selector, "v", 3)) DYYYUIHook(cls, selector, (IMP)DYYYWillDisplay, (IMP *)&DYYYOriginalWillDisplay);
    }
    DYYYInstallLifecycleHook(@"viewDidLoad");
    DYYYInstallLifecycleHook(@"vm_afterReloadData");
    DYYYInstallLifecycleHook(@"vm_afterUpdateData");
    DYYYInstallAppearanceHook();
    for (NSString *name in @[@"AWEIMReusableCommonCell", @"AWEIMMessageBaseTableViewCell", @"AWEIMUserMessageTableViewCell",
                             @"AWEIMCloseFriendInviteMessageTableViewCell", @"AWEIMInviteFriendTableViewCell", @"AWEIMShareH5GoodsMessageTableViewCell", @"AWEIMShareGameMessageTableViewCell",
                             @"AWEIMShareLiveMessageTableViewCell", @"AWEIMTextLinkMessageTableViewCell", @"AWEIMThirdPartLinkMessageTableViewCell", @"AWEIMVoipMessageTableViewCell"])
        DYYYInstallCellHooks(name);
}
