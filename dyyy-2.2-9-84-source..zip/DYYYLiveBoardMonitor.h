// DYYYLiveBoardMonitor.h — 直播间人气榜轮询（2.2-9-71）。
// 照抄 DYYYRadarMonitor.m 的前台纪律：定时器只在前台跑，
// DidBecomeActive/WillEnterForeground 恢复，DidEnterBackground/WillResignActive
// 暂停并取消在途请求，后台期间不补发。网络走 DYYYRadarNetwork 串行代理
// （一次一个请求、间隔 >=2 秒、单请求 15 秒看门狗），失败按
// DYYYRadarRetryInterval 退避。状态只在内存里，不落盘。
#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface DYYYLiveBoardMonitor : NSObject
+ (instancetype)shared;
- (void)start;
- (void)checkNow;
- (void)invalidateTarget:(NSString *)uid;
- (void)synchronizeAccount;
// 某主播的最近状态：@{@"live": @BOOL, @"viewers": NSNumber?, @"start": NSNumber?,
// @"totalViewers": NSNumber?（2.2-9-81 场观，读不到时无此键）,
// @"roomID": NSString?, @"source": @"fans"/@"profile"/@"reflow", @"checkedAt": @时间戳,
// @"error": NSString?}；从未查过返回 nil。
- (nullable NSDictionary *)stateForUID:(NSString *)uid;
// 最近一次任意主播查完的时间戳（0 表示本轮还没查完过）。
- (NSTimeInterval)lastCheckAt;
// 最近一次成功查到的取数来源（@"fans"/@"profile"/@"reflow"，无则 @"—"）。
- (NSString *)lastSource;
// 最近一次查完的失败短记（三路步骤拼起来的），成功时为空。
- (NSString *)lastFailure;
- (NSString *)status;
@end

NS_ASSUME_NONNULL_END
