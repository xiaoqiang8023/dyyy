// DYYYRadarApi.m — 由 DY778RadarApi.m 移植，仅重命名。
// 联系人读取在后台队列做解析；搜索/资料走 DYYYRadarNetwork 串行代理。
#import "DYYYRadarApi.h"

@protocol DYYYRadarHostListInitializer <NSObject>
- (instancetype)initWithUserID:(NSString *)uid;
@end

static id DYYYRadarLikesManager(NSString *uid) {
    id<DYYYRadarHostListInitializer> allocated = [NSClassFromString(@"AWEUserLikesDataManager") alloc];
    if (!DYYYRadarHasMethod(allocated, @"initWithUserID:", "@", "@")) return nil;
    @try { return [allocated initWithUserID:uid]; } @catch (__unused NSException *exception) { return nil; }
}
static NSString *DYYYRadarOrigin(id raw) {
    NSString *value = [raw isKindOfClass:NSURL.class] ? [raw absoluteString] : DYYYRadarString(raw);
    if (!value.length || [value hasPrefix:@"/"]) return nil;
    if (![value containsString:@"://"]) value = [@"https://" stringByAppendingString:value];
    NSURLComponents *parts = [NSURLComponents componentsWithString:value];
    if (![parts.scheme isEqualToString:@"https"] || !parts.host.length || parts.user || parts.password) return nil;
    parts.path = @""; parts.query = nil; parts.fragment = nil;
    return parts.string;
}
static NSString *DYYYRadarApiURL(NSString *path) {
    Class domain = NSClassFromString(@"NetworkProviderDomain");
    NSString *origin = DYYYRadarOrigin(DYYYRadarCall(domain, @"apiDomain", @[])) ?: DYYYRadarOrigin(DYYYRadarCall(domain, @"apiHost", @[]));
    // 宿主未暴露 API 域名时，回退到收藏接口。
    if (!origin) origin = DYYYRadarOrigin(DYYYRadarCall(DYYYRadarLikesManager(DYYYRadarCurrentAccount()), @"likeRequestURL", @[]));
    return [(origin ?: @"https://aweme.snssdk.com") stringByAppendingString:path];
}
static NSString *DYYYRadarNativeURL(id raw, NSString *fallbackPath) {
    NSString *value = [raw isKindOfClass:NSURL.class] ? [raw absoluteString] : DYYYRadarString(raw);
    NSURL *url = [NSURL URLWithString:value];
    if ([url.scheme isEqualToString:@"https"] && url.host.length) return value;
    return DYYYRadarApiURL([value hasPrefix:@"/aweme/"] ? value : fallbackPath);
}
static NSDictionary *DYYYRadarPayload(id value) {
    if (![value isKindOfClass:NSDictionary.class]) return nil;
    return [value[@"data"] isKindOfClass:NSDictionary.class] ? value[@"data"] : value;
}
static BOOL DYYYRadarHandleMatches(NSDictionary *profile, NSString *handle) {
    NSString *actual = DYYYRadarString(profile[@"handle"]);
    return actual.length && [actual caseInsensitiveCompare:handle] == NSOrderedSame;
}
// 搜索结果可能是 userInfo 模型或字典包装。
static void DYYYRadarSearchMatches(id object, NSString *handle, NSMutableDictionary *matches, NSUInteger depth, NSUInteger *budget, NSUInteger *recognized) {
    if (!object || depth > 7 || !*budget) return;
    (*budget)--;
    if ([object isKindOfClass:NSArray.class]) {
        for (id item in object) { if (!*budget) break; DYYYRadarSearchMatches(item, handle, matches, depth + 1, budget, recognized); }
        return;
    }
    NSDictionary *profile = DYYYRadarProfile(object);
    if (profile) (*recognized)++;
    if (profile && DYYYRadarHandleMatches(profile, handle)) matches[profile[@"uid"]] = profile;
    for (NSString *key in @[@"user_list", @"users", @"user_info", @"userInfo", @"user", @"data", @"items"]) {
        if (!*budget) break;
        DYYYRadarSearchMatches(DYYYRadarRead(object, key), handle, matches, depth + 1, budget, recognized);
    }
}
static id DYYYRadarContactDatabase(void) {
    Class cls = NSClassFromString(@"AWEIMUserDBManager");
    for (NSString *selector in @[@"sharedInstance", @"defaultManager", @"manager"]) {
        id manager = DYYYRadarCall(cls, selector, @[]); if (manager) return manager;
    }
    id center = DYYYRadarCall(NSClassFromString(@"HTSServiceCenter"), @"defaultCenter", @[]);
    id manager = cls ? DYYYRadarCall(center, @"getService:", @[cls]) : nil;
    if (!manager) { @try { manager = [cls new]; } @catch (__unused NSException *exception) { } }
    return manager;
}
static NSArray *DYYYRadarLocalContacts(id database) {
    // 同步的数据库读取在非主线程执行。
    id value = DYYYRadarCall(database, @"localContactList", @[]);
    NSArray *empty = [value isKindOfClass:NSArray.class] ? value : nil;
    if (empty.count) return [empty copy];
    if (DYYYRadarHasMethod(database, @"localContactListWithReadScene:", "@", "q")) {
        for (NSInteger scene = 0; scene <= 6; scene++) {
            value = DYYYRadarCall(database, @"localContactListWithReadScene:", @[@(scene)]);
            if ([value isKindOfClass:NSArray.class]) { empty = value; if (empty.count) return [empty copy]; }
        }
    }
    return empty;
}
static NSArray *DYYYRadarFollowedContacts(id database) {
    if (!DYYYRadarHasMethod(database, @"fetchFriendAndFollowedUsersWithLimits:readScene:", "@", "qq")) return nil;
    NSArray *empty;
    for (NSNumber *limit in @[@10000, @5000, @2000]) for (NSNumber *scene in @[@0, @1]) {
        id value = DYYYRadarCall(database, @"fetchFriendAndFollowedUsersWithLimits:readScene:", @[limit, scene]);
        if ([value isKindOfClass:NSArray.class]) { empty = value; if (empty.count) return [empty copy]; }
    }
    return empty;
}
static NSDictionary *DYYYRadarContactPage(NSArray *contacts, NSString *account) {
    NSMutableArray *all = [NSMutableArray array], *friends = [NSMutableArray array];
    NSMutableSet *seen = [NSMutableSet set];
    for (id user in contacts) {
        NSDictionary *profile = DYYYRadarProfile(user);
        if (!profile || [profile[@"uid"] isEqual:account] || [seen containsObject:profile[@"uid"]]) continue;
        if ([DYYYRadarCount(DYYYRadarRead(user, @"blockStatus")) boolValue]) continue;
        [seen addObject:profile[@"uid"]]; [all addObject:profile];
        // 互关要求 followStatus=2 且 followerStatus=1。
        if ([DYYYRadarCount(DYYYRadarRead(user, @"followStatus")) integerValue] == 2 &&
            [DYYYRadarCount(DYYYRadarRead(user, @"followerStatus")) integerValue] == 1) [friends addObject:profile];
    }
    return @{@"contacts": all, @"users": friends};
}
static void DYYYRadarLoadContacts(NSString *owner, DYYYRadarReply completion) {
    [DYYYRadarNetwork.shared perform:@"AWEIMUserDBManager.localContactList" owner:owner start:^dispatch_block_t(DYYYRadarReply reply, DYYYRadarIsCurrent current) {
        id database = DYYYRadarContactDatabase();
        if (!database) { reply(nil, DYYYRadarError(503, @"当前抖音版本的联系人服务不可用，请复制诊断。")); return nil; }
        NSString *account = DYYYRadarCurrentAccount();
        // 联系人回调只接受一个数组参数。
        void (^finishRead)(id) = ^(id raw) {
            NSArray *snapshot = [raw isKindOfClass:NSArray.class] ? [raw copy] : nil;
            dispatch_async(dispatch_get_global_queue(QOS_CLASS_USER_INITIATED, 0), ^{
                NSArray *contacts = snapshot.count ? snapshot : (DYYYRadarFollowedContacts(database) ?: snapshot);
                NSDictionary *page = contacts ? DYYYRadarContactPage(contacts, account) : nil;
                reply(page, page ? nil : DYYYRadarError(502, @"联系人尚未就绪，可先打开抖音消息页，再返回刷新。"));
            });
        };
        dispatch_async(dispatch_get_global_queue(QOS_CLASS_USER_INITIATED, 0), ^{
            NSArray *local = DYYYRadarLocalContacts(database);
            dispatch_async(dispatch_get_main_queue(), ^{
                if (!current()) { reply(nil, DYYYRadarError(-999, @"联系人读取已暂停。")); return; }
                if (local.count) { finishRead(local); return; }
                if (DYYYRadarHasMethod(database, @"localContactListWithReadScene:completion:", "v", "q@")) {
                    DYYYRadarCall(database, @"localContactListWithReadScene:completion:", @[@0, [^(id contacts) {
                        dispatch_async(dispatch_get_main_queue(), ^{
                            if (!current()) { reply(nil, DYYYRadarError(-999, @"联系人读取已暂停。")); return; }
                            finishRead(contacts ?: local);
                        });
                    } copy]]);
                } else finishRead(local);
            });
        });
        // 取消不得影响宿主共享的数据库服务。
        return nil;
    } completion:completion];
}

@implementation DYYYRadarApi
+ (void)profile:(NSDictionary *)target owner:(NSString *)owner completion:(DYYYRadarReply)completion {
    if (!DYYYRadarIdentifier(target[@"uid"])) { completion(nil, DYYYRadarError(400, @"账号标识无效，请重新添加。")); return; }
    NSMutableDictionary *params = [@{@"user_id": target[@"uid"], @"source": @"other_profile"} mutableCopy];
    if (DYYYRadarString(target[@"secUID"]).length) params[@"sec_user_id"] = target[@"secUID"];
    [DYYYRadarNetwork.shared get:DYYYRadarApiURL(@"/aweme/v1/user/profile/other/") parameters:params owner:owner completion:^(id value, NSError *error) {
        NSDictionary *profile = error ? nil : DYYYRadarProfile(DYYYRadarPayload(value));
        if (!error && (!profile || ![profile[@"uid"] isEqual:target[@"uid"]])) error = DYYYRadarError(502, @"资料返回不完整，本次数值已忽略。");
        if (!error && !DYYYRadarString(profile[@"secUID"]).length && DYYYRadarString(target[@"secUID"]).length) {
            NSMutableDictionary *merged = [profile mutableCopy]; merged[@"secUID"] = target[@"secUID"]; profile = merged;
        }
        completion(profile, error);
    }];
}
+ (void)resolveHandle:(NSString *)handle owner:(NSString *)owner completion:(DYYYRadarReply)completion {
    NSString *clean = [handle stringByTrimmingCharactersInSet:NSCharacterSet.whitespaceAndNewlineCharacterSet];
    if ([clean hasPrefix:@"@"]) clean = [clean substringFromIndex:1];
    if (!clean.length || clean.length > 64 || [clean rangeOfCharacterFromSet:NSCharacterSet.whitespaceAndNewlineCharacterSet].location != NSNotFound) {
        completion(nil, DYYYRadarError(400, @"请输入主页显示的完整抖音号，不是昵称。")); return;
    }
    DYYYRadarLoadContacts(owner, ^(id page, NSError *error) {
        if (error.code == NSURLErrorCancelled || error.code == 401) { completion(nil, error); return; }
        NSMutableDictionary *matches = [NSMutableDictionary dictionary];
        for (NSDictionary *profile in page[@"contacts"]) if (DYYYRadarHandleMatches(profile, clean)) matches[profile[@"uid"]] = profile;
        if (matches.count == 1) { completion(matches.allValues.firstObject, nil); return; }
        id manager;
        @try { manager = [NSClassFromString(@"AWESearchUserManager") new]; } @catch (__unused NSException *exception) { }
        [self searchHandle:clean manager:manager page:0 owner:owner completion:completion];
    });
}
+ (void)searchHandle:(NSString *)handle manager:(id)manager page:(NSUInteger)page owner:(NSString *)owner completion:(DYYYRadarReply)completion {
    NSNumber *previousCursor = DYYYRadarCount(DYYYRadarRead(manager, @"cursor")) ?: @0;
    [DYYYRadarNetwork.shared perform:@"AWESearchUserManager.fetchUsersWithKeyword" owner:owner start:^dispatch_block_t(DYYYRadarReply reply, DYYYRadarIsCurrent current) {
        NSString *selector = @"fetchUsersWithKeyword:cursor:isPullToRefresh:completion:";
        BOOL compatible = DYYYRadarHasMethod(manager, selector, "v", "@@B@") || DYYYRadarHasMethod(manager, selector, "v", "@@c@");
        if (!compatible) { reply(nil, DYYYRadarError(503, @"当前版本的抖音用户搜索入口不可用，请复制诊断。")); return nil; }
        if (!page) {
            DYYYRadarSet(manager, @"count", @20); DYYYRadarSet(manager, @"cursor", @0);
            DYYYRadarSet(manager, @"searchSource", @"normal_search"); DYYYRadarSet(manager, @"initialSearchSource", @"normal_search");
        }
        __weak id weakManager = manager;
        // 取数返回 (NSArray *, NSError *)；userArray 里是布局模型。
        void (^ready)(NSArray *, NSError *) = ^(NSArray *users, NSError *error) {
            NSArray *snapshot = [users isKindOfClass:NSArray.class] ? [users copy] : nil;
            dispatch_async(dispatch_get_main_queue(), ^{
                if (!current()) { reply(nil, DYYYRadarError(-999, @"用户搜索已暂停。")); return; }
                if (error) { reply(nil, error); return; }
                if (!snapshot) { reply(nil, DYYYRadarError(502, @"抖音搜索返回的用户资料格式不可识别，请复制诊断。")); return; }
                NSMutableDictionary *matches = [NSMutableDictionary dictionary]; NSUInteger budget = 800, recognized = 0;
                DYYYRadarSearchMatches(snapshot, handle, matches, 0, &budget, &recognized);
                if (matches.count > 1) { reply(nil, DYYYRadarError(409, @"返回多个同号结果，请核对完整抖音号。")); return; }
                NSDictionary *profile = matches.allValues.firstObject;
                id live = weakManager;
                reply(@{@"profile": profile ?: @{}, @"count": @(recognized), @"rawCount": @(snapshot.count),
                    @"more": @([DYYYRadarRead(live, @"hasMore") boolValue]), @"cursor": DYYYRadarCount(DYYYRadarRead(live, @"cursor")) ?: @0}, nil);
            });
        };
        DYYYRadarCall(manager, selector, @[handle, previousCursor, @(page == 0), ready]);
        return ^{ DYYYRadarCall(DYYYRadarRead(manager, @"task"), @"cancel", @[]); };
    } completion:^(id result, NSError *error) {
        if (error) { completion(nil, error); return; }
        NSDictionary *profile = result[@"profile"];
        if (DYYYRadarIdentifier(profile[@"uid"])) { completion(profile, nil); return; }
        if (page < 2 && [result[@"more"] boolValue] && [result[@"cursor"] longLongValue] > previousCursor.longLongValue) {
            [self searchHandle:handle manager:manager page:page + 1 owner:owner completion:completion]; return;
        }
        // 空回调无法区分「无此用户」与「搜索失败」。
        NSError *failure = DYYYRadarError([result[@"count"] unsignedIntegerValue] ? 404 : 502,
            [result[@"count"] unsignedIntegerValue] ? @"搜索结果中未匹配到完整抖音号，请从对方主页复制后重试。" :
            @"抖音用户搜索暂未返回可核对的账号，请确认抖音搜索可用后重试。也可以复制诊断反馈。" );
        NSMutableDictionary *info = [failure.userInfo mutableCopy]; info[@"DYYYRadarEndpoint"] = @"AWESearchUserManager.fetchUsersWithKeyword.result";
        completion(nil, [NSError errorWithDomain:failure.domain code:failure.code userInfo:info]);
    }];
}
+ (void)friendsForOwner:(NSString *)owner completion:(DYYYRadarReply)completion {
    DYYYRadarLoadContacts(owner, ^(id page, NSError *error) { completion(error ? nil : page[@"users"], error); });
}
+ (void)likes:(NSDictionary *)target cursor:(NSNumber *)cursor owner:(NSString *)owner completion:(DYYYRadarReply)completion {
    if (!DYYYRadarIdentifier(target[@"uid"])) { completion(nil, DYYYRadarError(400, @"账号标识无效，请重新添加。")); return; }
    id manager = DYYYRadarLikesManager(target[@"uid"]);
    DYYYRadarSet(manager, @"pageSize", @30); DYYYRadarSet(manager, @"count", @30);
    DYYYRadarSet(manager, @"maxCursor", cursor); DYYYRadarSet(manager, @"minCursor", @0);
    NSString *url = DYYYRadarNativeURL(DYYYRadarCall(manager, @"likeRequestURL", @[]), @"/aweme/v1/aweme/favorite/");
    id native = DYYYRadarCall(manager, @"paramsIsRefresh:", @[@(cursor.longLongValue == 0)]);
    NSMutableDictionary *params = [native isKindOfClass:NSDictionary.class] ? [native mutableCopy] : [NSMutableDictionary dictionary];
    params[@"user_id"] = target[@"uid"]; params[@"count"] = @30; params[@"max_cursor"] = cursor; params[@"min_cursor"] = @0;
    if (DYYYRadarString(target[@"secUID"]).length) params[@"sec_user_id"] = target[@"secUID"];
    [DYYYRadarNetwork.shared get:url parameters:params owner:owner completion:^(id value, NSError *error) {
        NSDictionary *payload = DYYYRadarPayload(value);
        id list = DYYYRadarFirst(payload, @[@"aweme_list", @"awemes"]);
        if (error || ![list isKindOfClass:NSArray.class]) { completion(nil, error ?: DYYYRadarError(502, @"喜欢列表暂不可读，保留上次记录。")); return; }
        NSMutableArray *videos = [NSMutableArray array]; NSMutableSet *ids = [NSMutableSet set];
        for (id raw in list) {
            NSDictionary *video = DYYYRadarVideo(raw);
            if (!video) { completion(nil, DYYYRadarError(502, @"喜欢作品资料不完整，保留上次基线。")); return; }
            if (![ids containsObject:video[@"id"]]) { [ids addObject:video[@"id"]]; [videos addObject:video]; }
        }
        NSNumber *next = DYYYRadarCount(payload[@"max_cursor"]), *hasMore = DYYYRadarCount(payload[@"has_more"]);
        if (!hasMore || (hasMore.boolValue && (!next || [next isEqual:cursor]))) {
            completion(nil, DYYYRadarError(502, @"喜欢列表分页暂不可用，保留上次基线。")); return;
        }
        completion(@{@"videos": videos, @"cursor": next ?: cursor, @"more": @(hasMore.boolValue)}, nil);
    }];
}
@end
