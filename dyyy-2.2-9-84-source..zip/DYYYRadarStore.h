// DYYYRadarStore.h — 特别关注：按登录账号隔离的关注对象/动态档案 JSON 存储。
// 选项（总开关/提醒/间隔/保留天数/条数上限）存在 NSUserDefaults，键见 DYYYRadarStore.m 顶部；
// 关注对象与档案存在 Application Support/DYYYRadar/account-<uid>.json（每账号一份）。
#import "DYYYRadarModel.h"

NS_ASSUME_NONNULL_BEGIN

// NSUserDefaults 键（开关未写过时一律视为 NO，即默认关闭）。
extern NSString *const DYYYRadarEnabledKey;       // BOOL，默认 NO
extern NSString *const DYYYRadarAlertsKey;        // BOOL，默认 NO
extern NSString *const DYYYRadarIntervalKey;      // NSNumber 秒，默认 300，钳制 30–300
extern NSString *const DYYYRadarRetentionDaysKey; // NSNumber 天，默认 7（0/1/7/30）
extern NSString *const DYYYRadarRecordLimitKey;   // NSNumber 条，默认 500（100/500/1000）

extern NSUInteger const DYYYRadarMaxTargets; // 20

@interface DYYYRadarStore : NSObject
@property(nonatomic, readonly, copy) NSString *accountID;
@property(nonatomic, readonly, copy) NSArray<NSDictionary *> *targets;
@property(nonatomic, readonly, copy) NSArray<NSDictionary *> *records;
@property(nonatomic, readonly, copy) NSDictionary *options;
@property(nonatomic, readonly, copy) NSString *storageError;
+ (instancetype)shared;
- (instancetype)initWithDirectory:(NSURL *)directory;
- (void)activateAccount:(NSString *)accountID;
- (void)setOption:(NSString *)key value:(id)value;
- (BOOL)addProfiles:(NSArray<NSDictionary *> *)profiles error:(NSError * _Nullable *)error;
- (nullable NSDictionary *)target:(NSString *)uid;
- (void)updateTarget:(NSString *)uid values:(NSDictionary *)values;
- (void)removeTarget:(NSString *)uid;
- (void)resetBaseline:(NSString *)uid;
- (NSArray<NSDictionary *> *)applyProfile:(NSDictionary *)profile forUID:(NSString *)uid;
- (NSArray<NSDictionary *> *)applyLikes:(NSArray<NSDictionary *> *)videos complete:(BOOL)complete forUID:(NSString *)uid;
- (void)markLikesUnavailable:(NSString *)uid;
- (void)deleteRecord:(NSString *)recordID;
- (void)clearRecords;
- (void)prune;
- (void)save;
- (void)flush;
- (NSUInteger)storageBytes;
@end

NS_ASSUME_NONNULL_END
