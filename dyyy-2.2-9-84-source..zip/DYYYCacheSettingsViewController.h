//  DYYYCacheSettingsViewController.h
//
//  缓存管理设置页（DY778 1.0-3 缓存页移植）。
//  独立 UITableViewController（insetGrouped），[[DYYYCacheSettingsViewController alloc] init]
//  即可用，无需参数。开关直接读写 DYYYCache* 设置键。

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface DYYYCacheSettingsViewController : UITableViewController

@end

NS_ASSUME_NONNULL_END
