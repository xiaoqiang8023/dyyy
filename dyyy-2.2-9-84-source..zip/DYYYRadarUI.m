// DYYYRadarUI.m — 由 DY778RadarUI.m 移植。
// 改动：DY778Core 外观/Toast/导航帮助改为 DYYY 自带实现（强调色 systemTeal，与星牌移植一致；
// Toast 走 DYYYUtils；导航用普通 UINavigationController 包裹后 modal 呈现）。
// 删掉了上游 viewDidLayoutSubviews 里改 tableHeaderView frame 的逻辑（DYYY 硬约束：
// layoutSubviews 内不改 frame、不制造布局循环）。
#import "DYYYRadarUI.h"
#import "DYYYRadarNetwork.h"
#import "DYYYUtils.h"
#import <objc/message.h>

UIWindow *DYYYRadarActiveWindow(void) {
    if (UIApplication.sharedApplication.applicationState != UIApplicationStateActive) return nil;
    UIWindow *fallback;
    for (UIScene *scene in UIApplication.sharedApplication.connectedScenes) {
        if (![scene isKindOfClass:UIWindowScene.class] || scene.activationState != UISceneActivationStateForegroundActive) continue;
        for (UIWindow *window in ((UIWindowScene *)scene).windows) {
            if (window.hidden || window.alpha < 0.01 || window.windowLevel != UIWindowLevelNormal || !window.rootViewController) continue;
            if (window.isKeyWindow) return window; fallback = window;
        }
    }
    if (!fallback) for (UIWindow *window in UIApplication.sharedApplication.windows.reverseObjectEnumerator) {
        if (!window.hidden && window.windowLevel == UIWindowLevelNormal && window.rootViewController) { if (window.isKeyWindow) return window; fallback = window; }
    }
    return fallback;
}
UIViewController *DYYYRadarTopController(UIViewController *controller) {
    if (controller.presentedViewController && !controller.presentedViewController.isBeingDismissed) return DYYYRadarTopController(controller.presentedViewController);
    if ([controller isKindOfClass:UINavigationController.class]) return DYYYRadarTopController(((UINavigationController *)controller).visibleViewController);
    if ([controller isKindOfClass:UITabBarController.class]) return DYYYRadarTopController(((UITabBarController *)controller).selectedViewController);
    return controller;
}
UIUserInterfaceStyle DYYYRadarStyle(void) {
    UIWindow *window = DYYYRadarActiveWindow();
    return window.traitCollection.userInterfaceStyle == UIUserInterfaceStyleDark ? UIUserInterfaceStyleDark : UIUserInterfaceStyleLight;
}
UIColor *DYYYRadarAccent(void) { return UIColor.systemTealColor; }
UIColor *DYYYRadarButtonColor(void) { return UIColor.systemTealColor; }
UIColor *DYYYRadarAccentForeground(void) { return UIColor.whiteColor; }
UIColor *DYYYRadarBackground(void) {
    return [UIColor colorWithDynamicProvider:^UIColor *(UITraitCollection *trait) {
        return trait.userInterfaceStyle == UIUserInterfaceStyleDark ?
            [UIColor colorWithRed:.055 green:.064 blue:.075 alpha:1] :
            [UIColor colorWithRed:.951 green:.965 blue:.966 alpha:1];
    }];
}
UIColor *DYYYRadarCardBackground(void) {
    return [UIColor colorWithDynamicProvider:^UIColor *(UITraitCollection *trait) {
        return trait.userInterfaceStyle == UIUserInterfaceStyleDark ?
            [UIColor colorWithRed:.105 green:.119 blue:.13 alpha:1] : UIColor.whiteColor;
    }];
}
UILabel *DYYYRadarLabel(NSString *text, CGFloat size, UIFontWeight weight) {
    UILabel *label = [UILabel new]; label.text = text; label.textColor = UIColor.labelColor; label.numberOfLines = 0;
    label.font = [[UIFontMetrics metricsForTextStyle:UIFontTextStyleBody] scaledFontForFont:[UIFont systemFontOfSize:size weight:weight] maximumPointSize:36];
    label.adjustsFontForContentSizeCategory = YES; return label;
}
UITableViewCell *DYYYRadarCell(NSString *title, NSString *subtitle, NSString *symbol, BOOL disclosure) {
    UITableViewCell *cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:nil];
    cell.backgroundColor = DYYYRadarCardBackground();
    UIListContentConfiguration *config = [UIListContentConfiguration subtitleCellConfiguration];
    config.text = title; config.secondaryText = subtitle;
    config.textProperties.font = [UIFont preferredFontForTextStyle:UIFontTextStyleBody]; config.textProperties.color = UIColor.labelColor;
    config.textProperties.numberOfLines = 0; config.secondaryTextProperties.numberOfLines = 0;
    config.secondaryTextProperties.font = [UIFont preferredFontForTextStyle:UIFontTextStyleFootnote];
    config.secondaryTextProperties.color = UIColor.secondaryLabelColor;
    config.textToSecondaryTextVerticalPadding = 5;
    config.directionalLayoutMargins = NSDirectionalEdgeInsetsMake(14, 20, 14, 20);
    if (symbol.length) {
        config.image = [UIImage systemImageNamed:symbol]; config.imageProperties.tintColor = DYYYRadarAccent();
        config.imageProperties.maximumSize = CGSizeMake(28, 28); config.imageProperties.reservedLayoutSize = CGSizeMake(28, 28); config.imageToTextPadding = 14;
    }
    cell.contentConfiguration = config;
    cell.accessoryType = disclosure ? UITableViewCellAccessoryDisclosureIndicator : UITableViewCellAccessoryNone;
    return cell;
}
void DYYYRadarMessage(UIViewController *presenter, NSString *title, NSString *message) {
    if (!presenter.view.window) return;
    UIViewController *presented = presenter.presentedViewController;
    if (presented) {
        if ([presented isKindOfClass:UIAlertController.class])
            [presented dismissViewControllerAnimated:YES completion:^{ DYYYRadarMessage(presenter, title, message); }];
        return;
    }
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:title message:message preferredStyle:UIAlertControllerStyleAlert];
    alert.overrideUserInterfaceStyle = DYYYRadarStyle(); alert.view.tintColor = DYYYRadarAccent();
    [alert addAction:[UIAlertAction actionWithTitle:@"知道了" style:UIAlertActionStyleDefault handler:nil]];
    [presenter presentViewController:alert animated:YES completion:nil];
}
void DYYYRadarConfirm(UIViewController *presenter, NSString *title, NSString *message, NSString *button, dispatch_block_t action) {
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:title message:message preferredStyle:UIAlertControllerStyleAlert];
    alert.overrideUserInterfaceStyle = DYYYRadarStyle(); alert.view.tintColor = DYYYRadarAccent();
    [alert addAction:[UIAlertAction actionWithTitle:@"取消" style:UIAlertActionStyleCancel handler:nil]];
    [alert addAction:[UIAlertAction actionWithTitle:button style:UIAlertActionStyleDestructive handler:^(UIAlertAction *a) { if (action) action(); }]];
    [presenter presentViewController:alert animated:YES completion:nil];
}
void DYYYRadarSheet(UIViewController *presenter, NSString *title, NSArray<NSString *> *options, void (^chosen)(NSUInteger)) {
    UIAlertController *sheet = [UIAlertController alertControllerWithTitle:title message:nil preferredStyle:UIAlertControllerStyleActionSheet];
    sheet.overrideUserInterfaceStyle = DYYYRadarStyle(); sheet.view.tintColor = DYYYRadarAccent();
    for (NSUInteger i = 0; i < options.count; i++) [sheet addAction:[UIAlertAction actionWithTitle:options[i] style:UIAlertActionStyleDefault handler:^(UIAlertAction *a) { chosen(i); }]];
    [sheet addAction:[UIAlertAction actionWithTitle:@"取消" style:UIAlertActionStyleCancel handler:nil]];
    sheet.popoverPresentationController.sourceView = presenter.view;
    sheet.popoverPresentationController.sourceRect = CGRectMake(presenter.view.bounds.size.width / 2, presenter.view.bounds.size.height / 2, 1, 1);
    sheet.popoverPresentationController.permittedArrowDirections = 0;
    [presenter presentViewController:sheet animated:YES completion:nil];
}
void DYYYRadarToast(UIViewController *presenter, NSString *message) {
    (void)presenter;
    if (NSThread.isMainThread) [DYYYUtils showToast:message];
    else dispatch_async(dispatch_get_main_queue(), ^{ [DYYYUtils showToast:message]; });
}
void DYYYRadarCopy(UIViewController *presenter, NSString *text) {
    if (!text.length) return;
    UIPasteboard.generalPasteboard.string = text; DYYYRadarToast(presenter, @"已复制到剪贴板");
}
void DYYYRadarCopySignature(UIViewController *presenter, id signature) {
    if (![signature isKindOfClass:NSString.class]) {
        DYYYRadarMessage(presenter, @"暂无可复制的简介", @"尚未成功读取个人简介，请等待下一次资料检测。"); return;
    }
    UIPasteboard.generalPasteboard.string = signature;
    DYYYRadarToast(presenter, [signature length] ? @"个人简介已复制" : @"简介为空，已清空剪贴板");
}
void DYYYRadarOpenVideo(UIViewController *presenter, NSString *videoID) {
    if (!DYYYRadarIdentifier(videoID)) return;
    NSString *route = [@"aweme://aweme/detail/" stringByAppendingString:videoID];
    NSString *web = [@"https://www.douyin.com/video/" stringByAppendingString:videoID];
    dispatch_block_t open = ^{
        Class router = NSClassFromString(@"AWERouter");
        if (DYYYRadarHasMethod(router, @"transferToURLString:", "B", "@") && [DYYYRadarCall(router, @"transferToURLString:", @[route]) boolValue]) return;
        [UIApplication.sharedApplication openURL:[NSURL URLWithString:web] options:@{} completionHandler:nil];
    };
    open();
}
void DYYYRadarPresentController(UIViewController *source, UIViewController *controller) {
    if (!NSThread.isMainThread) { dispatch_async(dispatch_get_main_queue(), ^{ DYYYRadarPresentController(source, controller); }); return; }
    UIViewController *top = source ?: [DYYYUtils topView];
    if (!top) return;
    // 已在特别关注导航栈内则直接 push，否则包一层导航后全屏 modal。
    if ([top isKindOfClass:DYYYRadarTableController.class] && top.navigationController) {
        [top.navigationController pushViewController:controller animated:YES]; return;
    }
    UINavigationController *nav = [[UINavigationController alloc] initWithRootViewController:controller];
    nav.modalPresentationStyle = UIModalPresentationFullScreen;
    controller.overrideUserInterfaceStyle = DYYYRadarStyle();
    [top presentViewController:nav animated:YES completion:nil];
}
// 在插件的导航栈内共用一份外观快照。
@interface DYYYRadarNavigationState : NSObject
@property(nonatomic) BOOL hidden;
@property(nonatomic, strong) UIColor *tint;
@end
@implementation DYYYRadarNavigationState
@end
@interface DYYYRadarTableController ()
@property(nonatomic, strong) DYYYRadarNavigationState *navigationState;
@property(nonatomic) CGPoint savedOffset;
@property(nonatomic) BOOL restoresOffset;
@property(nonatomic) BOOL hasAppeared;
@end
@implementation DYYYRadarTableController
- (instancetype)init {
    if ((self = [super initWithStyle:UITableViewStyleInsetGrouped])) self.hidesBottomBarWhenPushed = YES;
    return self;
}
- (void)applyNavigation:(BOOL)animated {
    UINavigationController *nav = self.navigationController;
    if (!nav) return;
    if (!self.navigationState) {
        for (UIViewController *page in nav.viewControllers) {
            if ([page isKindOfClass:DYYYRadarTableController.class] && ((DYYYRadarTableController *)page).navigationState) {
                self.navigationState = ((DYYYRadarTableController *)page).navigationState; break;
            }
        }
        if (!self.navigationState) {
            self.navigationState = [DYYYRadarNavigationState new];
            self.navigationState.hidden = nav.navigationBarHidden; self.navigationState.tint = nav.navigationBar.tintColor;
        }
    }
    [nav setNavigationBarHidden:NO animated:animated];
    nav.navigationBar.tintColor = [DYYYRadarAccent() resolvedColorWithTraitCollection:self.traitCollection];
}
- (void)restoreNavigation:(BOOL)animated {
    if (!self.navigationState) return;
    [self.navigationController setNavigationBarHidden:self.navigationState.hidden animated:animated];
    self.navigationController.navigationBar.tintColor = self.navigationState.tint;
}
- (void)restoreTableOffset:(CGPoint)offset {
    [self.tableView layoutIfNeeded];
    CGFloat low = -self.tableView.adjustedContentInset.top;
    CGFloat high = MAX(low, self.tableView.contentSize.height - self.tableView.bounds.size.height + self.tableView.adjustedContentInset.bottom);
    [self.tableView setContentOffset:CGPointMake(offset.x, MIN(high, MAX(low, offset.y))) animated:NO];
}
- (void)viewDidLoad {
    [super viewDidLoad]; self.view.tintColor = DYYYRadarAccent(); self.tableView.backgroundColor = DYYYRadarBackground();
    self.tableView.rowHeight = UITableViewAutomaticDimension; self.tableView.estimatedRowHeight = 70;
    self.tableView.sectionHeaderHeight = UITableViewAutomaticDimension; self.tableView.sectionFooterHeight = UITableViewAutomaticDimension;
    self.tableView.keyboardDismissMode = UIScrollViewKeyboardDismissModeOnDrag;
    self.navigationItem.largeTitleDisplayMode = UINavigationItemLargeTitleDisplayModeNever;
    self.navigationItem.backButtonTitle = @"返回";
    self.clearsSelectionOnViewWillAppear = NO;
    [NSNotificationCenter.defaultCenter addObserver:self selector:@selector(updateTheme) name:DYYYRadarThemeChanged object:nil];
    [NSNotificationCenter.defaultCenter addObserver:self selector:@selector(updateTheme) name:UIApplicationDidBecomeActiveNotification object:nil];
    [self updateTheme];
}
- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated]; [DYYYRadarMonitor.shared synchronizeAccount];
    [self updateTheme]; [self applyNavigation:animated]; [self refresh];
    if (self.restoresOffset) [self restoreTableOffset:self.savedOffset];
}
- (void)viewDidAppear:(BOOL)animated {
    [super viewDidAppear:animated]; self.hasAppeared = YES; [self applyNavigation:NO];
    if (self.restoresOffset) { [self restoreTableOffset:self.savedOffset]; self.restoresOffset = NO; }
}
- (void)viewWillDisappear:(BOOL)animated {
    self.savedOffset = self.tableView.contentOffset; self.restoresOffset = YES;
    [super viewWillDisappear:animated];
    UIViewController *to = [self.transitionCoordinator viewControllerForKey:UITransitionContextToViewControllerKey];
    BOOL leaving = (to && ![to isKindOfClass:DYYYRadarTableController.class]) ||
        (self.isMovingFromParentViewController && ![self.navigationController.topViewController isKindOfClass:DYYYRadarTableController.class]);
    if (leaving) {
        [self restoreNavigation:animated];
        __weak typeof(self) weakSelf = self;
        [self.transitionCoordinator animateAlongsideTransition:nil completion:^(id<UIViewControllerTransitionCoordinatorContext> context) {
            if (context.isCancelled) [weakSelf applyNavigation:NO];
        }];
    }
}
- (void)refresh {
    CGPoint offset = self.tableView.contentOffset;
    [self.tableView reloadData];
    if (self.hasAppeared) [self restoreTableOffset:offset];
}
- (void)updateTheme {
    UIUserInterfaceStyle style = DYYYRadarStyle();
    if (self.overrideUserInterfaceStyle != style) self.overrideUserInterfaceStyle = style;
    UINavigationBarAppearance *appearance = [UINavigationBarAppearance new]; [appearance configureWithOpaqueBackground];
    UITraitCollection *traits = [UITraitCollection traitCollectionWithUserInterfaceStyle:style];
    appearance.backgroundColor = [DYYYRadarBackground() resolvedColorWithTraitCollection:traits];
    appearance.titleTextAttributes = @{NSForegroundColorAttributeName: [UIColor.labelColor resolvedColorWithTraitCollection:traits]};
    UIColor *accent = [DYYYRadarAccent() resolvedColorWithTraitCollection:traits];
    appearance.buttonAppearance.normal.titleTextAttributes = @{NSForegroundColorAttributeName: accent};
    appearance.doneButtonAppearance.normal.titleTextAttributes = @{NSForegroundColorAttributeName: accent};
    appearance.backButtonAppearance.normal.titleTextAttributes = @{NSForegroundColorAttributeName: accent};
    self.navigationItem.standardAppearance = appearance; self.navigationItem.scrollEdgeAppearance = appearance; self.navigationItem.compactAppearance = appearance;
    if (self.view.window && self.navigationController.topViewController == self) self.navigationController.navigationBar.tintColor = accent;
    [self setNeedsStatusBarAppearanceUpdate];
}
- (void)traitCollectionDidChange:(UITraitCollection *)previous { [super traitCollectionDidChange:previous]; if (self.isViewLoaded) [self updateTheme]; }
- (UIStatusBarStyle)preferredStatusBarStyle { return DYYYRadarStyle() == UIUserInterfaceStyleDark ? UIStatusBarStyleLightContent : UIStatusBarStyleDarkContent; }
- (BOOL)checkAccount:(NSString *)account {
    [DYYYRadarMonitor.shared synchronizeAccount];
    if ([account isEqual:DYYYRadarStore.shared.accountID] && account.length) return YES;
    DYYYRadarMessage(self, @"账号已切换", @"已停止本次操作，请返回重新打开页面。"); return NO;
}
- (void)dealloc { [NSNotificationCenter.defaultCenter removeObserver:self]; }
@end
void DYYYRadarOpenSettings(void) {
    [DYYYRadarMonitor.shared synchronizeAccount];
    DYYYRadarPresentController([DYYYUtils topView], [DYYYRadarSettingsViewController new]);
}
