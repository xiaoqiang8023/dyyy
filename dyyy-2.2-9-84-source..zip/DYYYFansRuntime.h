#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

extern NSString * const DYYYFansName;
extern NSString * const DYYYFansVersion;

// .xm 按 ObjC++ 编译：C 函数声明必须包在 extern "C" 里，否则调用方
// 会按 C++ 修饰名链接、找不到 .m 里的 C 符号（-69 链接失败的根因，
// DYYYUtils.h 同款做法）。
#ifdef __cplusplus
extern "C" {
#endif

id DYYYFansRead(id object, NSString *key);
id DYYYFansFirst(id object, NSArray<NSString *> *keys);
BOOL DYYYFansSet(id object, NSString *key, id value);
BOOL DYYYFansHas(id object, NSString *selector, const char *returns, const char *arguments);
id DYYYFansCall(id object, NSString *selector, NSArray *arguments);
NSString *DYYYFansString(id value);
NSNumber *DYYYFansInteger(id value);
BOOL DYYYFansUID(NSString *text);
BOOL DYYYFansSecUID(NSString *text);
BOOL DYYYFansEnabled(NSString *key);
NSError *DYYYFansError(NSInteger code, NSString *message);
NSString *DYYYFansAccount(void);

// DYYY 最小实现（原 DY778Core 通用帮助的星牌所需子集，见 DYYYFansRuntime.m）。
NSUserDefaults *DYYYFansPreferences(void);
void DYYYFansToast(NSString *message);
void DYYYFansShowToast(NSString *channel, NSString *message, BOOL loading, BOOL success);
void DYYYFansDismissToast(NSString *channel);
UIViewController *DYYYFansTopController(void);
UIUserInterfaceStyle DYYYFansInterfaceStyle(void);
UIColor *DYYYFansAccent(void);
UIColor *DYYYFansBackground(void);
void DYYYFansStyleController(UIViewController *controller);
void DYYYFansPresentController(UIViewController *source, UIViewController *controller);

#ifdef __cplusplus
}
#endif
