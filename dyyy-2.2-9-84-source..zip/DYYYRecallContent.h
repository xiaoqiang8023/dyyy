// DYYYRecallContent.h
// 由 DY778RecallContent.h 移植（DY778 → DYYY 前缀重命名）。
// 只做纯数据解析：从消息 content 字典里抽出种类、摘要、媒体、分享作品与评论，不碰 UI、不碰网络、不碰磁盘。
#import <Foundation/Foundation.h>

FOUNDATION_EXPORT NSString *DYYYRecallMessageKind(NSString *className);

FOUNDATION_EXPORT NSDictionary *DYYYRecallEnrichRecord(NSDictionary *record);
FOUNDATION_EXPORT NSArray *DYYYRecallMediaFromContent(id content);
FOUNDATION_EXPORT NSString *DYYYRecallSummary(NSDictionary *record);
FOUNDATION_EXPORT BOOL DYYYRecallContentIsNotice(id content);
FOUNDATION_EXPORT NSDictionary *DYYYRecallCommentFromContent(id content);
FOUNDATION_EXPORT NSDictionary *DYYYMergeCapturedComment(NSDictionary *previous, NSDictionary *candidate);
// 经校验的作品标识，用于原生详情路由，绝非任意 URL。
FOUNDATION_EXPORT NSString *DYYYRecallWorkIdentifier(NSDictionary *record);

FOUNDATION_EXPORT BOOL DYYYRecallRecordShouldHide(NSDictionary *record);
FOUNDATION_EXPORT NSArray *DYYYRecallPreviewCandidates(NSDictionary *record);
FOUNDATION_EXPORT NSDictionary *DYYYRecallPrimaryMedia(NSDictionary *record);
