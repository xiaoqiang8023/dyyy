// DYYYRecallPolicy.h
// 由 DY778RecallPolicy.h 移植（DY778 → DYYY 前缀重命名，逻辑不变）。
// 纯决策函数：决定一条消息是否需要留存、是否需要提醒、以及气泡/恢复的显示状态。
// 不含任何状态，不订阅任何通知。
#ifndef DYYY_RECALL_POLICY_H
#define DYYY_RECALL_POLICY_H
#include <stdbool.h>

typedef struct {
    bool persist;
    bool notify;
} DYYYRecallDecision;

static inline DYYYRecallDecision DYYYRecallDecide(bool enabled, bool hasPrevious, bool samePayload,
                                                  bool previousRecalled, bool recalled,
                                                  bool previousAvailable, bool available) {
    DYYYRecallDecision result = {false, false};
    if (!enabled) return result;
    result.persist = !hasPrevious || !samePayload || previousRecalled != recalled;
    result.notify = (!previousRecalled && recalled) || (recalled && !previousAvailable && available);
    return result;
}

static inline bool DYYYRecallShouldNormalizeBubbleSkin(bool recalled, bool enabled, bool ordinaryText, bool hasSkin) {
    return recalled && enabled && ordinaryText && hasSkin;
}

static inline bool DYYYRecallDisplayState(bool enabled, bool original, bool recorded, bool available) {
    return enabled && recorded && available ? false : original;
}

static inline bool DYYYRecallShouldRestore(bool enabled, bool recalled, bool available, bool systemNotice,
                                           bool mutationInProgress, bool sameMessage, unsigned long revision,
                                           unsigned long renderedRevision) {
    return enabled && recalled && available && !systemNotice && !mutationInProgress && revision > 0 &&
           (!sameMessage || revision != renderedRevision);
}

static inline bool DYYYRecallShouldHydrate(bool storedAvailable, bool currentAvailable, bool storedRecalled, bool currentRecalled) {
    return storedAvailable && (!currentAvailable || storedRecalled || currentRecalled);
}

#endif
