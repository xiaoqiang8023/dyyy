// DYYYGlass.xm
// 液态玻璃移植（DYKiller -> DYYY 2.2-9，基底 -44，2026-11-04，用户点名先做长按、通知、聊天页三处）
//
// 范围说明（跟 DYKiller 全量版的区别，先说清楚）：
//   DYKiller 的三处是全量实现：材质 Regular/Clear 二选一、深色跟随、底色/圆角/恢复状态机、
//   聊天页还有布局对象 + 玻璃仓库（Store）管输入行、表情面板、加号宫格等，合计几千行。
//   这一版只做最小可见版：材质只用系统 Regular（不做 Clear 二选一），开关各自独立、默认关，
//   关了就恢复原 effect / 原底色；其他功能一字不动。具体：
//   - 长按菜单：DUXVisualEffectView 外壳，且祖先/响应链里含 LongPress 面板时才换玻璃，其他 DUX 弹层不动；
//   - 通知：AFDSnackBar（收藏提示）与 AWEPlayInteractionSnackBar（取消收藏提示）的底板挂一块玻璃，
//     原底色清掉、关了恢复；内容、按钮、展示时序不动；
//   - 聊天页：IESIMInputViewController 里已有的 UIVisualEffectView 模糊层换成玻璃，
//     以及输入行底部容器（类名含 Input、宽满屏、高 < 90）挂一块玻璃；表情/加号面板等 DYKiller 的
//     细项这一版不做，聊天输入本身不动。
//   系统没有 UIGlassEffect（iOS 26 以下）时三处一律不生效，开关开了也没用，不会闪退。
//   玻璃本体由 DYYYUtils.regularGlassEffect 运行时动态取，老 SDK 也能编译，见 DYYYUtils.h。

#import "AwemeHeaders.h"
#import "DYYYUtils.h"
#import <objc/runtime.h>

static char kDYYYGlassOriginalEffectKey;  // UIVisualEffectView 原 effect（NSNull = 原本 nil）
static char kDYYYGlassViewKey;            // 底板上挂的玻璃视图
static char kDYYYGlassOriginalColorKey;   // 底板原 backgroundColor（NSNull = 原本 nil）
static char kDYYYGlassOriginalOpaqueKey;  // 底板原 opaque

static BOOL DYYYGlassOn(NSString *key) {
    return [DYYYUtils glassEffectAvailable] && DYYYGetBool(key);
}
static void DYYYGlassClearBackground(UIView *view);
static void DYYYGlassClearPlatesIn(UIView *host);

static void DYYYGlassRestoreEffectView(UIVisualEffectView *view) {
    id saved = objc_getAssociatedObject(view, &kDYYYGlassOriginalEffectKey);
    if (!saved) return;
    objc_setAssociatedObject(view, &kDYYYGlassOriginalEffectKey, nil, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
    view.effect = [saved isKindOfClass:[NSNull class]] ? nil : (UIVisualEffect *)saved;
}

static void DYYYGlassApplyEffectView(UIVisualEffectView *view) {
    if (!view) return;
    UIVisualEffect *glass = [DYYYUtils clearGlassEffect];
    if (!glass) { DYYYGlassRestoreEffectView(view); return; }
    if (!objc_getAssociatedObject(view, &kDYYYGlassOriginalEffectKey)) {
        objc_setAssociatedObject(view, &kDYYYGlassOriginalEffectKey,
            view.effect ? view.effect : (id)[NSNull null], OBJC_ASSOCIATION_RETAIN_NONATOMIC);
    }
    if (![view.effect isKindOfClass:NSClassFromString(@"UIGlassEffect")]) {
        view.effect = glass;
    }
}

static void DYYYGlassRestorePlate(UIView *plate) {
    UIVisualEffectView *glass = objc_getAssociatedObject(plate, &kDYYYGlassViewKey);
    if (glass) [glass removeFromSuperview];
    objc_setAssociatedObject(plate, &kDYYYGlassViewKey, nil, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
    id savedColor = objc_getAssociatedObject(plate, &kDYYYGlassOriginalColorKey);
    if (savedColor) {
        plate.backgroundColor = [savedColor isKindOfClass:[NSNull class]] ? nil : (UIColor *)savedColor;
        objc_setAssociatedObject(plate, &kDYYYGlassOriginalColorKey, nil, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
    }
    NSNumber *savedOpaque = objc_getAssociatedObject(plate, &kDYYYGlassOriginalOpaqueKey);
    if (savedOpaque) {
        plate.opaque = savedOpaque.boolValue;
        objc_setAssociatedObject(plate, &kDYYYGlassOriginalOpaqueKey, nil, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
    }
}

static void DYYYGlassApplyPlate(UIView *plate) {
    if (!plate || CGRectIsEmpty(plate.bounds)) return;
    UIVisualEffect *glassEffect = [DYYYUtils clearGlassEffect];
    if (!glassEffect) { DYYYGlassRestorePlate(plate); return; }
    if (!objc_getAssociatedObject(plate, &kDYYYGlassOriginalColorKey)) {
        objc_setAssociatedObject(plate, &kDYYYGlassOriginalColorKey,
            plate.backgroundColor ? plate.backgroundColor : (id)[NSNull null], OBJC_ASSOCIATION_RETAIN_NONATOMIC);
        objc_setAssociatedObject(plate, &kDYYYGlassOriginalOpaqueKey, @(plate.opaque), OBJC_ASSOCIATION_RETAIN_NONATOMIC);
    }
    UIVisualEffectView *glass = objc_getAssociatedObject(plate, &kDYYYGlassViewKey);
    if (!glass) {
        glass = [[UIVisualEffectView alloc] initWithEffect:glassEffect];
        glass.userInteractionEnabled = NO;
        objc_setAssociatedObject(plate, &kDYYYGlassViewKey, glass, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
    } else {
        glass.effect = glassEffect;
    }
    if (glass.superview != plate) [plate insertSubview:glass atIndex:0];
    glass.frame = plate.bounds;
    glass.layer.cornerRadius = plate.layer.cornerRadius;
    glass.clipsToBounds = YES;
    plate.backgroundColor = [UIColor clearColor];
    plate.opaque = NO;
    DYYYGlassClearPlatesIn(plate);
}

static void DYYYGlassClearBackground(UIView *view) {
    if (!view) return;
    if (!objc_getAssociatedObject(view, &kDYYYGlassOriginalColorKey)) {
        objc_setAssociatedObject(view, &kDYYYGlassOriginalColorKey,
            view.backgroundColor ? view.backgroundColor : (id)[NSNull null], OBJC_ASSOCIATION_RETAIN_NONATOMIC);
        objc_setAssociatedObject(view, &kDYYYGlassOriginalOpaqueKey, @(view.opaque), OBJC_ASSOCIATION_RETAIN_NONATOMIC);
    }
    view.backgroundColor = [UIColor clearColor];
    view.opaque = NO;
}

// 底板里与底板等大、无子视图的纯色背景层：它盖在玻璃上面时玻璃就看不见，必须清掉，关时再恢复。
// 内容视图（带子视图的标签、按钮等）一律不动。
static void DYYYGlassClearPlatesIn(UIView *host) {
    if (!host) return;
    for (UIView *sub in [host.subviews copy]) {
        if (sub.subviews.count == 0 && [sub isMemberOfClass:[UIView class]] &&
            CGSizeEqualToSize(sub.bounds.size, host.bounds.size)) {
            DYYYGlassClearBackground(sub);
        }
    }
}

// 长按面板按钮卡片：截图里接口保存、复制原画等四个卡片本身是不透明浅灰底，
// 只换外壳玻璃的话卡片还是灰的，整个面板看着就不透。按 DYKiller 的做法去掉卡片常态底色，
// 只留文字图标浮在玻璃上，按下态高光不动。只清带圆角、不透明底色的普通视图，
// 标签、图片、按钮控件本身不动，关时按存的原色恢复（RestorePlate 遍历）。
static void DYYYGlassClearCardsIn(UIView *host, NSInteger depth) {
    if (!host || depth > 5) return;
    for (UIView *sub in [host.subviews copy]) {
        if (sub != host && [sub isKindOfClass:[UIView class]] &&
            ![sub isKindOfClass:[UILabel class]] && ![sub isKindOfClass:[UIImageView class]] &&
            ![sub isKindOfClass:[UIControl class]] && ![sub isKindOfClass:[UIVisualEffectView class]] &&
            sub.layer.cornerRadius > 0 && sub.backgroundColor &&
            CGColorGetAlpha(sub.backgroundColor.CGColor) > 0.1 &&
            CGRectGetWidth(sub.bounds) < CGRectGetWidth(host.bounds)) {
            DYYYGlassClearBackground(sub);
        }
        DYYYGlassClearCardsIn(sub, depth + 1);
    }
}
static void DYYYGlassRestoreCardsIn(UIView *host, NSInteger depth) {
    if (!host || depth > 5) return;
    for (UIView *sub in [host.subviews copy]) {
        DYYYGlassRestorePlate(sub);
        DYYYGlassRestoreCardsIn(sub, depth + 1);
    }
}

static BOOL DYYYGlassHasLongPressAncestor(UIView *view) {
    for (UIView *node = view; node; node = node.superview) {
        NSString *cn = NSStringFromClass([node class]);
        if ([cn containsString:@"LongPress"]) return YES;
    }
    UIResponder *resp = view.nextResponder;
    for (NSInteger i = 0; resp && i < 20; i++, resp = resp.nextResponder) {
        NSString *cn = NSStringFromClass([resp class]);
        if ([cn containsString:@"LongPress"]) return YES;
    }
    return NO;
}

static id DYYYGlassKVC(id obj, NSString *key) {
    if (!obj || !key) return nil;
    @try { return [obj valueForKey:key]; } @catch (__unused NSException *e) { return nil; }
}

#pragma mark - 长按菜单

// 2.2-9-49 修复（用户 23:58：开关已开、-48 包，三处都不出玻璃）：
// -48 的 LongPress 祖先限制是主因之一：DUX 外壳的父链 / 响应链里经常没有 LongPress 字样
// （弹层走 DUXBasicSheet / DUXContentSheet，不是长按面板控制器直属），一律被跳过，玻璃根本没挂上。
// DUXVisualEffectView 本身就是底栏弹层外壳，开关开时全挂玻璃、关时恢复，不再按 LongPress 字样过滤。
// 另一个主因是底板盖住玻璃：外壳 contentView 里等大的纯色底板不清除，玻璃换上了也被盖住看不见，
// 现在把 contentView 底色和等大纯色底板都清掉，关时按存的原色恢复。
%hook DUXVisualEffectView
- (void)layoutSubviews {
    %orig;
    if (!self.window) return;
    if (!DYYYGlassOn(@"DYYYGlassFeedMenu")) {
        DYYYGlassRestoreEffectView((UIVisualEffectView *)self);
        // 只还原之前清过的底板/卡片（RestorePlate 有存过原色才还原，没存过的不动，不会把原生底色清掉）。
        for (UIView *sub in [self.contentView.subviews copy]) {
            if (sub.subviews.count == 0 && [sub isMemberOfClass:[UIView class]]) DYYYGlassRestorePlate(sub);
        }
        DYYYGlassRestoreCardsIn(self.contentView, 0);
        return;
    }
    DYYYGlassApplyEffectView((UIVisualEffectView *)self);
    self.contentView.backgroundColor = [UIColor clearColor];
    DYYYGlassClearPlatesIn(self.contentView);
    DYYYGlassClearCardsIn(self.contentView, 0);
    // -54：DUX 帧收窄已删（-53 卡住的教训），玻璃只换材质清底色，不动任何帧
}
%end

// 原生主题刷新会把玻璃重写回模糊（DYKiller 明确拦这一处）：凡是被我们挂过玻璃的 effect 视图，
// 之后再写非玻璃 effect 时一律换回玻璃；关开关恢复时关联键已先清掉，这条锁就不再拦，恢复能正常走。
%hook UIVisualEffectView
- (void)setEffect:(UIVisualEffect *)effect {
    if (objc_getAssociatedObject(self, &kDYYYGlassOriginalEffectKey) &&
        effect && ![effect isKindOfClass:NSClassFromString(@"UIGlassEffect")]) {
        UIVisualEffect *glass = [DYYYUtils clearGlassEffect];
        if (glass) { %orig(glass); return; }
    }
    %orig;
}
%end

#pragma mark - 通知（收藏 / 取消收藏提示）

%hook AFDSnackBar
- (void)layoutSubviews {
    %orig;
    UIView *plate = (UIView *)DYYYGlassKVC(self, @"bodyView");
    if (!plate) return;
    if (!DYYYGlassOn(@"DYYYGlassNotification")) {
        DYYYGlassRestorePlate(plate);
        DYYYGlassRestorePlate(self);
        return;
    }
    // 宿主底色也要清，只清底板的话宿主不透明底色还会盖住玻璃。
    DYYYGlassClearBackground(self);
    DYYYGlassApplyPlate(plate);
}
%end

%hook AWEPlayInteractionSnackBar
- (void)layoutSubviews {
    %orig;
    if (!DYYYGlassOn(@"DYYYGlassNotification")) { DYYYGlassRestorePlate(self); return; }
    DYYYGlassApplyPlate(self);
}
%end

#pragma mark - 通知横幅（应用内通知，-51 补）
// -50 只做了收藏提示（AFDSnackBar），没做应用内通知横幅，所以用户说通知不透：
// DYKiller 的消息通知玻璃钩的是 AWEInnerNotificationContainerView / AWEInnerPushCommonView，
// 槽位是 containerView（KVC）或第一个不透明底色的直接子视图，白卡片底色清掉后挂玻璃。
static UIView *DYYYGlassNotiSlot(UIView *container) {
    UIView *candidate = (UIView *)DYYYGlassKVC(container, @"containerView");
    if (candidate && candidate.superview == container) return candidate;
    for (UIView *child in container.subviews) {
        if (child.hidden) continue;
        if (child.backgroundColor && CGColorGetAlpha(child.backgroundColor.CGColor) >= 0.99) return child;
    }
    return nil;
}
static void DYYYGlassSyncNotiView(UIView *view) {
    if (!view || CGRectIsEmpty(view.bounds)) return;
    UIView *slot = DYYYGlassNotiSlot(view);
    if (slot) {
        DYYYGlassClearBackground(view);
        DYYYGlassApplyPlate(slot);
    } else {
        DYYYGlassApplyPlate(view);
    }
}

%hook AWEInnerNotificationContainerView
- (void)layoutSubviews {
    %orig;
    if (!DYYYGlassOn(@"DYYYGlassNotification")) {
        UIView *slot = DYYYGlassNotiSlot(self);
        if (slot) DYYYGlassRestorePlate(slot);
        DYYYGlassRestorePlate(self);
        return;
    }
    DYYYGlassSyncNotiView(self);
}
%end

%hook AWEInnerPushCommonView
- (void)layoutSubviews {
    %orig;
    if (!DYYYGlassOn(@"DYYYGlassNotification")) {
        UIView *slot = DYYYGlassNotiSlot(self);
        if (slot) DYYYGlassRestorePlate(slot);
        DYYYGlassRestorePlate(self);
        return;
    }
    DYYYGlassSyncNotiView(self);
}
%end

