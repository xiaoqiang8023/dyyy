// DYYYRecallNotifications.m
// 由 DY778RecallNotifications.m 移植并简化（DY778 → DYYY 前缀重命名）。
// 提醒链路：DYYYRecallDetectedNotification（Recall 存档在后台队列确认一次真实撤回后投递）
//   → 前台（App 活跃）：在 keyWindow 顶部弹一张提醒卡片，点按打开对应会话的撤回记录；
//   → 后台（App 不活跃）：发一条本地系统通知（UNUserNotificationCenter），点按同样打开记录。
// 简化点（见报告）：不上游的 UNUserNotificationCenter delegate 劫持——
//   前台本来就有自己的提醒卡片，后台系统通知不需要 delegate 也能正常弹出与点按跳转；
//   不碰抖音自己的通知 delegate，避免与抖音/系统通知流程冲突。
#import "DYYYRecallNotifications.h"
#import "DYYYRecallContent.h"
#import <UserNotifications/UserNotifications.h>
#import <CommonCrypto/CommonDigest.h>
#import <QuartzCore/QuartzCore.h>

static NSString *const DYYYRecallRequestPrefix = @"DYYY.Recall.";

static BOOL DYYYNoticeAccountTransition;

static NSString *DYYYNoticeDigest(NSString *value) {
    NSData *data = [(value ?: @"") dataUsingEncoding:NSUTF8StringEncoding];
    unsigned char digest[CC_SHA256_DIGEST_LENGTH];
    CC_SHA256(data.bytes, (CC_LONG)data.length, digest);
    NSMutableString *text = [NSMutableString string];
    for (NSUInteger i = 0; i < sizeof(digest); i++) [text appendFormat:@"%02x", digest[i]];
    return text;
}

static NSString *DYYYNoticeString(NSDictionary *record, NSString *key) {
    return [record[key] isKindOfClass:NSString.class] ? record[key] : @"";
}

static NSString *DYYYMessageNoticeTitle(NSDictionary *record) {
    NSString *name = DYYYNoticeString(record, @"senderName");
    if (!name.length) name = DYYYNoticeString(record, @"conversationName");
    if (!name.length) name = @"对方";
    if (name.length > 40) name = [[name substringToIndex:40] stringByAppendingString:@"…"];
    return [name stringByAppendingString:@" 撤回了一条消息"];
}

static NSString *DYYYMessageNoticeBody(NSDictionary *record) {
    if (![record[@"available"] boolValue]) return @"已记录撤回事件，未取得原始内容。";
    NSString *summary = DYYYNoticeString(record, @"summary");
    if (!summary.length) summary = DYYYRecallSummary(record);
    if (!DYYYRecallBool(DYYYRecallNotificationPreviewKey) || !summary.length) return @"消息内容已留存，点按查看。";
    return summary.length > 180 ? [[summary substringToIndex:180] stringByAppendingString:@"…"] : summary;
}

static BOOL DYYYMessageNoticeAllowed(NSDictionary *record) {
    NSString *account = DYYYNoticeString(record, @"account"), *conversation = DYYYNoticeString(record, @"conversation");
    return !DYYYNoticeAccountTransition && DYYYRecallBool(DYYYRecallNotificationsKey) && account.length &&
           [account isEqual:DYYYRecallCurrentAccountID()] && conversation.length &&
           DYYYRecallEnabledForConversation(conversation);
}

static UIViewController *DYYYNoticeTopController(void) {
    UIWindow *window = nil;
    for (UIScene *scene in UIApplication.sharedApplication.connectedScenes) {
        if (![scene isKindOfClass:UIWindowScene.class]) continue;
        for (UIWindow *candidate in ((UIWindowScene *)scene).windows) {
            if (candidate.isKeyWindow) {
                window = candidate;
                break;
            }
        }
        if (window) break;
    }
    if (!window) window = UIApplication.sharedApplication.keyWindow;
    UIViewController *controller = window.rootViewController;
    while (controller.presentedViewController) controller = controller.presentedViewController;
    return controller;
}

static void DYYYOpenMessageNoticeWhenReady(NSDictionary *record, NSUInteger attempts) {
    if (attempts && (DYYYNoticeAccountTransition || UIApplication.sharedApplication.applicationState != UIApplicationStateActive || !DYYYNoticeTopController())) {
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(.5 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
            DYYYOpenMessageNoticeWhenReady(record, attempts - 1);
        });
        return;
    }
    if (DYYYNoticeAccountTransition || UIApplication.sharedApplication.applicationState != UIApplicationStateActive) return;
    if (![DYYYNoticeString(record, @"account") isEqual:DYYYRecallCurrentAccountID()]) return;
    NSString *conversation = DYYYNoticeString(record, @"conversation");
    if (!conversation.length) return;
    DYYYPresentRecallArchive(DYYYNoticeTopController(), conversation);
}

static void DYYYOpenMessageNotice(NSDictionary *record) {
    DYYYOpenMessageNoticeWhenReady(record, 10);
}

#pragma mark - 前台提醒卡片

@interface DYYYRecallBanner : UIControl
@property(nonatomic, copy) NSDictionary *record;
- (instancetype)initWithRecord:(NSDictionary *)record;
- (void)close;
@end

static DYYYRecallBanner *DYYYVisibleRecallBanner;

@implementation DYYYRecallBanner

- (instancetype)initWithRecord:(NSDictionary *)record {
    if ((self = [super initWithFrame:CGRectZero])) {
        self.record = record;
        self.translatesAutoresizingMaskIntoConstraints = NO;
        self.backgroundColor = UIColor.secondarySystemBackgroundColor;
        self.layer.cornerRadius = 21;
        self.layer.cornerCurve = kCACornerCurveContinuous;
        self.layer.shadowColor = UIColor.blackColor.CGColor;
        self.layer.shadowOpacity = .2;
        self.layer.shadowRadius = 18;
        self.layer.shadowOffset = CGSizeMake(0, 5);
        self.layer.borderWidth = .75;
        self.layer.borderColor = [UIColor.systemTealColor colorWithAlphaComponent:.6].CGColor;
        self.accessibilityIdentifier = @"DYYY.RecallBanner";
        UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(open)];
        tap.cancelsTouchesInView = NO;
        [self addGestureRecognizer:tap];
        UIImageView *portrait = [[UIImageView alloc] initWithImage:[UIImage systemImageNamed:@"arrow.uturn.backward.circle.fill"]];
        portrait.tintColor = UIColor.systemTealColor;
        portrait.contentMode = UIViewContentModeScaleAspectFill;
        portrait.backgroundColor = [UIColor.systemTealColor colorWithAlphaComponent:.1];
        portrait.layer.cornerRadius = 23;
        portrait.clipsToBounds = YES;
        [portrait.widthAnchor constraintEqualToConstant:46].active = YES;
        [portrait.heightAnchor constraintEqualToConstant:46].active = YES;
        UILabel *eyebrow = [UILabel new];
        eyebrow.text = @"DYYY · 撤回提醒";
        eyebrow.textColor = UIColor.systemTealColor;
        eyebrow.font = [UIFont preferredFontForTextStyle:UIFontTextStyleCaption2];
        UILabel *title = [UILabel new];
        title.text = DYYYMessageNoticeTitle(record);
        title.numberOfLines = 2;
        title.font = [UIFont preferredFontForTextStyle:UIFontTextStyleHeadline];
        title.textColor = UIColor.labelColor;
        UILabel *body = [UILabel new];
        body.text = DYYYMessageNoticeBody(record);
        body.numberOfLines = 2;
        body.font = [UIFont preferredFontForTextStyle:UIFontTextStyleSubheadline];
        body.textColor = UIColor.secondaryLabelColor;
        UIStackView *text = [[UIStackView alloc] initWithArrangedSubviews:@[eyebrow, title, body]];
        text.axis = UILayoutConstraintAxisVertical;
        text.spacing = 4;
        text.userInteractionEnabled = NO;
        UIButton *close = [UIButton buttonWithType:UIButtonTypeSystem];
        [close setImage:[UIImage systemImageNamed:@"xmark"] forState:UIControlStateNormal];
        close.tintColor = UIColor.tertiaryLabelColor;
        close.accessibilityLabel = @"关闭消息提醒";
        [close.widthAnchor constraintEqualToConstant:36].active = YES;
        [close.heightAnchor constraintEqualToConstant:44].active = YES;
        [close addTarget:self action:@selector(close) forControlEvents:UIControlEventTouchUpInside];
        UIStackView *row = [[UIStackView alloc] initWithArrangedSubviews:@[portrait, text, close]];
        row.axis = UILayoutConstraintAxisHorizontal;
        row.spacing = 12;
        row.alignment = UIStackViewAlignmentCenter;
        row.translatesAutoresizingMaskIntoConstraints = NO;
        [self addSubview:row];
        [NSLayoutConstraint activateConstraints:@[
            [row.topAnchor constraintEqualToAnchor:self.topAnchor constant:12],
            [row.bottomAnchor constraintEqualToAnchor:self.bottomAnchor constant:-12],
            [row.leadingAnchor constraintEqualToAnchor:self.leadingAnchor constant:14],
            [row.trailingAnchor constraintEqualToAnchor:self.trailingAnchor constant:-8],
        ]];
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(6 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
            [self close];
        });
    }
    return self;
}

- (void)open {
    NSDictionary *record = self.record;
    [self close];
    DYYYOpenMessageNotice(record);
}

- (void)close {
    if (DYYYVisibleRecallBanner == self) DYYYVisibleRecallBanner = nil;
    [self removeFromSuperview];
}

@end

static void DYYYShowRecallBanner(NSDictionary *record) {
    if (!NSThread.isMainThread) {
        dispatch_async(dispatch_get_main_queue(), ^{
            DYYYShowRecallBanner(record);
        });
        return;
    }
    UIWindow *window = nil;
    for (UIScene *scene in UIApplication.sharedApplication.connectedScenes) {
        if (![scene isKindOfClass:UIWindowScene.class]) continue;
        for (UIWindow *candidate in ((UIWindowScene *)scene).windows) {
            if (candidate.isKeyWindow) {
                window = candidate;
                break;
            }
        }
        if (window) break;
    }
    if (!window) return;
    [DYYYVisibleRecallBanner close];
    DYYYRecallBanner *banner = [[DYYYRecallBanner alloc] initWithRecord:record];
    DYYYVisibleRecallBanner = banner;
    [window addSubview:banner];
    [NSLayoutConstraint activateConstraints:@[
        [banner.topAnchor constraintEqualToAnchor:window.safeAreaLayoutGuide.topAnchor constant:8],
        [banner.leadingAnchor constraintEqualToAnchor:window.leadingAnchor constant:12],
        [banner.trailingAnchor constraintEqualToAnchor:window.trailingAnchor constant:-12],
    ]];
}

#pragma mark - 后台系统通知

static void DYYYPostRecallSystemNotification(NSDictionary *record) {
    NSString *key = DYYYNoticeString(record, @"key");
    if (!key.length) return;
    NSString *identifier = [DYYYRecallRequestPrefix stringByAppendingString:DYYYNoticeDigest(key)];
    UNMutableNotificationContent *content = [UNMutableNotificationContent new];
    content.title = DYYYMessageNoticeTitle(record);
    content.body = DYYYMessageNoticeBody(record);
    content.sound = UNNotificationSound.defaultSound;
    content.userInfo = @{@"DYYYRecallConversation": DYYYNoticeString(record, @"conversation"), @"DYYYRecallKey": key};
    UNNotificationRequest *request = [UNNotificationRequest requestWithIdentifier:identifier content:content trigger:nil];
    [UNUserNotificationCenter.currentNotificationCenter addNotificationRequest:request withCompletionHandler:nil];
}

static void DYYYHandleMessageEvent(NSDictionary *record) {
    if (![record isKindOfClass:NSDictionary.class]) return;
    if (!DYYYMessageNoticeAllowed(record)) return;
    if (UIApplication.sharedApplication.applicationState == UIApplicationStateActive) {
        DYYYShowRecallBanner(record);
    } else {
        // 后台：用后台任务兜住投递窗口，再发本地通知。
        __block UIBackgroundTaskIdentifier task = UIBackgroundTaskInvalid;
        task = [UIApplication.sharedApplication beginBackgroundTaskWithName:@"DYYY.RecallNotice" expirationHandler:^{
            if (task != UIBackgroundTaskInvalid) [UIApplication.sharedApplication endBackgroundTask:task];
            task = UIBackgroundTaskInvalid;
        }];
        DYYYPostRecallSystemNotification(record);
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(2 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
            if (task != UIBackgroundTaskInvalid) {
                [UIApplication.sharedApplication endBackgroundTask:task];
                task = UIBackgroundTaskInvalid;
            }
        });
    }
}

void DYYYRequestRecallNotificationPermission(UIViewController *source) {
    [UNUserNotificationCenter.currentNotificationCenter getNotificationSettingsWithCompletionHandler:^(UNNotificationSettings *settings) {
        if (settings.authorizationStatus == UNAuthorizationStatusAuthorized || settings.authorizationStatus == UNAuthorizationStatusProvisional) return;
        [UNUserNotificationCenter.currentNotificationCenter requestAuthorizationWithOptions:UNAuthorizationOptionAlert | UNAuthorizationOptionSound | UNAuthorizationOptionBadge
                                                                        completionHandler:^(__unused BOOL granted, NSError *error) {
                                                                            if (error) NSLog(@"[DYYY] 撤回提醒通知授权失败：%@", error);
                                                                        }];
    }];
}

void DYYYShowRecallNotificationStatus(UIViewController *source) {
    [UNUserNotificationCenter.currentNotificationCenter getNotificationSettingsWithCompletionHandler:^(UNNotificationSettings *settings) {
        NSString *status = @"未知";
        switch (settings.authorizationStatus) {
            case UNAuthorizationStatusAuthorized: status = @"已允许"; break;
            case UNAuthorizationStatusDenied: status = @"已拒绝，请到系统设置 → 抖音 → 通知中开启"; break;
            case UNAuthorizationStatusNotDetermined: status = @"未决定"; break;
            case UNAuthorizationStatusProvisional: status = @"临时允许"; break;
            case UNAuthorizationStatusEphemeral: status = @"临时授权"; break;
            default: break;
        }
        dispatch_async(dispatch_get_main_queue(), ^{
            UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"撤回提醒通知状态" message:[NSString stringWithFormat:@"系统通知：%@\n\n前台提醒卡片由 DYYY 自己显示，不依赖系统通知权限；后台系统通知需要系统通知权限。", status] preferredStyle:UIAlertControllerStyleAlert];
            [alert addAction:[UIAlertAction actionWithTitle:@"知道了" style:UIAlertActionStyleDefault handler:nil]];
            UIViewController *presenter = source ?: DYYYNoticeTopController();
            [presenter presentViewController:alert animated:YES completion:nil];
        });
    }];
}

void DYYYInstallRecallNotifications(void) {
    static dispatch_once_t once;
    dispatch_once(&once, ^{
        [NSNotificationCenter.defaultCenter addObserverForName:DYYYRecallDetectedNotification object:nil queue:NSOperationQueue.mainQueue usingBlock:^(NSNotification *notification) {
            DYYYHandleMessageEvent(notification.userInfo[@"record"]);
        }];
        // 设置变更只走本模块自有通知；收到后若提醒开关刚打开，顺手申请一次系统通知权限。
        [NSNotificationCenter.defaultCenter addObserverForName:DYYYRecallPreferencesChangedNotification object:nil queue:NSOperationQueue.mainQueue usingBlock:^(NSNotification *notification) {
            if ([notification.userInfo[@"key"] isEqual:DYYYRecallNotificationsKey] && DYYYRecallBool(DYYYRecallNotificationsKey)) {
                DYYYRequestRecallNotificationPermission(nil);
            }
        }];
        [NSNotificationCenter.defaultCenter addObserverForName:UIApplicationWillResignActiveNotification object:nil queue:NSOperationQueue.mainQueue usingBlock:^(__unused NSNotification *notification) {
            [DYYYVisibleRecallBanner close];
        }];
    });
}
